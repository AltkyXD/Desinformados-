# Desinformados Admin (solo servidor)

Mod aparte con comandos de admin. Va SOLO en la carpeta `mods` del servidor, junto al mod Desinformados y Fabric API.
Los jugadores no tienen que instalar nada.

Comandos (nivel de OP 2):
- `/rumores reiniciar` — pone a 0 el saldo del Banco de todos (también de los desconectados) y quita las monedas
  del inventario, del cofre de ender y del ratón a los que estén conectados.
- `/rumores reiniciar <jugadores>` — lo mismo solo para esos jugadores (tienen que estar conectados).
- `/rumores ver <jugador>` — cuánto tiene en el banco y cuánto lleva en monedas.

Rumores que sueltan los mobs (se guardan en `config/desinformados_admin.properties`, sobreviven a reinicios):
- `/rumores mobs` — muestra cómo está.
- `/rumores mobs cantidad <x>` — multiplica cuántos Rumores suelta cada mob (1 = normal, 2 = el doble, 0.5 = la mitad, 0 = nada).
- `/rumores mobs probabilidad <x>` — multiplica la probabilidad de que suelten (1 = normal; nunca pasa del 100 %).
- `/rumores mobs tope <n>` — tope por jugador (normal 150). Cuenta lo que suelta el mob antes de aplicar la cantidad.
- `/rumores mobs ventana <minutos>` — cada cuánto se reinicia el tope (normal 20).
- `/rumores mobs normal` — todo como venía en el mod.

No toca las monedas que haya en cofres normales o tiradas en el suelo, ni el inventario de los desconectados.

Compilar: `gradle build` (incluye `.github/workflows/build.yml` para GitHub Actions; el .jar sale en `build/libs`).

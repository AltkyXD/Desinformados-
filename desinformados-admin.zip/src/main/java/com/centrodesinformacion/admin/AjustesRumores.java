package com.centrodesinformacion.admin;

import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Ajustes de los Rumores que sueltan los mobs (se guardan en config/desinformados_admin.properties y sobreviven a los reinicios).
 * Los aplican los mixins sobre BotinMobs del mod principal.
 */
public final class AjustesRumores {
    private AjustesRumores() {}

    /** Multiplica cuántos Rumores suelta un mob (1 = normal, 0 = nada). */
    public static double cantidad = 1.0;
    /** Multiplica la probabilidad de que un mob suelte Rumores (1 = normal). */
    public static double probabilidad = 1.0;
    /** Tope de Rumores de mobs por jugador en cada ventana (normal 150). */
    public static int tope = 150;
    /** Minutos de la ventana del tope (normal 20). */
    public static int ventanaMinutos = 20;

    private static Path archivo() {
        return FabricLoader.getInstance().getConfigDir().resolve("desinformados_admin.properties");
    }

    public static void cargar() {
        Path f = archivo();
        if (!Files.exists(f)) { guardar(); return; }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
            cantidad = Double.parseDouble(p.getProperty("rumores_cantidad", "1.0"));
            probabilidad = Double.parseDouble(p.getProperty("rumores_probabilidad", "1.0"));
            tope = Integer.parseInt(p.getProperty("rumores_tope", "150"));
            ventanaMinutos = Integer.parseInt(p.getProperty("rumores_ventana_minutos", "20"));
        } catch (Exception e) {
            DesinformadosAdmin.LOG.warn("No se pudo leer {}: {}", f, e.toString());
        }
    }

    public static void guardar() {
        Properties p = new Properties();
        p.setProperty("rumores_cantidad", Double.toString(cantidad));
        p.setProperty("rumores_probabilidad", Double.toString(probabilidad));
        p.setProperty("rumores_tope", Integer.toString(tope));
        p.setProperty("rumores_ventana_minutos", Integer.toString(ventanaMinutos));
        try (Writer w = Files.newBufferedWriter(archivo())) {
            p.store(w, "Desinformados Admin: Rumores que sueltan los mobs (se cambian con /rumores mobs ...)");
        } catch (Exception e) {
            DesinformadosAdmin.LOG.warn("No se pudo guardar la configuración: {}", e.toString());
        }
    }

    public static void normal() {
        cantidad = 1.0; probabilidad = 1.0; tope = 150; ventanaMinutos = 20;
        guardar();
    }

    public static String resumen() {
        return "cantidad x" + cantidad + ", probabilidad x" + probabilidad + ", tope " + tope + " cada " + ventanaMinutos + " min";
    }
}

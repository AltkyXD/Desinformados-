package com.centrodesinformacion.admin;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.PersistentState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Mod aparte, SOLO para el servidor (los jugadores no lo necesitan). Comandos de admin para los Rumores:
 *   /rumores reiniciar              -> saldo del Banco de TODOS a 0 (también desconectados) y quita las monedas
 *                                      del inventario y del cofre de ender de los que estén conectados
 *   /rumores reiniciar <jugadores>  -> lo mismo, solo para esos jugadores (conectados)
 *   /rumores ver <jugador>          -> cuánto tiene en el banco y en monedas encima
 * Habla con el mod principal (desinformados) por reflexión, así que no hace falta compilarlo junto a él.
 */
public class DesinformadosAdmin implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("desinformados_admin");
    private static final String ESTADO = "com.centrodesinformacion.desinformados.EstadoServidor";
    private static final String[] COLORES = {"amarillo", "azul", "verde", "rojo", "gris"};

    @Override
    public void onInitialize() {
        AjustesRumores.cargar();
        LOG.info("Rumores de mobs: {}", AjustesRumores.resumen());
        CommandRegistrationCallback.EVENT.register((dispatcher, registro, entorno) -> registrar(dispatcher));
    }

    private static void registrar(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("rumores").requires(s -> s.hasPermissionLevel(2))
                .then(literal("reiniciar")
                        .executes(DesinformadosAdmin::reiniciarTodos)
                        .then(argument("jugadores", EntityArgumentType.players()).executes(DesinformadosAdmin::reiniciarAlgunos)))
                .then(literal("ver")
                        .then(argument("jugador", EntityArgumentType.player()).executes(DesinformadosAdmin::ver)))
                .then(literal("mobs")
                        .executes(c -> ok(c, "Rumores de mobs: " + AjustesRumores.resumen()))
                        .then(literal("cantidad").then(argument("multiplicador", DoubleArgumentType.doubleArg(0, 100)).executes(c -> {
                            AjustesRumores.cantidad = DoubleArgumentType.getDouble(c, "multiplicador");
                            AjustesRumores.guardar();
                            return ok(c, "Los mobs sueltan x" + AjustesRumores.cantidad + " Rumores.");
                        })))
                        .then(literal("probabilidad").then(argument("multiplicador", DoubleArgumentType.doubleArg(0, 100)).executes(c -> {
                            AjustesRumores.probabilidad = DoubleArgumentType.getDouble(c, "multiplicador");
                            AjustesRumores.guardar();
                            return ok(c, "Probabilidad de soltar Rumores x" + AjustesRumores.probabilidad + " (máximo 100 %).");
                        })))
                        .then(literal("tope").then(argument("rumores", IntegerArgumentType.integer(0, 1000000)).executes(c -> {
                            AjustesRumores.tope = IntegerArgumentType.getInteger(c, "rumores");
                            AjustesRumores.guardar();
                            return ok(c, "Tope: " + AjustesRumores.tope + " Rumores de mobs por jugador cada " + AjustesRumores.ventanaMinutos + " min.");
                        })))
                        .then(literal("ventana").then(argument("minutos", IntegerArgumentType.integer(1, 1440)).executes(c -> {
                            AjustesRumores.ventanaMinutos = IntegerArgumentType.getInteger(c, "minutos");
                            AjustesRumores.guardar();
                            return ok(c, "Tope: " + AjustesRumores.tope + " Rumores de mobs por jugador cada " + AjustesRumores.ventanaMinutos + " min.");
                        })))
                        .then(literal("normal").executes(c -> {
                            AjustesRumores.normal();
                            return ok(c, "Rumores de mobs como venían: " + AjustesRumores.resumen());
                        }))));
    }

    private static int ok(CommandContext<ServerCommandSource> c, String texto) {
        c.getSource().sendFeedback(() -> Text.literal(texto).formatted(Formatting.YELLOW), true);
        return 1;
    }

    // ------------------------------------------------------------------ comandos

    private static int reiniciarTodos(CommandContext<ServerCommandSource> c) {
        MinecraftServer server = c.getSource().getServer();
        try {
            Object estado = estado(server);
            Field f = estado.getClass().getDeclaredField("saldos");
            f.setAccessible(true);
            int cuentas = ((Map<?, ?>) f.get(estado)).size();
            ((Map<?, ?>) f.get(estado)).clear();
            ((PersistentState) estado).markDirty();
            int monedas = 0;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) monedas += quitarMonedas(p);
            int m = monedas;
            c.getSource().sendFeedback(() -> Text.literal("Rumores reiniciados: " + cuentas + " cuentas del banco a 0 y "
                    + m + " monedas quitadas a los conectados.").formatted(Formatting.YELLOW), true);
            return 1;
        } catch (Exception e) {
            return error(c, e);
        }
    }

    private static int reiniciarAlgunos(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        Collection<ServerPlayerEntity> jugadores = EntityArgumentType.getPlayers(c, "jugadores");
        try {
            Object estado = estado(c.getSource().getServer());
            Method set = estado.getClass().getMethod("setSaldo", UUID.class, int.class);
            List<String> nombres = new ArrayList<>();
            int monedas = 0;
            for (ServerPlayerEntity p : jugadores) {
                set.invoke(estado, p.getUuid(), 0);
                monedas += quitarMonedas(p);
                nombres.add(p.getGameProfile().getName());
                p.sendMessage(Text.literal("Tus Rumores se han reiniciado.").formatted(Formatting.RED), false);
            }
            int m = monedas;
            c.getSource().sendFeedback(() -> Text.literal("Rumores reiniciados para " + String.join(", ", nombres)
                    + " (" + m + " monedas quitadas).").formatted(Formatting.YELLOW), true);
            return nombres.size();
        } catch (Exception e) {
            return error(c, e);
        }
    }

    private static int ver(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "jugador");
        try {
            Object estado = estado(c.getSource().getServer());
            int saldo = (int) estado.getClass().getMethod("getSaldo", UUID.class).invoke(estado, p.getUuid());
            int encima = valorEn(p.getInventory()) + valorEn(p.getEnderChestInventory());
            c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": " + saldo + " en el banco, "
                    + encima + " en monedas (inventario + cofre de ender).").formatted(Formatting.GOLD), false);
            return 1;
        } catch (Exception e) {
            return error(c, e);
        }
    }

    // ------------------------------------------------------------------ utilidades

    private static Object estado(MinecraftServer server) throws Exception {
        Class<?> clase = Class.forName(ESTADO);
        return clase.getMethod("get", MinecraftServer.class).invoke(null, server);
    }

    private static boolean esRumor(ItemStack s) {
        if (s.isEmpty()) return false;
        Identifier id = Registries.ITEM.getId(s.getItem());
        return id.getNamespace().equals("desinformados") && id.getPath().startsWith("rumor_");
    }

    /** Quita las monedas del inventario, del cofre de ender y del ratón. Devuelve cuántas monedas quitó. */
    private static int quitarMonedas(ServerPlayerEntity p) {
        int n = vaciar(p.getInventory()) + vaciar(p.getEnderChestInventory());
        ItemStack raton = p.currentScreenHandler.getCursorStack();
        if (esRumor(raton)) {
            n += raton.getCount();
            p.currentScreenHandler.setCursorStack(ItemStack.EMPTY);
        }
        p.currentScreenHandler.sendContentUpdates();
        return n;
    }

    private static int vaciar(Inventory inv) {
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (esRumor(s)) {
                n += s.getCount();
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        inv.markDirty();
        return n;
    }

    /** Valor en Rumores de las monedas de un inventario (usa getValor() de RumorItem; si no, cuenta 1 por moneda). */
    private static int valorEn(Inventory inv) {
        int total = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (esRumor(s)) total += valor(s.getItem()) * s.getCount();
        }
        return total;
    }

    private static int valor(Item item) {
        try {
            return (int) item.getClass().getMethod("getValor").invoke(item);
        } catch (Exception e) {
            return 1;
        }
    }

    private static int error(CommandContext<ServerCommandSource> c, Exception e) {
        LOG.error("Fallo en /rumores", e);
        c.getSource().sendError(Text.literal("No se pudo: " + e + " (¿está instalado el mod Desinformados?)"));
        return 0;
    }
}

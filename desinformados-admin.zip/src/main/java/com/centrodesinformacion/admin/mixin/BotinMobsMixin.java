package com.centrodesinformacion.admin.mixin;

import com.centrodesinformacion.admin.AjustesRumores;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Cambia los valores de BotinMobs (Rumores de los mobs) del mod principal sin tocar su .jar.
 * remap = false: son métodos del mod, no de Minecraft. Los objetivos van sin descriptor para no depender de nombres de Minecraft.
 */
@Mixin(targets = "com.centrodesinformacion.desinformados.BotinMobs", remap = false)
public abstract class BotinMobsMixin {

    /** Probabilidad de soltar (la variable "prob" de alMorir, el primer float). */
    @ModifyVariable(method = "alMorir", at = @At("STORE"), ordinal = 0, remap = false)
    private static float desinfoAdmin$probabilidad(float prob) {
        return (float) Math.min(1.0, Math.max(0.0, prob * AjustesRumores.probabilidad));
    }

    /** Cantidad que se suelta (tercer argumento de soltar(mundo, mob, cantidad, lluvia)). */
    @ModifyArg(method = "alMorir", at = @At(value = "INVOKE",
            target = "Lcom/centrodesinformacion/desinformados/BotinMobs;soltar"), index = 2, remap = false)
    private static int desinfoAdmin$cantidad(int cantidad) {
        return (int) Math.round(cantidad * AjustesRumores.cantidad);
    }

    /** Tope por jugador (150). */
    @ModifyConstant(method = "quedan", constant = @Constant(intValue = 150), remap = false)
    private static int desinfoAdmin$tope(int original) {
        return AjustesRumores.tope;
    }

    /** Ventana del tope (20 minutos = 24000 ticks). */
    @ModifyConstant(method = "quedan", constant = @Constant(intValue = 24000), remap = false)
    private static int desinfoAdmin$ventana(int original) {
        return AjustesRumores.ventanaMinutos * 60 * 20;
    }
}

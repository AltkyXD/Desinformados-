package com.centrodesinformacion.desinformados;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Pastilla anti-Endcer: al tomarla puedes estar 20 minutos en el End sin que el Endcer te haga daño. */
public class PastillaItem extends Item {
    public static final int DURACION = 20 * 60 * 20;

    public PastillaItem(Settings settings) {
        super(settings);
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient()) user.addStatusEffect(new StatusEffectInstance(Endcer.ANTI_ENDCER, DURACION, 0, false, true, true));
        return super.finishUsing(stack, world, user);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("20 minutos sin Endcer en el End").formatted(Formatting.LIGHT_PURPLE));
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.*;
import java.util.function.BiConsumer;

/**
 * Tragamonedas: se paga con los Rumores del inventario (se devuelve el cambio),
 * los rodillos giran 3 segundos en la barra de acción y sale un premio según la rareza.
 */
public class Tragamonedas {
    public enum Rareza {
        AZUL("azul", 10, Formatting.BLUE), MORADA("morada", 20, Formatting.LIGHT_PURPLE), GRIS("gris", 50, Formatting.GRAY);
        public final String id; public final int coste; public final Formatting color;
        Rareza(String id, int coste, Formatting color) { this.id = id; this.coste = coste; this.color = color; }
    }

    /** Símbolo de los rodillos + qué pasa al salir. */
    record Premio(String nombre, char simbolo, Formatting color, int peso, BiConsumer<ServerPlayerEntity, BlockPos> dar) {}

    private static final Map<Rareza, List<Premio>> TABLAS = new EnumMap<>(Rareza.class);
    private static final char[] SIMBOLOS_NADA = {'♣', '⚒', '$', '♦', '❤', '★', '✉'};

    private static BiConsumer<ServerPlayerEntity, BlockPos> objeto(Item item, int n) {
        return (p, pos) -> dar(p, new ItemStack(item, n));
    }

    private static BiConsumer<ServerPlayerEntity, BlockPos> mobs(EntityType<?> tipo, int n) {
        return (p, pos) -> {
            for (int i = 0; i < n; i++) tipo.spawn(p.getServerWorld(), p.getBlockPos().add(p.getRandom().nextInt(5) - 2, 0, p.getRandom().nextInt(5) - 2), SpawnReason.EVENT);
        };
    }

    static {
        // ======================= TABLAS DE PREMIOS =======================
        // peso = probabilidad x10 (45 % -> 450, 0,5 % -> 5). Cada tabla suma 1000.
        // En todas: 1 % de desafío rojo al azar (sacado del porcentaje de "Nada").
        TABLAS.put(Rareza.AZUL, List.of(
                new Premio("Nada", ' ', Formatting.WHITE, 440, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("8 panes", '♣', Formatting.GREEN, 70, objeto(Items.BREAD, 8)),
                new Premio("6 lingotes de hierro", '⚒', Formatting.GRAY, 70, objeto(Items.IRON_INGOT, 6)),
                new Premio("15 Rumores Amarillos", '$', Formatting.YELLOW, 70, objeto(ModItems.RUMOR_AMARILLO, 15)),
                new Premio("4 Rumores Azules", '$', Formatting.AQUA, 70, objeto(ModItems.RUMOR_AZUL, 4)),
                new Premio("2 Rumores Verdes", '$', Formatting.GREEN, 70, objeto(ModItems.RUMOR_VERDE, 2)),
                new Premio("1 Corazón Rojo", '❤', Formatting.RED, 30, objeto(ModItems.CORAZON_ROJO, 1)),
                new Premio("1 Corazón de Alma", '❤', Formatting.BLUE, 10, objeto(ModItems.CORAZON_ALMA, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 5, objeto(Items.TOTEM_OF_UNDYING, 1)),
                new Premio("1 Rumor Rojo", '$', Formatting.RED, 155, objeto(ModItems.RUMOR_ROJO, 1))));
        TABLAS.put(Rareza.MORADA, List.of(
                new Premio("Nada", ' ', Formatting.WHITE, 340, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("12 lingotes de hierro", '⚒', Formatting.GRAY, 90, objeto(Items.IRON_INGOT, 12)),
                new Premio("8 lingotes de oro", '★', Formatting.GOLD, 90, objeto(Items.GOLD_INGOT, 8)),
                new Premio("2 Rumores Rojos", '$', Formatting.RED, 90, objeto(ModItems.RUMOR_ROJO, 2)),
                new Premio("5 diamantes", '♦', Formatting.AQUA, 80, objeto(Items.DIAMOND, 5)),
                new Premio("1 Corazón Rojo", '❤', Formatting.RED, 80, objeto(ModItems.CORAZON_ROJO, 1)),
                new Premio("1 Corazón de Alma", '❤', Formatting.BLUE, 50, objeto(ModItems.CORAZON_ALMA, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 60, objeto(Items.TOTEM_OF_UNDYING, 1)),
                new Premio("3 Rumores Verdes", '$', Formatting.GREEN, 70, objeto(ModItems.RUMOR_VERDE, 3)),
                new Premio("1 Rumor Gris", '$', Formatting.GRAY, 40, objeto(ModItems.RUMOR_GRIS, 1))));
        TABLAS.put(Rareza.GRIS, List.of(
                new Premio("Nada", ' ', Formatting.WHITE, 240, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("6 Rumores Rojos", '$', Formatting.RED, 150, objeto(ModItems.RUMOR_ROJO, 6)),
                new Premio("15 diamantes", '♦', Formatting.AQUA, 100, objeto(Items.DIAMOND, 15)),
                new Premio("4 Corazones Rojos", '❤', Formatting.RED, 100, objeto(ModItems.CORAZON_ROJO, 4)),
                new Premio("3 Corazones de Alma", '❤', Formatting.BLUE, 100, objeto(ModItems.CORAZON_ALMA, 3)),
                new Premio("1 Periódico Desinformado", '✉', Formatting.WHITE, 30, objeto(ModItems.PERIODICO, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 150, objeto(Items.TOTEM_OF_UNDYING, 1)),
                new Premio("3 Rumores Grises", '$', Formatting.GRAY, 60, objeto(ModItems.RUMOR_GRIS, 3)),
                new Premio("5 Rumores Verdes", '$', Formatting.GREEN, 60, objeto(ModItems.RUMOR_VERDE, 5))));
    }

    // ------------------------------------------------------------------------------------------

    private static class Tirada {
        final ServerPlayerEntity jugador; final BlockPos base; final Rareza rareza; final Premio premio;
        final char[] finales = new char[3]; final Formatting[] colores = new Formatting[3];
        int ticks = 0;
        Tirada(ServerPlayerEntity j, BlockPos b, Rareza r, Premio p) { jugador = j; base = b; rareza = r; premio = p; }
    }

    private static final Map<BlockPos, Tirada> EN_CURSO = new HashMap<>();
    private static final int DURACION = 60;

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(Tragamonedas::tick);
    }

    public static void tirar(ServerPlayerEntity p, BlockPos base, Rareza r, Direction frente) {
        if (EN_CURSO.containsKey(base)) {
            p.sendMessage(Text.literal("La máquina está girando...").formatted(Formatting.GRAY), true);
            return;
        }
        if (!pagar(p, r.coste)) {
            p.sendMessage(Text.literal("Necesitas " + r.coste + " Rumores en el inventario para jugar").formatted(Formatting.RED), true);
            return;
        }
        Premio premio = sortear(TABLAS.get(r), p.getRandom());
        Tirada t = new Tirada(p, base.toImmutable(), r, premio);
        if (premio.simbolo() == ' ') {
            // "Nada": tres símbolos que no coinciden
            List<Character> lista = new ArrayList<>();
            for (char c : SIMBOLOS_NADA) lista.add(c);
            Collections.shuffle(lista, new java.util.Random(p.getRandom().nextLong()));
            for (int i = 0; i < 3; i++) { t.finales[i] = lista.get(i); t.colores[i] = Formatting.WHITE; }
        } else {
            Arrays.fill(t.finales, premio.simbolo());
            Arrays.fill(t.colores, premio.color());
        }
        EN_CURSO.put(t.base, t);
        p.getServerWorld().playSound(null, base, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 1f, 0.8f);
        p.getServerWorld().playSound(null, base, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.6f, 0.6f);
    }

    private static void tick(MinecraftServer server) {
        Iterator<Tirada> it = EN_CURSO.values().iterator();
        while (it.hasNext()) {
            Tirada t = it.next();
            t.ticks++;
            ServerPlayerEntity p = t.jugador;
            if (p.isRemoved()) { it.remove(); continue; }
            // Los rodillos se paran uno a uno (a los 30, 45 y 60 ticks)
            if (t.ticks % 2 == 0 || t.ticks == 30 || t.ticks == 45 || t.ticks == DURACION) {
                MutableText linea = Text.literal("[ ").formatted(t.rareza.color, Formatting.BOLD);
                for (int i = 0; i < 3; i++) {
                    boolean parado = t.ticks >= 30 + i * 15;
                    char c = parado ? t.finales[i] : SIMBOLOS_NADA[p.getRandom().nextInt(SIMBOLOS_NADA.length)];
                    linea.append(Text.literal(String.valueOf(c)).formatted(parado ? t.colores[i] : Formatting.WHITE, Formatting.BOLD));
                    linea.append(Text.literal(i < 2 ? " | " : " ]").formatted(t.rareza.color, Formatting.BOLD));
                }
                p.sendMessage(linea, true);
                if (t.ticks % 4 == 0 && t.ticks < DURACION) {
                    p.getServerWorld().playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), SoundCategory.BLOCKS, 0.6f, 1.5f);
                }
                if (t.ticks == 30 || t.ticks == 45) {
                    p.getServerWorld().playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM.value(), SoundCategory.BLOCKS, 0.9f, 1f);
                }
            }
            if (t.ticks >= DURACION) {
                it.remove();
                resultado(t);
            }
        }
    }

    private static void resultado(Tirada t) {
        ServerPlayerEntity p = t.jugador;
        ServerWorld w = p.getServerWorld();
        Premio pr = t.premio;
        if (pr.simbolo() == ' ') {
            p.sendMessage(Text.literal("Nada... el Centro de Desinformación agradece tu donación").formatted(Formatting.GRAY), false);
            w.playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_DIDGERIDOO.value(), SoundCategory.BLOCKS, 1f, 0.6f);
            return;
        }
        boolean malo = pr.simbolo() == '☠' || pr.simbolo() == '⚡';
        p.sendMessage(Text.literal(malo ? "Mala suerte: " : "¡Premio! ").formatted(malo ? Formatting.DARK_RED : Formatting.GOLD, Formatting.BOLD)
                .append(Text.literal(pr.nombre()).formatted(pr.color())), false);
        if (malo) {
            w.playSound(null, t.base, SoundEvents.ENTITY_WITCH_CELEBRATE, SoundCategory.BLOCKS, 1f, 0.8f);
        } else {
            w.playSound(null, t.base, SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.BLOCKS, 1f, 1.2f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, t.base.getX() + 0.5, t.base.getY() + 2.2, t.base.getZ() + 0.5, 20, 0.8, 0.6, 0.8, 0.1);
        }
        if (pr.simbolo() == '7') {
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, t.base.getX() + 0.5, t.base.getY() + 2.5, t.base.getZ() + 0.5, 80, 1, 1, 1, 0.4);
            p.getServer().getPlayerManager().broadcast(Text.literal("¡" + p.getGameProfile().getName() + " ha ganado el JACKPOT de la tragamonedas " + t.rareza.id + "!")
                    .formatted(Formatting.GOLD, Formatting.BOLD), false);
        }
        pr.dar().accept(p, t.base);
    }

    private static Premio sortear(List<Premio> tabla, Random r) {
        int total = 0;
        for (Premio p : tabla) total += p.peso();
        int x = r.nextInt(total);
        for (Premio p : tabla) { x -= p.peso(); if (x < 0) return p; }
        return tabla.get(0);
    }

    /** Cobra con los Rumores del inventario y devuelve el cambio en las monedas más grandes posibles. */
    private static boolean pagar(ServerPlayerEntity p, int coste) {
        PlayerInventory inv = p.getInventory();
        int total = 0;
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).getItem() instanceof RumorItem r) total += r.getValor() * inv.getStack(i).getCount();
        if (total < coste) return false;
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).getItem() instanceof RumorItem) inv.setStack(i, ItemStack.EMPTY);
        int cambio = total - coste;
        Item[] monedas = {ModItems.RUMOR_GRIS, ModItems.RUMOR_ROJO, ModItems.RUMOR_VERDE, ModItems.RUMOR_AZUL, ModItems.RUMOR_AMARILLO};
        for (Item m : monedas) {
            int v = ((RumorItem) m).getValor();
            int n = cambio / v;
            cambio -= n * v;
            while (n > 0) { int lote = Math.min(64, n); dar(p, new ItemStack(m, lote)); n -= lote; }
        }
        return true;
    }

    private static void dar(ServerPlayerEntity p, ItemStack s) {
        if (!p.getInventory().insertStack(s)) p.dropItem(s, false);
    }
}

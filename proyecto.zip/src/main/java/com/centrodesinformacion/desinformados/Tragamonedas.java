package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.*;
import java.util.function.BiConsumer;

/**
 * Tragamonedas: se paga con los Rumores del inventario (se devuelve el cambio),
 * los rodillos giran 3 segundos en la barra de acción y sale un premio según la rareza.
 */
public class Tragamonedas {
    public enum Rareza {
        AZUL("azul", 10, Formatting.BLUE), MORADA("morada", 20, Formatting.LIGHT_PURPLE), GRIS("gris", 50, Formatting.GRAY);
        public final String id; public final int coste; public final Formatting color;
        Rareza(String id, int coste, Formatting color) { this.id = id; this.coste = coste; this.color = color; }
    }

    /** Símbolo de los rodillos + qué pasa al salir. */
    record Premio(String nombre, char simbolo, Formatting color, int peso, BiConsumer<ServerPlayerEntity, BlockPos> dar) {}

    private static final Map<Rareza, List<Premio>> TABLAS = new EnumMap<>(Rareza.class);
    private static final char[] SIMBOLOS_NADA = {'♣', '⚒', '$', '♦', '❤', '★', '✉'};

    /** Premio de objetos (record para poder saber cuántos Rumores vale si hay que pagarlo al Banco). */
    private record Objeto(Item item, int n) implements BiConsumer<ServerPlayerEntity, BlockPos> {
        @Override
        public void accept(ServerPlayerEntity p, BlockPos pos) {
            Tragamonedas.dar(p, new ItemStack(item, n));
        }
    }

    private static BiConsumer<ServerPlayerEntity, BlockPos> objeto(Item item, int n) {
        return new Objeto(item, n);
    }

    private static BiConsumer<ServerPlayerEntity, BlockPos> mobs(EntityType<?> tipo, int n) {
        return (p, pos) -> {
            for (int i = 0; i < n; i++) tipo.spawn(p.getServerWorld(), p.getBlockPos().add(p.getRandom().nextInt(5) - 2, 0, p.getRandom().nextInt(5) - 2), SpawnReason.EVENT);
        };
    }

    static {
        // ======================= TABLAS DE PREMIOS =======================
        // peso = probabilidad x10 (45 % -> 450, 0,5 % -> 5). Cada tabla suma 1000.
        // En todas: 1 % de desafío rojo al azar (sacado del porcentaje de "Nada").
        // Actualización del casino: en Rumores devuelven ~50 % (no se puede hacer dinero infinito), pero se gana algo
        // en ~6 de cada 10 tiradas y hay jackpots de Rumores. Cualquier objeto concreto sale más barato en la tienda.
        TABLAS.put(Rareza.AZUL, List.of(                                            // 10 Rumores: "probar suerte"
                new Premio("Nada", ' ', Formatting.WHITE, 415, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("8 panes", '♣', Formatting.GREEN, 60, objeto(Items.BREAD, 8)),
                new Premio("6 lingotes de hierro", '⚒', Formatting.GRAY, 60, objeto(Items.IRON_INGOT, 6)),
                new Premio("5 Rumores Amarillos", '$', Formatting.YELLOW, 175, objeto(ModItems.RUMOR_AMARILLO, 5)),
                new Premio("1 Rumor Verde", '$', Formatting.GREEN, 130, objeto(ModItems.RUMOR_VERDE, 1)),
                new Premio("1 Rumor Rojo", '$', Formatting.RED, 90, objeto(ModItems.RUMOR_ROJO, 1)),
                new Premio("1 Rumor Gris", '$', Formatting.GRAY, 15, objeto(ModItems.RUMOR_GRIS, 1)),
                new Premio("¡JACKPOT! 100 Rumores", '7', Formatting.GOLD, 5, objeto(ModItems.RUMOR_GRIS, 2)),
                new Premio("1 Corazón Rojo", '❤', Formatting.RED, 25, objeto(ModItems.CORAZON_ROJO, 1)),
                new Premio("1 Corazón de Alma", '❤', Formatting.BLUE, 10, objeto(ModItems.CORAZON_ALMA, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 5, objeto(Items.TOTEM_OF_UNDYING, 1))));
        TABLAS.put(Rareza.MORADA, List.of(                                          // 20 Rumores: la equilibrada
                new Premio("Nada", ' ', Formatting.WHITE, 371, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("12 lingotes de hierro", '⚒', Formatting.GRAY, 70, objeto(Items.IRON_INGOT, 12)),
                new Premio("8 lingotes de oro", '★', Formatting.GOLD, 70, objeto(Items.GOLD_INGOT, 8)),
                new Premio("1 Rumor Verde", '$', Formatting.GREEN, 150, objeto(ModItems.RUMOR_VERDE, 1)),
                new Premio("1 Rumor Rojo", '$', Formatting.RED, 130, objeto(ModItems.RUMOR_ROJO, 1)),
                new Premio("2 Rumores Rojos", '$', Formatting.RED, 80, objeto(ModItems.RUMOR_ROJO, 2)),
                new Premio("2 Rumores Grises", '$', Formatting.GRAY, 20, objeto(ModItems.RUMOR_GRIS, 2)),
                new Premio("¡JACKPOT! 250 Rumores", '7', Formatting.GOLD, 4, objeto(ModItems.RUMOR_GRIS, 5)),
                new Premio("2 diamantes", '♦', Formatting.AQUA, 30, objeto(Items.DIAMOND, 2)),
                new Premio("1 Corazón Rojo", '❤', Formatting.RED, 35, objeto(ModItems.CORAZON_ROJO, 1)),
                new Premio("1 Corazón de Alma", '❤', Formatting.BLUE, 20, objeto(ModItems.CORAZON_ALMA, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 10, objeto(Items.TOTEM_OF_UNDYING, 1))));
        TABLAS.put(Rareza.GRIS, List.of(                                            // 50 Rumores: alto riesgo, premios gordos
                new Premio("Nada", ' ', Formatting.WHITE, 255, (p, pos) -> {}),
                new Premio("¡Desafío sorpresa!", '⚡', Formatting.DARK_RED, 10, (p, pos) -> {
                    List<String> ids = new ArrayList<>(Desafios.TODOS.keySet());
                    Desafios.lanzar(p.getServer(), ids.get(p.getRandom().nextInt(ids.size())));
                }),
                new Premio("1 Rumor Rojo", '$', Formatting.RED, 250, objeto(ModItems.RUMOR_ROJO, 1)),
                new Premio("1 Rumor Gris", '$', Formatting.GRAY, 200, objeto(ModItems.RUMOR_GRIS, 1)),
                new Premio("2 Rumores Grises", '$', Formatting.GRAY, 80, objeto(ModItems.RUMOR_GRIS, 2)),
                new Premio("3 Rumores Grises", '$', Formatting.GRAY, 30, objeto(ModItems.RUMOR_GRIS, 3)),
                new Premio("¡MEGA JACKPOT! 1000 Rumores", '7', Formatting.GOLD, 2, objeto(ModItems.RUMOR_GRIS, 20)),
                new Premio("5 diamantes", '♦', Formatting.AQUA, 35, objeto(Items.DIAMOND, 5)),
                new Premio("1 lingote de netherite", '♦', Formatting.DARK_GRAY, 13, objeto(Items.NETHERITE_INGOT, 1)),
                new Premio("2 Corazones Rojos", '❤', Formatting.RED, 45, objeto(ModItems.CORAZON_ROJO, 2)),
                new Premio("1 Corazón de Alma", '❤', Formatting.BLUE, 40, objeto(ModItems.CORAZON_ALMA, 1)),
                new Premio("1 Periódico Desinformado", '✉', Formatting.WHITE, 10, objeto(ModItems.PERIODICO, 1)),
                new Premio("¡JACKPOT! 1 Gato de la Desinformación", '7', Formatting.GOLD, 30, objeto(Items.TOTEM_OF_UNDYING, 1))));
    }

    // ------------------------------------------------------------------------------------------

    private static class Tirada {
        final UUID jugador; final BlockPos base; final Rareza rareza; final Premio premio;   // UUID: sigue valiendo si reaparece o se reconecta
        final char[] finales = new char[3]; final Formatting[] colores = new Formatting[3];
        int ticks = 0;
        Tirada(UUID j, BlockPos b, Rareza r, Premio p) { jugador = j; base = b; rareza = r; premio = p; }
    }

    private static final Map<BlockPos, Tirada> EN_CURSO = new HashMap<>();
    private static final int DURACION = 60;

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(Tragamonedas::tick);
        // Al parar el servidor (LAN: el mapa estático sobrevive), las tiradas a medias se pagan al Banco
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (!EN_CURSO.isEmpty() && server.getOverworld() != null) for (Tirada t : EN_CURSO.values()) alBanco(server, t);
            EN_CURSO.clear();
        });
    }

    public static void tirar(ServerPlayerEntity p, BlockPos base, Rareza r, Direction frente) {
        if (EN_CURSO.containsKey(base)) {
            p.sendMessage(Text.literal("La máquina está girando...").formatted(Formatting.GRAY), true);
            return;
        }
        if (!pagar(p, r.coste)) {
            p.sendMessage(Text.literal("Necesitas " + r.coste + " Rumores en el inventario para jugar").formatted(Formatting.RED), true);
            return;
        }
        Misiones.sumar(p, "tragamonedas", 1);
        Premio premio = sortear(TABLAS.get(r), p.getRandom());
        Tirada t = new Tirada(p.getUuid(), base.toImmutable(), r, premio);
        if (premio.simbolo() == ' ') {
            // "Nada": tres símbolos que no coinciden
            List<Character> lista = new ArrayList<>();
            for (char c : SIMBOLOS_NADA) lista.add(c);
            Collections.shuffle(lista, new java.util.Random(p.getRandom().nextLong()));
            for (int i = 0; i < 3; i++) { t.finales[i] = lista.get(i); t.colores[i] = Formatting.WHITE; }
        } else {
            Arrays.fill(t.finales, premio.simbolo());
            Arrays.fill(t.colores, premio.color());
        }
        EN_CURSO.put(t.base, t);
        p.getServerWorld().playSound(null, base, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 1f, 0.8f);
        p.getServerWorld().playSound(null, base, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.6f, 0.6f);
    }

    private static void tick(MinecraftServer server) {
        Iterator<Tirada> it = EN_CURSO.values().iterator();
        while (it.hasNext()) {
            Tirada t = it.next();
            t.ticks++;
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(t.jugador);
            if (p == null) {                       // se fue a mitad de la tirada: al acabar, el premio va a su cuenta del Banco
                if (t.ticks >= DURACION) {
                    it.remove();
                    alBanco(server, t);
                }
                continue;
            }
            // Los rodillos se paran uno a uno (a los 30, 45 y 60 ticks)
            if (t.ticks % 2 == 0 || t.ticks == 30 || t.ticks == 45 || t.ticks == DURACION) {
                MutableText linea = Text.literal("[ ").formatted(t.rareza.color, Formatting.BOLD);
                for (int i = 0; i < 3; i++) {
                    boolean parado = t.ticks >= 30 + i * 15;
                    char c = parado ? t.finales[i] : SIMBOLOS_NADA[p.getRandom().nextInt(SIMBOLOS_NADA.length)];
                    linea.append(Text.literal(String.valueOf(c)).formatted(parado ? t.colores[i] : Formatting.WHITE, Formatting.BOLD));
                    linea.append(Text.literal(i < 2 ? " | " : " ]").formatted(t.rareza.color, Formatting.BOLD));
                }
                p.sendMessage(linea, true);
                if (t.ticks % 4 == 0 && t.ticks < DURACION) {
                    p.getServerWorld().playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), SoundCategory.BLOCKS, 0.6f, 1.5f);
                }
                if (t.ticks == 30 || t.ticks == 45) {
                    p.getServerWorld().playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM.value(), SoundCategory.BLOCKS, 0.9f, 1f);
                }
            }
            if (t.ticks >= DURACION) {
                it.remove();
                resultado(t, p);
            }
        }
    }

    /**
     * El jugador no está al acabar la tirada: si ganó Rumores, van a su cuenta del Banco (como en la ruleta);
     * si ganó un objeto (el Banco solo guarda Rumores) se le devuelve lo que pagó. Si perdió, nada.
     */
    private static void alBanco(MinecraftServer server, Tirada t) {
        Premio pr = t.premio;
        if (pr.simbolo() == ' ' || pr.simbolo() == '☠' || pr.simbolo() == '⚡') return;
        int valor = t.rareza.coste;
        if (pr.dar() instanceof Objeto o && o.item() instanceof RumorItem r) valor = r.getValor() * o.n();
        EstadoServidor e = EstadoServidor.get(server);
        e.setSaldo(t.jugador, e.getSaldo(t.jugador) + valor);
    }

    private static void resultado(Tirada t, ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Premio pr = t.premio;
        if (pr.simbolo() == ' ') {
            p.sendMessage(Text.literal("Nada... el Centro de Desinformación agradece tu donación").formatted(Formatting.GRAY), false);
            w.playSound(null, t.base, SoundEvents.BLOCK_NOTE_BLOCK_DIDGERIDOO.value(), SoundCategory.BLOCKS, 1f, 0.6f);
            return;
        }
        boolean malo = pr.simbolo() == '☠' || pr.simbolo() == '⚡';
        p.sendMessage(Text.literal(malo ? "Mala suerte: " : "¡Premio! ").formatted(malo ? Formatting.DARK_RED : Formatting.GOLD, Formatting.BOLD)
                .append(Text.literal(pr.nombre()).formatted(pr.color())), false);
        if (malo) {
            w.playSound(null, t.base, SoundEvents.ENTITY_WITCH_CELEBRATE, SoundCategory.BLOCKS, 1f, 0.8f);
        } else {
            w.playSound(null, t.base, SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.BLOCKS, 1f, 1.2f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, t.base.getX() + 0.5, t.base.getY() + 2.2, t.base.getZ() + 0.5, 20, 0.8, 0.6, 0.8, 0.1);
        }
        if (pr.simbolo() == '7') {
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, t.base.getX() + 0.5, t.base.getY() + 2.5, t.base.getZ() + 0.5, 80, 1, 1, 1, 0.4);
            p.getServer().getPlayerManager().broadcast(Text.literal("¡" + p.getGameProfile().getName() + " ha ganado en la tragamonedas " + t.rareza.id + ": "
                    + pr.nombre() + "!").formatted(Formatting.GOLD, Formatting.BOLD), false);
        }
        pr.dar().accept(p, t.base);
    }

    private static Premio sortear(List<Premio> tabla, Random r) {
        int total = 0;
        for (Premio p : tabla) total += p.peso();
        int x = r.nextInt(total);
        for (Premio p : tabla) { x -= p.peso(); if (x < 0) return p; }
        return tabla.get(0);
    }

    /** Cuántos Rumores lleva en el inventario (sumando el valor de cada moneda). */
    static int rumores(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        int total = 0;
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).getItem() instanceof RumorItem r) total += r.getValor() * inv.getStack(i).getCount();
        return total;
    }

    /** Cobra con los Rumores del inventario y devuelve el cambio en las monedas más grandes posibles. */
    static boolean pagar(ServerPlayerEntity p, int coste) {
        PlayerInventory inv = p.getInventory();
        int total = rumores(p);
        if (total < coste) return false;
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).getItem() instanceof RumorItem) inv.setStack(i, ItemStack.EMPTY);
        darRumores(p, total - coste);
        return true;
    }

    /** Da esa cantidad de Rumores en las monedas más grandes posibles. */
    static void darRumores(ServerPlayerEntity p, int cantidad) {
        Item[] monedas = {ModItems.RUMOR_GRIS, ModItems.RUMOR_ROJO, ModItems.RUMOR_VERDE, ModItems.RUMOR_AZUL, ModItems.RUMOR_AMARILLO};
        for (Item m : monedas) {
            int v = ((RumorItem) m).getValor();
            int n = cantidad / v;
            cantidad -= n * v;
            while (n > 0) { int lote = Math.min(64, n); dar(p, new ItemStack(m, lote)); n -= lote; }
        }
    }

    static void dar(ServerPlayerEntity p, ItemStack s) {
        if (!p.getInventory().insertStack(s)) p.dropItem(s, false);
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.ManchaPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Pantalla manchada de tinta. Además de las manchas en los bordes de la pantalla, mientras dura
 * da Lentitud I y Debilidad I (la tinta pesa y pringa las manos).
 */
public final class Mancha {
    private Mancha() {}

    public static void manchar(ServerPlayerEntity p, int ticks) {
        if (p.isSpectator() || p.isCreative()) return;
        if (ServerPlayNetworking.canSend(p, ManchaPayload.ID)) ServerPlayNetworking.send(p, new ManchaPayload(ticks));
        // sin partículas (ya se ve la tinta), con icono para saber cuánto queda
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 0, false, false, true));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, ticks, 0, false, false, true));
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.intro.Final;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Orbe de Estática: lo suelta La Desinformación al morir. Clic derecho = cinemática final para todos. */
public class OrbeEstaticaItem extends Item {
    public OrbeEstaticaItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World mundo, PlayerEntity jugador, Hand mano) {
        ItemStack stack = jugador.getStackInHand(mano);
        if (!mundo.isClient() && mundo.getServer() != null) {
            if (!Final.empezar(mundo.getServer())) {
                jugador.sendMessage(Text.literal("El final ya está en marcha...").formatted(Formatting.GRAY), true);
                return TypedActionResult.fail(stack);
            }
            stack.decrementUnlessCreative(1, jugador);
        }
        return TypedActionResult.success(stack, mundo.isClient());
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext contexto, List<Text> lineas, TooltipType tipo) {
        lineas.add(Text.literal("Todo lo que quedó de La Desinformación.").formatted(Formatting.GRAY));
        lineas.add(Text.literal("Clic derecho: ver el final (para todos).").formatted(Formatting.DARK_GREEN));
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModVariantes2;

import java.util.List;
import java.util.Map;

/** Teles azules de las variantes de los mobs del mod (parte 1 de 2): cada una desbloquea su variante. */
public final class TelesVariantes2 {
    private TelesVariantes2() {}

    /** Ids de las teles (= ids de los mobs), en el orden en que deberían salir (cada una, después de la de su original). La última es del Nether. */
    public static final List<String> IDS = List.of(
            "furro_gigante", "cubo_negro", "garabato_elastico", "creeper_bulo", "zombie_limon",
            "travensano_pesado", "ruido_blanco",
            "cubo_purpura");

    /** Para la Enciclopedia: nombre corto del mob de cada tele. */
    public static final Map<String, String> NOMBRES = Map.ofEntries(
            Map.entry("creeper_bulo", "Creeper Bulo"),
            Map.entry("furro_gigante", "Furro Gigante"),
            Map.entry("cubo_negro", "Cubo Negro"),
            Map.entry("zombie_limon", "Zombie Limón"),
            Map.entry("garabato_elastico", "Garabato Elástico"),
            Map.entry("ruido_blanco", "Ruido Blanco"),
            Map.entry("travensano_pesado", "Travensaño Pesado"),
            Map.entry("cubo_purpura", "Cubo Púrpura"));

    /** Crea las teles (lo llama Eventos al cargar). Se vuelven azules solas al estar en GRUPO_MOBS. */
    static void eventos() {
        Eventos.amarillo("furro_gigante", "¡Llega el Furro Gigante!",
                "Aparecerá en la superficie a cualquier hora (de día, menos). Es un 50 % más grande que un Furro, tiene 16 corazones y es algo más lento. "
                        + "Su abrazo atrapa a la vez a todos los jugadores que estén a menos de 2 bloques de él y no os deja alejaros: "
                        + "Lentitud IV y medio corazón cada 2 segundos a cada uno, durante como mucho 10 segundos. Mátalo para que os suelte.",
                "La convención del sótano del Centro de Desinformación ha crecido. Literalmente: uno de los asistentes se comió todo el catering "
                        + "y ahora tiene abrazos para todo el mundo a la vez. El Centro de Desinformación lo considera una medida de ahorro: un abrazo, cinco clientes.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.FURRO_GIGANTE));

        Eventos.amarillo("cubo_negro", "¡Ha aparecido el Cubo Negro!",
                "Aparecerá en la superficie por la noche. Es un 50 % más rápido que el Cubo Blanco y, si te toca, en lugar de flashearte te deja a oscuras: "
                        + "Ceguera durante 4 segundos, Oscuridad durante 6 segundos y Lentitud I durante 3 segundos. No hace daño.",
                "El becario del Centro de Desinformación metió el Cubo Blanco en la lavadora con la ropa oscura. Ha salido negro, más rápido "
                        + "y con muy poco sentido del humor. Dice que el minimalismo ya no se lleva.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.CUBO_NEGRO));

        Eventos.amarillo("garabato_elastico", "¡Llega el Garabato Elástico!",
                "Aparecerá en la superficie a cualquier hora (de día, menos). Si te toca, no te manda hacia arriba: te lanza lejos de él, "
                        + "unos 13 bloques en horizontal (y un poco hacia arriba). Puede hacerlo una vez cada 3 segundos. Cuidado con los precipicios y la lava.",
                "El becario del Centro de Desinformación se quedó sin lápiz y terminó los Garabatos con un boli rojo y unos muelles del almacén. "
                        + "Ahora rebotan. Y tú también.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.GARABATO_ELASTICO));

        Eventos.amarillo("creeper_bulo", "¡Llega el Creeper Bulo!",
                "Aparecerá solo en cuevas, como el Creeper Oscuro. Al aparecer decide en secreto si su explosión es un bulo "
                        + "(la mitad de las veces): si lo es, sisea y \"explota\" con mucho ruido y humo, pero no hace daño, no rompe nada y desaparece. "
                        + "Si no lo es, es un Creeper Oscuro de verdad: si su explosión te alcanza, perderás un contenedor de corazón. "
                        + "Por fuera son todos iguales: no sabrás cuál es cuál hasta que explote.",
                "Para ahorrar pólvora, el departamento de comunicación del Centro de Desinformación ha decidido que no todas las explosiones "
                        + "tienen que ser reales: basta con que lo parezcan. Cuáles son de verdad, no lo sabemos ni nosotros. Contrastad la información. Desde lejos.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.CREEPER_BULO));

        Eventos.amarillo("zombie_limon", "¡Llega el Zombie Limón!",
                "Aparecerá en lugares oscuros. Es lo contrario del Zombie Naranja: los proyectiles (flechas, tridentes...) no le hacen nada "
                        + "y solo recibe daño de los golpes cuerpo a cuerpo. Tiene 15 corazones, es igual de rápido y fuerte que el Naranja "
                        + "y, si te pega, su ácido te da Náuseas durante 5 segundos.",
                "El Zombie Naranja tenía un primo que nunca tomaba el sol. Se ha quedado amarillo, ácido y con muy mala leche. "
                        + "El Centro de Desinformación recomienda no exprimirlo y, sobre todo, no gastar flechas: le resbalan.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.ZOMBIE_LIMON));

        Eventos.amarillo("travensano_pesado", "¡Llega el Travensaño Pesado!",
                "Aparecerá en lugares oscuros. Como un Travensaño, te persigue y se te sienta en el cuello (te quita medio corazón cada 3 segundos, "
                        + "hasta 15 segundos), pero no te invierte los controles: mientras lo lleves encima no podrás saltar y, si estás en el agua, te hundirá.",
                "Algunos Travensaños se apuntaron al gimnasio con Ale y se pasaron con las pesas. Ya no se te sientan en el cuello: se te desploman. "
                        + "El Centro de Desinformación recomienda no bañarse con ellos.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.TRAVENSANO_PESADO));

        Eventos.amarillo("ruido_blanco", "¡El Ruido Blanco ha entrado en la señal!",
                "Como Tinky Winky, solo aparece en cuevas y sitios en oscuridad total, le dan miedo las antorchas, es rápido, tiene 4 corazones "
                        + "y desaparece después de tocarte. Pero su toque es distinto: Náuseas durante 6 segundos, Ceguera durante 3 segundos "
                        + "y 3 corazones menos durante 1 minuto. Un corazón de alma evita perder los corazones.",
                "La tele del Centro de Desinformación ha vuelto a captar un canal que no existe. Esta vez no hay presentador: solo estática con ojos. "
                        + "El servicio técnico dice que es \"ruido blanco\" y que es completamente normal. El servicio técnico no ha bajado a las cuevas.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.RUIDO_BLANCO));

        Eventos.amarillo("cubo_purpura", "¡Ha aparecido el Cubo Púrpura!",
                "Aparecerá en lugares oscuros de cualquier bioma del Nether. Como el Cubo Rojo, si te toca te flashea (pantalla en blanco y Lentitud I), "
                        + "pero en lugar de quemarte te hace levitar durante 3 segundos. Lo que pase al bajar es cosa de la gravedad.",
                "El Cubo Rojo pidió unas vacaciones lejos del calor y el Centro de Desinformación le mandó un sustituto en prácticas. "
                        + "Es morado, no sabe quemar y todo lo que toca sale flotando. Lo hemos contratado igual: era más barato.",
                server -> Eventos.desbloquearMob(server, ModVariantes2.CUBO_PURPURA));
    }
}

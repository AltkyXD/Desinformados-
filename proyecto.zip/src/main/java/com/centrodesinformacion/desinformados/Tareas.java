package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.List;

/** Ejecuta cosas después de X ticks (20 ticks = 1 segundo). */
public class Tareas {
    private static final List<Tarea> PENDIENTES = new ArrayList<>();

    private static class Tarea {
        int ticks;
        final Runnable accion;
        Tarea(int ticks, Runnable accion) { this.ticks = ticks; this.accion = accion; }
    }

    public static void programar(int ticks, Runnable accion) {
        PENDIENTES.add(new Tarea(ticks, accion));
    }

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            List<Tarea> listas = new ArrayList<>();
            PENDIENTES.removeIf(t -> {
                if (--t.ticks <= 0) { listas.add(t); return true; }
                return false;
            });
            listas.forEach(t -> t.accion.run());
        });
    }
}

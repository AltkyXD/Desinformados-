package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item PERIODICO = Registry.register(Registries.ITEM, Desinformados.id("periodico"),
            new PeriodicoItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC).fireproof()));

    public static final Item CORAZON_ROJO = Registry.register(Registries.ITEM, Desinformados.id("corazon_rojo"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), false));

    public static final Item CORAZON_ALMA = Registry.register(Registries.ITEM, Desinformados.id("corazon_alma"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), true));

    public static final Item HUEVO_CREEPER_OSCURO = Registry.register(Registries.ITEM, Desinformados.id("creeper_oscuro_spawn_egg"),
            new SpawnEggItem(ModEntidades.CREEPER_OSCURO, 0x1B1B2F, 0x7B2CBF, new Item.Settings()));

    public static void inicializar() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(PERIODICO);
            e.add(CORAZON_ROJO);
            e.add(CORAZON_ALMA);
            e.add(HUEVO_CREEPER_OSCURO);
        });
    }
}

package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item PERIODICO = Registry.register(Registries.ITEM, Desinformados.id("periodico"),
            new PeriodicoItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC).fireproof()));

    public static final Item CORAZON_ROJO = Registry.register(Registries.ITEM, Desinformados.id("corazon_rojo"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), false));

    public static final Item CORAZON_ALMA = Registry.register(Registries.ITEM, Desinformados.id("corazon_alma"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), true));

    public static final Item HUEVO_CREEPER_OSCURO = Registry.register(Registries.ITEM, Desinformados.id("creeper_oscuro_spawn_egg"),
            new SpawnEggItem(ModEntidades.CREEPER_OSCURO, 0x1B1B2F, 0x7B2CBF, new Item.Settings()));

    public static final Item HUEVO_FURRO = Registry.register(Registries.ITEM, Desinformados.id("furro_spawn_egg"),
            new SpawnEggItem(ModEntidades.FURRO, 0xA0693A, 0xF0DDB4, new Item.Settings()));

    public static final Item HUEVO_CUBO_BLANCO = Registry.register(Registries.ITEM, Desinformados.id("cubo_blanco_spawn_egg"),
            new SpawnEggItem(ModEntidades.CUBO_BLANCO, 0xFFFFFF, 0xD8D8D8, new Item.Settings()));

    public static final Item HUEVO_ZOMBIE_NARANJA = Registry.register(Registries.ITEM, Desinformados.id("zombie_naranja_spawn_egg"),
            new SpawnEggItem(ModEntidades.ZOMBIE_NARANJA, 0xF57C00, 0x5D4037, new Item.Settings()));

    public static final Item HUEVO_GARABATO = Registry.register(Registries.ITEM, Desinformados.id("garabato_spawn_egg"),
            new SpawnEggItem(ModEntidades.GARABATO, 0xF5F1E6, 0x2B2B2B, new Item.Settings()));

    public static final Item HUEVO_ALE = Registry.register(Registries.ITEM, Desinformados.id("ale_spawn_egg"),
            new SpawnEggItem(ModEntidades.ALE, 0x1E3CB4, 0xF0BE28, new Item.Settings()));
    public static final Item HUEVO_TRAVENSANO = Registry.register(Registries.ITEM, Desinformados.id("travensano_spawn_egg"),
            new SpawnEggItem(ModEntidades.TRAVENSANO, 0xBE8C6E, 0xAA3CC8, new Item.Settings()));

    public static final Item HUEVO_ULISES = Registry.register(Registries.ITEM, Desinformados.id("ulises_spawn_egg"),
            new SpawnEggItem(ModEntidades.ULISES, 0x151515, 0xE01E1E, new Item.Settings()));

    public static final Item HUEVO_INTERFERENCIA = Registry.register(Registries.ITEM, Desinformados.id("interferencia_spawn_egg"),
            new SpawnEggItem(ModEntidades.INTERFERENCIA, 0x2A2A2A, 0xD8D0C0, new Item.Settings()));

    public static final Item RUMOR_AMARILLO = rumor("amarillo", 1, net.minecraft.util.Formatting.YELLOW);
    public static final Item RUMOR_AZUL = rumor("azul", 5, net.minecraft.util.Formatting.AQUA);
    public static final Item RUMOR_VERDE = rumor("verde", 10, net.minecraft.util.Formatting.GREEN);
    public static final Item RUMOR_ROJO = rumor("rojo", 20, net.minecraft.util.Formatting.RED);
    public static final Item RUMOR_GRIS = rumor("gris", 50, net.minecraft.util.Formatting.GRAY);

    private static Item rumor(String color, int valor, net.minecraft.util.Formatting formato) {
        return Registry.register(Registries.ITEM, Desinformados.id("rumor_" + color),
                new RumorItem(new Item.Settings().maxCount(64), valor, formato));
    }

    public static final Item HUEVO_ANGEL = Registry.register(Registries.ITEM, Desinformados.id("angel_spawn_egg"),
            new SpawnEggItem(ModEntidades.ANGEL, 0x111122, 0x3C78FF, new Item.Settings()));

    public static final Item FRAGMENTO_ESTATICA = Registry.register(Registries.ITEM, Desinformados.id("fragmento_estatica"),
            new Item(new Item.Settings().rarity(Rarity.UNCOMMON)));
    public static final Item HUEVO_ZOMBIE_ESTATICA = huevo("zombie_estatica", ModEntidades.ZOMBIE_ESTATICA);
    public static final Item HUEVO_ESQUELETO_ESTATICA = huevo("esqueleto_estatica", ModEntidades.ESQUELETO_ESTATICA);
    public static final Item HUEVO_ARANA_ESTATICA = huevo("arana_estatica", ModEntidades.ARANA_ESTATICA);
    public static final Item HUEVO_CREEPER_ESTATICA = huevo("creeper_estatica", ModEntidades.CREEPER_ESTATICA);

    public static final Item GARATITA = Registry.register(Registries.ITEM, Desinformados.id("garatita"),
            new Item(new Item.Settings().rarity(Rarity.RARE)));
    /** Se fabrica con 9 Fragmentos de Estática. */
    public static final Item CENTRO_ESTATICA = Registry.register(Registries.ITEM, Desinformados.id("centro_estatica"),
            new Item(new Item.Settings().rarity(Rarity.EPIC).maxCount(16)));
    /** Rompe la Tele Gigante al usarlo. */
    public static final Item CUBO_DESINFORMACION = Registry.register(Registries.ITEM, Desinformados.id("cubo_desinformacion"),
            new CuboDesinformacionItem(new Item.Settings().rarity(Rarity.EPIC).maxCount(1).fireproof()));
    /** Un huevo por cada Gato Cubo (el becario no: nadie lo ha visto nunca). */
    public static final Item[] HUEVOS_GATO = {
            huevoGato("recepcionista", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.RECEPCIONISTA, 0xC0392B),
            huevoGato("periodista", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.PERIODISTA, 0x6B4528),
            huevoGato("conserje", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.CONSERJE, 0x2456A6),
            huevoGato("vendedor_pasivas", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.VEND_PASIVAS, 0x6A2BB0),
            huevoGato("vendedor_corazones", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.VEND_CORAZONES, 0xF8F8F8),
            huevoGato("vendedor_minerales", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.VEND_MINERALES, 0xF2C230),
            huevoGato("principal", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.PRINCIPAL, 0x7A6A5A),
            huevoGato("anime", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.ANIME, 0xFF8FC8),
            huevoGato("nerd", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.NERD, 0x2A2A2A),
            huevoGato("robot", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.ROBOT, 0x9AA3AD),
            huevoGato("granjero", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.GRANJERO, 0xE6C35C),
            huevoGato("gato", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.GATO_GATO, 0xD12C2C),
            huevoGato("romantico", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.ROMANTICO, 0xE8335A),
            huevoGato("millonario", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.MILLONARIO, 0x3BAA4A),
            huevoGato("elegante", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.ELEGANTE, 0x111111),
            huevoGato("chef", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.CHEF, 0xFFFFFF),
            huevoGato("detective", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.DETECTIVE, 0x8A6A42),
            huevoGato("dj", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.DJ, 0x39FF5A),
            huevoGato("cientifica", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.CIENTIFICA, 0xF4F6F8),
            huevoGato("fujoshi", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.FUJOSHI, 0xE24A8A),
            huevoGato("madre", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.MADRE, 0xF7D8E4),
            huevoGato("gatito", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.GATITO, 0xBFE3FF),
            huevoGato("fiestera", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.FIESTERA, 0xFFE04A),
            huevoGato("perro", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.PERRO, 0x6B4A2E),
            huevoGato("plano", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.PLANO, 0x111111),
            huevoGato("katem", com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.KATEM, 0x1A1A1E)};

    private static Item huevoGato(String id, int tipo, int color) {
        return Registry.register(Registries.ITEM, Desinformados.id("gato_" + id + "_spawn_egg"),
                new com.centrodesinformacion.desinformados.entidad.HuevoGatoCuboItem(tipo, 0xB89A74, color, new Item.Settings()));
    }

    public static final Item HUEVO_CREEPER_FUEGO = Registry.register(Registries.ITEM, Desinformados.id("creeper_fuego_spawn_egg"),
            new SpawnEggItem(ModEntidades.CREEPER_FUEGO, 0xC23A0E, 0xFFB020, new Item.Settings()));
    public static final Item HUEVO_CUBO_ROJO = Registry.register(Registries.ITEM, Desinformados.id("cubo_rojo_spawn_egg"),
            new SpawnEggItem(ModEntidades.CUBO_ROJO, 0xD42020, 0xFF8040, new Item.Settings()));
    public static final Item HUEVO_ESQUELETO_RAFAGA = Registry.register(Registries.ITEM, Desinformados.id("esqueleto_rafaga_spawn_egg"),
            new SpawnEggItem(ModEntidades.ESQUELETO_RAFAGA, 0x6FCF4A, 0x2E5E1E, new Item.Settings()));
    public static final Item HUEVO_BRANDON = Registry.register(Registries.ITEM, Desinformados.id("brandon_spawn_egg"),
            new SpawnEggItem(ModEntidades.BRANDON, 0xD6E6FA, 0x46CDFF, new Item.Settings()));
    public static final Item HUEVO_KEVIN = Registry.register(Registries.ITEM, Desinformados.id("kevin_spawn_egg"),
            new SpawnEggItem(ModEntidades.KEVIN, 0x3A3A3C, 0x34200F, new Item.Settings()));
    public static final Item HUEVO_ALTKY = Registry.register(Registries.ITEM, Desinformados.id("altky_spawn_egg"),
            new SpawnEggItem(ModEntidades.ALTKY, 0xDADADA, 0x2A2A2A, new Item.Settings()));
    public static final Item HUEVO_FURRO_DIBUJO = Registry.register(Registries.ITEM, Desinformados.id("furro_dibujo_spawn_egg"),
            new SpawnEggItem(ModEntidades.FURRO_DIBUJO, 0xF4F0E6, 0x1A1A1A, new Item.Settings()));
    public static final Item HUEVO_MUNECO = Registry.register(Registries.ITEM, Desinformados.id("muneco_spawn_egg"),
            new SpawnEggItem(ModEntidades.MUNECO, 0x2E9EDB, 0x5B3A1F, new Item.Settings()));
    // ---------- Pasivas (se compran al Mago de las Pasivas) ----------
    private static Item pasiva(String id, net.minecraft.util.Rarity rareza) {
        return Registry.register(Registries.ITEM, Desinformados.id("pasiva_" + id),
                new com.centrodesinformacion.desinformados.pasivas.PasivaItem(id, new Item.Settings().maxCount(1).rarity(rareza)));
    }
    public static final Item PASIVA_CAIDA = pasiva("caida", net.minecraft.util.Rarity.UNCOMMON);
    public static final Item PASIVA_GARRAS = pasiva("garras", net.minecraft.util.Rarity.RARE);
    public static final Item PASIVA_DOBLE_SALTO = pasiva("doble_salto", net.minecraft.util.Rarity.RARE);
    public static final Item PASIVA_VENENO = pasiva("veneno", net.minecraft.util.Rarity.UNCOMMON);
    public static final Item PASIVA_ROCK_BOTTOM = pasiva("rock_bottom", net.minecraft.util.Rarity.EPIC);
    public static final Item[] PASIVAS = {PASIVA_CAIDA, PASIVA_GARRAS, PASIVA_DOBLE_SALTO, PASIVA_VENENO, PASIVA_ROCK_BOTTOM};

    public static final Item[] HUEVOS_DIBUJO = {
            huevo("zombie_dibujo", ModEntidades.ZOMBIE_DIBUJO), huevo("esqueleto_dibujo", ModEntidades.ESQUELETO_DIBUJO),
            huevo("creeper_dibujo", ModEntidades.CREEPER_DIBUJO), huevo("arana_dibujo", ModEntidades.ARANA_DIBUJO)};

    public static final Item CUBO_TINTA = Registry.register(Registries.ITEM, Desinformados.id("cubo_tinta"),
            new net.minecraft.item.BucketItem(com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA,
                    new Item.Settings().recipeRemainder(net.minecraft.item.Items.BUCKET).maxCount(1)));

    private static Item huevo(String id, net.minecraft.entity.EntityType<? extends net.minecraft.entity.mob.MobEntity> tipo) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, 0xBDBDBD, 0x3A3A3A, new Item.Settings()));
    }

    public static void inicializar() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(PERIODICO);
            e.add(ModBloques.BANCO_ITEM);
            e.add(ModBloques.TRAGAMONEDAS_AZUL.asItem());
            e.add(ModBloques.TRAGAMONEDAS_MORADA.asItem());
            e.add(ModBloques.TRAGAMONEDAS_GRIS.asItem());
            e.add(RUMOR_AMARILLO);
            e.add(RUMOR_AZUL);
            e.add(RUMOR_VERDE);
            e.add(RUMOR_ROJO);
            e.add(RUMOR_GRIS);
            e.add(CORAZON_ROJO);
            e.add(CORAZON_ALMA);
            e.add(HUEVO_CREEPER_OSCURO);
            e.add(HUEVO_FURRO);
            e.add(HUEVO_CUBO_BLANCO);
            e.add(HUEVO_ZOMBIE_NARANJA);
            e.add(HUEVO_GARABATO);
            e.add(HUEVO_ALE);
            e.add(HUEVO_TRAVENSANO);
            e.add(HUEVO_ULISES);
            e.add(HUEVO_ANGEL);
            e.add(HUEVO_INTERFERENCIA);
            e.add(FRAGMENTO_ESTATICA);
            e.add(ModBloques.TELE_PORTAL.asItem());
            e.add(ModBloques.LIBRETA_PORTAL.asItem());
            e.add(ModBloques.MURO_ESTATICA.asItem());
            e.add(ModBloques.GARATITA_MENA.asItem());
            e.add(GARATITA);
            e.add(ModBloques.SALIDA_TELE.asItem());
            e.add(ModBloques.BLOQUE_ESTATICA.asItem());
            e.add(ModBloques.MINERAL_ESTATICA.asItem());
            e.add(HUEVO_ZOMBIE_ESTATICA);
            e.add(HUEVO_ESQUELETO_ESTATICA);
            e.add(HUEVO_ARANA_ESTATICA);
            e.add(HUEVO_CREEPER_ESTATICA);
            for (Item h : HUEVOS_DIBUJO) e.add(h);
            for (Item h : HUEVOS_GATO) e.add(h);
            e.add(HUEVO_CREEPER_FUEGO);
            e.add(HUEVO_CUBO_ROJO);
            e.add(HUEVO_ESQUELETO_RAFAGA);
            e.add(HUEVO_BRANDON);
            e.add(HUEVO_KEVIN);
            e.add(HUEVO_ALTKY);
            e.add(HUEVO_FURRO_DIBUJO);
            e.add(HUEVO_MUNECO);
            for (Item pa : PASIVAS) e.add(pa);
            e.add(CUBO_TINTA);
            e.add(CENTRO_ESTATICA);
            e.add(CUBO_DESINFORMACION);
            e.add(ModBloques.BLOQUE_GARATITA.asItem());
            for (net.minecraft.block.Block b : ModBloques.PAPEL) e.add(b.asItem());
            for (net.minecraft.block.Block b : ModBloques.METAL) e.add(b.asItem());
            e.add(ModBloques.RECEPCION.asItem());
            e.add(ModBloques.VALLA_OBRA.asItem());
            e.add(ModBloques.ANDAMIO_OBRA.asItem());
            e.add(ModBloques.MESA_DJ.asItem());
            e.add(ModBloques.PISTA_BAILE.asItem());
            for (net.minecraft.block.Block b : ModBloques.DECORACION) e.add(b.asItem());
        });
    }
}

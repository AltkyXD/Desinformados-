package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item PERIODICO = Registry.register(Registries.ITEM, Desinformados.id("periodico"),
            new PeriodicoItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC).fireproof()));

    public static final Item CORAZON_ROJO = Registry.register(Registries.ITEM, Desinformados.id("corazon_rojo"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), false));

    public static final Item CORAZON_ALMA = Registry.register(Registries.ITEM, Desinformados.id("corazon_alma"),
            new CorazonItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE), true));

    public static final Item HUEVO_CREEPER_OSCURO = Registry.register(Registries.ITEM, Desinformados.id("creeper_oscuro_spawn_egg"),
            new SpawnEggItem(ModEntidades.CREEPER_OSCURO, 0x1B1B2F, 0x7B2CBF, new Item.Settings()));

    public static final Item HUEVO_FURRO = Registry.register(Registries.ITEM, Desinformados.id("furro_spawn_egg"),
            new SpawnEggItem(ModEntidades.FURRO, 0xA0693A, 0xF0DDB4, new Item.Settings()));

    public static final Item HUEVO_CUBO_BLANCO = Registry.register(Registries.ITEM, Desinformados.id("cubo_blanco_spawn_egg"),
            new SpawnEggItem(ModEntidades.CUBO_BLANCO, 0xFFFFFF, 0xD8D8D8, new Item.Settings()));

    public static final Item HUEVO_ZOMBIE_NARANJA = Registry.register(Registries.ITEM, Desinformados.id("zombie_naranja_spawn_egg"),
            new SpawnEggItem(ModEntidades.ZOMBIE_NARANJA, 0xF57C00, 0x5D4037, new Item.Settings()));

    public static final Item HUEVO_GARABATO = Registry.register(Registries.ITEM, Desinformados.id("garabato_spawn_egg"),
            new SpawnEggItem(ModEntidades.GARABATO, 0xF5F1E6, 0x2B2B2B, new Item.Settings()));

    public static final Item HUEVO_ALE = Registry.register(Registries.ITEM, Desinformados.id("ale_spawn_egg"),
            new SpawnEggItem(ModEntidades.ALE, 0x1E3CB4, 0xF0BE28, new Item.Settings()));
    public static final Item HUEVO_TRAVENSANO = Registry.register(Registries.ITEM, Desinformados.id("travensano_spawn_egg"),
            new SpawnEggItem(ModEntidades.TRAVENSANO, 0xBE8C6E, 0xAA3CC8, new Item.Settings()));

    public static final Item HUEVO_ULISES = Registry.register(Registries.ITEM, Desinformados.id("ulises_spawn_egg"),
            new SpawnEggItem(ModEntidades.ULISES, 0x151515, 0xE01E1E, new Item.Settings()));

    public static final Item HUEVO_INTERFERENCIA = Registry.register(Registries.ITEM, Desinformados.id("interferencia_spawn_egg"),
            new SpawnEggItem(ModEntidades.INTERFERENCIA, 0x2A2A2A, 0xD8D0C0, new Item.Settings()));

    public static final Item RUMOR_AMARILLO = rumor("amarillo", 1, net.minecraft.util.Formatting.YELLOW);
    public static final Item RUMOR_AZUL = rumor("azul", 5, net.minecraft.util.Formatting.AQUA);
    public static final Item RUMOR_VERDE = rumor("verde", 10, net.minecraft.util.Formatting.GREEN);
    public static final Item RUMOR_ROJO = rumor("rojo", 20, net.minecraft.util.Formatting.RED);
    public static final Item RUMOR_GRIS = rumor("gris", 50, net.minecraft.util.Formatting.GRAY);

    private static Item rumor(String color, int valor, net.minecraft.util.Formatting formato) {
        return Registry.register(Registries.ITEM, Desinformados.id("rumor_" + color),
                new RumorItem(new Item.Settings().maxCount(64), valor, formato));
    }

    public static final Item HUEVO_ANGEL = Registry.register(Registries.ITEM, Desinformados.id("angel_spawn_egg"),
            new SpawnEggItem(ModEntidades.ANGEL, 0x111122, 0x3C78FF, new Item.Settings()));

    public static void inicializar() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(PERIODICO);
            e.add(ModBloques.BANCO_ITEM);
            e.add(ModBloques.TRAGAMONEDAS_AZUL.asItem());
            e.add(ModBloques.TRAGAMONEDAS_MORADA.asItem());
            e.add(ModBloques.TRAGAMONEDAS_GRIS.asItem());
            e.add(RUMOR_AMARILLO);
            e.add(RUMOR_AZUL);
            e.add(RUMOR_VERDE);
            e.add(RUMOR_ROJO);
            e.add(RUMOR_GRIS);
            e.add(CORAZON_ROJO);
            e.add(CORAZON_ALMA);
            e.add(HUEVO_CREEPER_OSCURO);
            e.add(HUEVO_FURRO);
            e.add(HUEVO_CUBO_BLANCO);
            e.add(HUEVO_ZOMBIE_NARANJA);
            e.add(HUEVO_GARABATO);
            e.add(HUEVO_ALE);
            e.add(HUEVO_TRAVENSANO);
            e.add(HUEVO_ULISES);
            e.add(HUEVO_ANGEL);
            e.add(HUEVO_INTERFERENCIA);
        });
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Datos guardados en el mundo: fase de minerales, radio del spawn y jugadores muertos. */
public class EstadoServidor extends PersistentState {
    private final Map<UUID, String> muertos = new LinkedHashMap<>();
    private int fase = 1;
    private int radioSpawn = 32;

    public static final PersistentState.Type<EstadoServidor> TYPE =
            new PersistentState.Type<>(EstadoServidor::new, EstadoServidor::desdeNbt, null);

    public static EstadoServidor get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, Desinformados.MOD_ID);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        nbt.putInt("fase", fase);
        nbt.putInt("radioSpawn", radioSpawn);
        NbtList lista = new NbtList();
        muertos.forEach((uuid, nombre) -> {
            NbtCompound c = new NbtCompound();
            c.putUuid("uuid", uuid);
            c.putString("nombre", nombre);
            lista.add(c);
        });
        nbt.put("muertos", lista);
        return nbt;
    }

    private static EstadoServidor desdeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        EstadoServidor e = new EstadoServidor();
        if (nbt.contains("fase")) e.fase = nbt.getInt("fase");
        if (nbt.contains("radioSpawn")) e.radioSpawn = nbt.getInt("radioSpawn");
        NbtList lista = nbt.getList("muertos", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < lista.size(); i++) {
            NbtCompound c = lista.getCompound(i);
            e.muertos.put(c.getUuid("uuid"), c.getString("nombre"));
        }
        return e;
    }

    public Map<UUID, String> getMuertos() { return muertos; }
    public boolean estaMuerto(UUID uuid) { return muertos.containsKey(uuid); }

    public void agregarMuerto(UUID uuid, String nombre) {
        muertos.put(uuid, nombre);
        markDirty();
    }

    public String quitarMuerto(UUID uuid) {
        String nombre = muertos.remove(uuid);
        markDirty();
        return nombre;
    }

    public UUID buscarMuerto(String nombre) {
        for (var e : muertos.entrySet()) {
            if (e.getValue().equalsIgnoreCase(nombre)) return e.getKey();
        }
        return null;
    }

    public int getFase() { return fase; }
    public void setFase(int fase) { this.fase = fase; markDirty(); }
    public int getRadioSpawn() { return radioSpawn; }
    public void setRadioSpawn(int radio) { this.radioSpawn = radio; markDirty(); }
}

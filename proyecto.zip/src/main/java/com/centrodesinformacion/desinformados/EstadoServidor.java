package com.centrodesinformacion.desinformados;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.nbt.NbtString;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Datos guardados en el mundo: fase de minerales, radio del spawn y jugadores muertos. */
public class EstadoServidor extends PersistentState {
    private final Map<UUID, String> muertos = new LinkedHashMap<>();
    private final Map<UUID, Integer> rojos = new HashMap<>();
    private final Map<UUID, Float> almas = new HashMap<>();
    private final Set<String> cambios = new HashSet<>();
    private final Set<String> mobsBloqueados = new HashSet<>(Set.of("desinformados:creeper_oscuro"));
    private final Set<String> mobsDesbloqueados = new HashSet<>();
    public static final int VIDAS_BASE = 2;
    private final Map<UUID, Integer> vidas = new HashMap<>();
    private final Set<String> restaurar = new HashSet<>();
    private final Map<String, String> misionesActivas = new LinkedHashMap<>(); // id -> "diaria" | "secundaria"
    private final Map<String, Set<UUID>> misionesHechas = new HashMap<>();
    private final Map<UUID, Integer> saldos = new HashMap<>();
    private final Map<UUID, String> pasivas = new HashMap<>();          // compradas, separadas por comas
    private final Map<UUID, String> pasivasApagadas = new HashMap<>();  // desactivadas con la tecla K
    private final Set<Long> telesPortal = new HashSet<>();
    /** Bloques de obra colocados: "dimension|posicion". */
    private final Set<String> obras = new HashSet<>();
    private int fase = 1;
    private int radioSpawn = 32;
    private Long centroProtegido = null;   // null = el spawn del mundo

    public static final PersistentState.Type<EstadoServidor> TYPE =
            new PersistentState.Type<>(EstadoServidor::new, EstadoServidor::desdeNbt, null);

    public static EstadoServidor get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, Desinformados.MOD_ID);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        nbt.putInt("fase", fase);
        nbt.putInt("radioSpawn", radioSpawn);
        if (centroProtegido != null) nbt.putLong("centroProtegido", centroProtegido);
        NbtList lista = new NbtList();
        muertos.forEach((uuid, nombre) -> {
            NbtCompound c = new NbtCompound();
            c.putUuid("uuid", uuid);
            c.putString("nombre", nombre);
            lista.add(c);
        });
        nbt.put("muertos", lista);
        nbt.put("rojos", mapaANbt(rojos));
        nbt.put("cambios", setANbt(cambios));
        NbtCompound mis = new NbtCompound();
        misionesActivas.forEach((id, tipo) -> {
            NbtCompound c = new NbtCompound();
            c.putString("tipo", tipo);
            NbtList hechos = new NbtList();
            for (UUID u : misionesHechas.getOrDefault(id, Set.of())) hechos.add(NbtString.of(u.toString()));
            c.put("hechos", hechos);
            mis.put(id, c);
        });
        nbt.put("misiones", mis);
        nbt.put("vidas", mapaANbt(vidas));
        nbt.put("saldos", mapaANbt(saldos));
        NbtCompound np = new NbtCompound();
        pasivas.forEach((u, v) -> np.putString(u.toString(), v));
        nbt.put("pasivas", np);
        NbtCompound na = new NbtCompound();
        pasivasApagadas.forEach((u, v) -> na.putString(u.toString(), v));
        nbt.put("pasivasApagadas", na);
        nbt.putLongArray("telesPortal", new java.util.ArrayList<>(telesPortal));
        NbtList listaObras = new NbtList();
        for (String o : obras) listaObras.add(net.minecraft.nbt.NbtString.of(o));
        nbt.put("obras", listaObras);
        nbt.put("restaurar", setANbt(restaurar));
        nbt.put("mobsBloqueados", setANbt(mobsBloqueados));
        nbt.put("mobsDesbloqueados", setANbt(mobsDesbloqueados));
        NbtCompound a = new NbtCompound();
        almas.forEach((uuid, valor) -> a.putFloat(uuid.toString(), valor));
        nbt.put("almas", a);
        return nbt;
    }

    private static EstadoServidor desdeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        EstadoServidor e = new EstadoServidor();
        if (nbt.contains("fase")) e.fase = nbt.getInt("fase");
        if (nbt.contains("radioSpawn")) e.radioSpawn = nbt.getInt("radioSpawn");
        if (nbt.contains("centroProtegido")) e.centroProtegido = nbt.getLong("centroProtegido");
        NbtList lista = nbt.getList("muertos", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < lista.size(); i++) {
            NbtCompound c = lista.getCompound(i);
            e.muertos.put(c.getUuid("uuid"), c.getString("nombre"));
        }
        nbtAMapa(nbt.getCompound("rojos"), e.rojos);
        nbtASet(nbt, "cambios", e.cambios);
        NbtCompound mis = nbt.getCompound("misiones");
        for (String id : mis.getKeys()) {
            NbtCompound c = mis.getCompound(id);
            e.misionesActivas.put(id, c.getString("tipo"));
            Set<UUID> hechos = new HashSet<>();
            NbtList l = c.getList("hechos", NbtElement.STRING_TYPE);
            for (int i = 0; i < l.size(); i++) hechos.add(UUID.fromString(l.getString(i)));
            e.misionesHechas.put(id, hechos);
        }
        nbtAMapa(nbt.getCompound("vidas"), e.vidas);
        nbtAMapa(nbt.getCompound("saldos"), e.saldos);
        NbtCompound np = nbt.getCompound("pasivas");
        for (String k : np.getKeys()) e.pasivas.put(UUID.fromString(k), np.getString(k));
        NbtCompound na = nbt.getCompound("pasivasApagadas");
        for (String k : na.getKeys()) e.pasivasApagadas.put(UUID.fromString(k), na.getString(k));
        for (long l : nbt.getLongArray("telesPortal")) e.telesPortal.add(l);
        NbtList listaObras = nbt.getList("obras", NbtElement.STRING_TYPE);
        for (int i = 0; i < listaObras.size(); i++) e.obras.add(listaObras.getString(i));
        nbtASet(nbt, "restaurar", e.restaurar);
        if (nbt.contains("mobsBloqueados")) { e.mobsBloqueados.clear(); nbtASet(nbt, "mobsBloqueados", e.mobsBloqueados); }
        nbtASet(nbt, "mobsDesbloqueados", e.mobsDesbloqueados);
        NbtCompound a = nbt.getCompound("almas");
        for (String clave : a.getKeys()) e.almas.put(UUID.fromString(clave), a.getFloat(clave));
        return e;
    }

    private static NbtCompound mapaANbt(Map<UUID, Integer> mapa) {
        NbtCompound c = new NbtCompound();
        mapa.forEach((uuid, valor) -> c.putInt(uuid.toString(), valor));
        return c;
    }

    private static void nbtAMapa(NbtCompound c, Map<UUID, Integer> mapa) {
        for (String clave : c.getKeys()) mapa.put(UUID.fromString(clave), c.getInt(clave));
    }

    private static NbtList setANbt(Set<String> set) {
        NbtList lista = new NbtList();
        for (String s : set) lista.add(NbtString.of(s));
        return lista;
    }

    private static void nbtASet(NbtCompound nbt, String clave, Set<String> set) {
        NbtList lista = nbt.getList(clave, NbtElement.STRING_TYPE);
        for (int i = 0; i < lista.size(); i++) set.add(lista.getString(i));
    }

    // Teles portal del spawn
    public Set<Long> getTelesPortal() { return telesPortal; }
    public void agregarTelePortal(long l) { telesPortal.add(l); markDirty(); }
    public void quitarTelePortal(long l) { if (telesPortal.remove(l)) markDirty(); }
    public Set<String> getObras() { return obras; }
    public void agregarObra(String o) { if (obras.add(o)) markDirty(); }
    public void quitarObra(String o) { if (obras.remove(o)) markDirty(); }

    // Banco de Rumores
    public int getSaldo(UUID uuid) { return saldos.getOrDefault(uuid, 0); }
    public void setSaldo(UUID uuid, int n) { saldos.put(uuid, Math.max(0, n)); markDirty(); }
    public String getPasivas(UUID uuid) { return pasivas.getOrDefault(uuid, ""); }
    public void setPasivas(UUID uuid, String s) { pasivas.put(uuid, s); markDirty(); }
    public String getPasivasApagadas(UUID uuid) { return pasivasApagadas.getOrDefault(uuid, ""); }
    public void setPasivasApagadas(UUID uuid, String s) { pasivasApagadas.put(uuid, s); markDirty(); }

    // Vidas (2 por defecto)
    public int getVidas(UUID uuid) { return vidas.getOrDefault(uuid, VIDAS_BASE); }
    public void setVidas(UUID uuid, int n) { vidas.put(uuid, n); markDirty(); }

    // Revividos que deben volver a supervivencia al entrar
    public boolean debeRestaurar(UUID uuid) { return restaurar.contains(uuid.toString()); }
    public void marcarRestaurar(UUID uuid, boolean si) {
        if (si) restaurar.add(uuid.toString()); else restaurar.remove(uuid.toString());
        markDirty();
    }

    // Misiones
    public Map<String, String> getMisionesActivas() { return misionesActivas; }
    public void activarMision(String id, String tipo) { misionesActivas.put(id, tipo); misionesHechas.computeIfAbsent(id, k -> new HashSet<>()); markDirty(); }
    public boolean quitarMision(String id) { misionesHechas.remove(id); boolean ok = misionesActivas.remove(id) != null; markDirty(); return ok; }
    public void limpiarMisiones() { misionesActivas.clear(); misionesHechas.clear(); markDirty(); }
    public boolean misionCompletada(String id, UUID u) { return misionesHechas.getOrDefault(id, Set.of()).contains(u); }
    public void completarMision(String id, UUID u) { misionesHechas.computeIfAbsent(id, k -> new HashSet<>()).add(u); markDirty(); }

    // Cambios de dificultad permanentes
    public boolean tieneCambio(String id) { return cambios.contains(id); }
    public void agregarCambio(String id) { cambios.add(id); markDirty(); }
    public boolean quitarCambio(String id) { boolean ok = cambios.remove(id); markDirty(); return ok; }
    public Set<String> getCambios() { return cambios; }

    // Mobs
    public Set<String> getMobsBloqueados() { return mobsBloqueados; }
    public Set<String> getMobsDesbloqueados() { return mobsDesbloqueados; }
    public void bloquearMob(String id) { mobsBloqueados.add(id); mobsDesbloqueados.remove(id); markDirty(); }
    public void desbloquearMob(String id) { mobsBloqueados.remove(id); mobsDesbloqueados.add(id); markDirty(); }

    public int getRojos(UUID uuid) { return rojos.getOrDefault(uuid, 0); }
    public void setRojos(UUID uuid, int valor) { rojos.put(uuid, valor); markDirty(); }
    /** Puntos de alma (2 = 1 corazón azul). */
    public float getAlmas(UUID uuid) { return almas.getOrDefault(uuid, 0f); }
    public void setAlmas(UUID uuid, float valor) { almas.put(uuid, valor); markDirty(); }

    public Map<UUID, String> getMuertos() { return muertos; }
    public boolean estaMuerto(UUID uuid) { return muertos.containsKey(uuid); }

    public void agregarMuerto(UUID uuid, String nombre) {
        muertos.put(uuid, nombre);
        markDirty();
    }

    public String quitarMuerto(UUID uuid) {
        String nombre = muertos.remove(uuid);
        markDirty();
        return nombre;
    }

    public UUID buscarMuerto(String nombre) {
        for (var e : muertos.entrySet()) {
            if (e.getValue().equalsIgnoreCase(nombre)) return e.getKey();
        }
        return null;
    }

    public int getFase() { return fase; }
    public void setFase(int fase) { this.fase = fase; markDirty(); }
    public int getRadioSpawn() { return radioSpawn; }
    public void setRadioSpawn(int radio) { this.radioSpawn = radio; markDirty(); }
    public Long getCentroProtegido() { return centroProtegido; }
    public void setCentroProtegido(Long pos) { this.centroProtegido = pos; markDirty(); }
}

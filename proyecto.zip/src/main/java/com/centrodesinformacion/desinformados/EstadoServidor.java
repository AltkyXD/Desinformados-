package com.centrodesinformacion.desinformados;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.nbt.NbtString;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Datos guardados en el mundo: fase de minerales, radio del spawn y jugadores muertos. */
public class EstadoServidor extends PersistentState {
    private final Map<UUID, String> muertos = new LinkedHashMap<>();
    private final Map<UUID, Integer> rojos = new HashMap<>();
    private final Map<UUID, Float> almas = new HashMap<>();
    private final Set<String> cambios = new HashSet<>();
    private final Set<String> mobsBloqueados = new HashSet<>(Set.of("desinformados:creeper_oscuro"));
    private final Set<String> mobsDesbloqueados = new HashSet<>();
    public static final int VIDAS_BASE = 2;
    private final Map<UUID, Integer> vidas = new HashMap<>();
    private final Set<String> restaurar = new HashSet<>();
    private final Map<String, Set<UUID>> misionesHechas = new HashMap<>();      // misión -> jugadores que la completaron
    private final Map<UUID, String> jugadoresSerie = new LinkedHashMap<>();      // todos los que han entrado alguna vez (uuid -> nombre)
    private final Map<String, Integer> contadores = new HashMap<>();              // "uuid|clave" -> número (misiones secundarias)
    private final Map<String, Integer> relojes = new HashMap<>();                 // cuentas atrás guardadas (ticks de juego)
    private final Set<String> premiosPendientes = new HashSet<>();                // "mision|uuid": premios de grupo para los que no estaban
    private final Map<UUID, Integer> saldos = new HashMap<>();
    private final Map<UUID, String> pasivas = new HashMap<>();          // compradas, separadas por comas
    private final Map<UUID, String> pasivasApagadas = new HashMap<>();  // desactivadas con la tecla I
    private final Set<Long> telesPortal = new HashSet<>();
    /** Bloques de obra colocados: "dimension|posicion". */
    private final Set<String> obras = new HashSet<>();
    private int fase = 1;
    private int radioSpawn = 32;
    private Long centroProtegido = null;   // null = el spawn del mundo
    /** Teles automáticas: activas o en pausa, cada cuánto (al azar entre mínimo y máximo, en ticks) y cuánto falta para la próxima. */
    private boolean autoActivo = false;
    private int autoIntervalo = 20 * 60 * 20;   // mínimo
    private int autoMaximo = 20 * 60 * 40;
    private int autoRestante = 20 * 60 * 30;
    /** Desafíos rojos automáticos: cuánto falta para el próximo y su rango al azar (ticks). */
    private int rojoRestante = 20 * 60 * 80;
    private int rojoMinimo = 20 * 60 * 30;
    private int rojoMaximo = 20 * 60 * 60;

    public static final PersistentState.Type<EstadoServidor> TYPE =
            new PersistentState.Type<>(EstadoServidor::new, EstadoServidor::desdeNbt, null);

    public static EstadoServidor get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, Desinformados.MOD_ID);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        nbt.putInt("fase", fase);
        nbt.putInt("radioSpawn", radioSpawn);
        if (centroProtegido != null) nbt.putLong("centroProtegido", centroProtegido);
        NbtList lista = new NbtList();
        muertos.forEach((uuid, nombre) -> {
            NbtCompound c = new NbtCompound();
            c.putUuid("uuid", uuid);
            c.putString("nombre", nombre);
            lista.add(c);
        });
        nbt.put("muertos", lista);
        nbt.put("rojos", mapaANbt(rojos));
        nbt.put("cambios", setANbt(cambios));
        NbtCompound mis = new NbtCompound();
        misionesHechas.forEach((id, quienes) -> {
            NbtList hechos = new NbtList();
            for (UUID u : quienes) hechos.add(NbtString.of(u.toString()));
            mis.put(id, hechos);
        });
        nbt.put("misionesHechas", mis);
        NbtCompound js = new NbtCompound();
        jugadoresSerie.forEach((u, n) -> js.putString(u.toString(), n));
        nbt.put("jugadoresSerie", js);
        NbtCompound cont = new NbtCompound();
        contadores.forEach(cont::putInt);
        nbt.put("contadores", cont);
        NbtCompound rel = new NbtCompound();
        relojes.forEach(rel::putInt);
        nbt.put("relojes", rel);
        nbt.put("premiosPendientes", setANbt(premiosPendientes));
        nbt.put("vidas", mapaANbt(vidas));
        nbt.put("saldos", mapaANbt(saldos));
        NbtCompound np = new NbtCompound();
        pasivas.forEach((u, v) -> np.putString(u.toString(), v));
        nbt.put("pasivas", np);
        NbtCompound na = new NbtCompound();
        pasivasApagadas.forEach((u, v) -> na.putString(u.toString(), v));
        nbt.put("pasivasApagadas", na);
        nbt.putLongArray("telesPortal", new java.util.ArrayList<>(telesPortal));
        NbtList listaObras = new NbtList();
        for (String o : obras) listaObras.add(net.minecraft.nbt.NbtString.of(o));
        nbt.put("obras", listaObras);
        nbt.putBoolean("autoActivo", autoActivo);
        nbt.putInt("autoMinimo", autoIntervalo);
        nbt.putInt("autoMaximo", autoMaximo);
        nbt.putInt("autoRestante", autoRestante);
        nbt.putInt("rojoRestante", rojoRestante);
        nbt.putInt("rojoMinimo", rojoMinimo);
        nbt.putInt("rojoMaximo", rojoMaximo);
        nbt.put("restaurar", setANbt(restaurar));
        nbt.put("mobsBloqueados", setANbt(mobsBloqueados));
        nbt.put("mobsDesbloqueados", setANbt(mobsDesbloqueados));
        NbtCompound a = new NbtCompound();
        almas.forEach((uuid, valor) -> a.putFloat(uuid.toString(), valor));
        nbt.put("almas", a);
        return nbt;
    }

    private static EstadoServidor desdeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registros) {
        EstadoServidor e = new EstadoServidor();
        if (nbt.contains("fase")) e.fase = nbt.getInt("fase");
        if (nbt.contains("radioSpawn")) e.radioSpawn = nbt.getInt("radioSpawn");
        if (nbt.contains("centroProtegido")) e.centroProtegido = nbt.getLong("centroProtegido");
        NbtList lista = nbt.getList("muertos", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < lista.size(); i++) {
            NbtCompound c = lista.getCompound(i);
            e.muertos.put(c.getUuid("uuid"), c.getString("nombre"));
        }
        nbtAMapa(nbt.getCompound("rojos"), e.rojos);
        nbtASet(nbt, "cambios", e.cambios);
        NbtCompound mis = nbt.getCompound("misionesHechas");      // (las misiones diarias viejas, "misiones", ya no se cargan)
        for (String id : mis.getKeys()) {
            Set<UUID> hechos = new HashSet<>();
            NbtList l = mis.getList(id, NbtElement.STRING_TYPE);
            for (int i = 0; i < l.size(); i++) hechos.add(UUID.fromString(l.getString(i)));
            e.misionesHechas.put(id, hechos);
        }
        NbtCompound js = nbt.getCompound("jugadoresSerie");
        for (String k : js.getKeys()) e.jugadoresSerie.put(UUID.fromString(k), js.getString(k));
        NbtCompound cont = nbt.getCompound("contadores");
        for (String k : cont.getKeys()) e.contadores.put(k, cont.getInt(k));
        NbtCompound rel = nbt.getCompound("relojes");
        for (String k : rel.getKeys()) e.relojes.put(k, rel.getInt(k));
        nbtASet(nbt, "premiosPendientes", e.premiosPendientes);
        nbtAMapa(nbt.getCompound("vidas"), e.vidas);
        nbtAMapa(nbt.getCompound("saldos"), e.saldos);
        NbtCompound np = nbt.getCompound("pasivas");
        for (String k : np.getKeys()) e.pasivas.put(UUID.fromString(k), np.getString(k));
        NbtCompound na = nbt.getCompound("pasivasApagadas");
        for (String k : na.getKeys()) e.pasivasApagadas.put(UUID.fromString(k), na.getString(k));
        for (long l : nbt.getLongArray("telesPortal")) e.telesPortal.add(l);
        NbtList listaObras = nbt.getList("obras", NbtElement.STRING_TYPE);
        for (int i = 0; i < listaObras.size(); i++) e.obras.add(listaObras.getString(i));
        nbtASet(nbt, "restaurar", e.restaurar);
        if (nbt.contains("mobsBloqueados")) { e.mobsBloqueados.clear(); nbtASet(nbt, "mobsBloqueados", e.mobsBloqueados); }
        nbtASet(nbt, "mobsDesbloqueados", e.mobsDesbloqueados);
        NbtCompound a = nbt.getCompound("almas");
        for (String clave : a.getKeys()) e.almas.put(UUID.fromString(clave), a.getFloat(clave));
        if (nbt.contains("autoActivo")) e.autoActivo = nbt.getBoolean("autoActivo");
        if (nbt.contains("autoMinimo")) e.autoIntervalo = nbt.getInt("autoMinimo");
        if (nbt.contains("autoMaximo")) e.autoMaximo = nbt.getInt("autoMaximo");
        if (nbt.contains("autoRestante")) e.autoRestante = nbt.getInt("autoRestante");
        if (nbt.contains("rojoRestante")) e.rojoRestante = nbt.getInt("rojoRestante");
        if (nbt.contains("rojoMinimo")) e.rojoMinimo = nbt.getInt("rojoMinimo");
        if (nbt.contains("rojoMaximo")) e.rojoMaximo = nbt.getInt("rojoMaximo");
        return e;
    }

    private static NbtCompound mapaANbt(Map<UUID, Integer> mapa) {
        NbtCompound c = new NbtCompound();
        mapa.forEach((uuid, valor) -> c.putInt(uuid.toString(), valor));
        return c;
    }

    private static void nbtAMapa(NbtCompound c, Map<UUID, Integer> mapa) {
        for (String clave : c.getKeys()) mapa.put(UUID.fromString(clave), c.getInt(clave));
    }

    private static NbtList setANbt(Set<String> set) {
        NbtList lista = new NbtList();
        for (String s : set) lista.add(NbtString.of(s));
        return lista;
    }

    private static void nbtASet(NbtCompound nbt, String clave, Set<String> set) {
        NbtList lista = nbt.getList(clave, NbtElement.STRING_TYPE);
        for (int i = 0; i < lista.size(); i++) set.add(lista.getString(i));
    }

    // Teles portal del spawn
    public Set<Long> getTelesPortal() { return telesPortal; }
    public void agregarTelePortal(long l) { telesPortal.add(l); markDirty(); }
    public void quitarTelePortal(long l) { if (telesPortal.remove(l)) markDirty(); }
    public Set<String> getObras() { return obras; }
    public void agregarObra(String o) { if (obras.add(o)) markDirty(); }
    public void quitarObra(String o) { if (obras.remove(o)) markDirty(); }

    // Banco de Rumores
    public int getSaldo(UUID uuid) { return saldos.getOrDefault(uuid, 0); }
    public void setSaldo(UUID uuid, int n) { saldos.put(uuid, Math.max(0, n)); markDirty(); }
    public String getPasivas(UUID uuid) { return pasivas.getOrDefault(uuid, ""); }
    public void setPasivas(UUID uuid, String s) { pasivas.put(uuid, s); markDirty(); }
    public String getPasivasApagadas(UUID uuid) { return pasivasApagadas.getOrDefault(uuid, ""); }
    public void setPasivasApagadas(UUID uuid, String s) { pasivasApagadas.put(uuid, s); markDirty(); }

    // Vidas (2 por defecto)
    public int getVidas(UUID uuid) { return vidas.getOrDefault(uuid, VIDAS_BASE); }
    public void setVidas(UUID uuid, int n) { vidas.put(uuid, n); markDirty(); }

    // Revividos que deben volver a supervivencia al entrar
    public boolean debeRestaurar(UUID uuid) { return restaurar.contains(uuid.toString()); }
    public void marcarRestaurar(UUID uuid, boolean si) {
        if (si) restaurar.add(uuid.toString()); else restaurar.remove(uuid.toString());
        markDirty();
    }

    // Misiones
    public boolean misionCompletada(String id, UUID u) { return misionesHechas.getOrDefault(id, Set.of()).contains(u); }
    public void completarMision(String id, UUID u) { misionesHechas.computeIfAbsent(id, k -> new HashSet<>()).add(u); markDirty(); }
    public Set<UUID> completaronMision(String id) { return misionesHechas.getOrDefault(id, Set.of()); }
    public void limpiarMisiones() { misionesHechas.clear(); contadores.clear(); premiosPendientes.clear(); markDirty(); }

    // Jugadores de la serie (para el 75 % de las misiones principales)
    public Map<UUID, String> getJugadoresSerie() { return jugadoresSerie; }
    public void registrarJugador(UUID u, String nombre) { if (!nombre.equals(jugadoresSerie.put(u, nombre))) markDirty(); }
    /** Lo saca de la cuenta del 75 % (por si entró alguien que no juega la serie). Vuelve a contar si entra jugando. */
    public boolean quitarJugadorSerie(String nombre) {
        boolean ok = jugadoresSerie.values().removeIf(n -> n.equalsIgnoreCase(nombre));
        if (ok) markDirty();
        return ok;
    }

    // Contadores por jugador (misiones secundarias)
    public int getContador(UUID u, String clave) { return contadores.getOrDefault(u + "|" + clave, 0); }
    public void setContador(UUID u, String clave, int n) { contadores.put(u + "|" + clave, n); markDirty(); }
    public int sumarContador(UUID u, String clave, int n) { int v = getContador(u, clave) + n; setContador(u, clave, v); return v; }
    /** Cuántas claves de este jugador empiezan por ese prefijo (p. ej. los gatos con los que ha hablado). */
    public int contarClaves(UUID u, String prefijo) {
        String p = u + "|" + prefijo;
        int n = 0;
        for (String k : contadores.keySet()) if (k.startsWith(p)) n++;
        return n;
    }

    // Cuentas atrás guardadas en el mundo (en ticks de juego)
    public int getReloj(String id) { return relojes.getOrDefault(id, -1); }
    public void setReloj(String id, int ticks) { relojes.put(id, ticks); markDirty(); }
    public void quitarReloj(String id) { if (relojes.remove(id) != null) markDirty(); }

    // Premios de las misiones de grupo para los que no estaban conectados
    public Set<String> getPremiosPendientes() { return premiosPendientes; }
    public void agregarPremioPendiente(String clave) { if (premiosPendientes.add(clave)) markDirty(); }
    public boolean quitarPremioPendiente(String clave) { boolean ok = premiosPendientes.remove(clave); if (ok) markDirty(); return ok; }

    // Cambios de dificultad permanentes
    public boolean tieneCambio(String id) { return cambios.contains(id); }
    public void agregarCambio(String id) { cambios.add(id); markDirty(); }
    public boolean quitarCambio(String id) { boolean ok = cambios.remove(id); markDirty(); return ok; }
    public Set<String> getCambios() { return cambios; }

    // Mobs
    public Set<String> getMobsBloqueados() { return mobsBloqueados; }
    public Set<String> getMobsDesbloqueados() { return mobsDesbloqueados; }
    public void bloquearMob(String id) { mobsBloqueados.add(id); mobsDesbloqueados.remove(id); markDirty(); }
    public void desbloquearMob(String id) { mobsBloqueados.remove(id); mobsDesbloqueados.add(id); markDirty(); }

    public int getRojos(UUID uuid) { return rojos.getOrDefault(uuid, 0); }
    public void setRojos(UUID uuid, int valor) { rojos.put(uuid, valor); markDirty(); }
    /** Puntos de alma (2 = 1 corazón azul). */
    public float getAlmas(UUID uuid) { return almas.getOrDefault(uuid, 0f); }
    public void setAlmas(UUID uuid, float valor) { almas.put(uuid, valor); markDirty(); }

    public Map<UUID, String> getMuertos() { return muertos; }
    public boolean estaMuerto(UUID uuid) { return muertos.containsKey(uuid); }

    public void agregarMuerto(UUID uuid, String nombre) {
        muertos.put(uuid, nombre);
        markDirty();
    }

    public String quitarMuerto(UUID uuid) {
        String nombre = muertos.remove(uuid);
        markDirty();
        return nombre;
    }

    public UUID buscarMuerto(String nombre) {
        for (var e : muertos.entrySet()) {
            if (e.getValue().equalsIgnoreCase(nombre)) return e.getKey();
        }
        return null;
    }

    public int getFase() { return fase; }
    public void setFase(int fase) { this.fase = fase; markDirty(); }
    public boolean isAutoActivo() { return autoActivo; }
    public void setAutoActivo(boolean v) { autoActivo = v; markDirty(); }
    public int getAutoMinimo() { return autoIntervalo; }
    public int getAutoMaximo() { return autoMaximo; }
    public void setAutoRango(int minimo, int maximo) { autoIntervalo = minimo; autoMaximo = Math.max(minimo, maximo); markDirty(); }
    public int getAutoRestante() { return autoRestante; }
    public void setAutoRestante(int ticks) { autoRestante = ticks; markDirty(); }
    public int getRojoRestante() { return rojoRestante; }
    public void setRojoRestante(int ticks) { rojoRestante = ticks; markDirty(); }
    public int getRojoMinimo() { return rojoMinimo; }
    public int getRojoMaximo() { return rojoMaximo; }
    public void setRojoRango(int minimo, int maximo) { rojoMinimo = minimo; rojoMaximo = Math.max(minimo, maximo); markDirty(); }

    public int getRadioSpawn() { return radioSpawn; }
    public void setRadioSpawn(int radio) { this.radioSpawn = radio; markDirty(); }
    public Long getCentroProtegido() { return centroProtegido; }
    public void setCentroProtegido(Long pos) { this.centroProtegido = pos; markDirty(); }
}

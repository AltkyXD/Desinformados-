package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModVariantes3;

import java.util.List;
import java.util.Map;

/** Teles azules de las variantes de los mobs del mod (parte 2 de 2): cada una desbloquea su variante. */
public final class TelesVariantes3 {
    private TelesVariantes3() {}

    /** Ids de las teles (= ids de los mobs), en el orden en que deberían salir (las dos últimas son del Nether). */
    public static final List<String> IDS = List.of(
            "creeper_ceniza", "esqueleto_fuego");

    /** Para la Enciclopedia: nombre corto del mob de cada tele. */
    public static final Map<String, String> NOMBRES = Map.ofEntries(
            Map.entry("creeper_ceniza", "Creeper de Ceniza"),
            Map.entry("esqueleto_fuego", "Esqueleto de Fuego"));

    /** Crea las teles (lo llama Eventos al cargar). Se vuelven azules solas al estar en GRUPO_MOBS. */
    static void eventos() {
        Eventos.amarillo("creeper_ceniza", "¡Llega el Creeper de Ceniza!",
                "Aparecerá en lugares oscuros de cualquier bioma del Nether. Explota como un Creeper de Fuego (te prende fuego "
                        + "y deja llamas alrededor), pero además deja una nube de humo y ceniza durante 10 segundos: mientras estés dentro, "
                        + "Ceguera durante 4 segundos y Debilidad durante 8 segundos (se renuevan cada medio segundo).",
                "Un Creeper de Fuego ardió tanto que de él solo quedó la ceniza. El Centro de Desinformación lo iba a tirar, "
                        + "pero el contenedor de orgánico estaba lleno. Sigue explotando igual, pero ahora además lo deja todo perdido de humo.",
                server -> Eventos.desbloquearMob(server, ModVariantes3.CREEPER_CENIZA));

        Eventos.amarillo("esqueleto_fuego", "¡Llega el Esqueleto de Fuego!",
                "Aparecerá en lugares oscuros de cualquier bioma del Nether. No le hace nada el fuego ni la lava, va soltando llamas "
                        + "y todas sus flechas salen ardiendo: si te dan, te prenden fuego 5 segundos. Mejor llevar Resistencia al fuego.",
                "El Esqueleto Ráfaga se pasó tanto tiempo cerca de la lava que acabó prendiéndose. El Centro de Desinformación "
                        + "le ofreció un extintor, pero dice que así está más calentito y que las flechas le salen \"más crujientes\".",
                server -> Eventos.desbloquearMob(server, ModVariantes3.ESQUELETO_FUEGO));
    }
}

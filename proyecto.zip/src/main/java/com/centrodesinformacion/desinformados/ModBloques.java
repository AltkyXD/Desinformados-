package com.centrodesinformacion.desinformados;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public class ModBloques {
    /** Irrompible en supervivencia (como la piedra base); en creativo sí se puede quitar. */
    public static final Block BANCO = Registry.register(Registries.BLOCK, Desinformados.id("banco_rumores"),
            new BancoBlock(AbstractBlock.Settings.create().mapColor(MapColor.EMERALD_GREEN)
                    .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing()));

    public static final Item BANCO_ITEM = Registry.register(Registries.ITEM, Desinformados.id("banco_rumores"),
            new BlockItem(BANCO, new Item.Settings()));

    public static void inicializar() {
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public class ModBloques {
    /** Irrompible en supervivencia (como la piedra base); en creativo sí se puede quitar. */
    public static final Block BANCO = Registry.register(Registries.BLOCK, Desinformados.id("banco_rumores"),
            new BancoBlock(AbstractBlock.Settings.create().mapColor(MapColor.EMERALD_GREEN)
                    .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing()));

    public static final Item BANCO_ITEM = Registry.register(Registries.ITEM, Desinformados.id("banco_rumores"),
            new BlockItem(BANCO, new Item.Settings()));

    public static final Block TRAGAMONEDAS_AZUL = tragamonedas(Tragamonedas.Rareza.AZUL);
    public static final Block TRAGAMONEDAS_MORADA = tragamonedas(Tragamonedas.Rareza.MORADA);
    public static final Block TRAGAMONEDAS_GRIS = tragamonedas(Tragamonedas.Rareza.GRIS);

    private static Block tragamonedas(Tragamonedas.Rareza r) {
        Block b = Registry.register(Registries.BLOCK, Desinformados.id("tragamonedas_" + r.id),
                new TragamonedasBlock(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY)
                        .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing().nonOpaque().luminance(s -> 6), r));
        Registry.register(Registries.ITEM, Desinformados.id("tragamonedas_" + r.id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    public static void inicializar() {
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public class ModBloques {
    /** Irrompible en supervivencia (como la piedra base); en creativo sí se puede quitar. */
    public static final Block BANCO = Registry.register(Registries.BLOCK, Desinformados.id("banco_rumores"),
            new BancoBlock(AbstractBlock.Settings.create().mapColor(MapColor.EMERALD_GREEN)
                    .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing()));

    public static final Item BANCO_ITEM = Registry.register(Registries.ITEM, Desinformados.id("banco_rumores"),
            new BlockItem(BANCO, new Item.Settings()));

    public static final Block TRAGAMONEDAS_AZUL = tragamonedas(Tragamonedas.Rareza.AZUL);
    public static final Block TRAGAMONEDAS_MORADA = tragamonedas(Tragamonedas.Rareza.MORADA);
    public static final Block TRAGAMONEDAS_GRIS = tragamonedas(Tragamonedas.Rareza.GRIS);

    private static Block tragamonedas(Tragamonedas.Rareza r) {
        Block b = Registry.register(Registries.BLOCK, Desinformados.id("tragamonedas_" + r.id),
                new TragamonedasBlock(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY)
                        .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing().nonOpaque().luminance(s -> 6), r));
        Registry.register(Registries.ITEM, Desinformados.id("tragamonedas_" + r.id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    // ---------- Dimensiones ----------
    private static Block bloque(String id, Block b, boolean conItem) {
        Registry.register(Registries.BLOCK, Desinformados.id(id), b);
        if (conItem) Registry.register(Registries.ITEM, Desinformados.id(id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    private static AbstractBlock.Settings irrompible() {
        return AbstractBlock.Settings.create().strength(-1.0f, 3600000.0f).dropsNothing();
    }

    public static final Block BLOQUE_ESTATICA = bloque("bloque_estatica", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.LIGHT_GRAY).strength(1.5f, 6f).requiresTool().sounds(BlockSoundGroup.TUFF)), true);
    public static final Block MINERAL_ESTATICA = bloque("mineral_estatica", new net.minecraft.block.ExperienceDroppingBlock(
            net.minecraft.util.math.intprovider.UniformIntProvider.create(2, 5),
            AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_GRAY).strength(3f, 3f).requiresTool().luminance(s -> 4)), true);
    public static final Block PARED_OFICINA = bloque("pared_oficina", new Block(irrompible().mapColor(MapColor.PALE_YELLOW).sounds(BlockSoundGroup.WOOD)), true);
    public static final Block TECHO_OFICINA = bloque("techo_oficina", new Block(irrompible().mapColor(MapColor.WHITE_GRAY)), true);
    public static final Block MOQUETA = bloque("moqueta", new Block(irrompible().mapColor(MapColor.GRAY).sounds(BlockSoundGroup.WOOL)), true);
    public static final Block PILA_PERIODICOS = bloque("pila_periodicos", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(0.4f).sounds(BlockSoundGroup.WOOL)), true);
    public static final Block TELE_PORTAL = bloque("tele_portal", new com.centrodesinformacion.desinformados.dimension.TelePortalBlock(
            irrompible().mapColor(MapColor.BROWN).sounds(BlockSoundGroup.WOOD).luminance(s -> 7).nonOpaque()), true);
    public static final Block PUERTA_OFICINA = bloque("puerta_oficina", new com.centrodesinformacion.desinformados.dimension.PuertaBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.OAK_TAN).strength(2f, 6f).sounds(BlockSoundGroup.WOOD),
            com.centrodesinformacion.desinformados.dimension.Dimensiones.REDACCION), true);
    public static final Block SALIDA_TELE = bloque("salida_tele", new com.centrodesinformacion.desinformados.dimension.PuertaBlock(
            irrompible().mapColor(MapColor.BROWN).luminance(s -> 12),
            com.centrodesinformacion.desinformados.dimension.Dimensiones.TELE), true);

    public static void inicializar() {
        Registry.register(Registries.FEATURE, Desinformados.id("oficina"),
                new com.centrodesinformacion.desinformados.dimension.OficinaFeature(net.minecraft.world.gen.feature.DefaultFeatureConfig.CODEC));
        Registry.register(Registries.FEATURE, Desinformados.id("cofre_tele"),
                new com.centrodesinformacion.desinformados.dimension.CofreFeature(net.minecraft.world.gen.feature.DefaultFeatureConfig.CODEC));
    }
}

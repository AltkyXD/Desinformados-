package com.centrodesinformacion.desinformados;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public class ModBloques {
    /** Irrompible en supervivencia (como la piedra base); en creativo sí se puede quitar. */
    public static final Block BANCO = Registry.register(Registries.BLOCK, Desinformados.id("banco_rumores"),
            new BancoBlock(AbstractBlock.Settings.create().mapColor(MapColor.EMERALD_GREEN)
                    .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing()));

    public static final Item BANCO_ITEM = Registry.register(Registries.ITEM, Desinformados.id("banco_rumores"),
            new BlockItem(BANCO, new Item.Settings()));

    public static final Block TRAGAMONEDAS_AZUL = tragamonedas(Tragamonedas.Rareza.AZUL);
    public static final Block TRAGAMONEDAS_MORADA = tragamonedas(Tragamonedas.Rareza.MORADA);
    public static final Block TRAGAMONEDAS_GRIS = tragamonedas(Tragamonedas.Rareza.GRIS);

    private static Block tragamonedas(Tragamonedas.Rareza r) {
        Block b = Registry.register(Registries.BLOCK, Desinformados.id("tragamonedas_" + r.id),
                new TragamonedasBlock(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY)
                        .strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.METAL).dropsNothing().nonOpaque().luminance(s -> 6), r));
        Registry.register(Registries.ITEM, Desinformados.id("tragamonedas_" + r.id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    // ---------- Dimensiones ----------
    private static Block bloque(String id, Block b, boolean conItem) {
        Registry.register(Registries.BLOCK, Desinformados.id(id), b);
        if (conItem) Registry.register(Registries.ITEM, Desinformados.id(id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    private static AbstractBlock.Settings irrompible() {
        return AbstractBlock.Settings.create().strength(-1.0f, 3600000.0f).dropsNothing();
    }

    public static final Block BLOQUE_ESTATICA = bloque("bloque_estatica", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.LIGHT_GRAY).strength(1.5f, 6f).requiresTool().sounds(BlockSoundGroup.TUFF)), true);
    public static final Block MINERAL_ESTATICA = bloque("mineral_estatica", new net.minecraft.block.ExperienceDroppingBlock(
            net.minecraft.util.math.intprovider.UniformIntProvider.create(2, 5),
            AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_GRAY).strength(3f, 3f).requiresTool().luminance(s -> 4)), true);
    public static final Block MURO_ESTATICA = bloque("muro_estatica", new Block(irrompible().mapColor(MapColor.LIGHT_GRAY).sounds(BlockSoundGroup.TUFF)), true);
    public static final Block GARATITA_MENA = bloque("garatita_mena", new net.minecraft.block.ExperienceDroppingBlock(
            net.minecraft.util.math.intprovider.UniformIntProvider.create(3, 7),
            AbstractBlock.Settings.create().mapColor(MapColor.STONE_GRAY).strength(3.5f, 3f).requiresTool()), true);
    public static final Block TELE_PORTAL = bloque("tele_portal", new com.centrodesinformacion.desinformados.dimension.TelePortalBlock(
            irrompible().mapColor(MapColor.BROWN).sounds(BlockSoundGroup.WOOD).luminance(s -> 7).nonOpaque()), true);
    public static final Block LIBRETA_PORTAL = bloque("libreta_portal", new com.centrodesinformacion.desinformados.dimension.LibretaBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(1f, 3f).sounds(BlockSoundGroup.WOOL).nonOpaque()), true);
    public static final Block SALIDA_TELE = bloque("salida_tele", new com.centrodesinformacion.desinformados.dimension.PuertaBlock(
            irrompible().mapColor(MapColor.BROWN).luminance(s -> 12),
            com.centrodesinformacion.desinformados.dimension.Dimensiones.TELE), true);

    /** Tele del cuarto de bienvenida (cinemática del primer día). */
    public static final Block TELE_INTRO = bloque("tele_intro", new com.centrodesinformacion.desinformados.intro.TeleIntroBlock(
            irrompible().mapColor(MapColor.BROWN).sounds(BlockSoundGroup.WOOD).luminance(s -> 6).nonOpaque()), false);

    // ---------- Construcción del Centro de Desinformación (metal) ----------
    private static AbstractBlock.Settings metal() {
        return AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY).strength(4f, 8f).requiresTool().sounds(BlockSoundGroup.METAL);
    }
    public static final Block PANEL_METAL = bloque("panel_metal", new Block(metal()), true);
    public static final Block PANEL_METAL_FRANJA = bloque("panel_metal_franja", new Block(metal()), true);
    public static final Block VIGA_ACERO = bloque("viga_acero", new net.minecraft.block.PillarBlock(metal().mapColor(MapColor.GRAY)), true);
    public static final Block REJILLA_METAL = bloque("rejilla_metal", new net.minecraft.block.TransparentBlock(metal().nonOpaque()
            .allowsSpawning((s, w, pos, t) -> false).solidBlock((s, w, pos) -> false).suffocates((s, w, pos) -> false)
            .blockVision((s, w, pos) -> false)), true);
    public static final Block LUZ_INDUSTRIAL = bloque("luz_industrial", new Block(metal().luminance(s -> 15).sounds(BlockSoundGroup.GLASS)), true);
    public static final Block[] METAL = {PANEL_METAL, PANEL_METAL_FRANJA, VIGA_ACERO, REJILLA_METAL, LUZ_INDUSTRIAL};

    // ---------- Muebles y decoración del Centro ----------
    public static final Block RECEPCION = bloque("recepcion", new com.centrodesinformacion.desinformados.muebles.RecepcionBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(2f, 6f).sounds(BlockSoundGroup.WOOD).nonOpaque()), true);
    public static final Block MESA_DJ = bloque("mesa_dj", new com.centrodesinformacion.desinformados.muebles.MesaDjBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(2f, 6f).sounds(BlockSoundGroup.METAL).nonOpaque().luminance(s -> 5)), true);
    public static final Block PISTA_BAILE = bloque("pista_baile", new com.centrodesinformacion.desinformados.muebles.PistaBaileBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(1.5f, 6f).sounds(BlockSoundGroup.GLASS).luminance(s -> 12)), true);
    public static final Block CUADRO_GATO = bloque("cuadro_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.WOOD), new double[]{1.0, 1.0, 15.0, 15.0, 15.0, 16.0}, true), true);
    public static final Block PANTALLA_NOTICIAS = bloque("pantalla_noticias", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.METAL).luminance(s -> 8), new double[]{0.0, 2.0, 14.5, 16.0, 14.0, 16.0}, true), true);
    public static final Block LETRERO_CENTRO = bloque("letrero_centro", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.METAL).luminance(s -> 6), new double[]{1.0, 1.0, 15.0, 15.0, 15.0, 16.0}, true), true);
    public static final Block PELUCHE_GATO = bloque("peluche_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.WOOL), new double[]{4.0, 0.0, 4.0, 12.0, 10.0, 12.0}, false), true);
    public static final Block LAMPARA_GATO = bloque("lampara_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.LANTERN).luminance(s -> 14), new double[]{3.5, 0.0, 3.5, 12.5, 15.0, 12.5}, false), true);
    public static final Block RASCADOR = bloque("rascador", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.WOOL), new double[]{1.0, 0.0, 1.0, 15.0, 15.0, 15.0}, false), true);
    public static final Block CAMA_GATO = bloque("cama_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.WOOL), new double[]{1.0, 0.0, 1.0, 15.0, 5.0, 15.0}, false), true);
    public static final Block TAZA_GATO = bloque("taza_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.GLASS), new double[]{5.0, 0.0, 5.0, 13.0, 7.0, 11.0}, false), true);
    public static final Block MACETA_GATERA = bloque("maceta_gatera", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.GRASS), new double[]{4.0, 0.0, 4.0, 12.0, 15.0, 12.0}, false), true);
    public static final Block ESTATUA_GATO = bloque("estatua_gato", new com.centrodesinformacion.desinformados.muebles.DecoracionBlock(AbstractBlock.Settings.create().strength(0.8f).nonOpaque().sounds(BlockSoundGroup.METAL), new double[]{4.0, 0.0, 5.0, 13.5, 15.0, 11.0}, false), true);
    public static final Block[] DECORACION = {CUADRO_GATO, PANTALLA_NOTICIAS, LETRERO_CENTRO, PELUCHE_GATO, LAMPARA_GATO, RASCADOR, CAMA_GATO, TAZA_GATO, MACETA_GATERA, ESTATUA_GATO};
    public static final Block[] DECO_CUTOUT = {MACETA_GATERA};

    // ---------- Libreta del Becario: todo es papel ----------
    public static final Block PIEDRA_PAPEL = bloque("piedra_papel", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(1.5f, 6f).requiresTool().sounds(BlockSoundGroup.STONE)), true);
    public static final Block CESPED_PAPEL = bloque("cesped_papel", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(0.6f).sounds(BlockSoundGroup.GRASS)), true);
    public static final Block TIERRA_PAPEL = bloque("tierra_papel", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(0.5f).sounds(BlockSoundGroup.GRAVEL)), true);
    public static final Block ARENA_PAPEL = bloque("arena_papel", new net.minecraft.block.ColoredFallingBlock(
            new net.minecraft.util.ColorCode(0xEDE8D8), AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(0.5f).sounds(BlockSoundGroup.SAND)), true);
    public static final Block TRONCO_PAPEL = bloque("tronco_papel", new net.minecraft.block.PillarBlock(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(2f).sounds(BlockSoundGroup.WOOD).burnable()), true);
    public static final Block TABLAS_PAPEL = bloque("tablas_papel", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(2f, 3f).sounds(BlockSoundGroup.WOOD).burnable()), true);
    public static final Block HOJAS_PAPEL = bloque("hojas_papel", new net.minecraft.block.LeavesBlock(
            AbstractBlock.Settings.copy(net.minecraft.block.Blocks.OAK_LEAVES).mapColor(MapColor.WHITE)), true);
    public static final Block FONDO_LIBRETA = bloque("fondo_libreta", new Block(irrompible().mapColor(MapColor.GRAY)), true);
    public static final Block TINTA = bloque("tinta", new net.minecraft.block.FluidBlock(
            com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA,
            AbstractBlock.Settings.copy(net.minecraft.block.Blocks.WATER).mapColor(MapColor.BLACK)) {}, false);

    public static final Block BLOQUE_GARATITA = bloque("bloque_garatita", new Block(AbstractBlock.Settings.create()
            .mapColor(MapColor.WHITE).strength(5f, 6f).requiresTool().sounds(BlockSoundGroup.METAL)), true);

    public static final Block[] PAPEL = {PIEDRA_PAPEL, CESPED_PAPEL, TIERRA_PAPEL, ARENA_PAPEL, TRONCO_PAPEL, TABLAS_PAPEL, HOJAS_PAPEL, FONDO_LIBRETA};

    /** Conversor Difamónico (2x1): mejora diamante -> netherite -> Garatita. Irrompible en supervivencia, como el Banco. */
    public static final Block CONVERSOR = bloque("conversor_difamonico", new ConversorBlock(AbstractBlock.Settings.create()
            .mapColor(MapColor.PURPLE).strength(-1.0f, 3600000.0f).sounds(BlockSoundGroup.NETHERITE).dropsNothing().luminance(s -> 5)), true);

    public static void inicializar() {

    }
}

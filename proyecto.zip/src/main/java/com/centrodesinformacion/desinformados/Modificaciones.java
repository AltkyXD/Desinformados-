package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.village.TradeOffer;
import com.centrodesinformacion.desinformados.mixin.CreeperAccessor;
import net.minecraft.entity.mob.CreeperEntity;
import com.centrodesinformacion.desinformados.entidad.AleEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

/**
 * Cambios de dificultad que modifican mobs normales.
 * Se aplican a los mobs que aparecen y a los que ya existían cuando salió la tele.
 */
public class Modificaciones {
    private static final Identifier ARANA_PEQUENA = Desinformados.id("arana_pequena");
    private static final Identifier BEBE_RAPIDO = Desinformados.id("bebe_rapido");
    private static final Identifier ALE_FUERTE = Desinformados.id("ale_poderoso");

    /** Pone (o quita, con 0) un multiplicador sobre un atributo. 0.5 = +50%. */
    private static void modificador(LivingEntity vivo, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> atributo,
                                    Identifier id, double cambio) {
        EntityAttributeInstance inst = vivo.getAttributeInstance(atributo);
        if (inst == null) return;
        if (cambio == 0) inst.removeModifier(id);
        else if (!inst.hasModifier(id)) {
            inst.addPersistentModifier(new EntityAttributeModifier(id, cambio, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    public static void registrar() {
        // Aldeanos un 50% más caros: se suma al precio justo antes de abrir el comercio
        // (Minecraft borra este extra al cerrar el comercio, así que no se acumula)
        UseEntityCallback.EVENT.register((jugador, mundo, mano, entidad, golpe) -> {
            if (mundo.isClient() || mano != Hand.MAIN_HAND || golpe != null) return ActionResult.PASS;
            if (!(entidad instanceof VillagerEntity aldeano) || aldeano.isBaby() || aldeano.getCustomer() != null) return ActionResult.PASS;
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("aldeanos_caros")) return ActionResult.PASS;
            for (TradeOffer oferta : aldeano.getOffers()) {
                int base = oferta.getOriginalFirstBuyItem().getCount();
                oferta.increaseSpecialPrice(MathHelper.ceil(base * 0.5));
            }
            return ActionResult.PASS;
        });

        // Las ovejas recuperan la lana al comer hierba: cada segundo se la volvemos a quitar
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0 || !EstadoServidor.get(server).tieneCambio("ovejas_sin_lana")) return;
            for (ServerWorld mundo : server.getWorlds()) {
                for (Entity e : mundo.iterateEntities()) {
                    if (e instanceof SheepEntity oveja && !oveja.isSheared()) oveja.setSheared(true);
                }
            }
        });

        // Objetos catapulta: lo que suelta un jugador sale disparado hacia donde mira, como una flecha tensada
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (!(entidad instanceof ItemEntity objeto) || objeto.getCommandTags().contains(MARCA_OBJETO)) return;
            objeto.addCommandTag(MARCA_OBJETO);
            if (!(objeto.getOwner() instanceof ServerPlayerEntity jugador) || jugador.isSpectator()) return;
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("objetos_catapulta")) return;
            objeto.setVelocity(jugador.getRotationVector().multiply(2.5));
            objeto.velocityModified = true;
        });

        // Fuego eterno: si un jugador arde, el fuego no se consume solo; hay que usar agua
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!EstadoServidor.get(server).tieneCambio("fuego_eterno")) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isCreative() || p.isSpectator() || p.getFireTicks() <= 0) continue;
                if (p.getFireTicks() < 40) p.setFireTicks(40);
                if (server.getTicks() % 60 == 0) {
                    p.sendMessage(Text.literal("¡El fuego no se apaga solo! Busca agua").formatted(Formatting.GOLD), true);
                }
            }
        });

        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> aplicar(mundo.getServer(), entidad));

        // Esqueletos con doble arco: cada flecha que disparan sale acompañada de otra
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (!(entidad instanceof PersistentProjectileEntity flecha)) return;
            if (!(flecha.getOwner() instanceof SkeletonEntity)) return;
            if (flecha.getCommandTags().contains(MARCA_FLECHA)) return; // ya procesada o es la copia
            flecha.addCommandTag(MARCA_FLECHA);
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("esqueletos_doble_arco")) return;
            Tareas.programar(1, () -> segundaFlecha(flecha, mundo));
        });

        // Zombies adultos falsos: al morir se parten en 2 zombies bebé que se reparten la armadura
        ServerLivingEntityEvents.ALLOW_DEATH.register((entidad, fuente, cantidad) -> {
            if (entidad.getType() == EntityType.ZOMBIE && entidad instanceof ZombieEntity zombie && !zombie.isBaby()
                    && zombie.getWorld() instanceof ServerWorld mundo
                    && EstadoServidor.get(mundo.getServer()).tieneCambio("zombies_falsos")) {
                partirZombie(zombie, mundo);
            }
            return true;
        });
    }

    private static final String MARCA_FLECHA = "desinfo_flecha";
    private static final String MARCA_OBJETO = "desinfo_objeto";

    private static void segundaFlecha(PersistentProjectileEntity original, ServerWorld mundo) {
        if (original.isRemoved()) return;
        Entity creada = original.getType().create(mundo);
        if (!(creada instanceof PersistentProjectileEntity copia)) return;
        copia.addCommandTag(MARCA_FLECHA);
        copia.setOwner(original.getOwner());
        copia.setDamage(original.getDamage());
        copia.pickupType = original.pickupType;
        // Misma trayectoria pero abierta unos grados hacia un lado (lo justo para que cueste esquivar las dos)
        Vec3d v = original.getVelocity().rotateY((float) Math.toRadians(mundo.random.nextBoolean() ? 7 : -7));
        copia.refreshPositionAndAngles(original.getX(), original.getY(), original.getZ(), original.getYaw(), original.getPitch());
        copia.setVelocity(v);
        mundo.spawnEntity(copia);
    }

    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static void partirZombie(ZombieEntity zombie, ServerWorld mundo) {
        ZombieEntity[] hijos = new ZombieEntity[2];
        for (int i = 0; i < 2; i++) {
            ZombieEntity hijo = EntityType.ZOMBIE.create(mundo);
            if (hijo == null) return;
            hijo.refreshPositionAndAngles(zombie.getX() + (i == 0 ? -0.3 : 0.3), zombie.getY(), zombie.getZ(),
                    zombie.getYaw(), 0f);
            hijo.setBaby(true);
            hijo.setVelocity((i == 0 ? -0.25 : 0.25), 0.35, (mundo.random.nextDouble() - 0.5) * 0.3);
            if (zombie.getTarget() != null) hijo.setTarget(zombie.getTarget());
            hijos[i] = hijo;
        }
        // La armadura se reparte por turnos: 1ª pieza al primero, 2ª al segundo, 3ª al primero...
        int turno = 0;
        for (EquipmentSlot slot : ARMADURA) {
            ItemStack pieza = zombie.getEquippedStack(slot);
            if (pieza.isEmpty()) continue;
            hijos[turno % 2].equipStack(slot, pieza.copy());
            zombie.equipStack(slot, ItemStack.EMPTY); // para que no se duplique al soltarla
            turno++;
        }
        // El arma, si tenía, se la queda el que menos armadura recibió
        ItemStack arma = zombie.getMainHandStack();
        if (!arma.isEmpty()) {
            hijos[turno % 2].equipStack(EquipmentSlot.MAINHAND, arma.copy());
            zombie.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        for (ZombieEntity hijo : hijos) mundo.spawnEntity(hijo);
        mundo.spawnParticles(ParticleTypes.POOF, zombie.getX(), zombie.getY() + 1, zombie.getZ(), 15, 0.3, 0.5, 0.3, 0.05);
        mundo.playSound(null, zombie.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.8f);
    }

    public static void aplicarATodos(MinecraftServer server) {
        for (ServerWorld mundo : server.getWorlds()) {
            for (Entity e : mundo.iterateEntities()) aplicar(server, e);
        }
    }

    private static void aplicar(MinecraftServer server, Entity entidad) {
        if (!(entidad instanceof LivingEntity vivo)) return;
        EstadoServidor estado = EstadoServidor.get(server);

        // Esqueletos con un segundo arco en la otra mano
        if (entidad.getType() == EntityType.SKELETON && entidad instanceof SkeletonEntity esqueleto) {
            boolean activo = estado.tieneCambio("esqueletos_doble_arco");
            ItemStack mano2 = esqueleto.getOffHandStack();
            if (activo && mano2.isEmpty()) {
                esqueleto.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.BOW));
                esqueleto.setEquipmentDropChance(EquipmentSlot.OFFHAND, 0f);
            } else if (!activo && mano2.isOf(Items.BOW)) {
                esqueleto.equipStack(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
            }
        }

        // Ovejas sin lana (y sin posibilidad de que les vuelva a crecer)
        if (entidad instanceof SheepEntity oveja && estado.tieneCambio("ovejas_sin_lana") && !oveja.isSheared()) {
            oveja.setSheared(true);
        }

        // Creepers electrificados (también los Creepers Oscuros)
        if (entidad instanceof CreeperEntity creeper) {
            boolean activo = estado.tieneCambio("creepers_electrificados");
            var electrificado = CreeperAccessor.desinformados$getCharged();
            if (creeper.getDataTracker().get(electrificado) != activo) {
                creeper.getDataTracker().set(electrificado, activo);
            }
        }

        // Zombies pequeños un 50% más rápidos (cualquier tipo de zombie bebé)
        if (entidad instanceof ZombieEntity zombi) {
            boolean activo = zombi.isBaby() && estado.tieneCambio("bebes_rapidos");
            EntityAttributeInstance vel = zombi.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if (vel != null) {
                if (!activo) vel.removeModifier(BEBE_RAPIDO);
                else if (!vel.hasModifier(BEBE_RAPIDO)) {
                    vel.addPersistentModifier(new EntityAttributeModifier(BEBE_RAPIDO, 0.5, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }
            }
        }

        // Ale más poderoso: +50% vida, fuerza y velocidad, y un 25% más grande
        if (entidad instanceof AleEntity ale) {
            boolean activo = estado.tieneCambio("ale_poderoso");
            float antes = ale.getMaxHealth();
            modificador(ale, EntityAttributes.GENERIC_MAX_HEALTH, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_ATTACK_DAMAGE, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_MOVEMENT_SPEED, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_SCALE, ALE_FUERTE, activo ? 0.25 : 0);
            if (ale.getMaxHealth() > antes) ale.setHealth(ale.getHealth() + (ale.getMaxHealth() - antes));
            if (ale.getHealth() > ale.getMaxHealth()) ale.setHealth(ale.getMaxHealth());
        }

        // Arañas del tamaño de un pez globo (las arañas de cueva no cambian)
        if (entidad.getType() == EntityType.SPIDER) {
            escala(vivo, ARANA_PEQUENA, estado.tieneCambio("aranas_pequenas") ? -0.5 : 0);
        }
    }

    /** cambio = -0.5 hace el mob la mitad de grande; 0 lo deja normal. */
    private static void escala(LivingEntity vivo, Identifier id, double cambio) {
        EntityAttributeInstance escala = vivo.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if (escala == null) return;
        if (cambio == 0) {
            escala.removeModifier(id);
        } else if (!escala.hasModifier(id)) {
            escala.addPersistentModifier(new EntityAttributeModifier(id, cambio, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }
}

package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.village.TradeOffer;
import com.centrodesinformacion.desinformados.mixin.CreeperAccessor;
import net.minecraft.entity.mob.CreeperEntity;
import com.centrodesinformacion.desinformados.entidad.AleEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

/**
 * Cambios de dificultad que modifican mobs normales.
 * Se aplican a los mobs que aparecen y a los que ya existían cuando salió la tele.
 */
public class Modificaciones {
    private static final Identifier ARANA_PEQUENA = Desinformados.id("arana_pequena");
    private static final Identifier BEBE_RAPIDO = Desinformados.id("bebe_rapido");
    private static final Identifier ALE_FUERTE = Desinformados.id("ale_poderoso");
    private static final Identifier TRAVENSANO_FURIOSO = Desinformados.id("travensano_furioso");

    /** Pone (o quita, con 0) un multiplicador sobre un atributo. 0.5 = +50%. */
    private static void modificador(LivingEntity vivo, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> atributo,
                                    Identifier id, double cambio) {
        EntityAttributeInstance inst = vivo.getAttributeInstance(atributo);
        if (inst == null) return;
        if (cambio == 0) inst.removeModifier(id);
        else if (!inst.hasModifier(id)) {
            inst.addPersistentModifier(new EntityAttributeModifier(id, cambio, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    // ---------------- Antorchas que se apagan ----------------
    private static final java.util.Map<net.minecraft.registry.RegistryKey<net.minecraft.world.World>, java.util.Map<net.minecraft.util.math.BlockPos, Integer>> ANTORCHAS = new java.util.HashMap<>();
    private static final int VIDA_ANTORCHA = 12000; // 10 minutos
    private static final java.util.Map<java.util.UUID, net.minecraft.util.math.Vec3d> ULTIMA_POS = new java.util.HashMap<>();

    private static boolean esAntorcha(net.minecraft.block.BlockState s) {
        return s.isOf(net.minecraft.block.Blocks.TORCH) || s.isOf(net.minecraft.block.Blocks.WALL_TORCH)
                || s.isOf(net.minecraft.block.Blocks.SOUL_TORCH) || s.isOf(net.minecraft.block.Blocks.SOUL_WALL_TORCH);
    }

    public static void registrar() {
        // Antorchas: al ponerlas se apuntan con la hora; a los 10 minutos se apagan (si el cambio está activo)
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((jugador, mundo, mano, golpe) -> {
            if (mundo.isClient()) return ActionResult.PASS;
            ItemStack s = jugador.getStackInHand(mano);
            if (!s.isOf(Items.TORCH) && !s.isOf(Items.SOUL_TORCH)) return ActionResult.PASS;
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("antorchas_apagan")) return ActionResult.PASS;   // solo con el cambio activo
            net.minecraft.util.math.BlockPos pos = golpe.getBlockPos().offset(golpe.getSide()).toImmutable();
            net.minecraft.util.math.BlockPos pos2 = golpe.getBlockPos().toImmutable();
            Tareas.programar(1, () -> {
                for (net.minecraft.util.math.BlockPos q : new net.minecraft.util.math.BlockPos[]{pos, pos2}) {
                    if (esAntorcha(mundo.getBlockState(q))) {
                        ANTORCHAS.computeIfAbsent(mundo.getRegistryKey(), k -> new java.util.HashMap<>()).put(q, mundo.getServer().getTicks());
                    }
                }
            });
            return ActionResult.PASS;
        });

        // Las horas de las antorchas son ticks de esta sesión del servidor: no sirven para la siguiente
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            ANTORCHAS.clear();
            ULTIMA_POS.clear();
        });

        // Camas rotas: dormir guarda el punto de reaparición pero ya no pasa la noche
        net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents.ALLOW_RESETTING_TIME.register(jugador ->
                jugador.getServer() == null || !EstadoServidor.get(jugador.getServer()).tieneCambio("camas_rotas"));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            EstadoServidor estado = EstadoServidor.get(server);
            int ahora = server.getTicks();

            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isCreative() || p.isSpectator()) continue;
                // Sed de cuevas: bajo la capa 0 el hambre baja el doble
                if (estado.tieneCambio("sed_cuevas") && p.getY() < 0) p.addExhaustion(0.012f);
                // Esprintar agota (x1,5): Minecraft gasta 0,1 por metro corriendo; sumamos 0,05
                net.minecraft.util.math.Vec3d antes = ULTIMA_POS.put(p.getUuid(), p.getPos());
                if (estado.tieneCambio("esprintar_agota") && p.isSprinting() && antes != null) {
                    double dx = p.getX() - antes.x, dz = p.getZ() - antes.z;
                    double metros = Math.sqrt(dx * dx + dz * dz);
                    if (metros < 2) p.addExhaustion((float) (0.05 * metros));
                }
                // Armadura oxidada: la de hierro se gasta con la lluvia o en el agua
                if (estado.tieneCambio("armadura_oxidada") && ahora % 40 == 0 && p.isWet()) {
                    for (EquipmentSlot slot : ARMADURA) {
                        ItemStack pieza = p.getEquippedStack(slot);
                        if (pieza.isOf(Items.IRON_HELMET) || pieza.isOf(Items.IRON_CHESTPLATE) || pieza.isOf(Items.IRON_LEGGINGS) || pieza.isOf(Items.IRON_BOOTS)) {
                            pieza.damage(1, p, slot);
                        }
                    }
                }
            }

            // Antorchas caducadas
            if (ahora % 100 == 0) {
                if (!estado.tieneCambio("antorchas_apagan")) ANTORCHAS.clear();          // sin el cambio no hay nada que vigilar
                for (ServerWorld mundo : server.getWorlds()) {
                    var mapa = ANTORCHAS.get(mundo.getRegistryKey());
                    if (mapa == null) continue;
                    mapa.entrySet().removeIf(e -> {
                        if (!mundo.isChunkLoaded(e.getKey())) return false;                   // antes de leer el bloque: nunca cargar chunks desde aquí
                        if (!esAntorcha(mundo.getBlockState(e.getKey()))) return true;
                        if (ahora - e.getValue() < VIDA_ANTORCHA) return false;
                        mundo.setBlockState(e.getKey(), net.minecraft.block.Blocks.AIR.getDefaultState());
                        mundo.spawnParticles(ParticleTypes.LARGE_SMOKE, e.getKey().getX() + 0.5, e.getKey().getY() + 0.6, e.getKey().getZ() + 0.5, 6, 0.1, 0.1, 0.1, 0.01);
                        mundo.playSound(null, e.getKey(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.5f, 1.4f);
                        return true;
                    });
                }
            }
        });

        // Aldeanos un 50% más caros: se suma al precio justo antes de abrir el comercio
        // (Minecraft borra este extra al cerrar el comercio, así que no se acumula)
        UseEntityCallback.EVENT.register((jugador, mundo, mano, entidad, golpe) -> {
            if (mundo.isClient() || mano != Hand.MAIN_HAND || golpe != null) return ActionResult.PASS;
            if (!(entidad instanceof VillagerEntity aldeano) || aldeano.isBaby() || aldeano.getCustomer() != null) return ActionResult.PASS;
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("aldeanos_caros")) return ActionResult.PASS;
            for (TradeOffer oferta : aldeano.getOffers()) {
                int base = oferta.getOriginalFirstBuyItem().getCount();
                oferta.increaseSpecialPrice(MathHelper.ceil(base * 0.5));
            }
            return ActionResult.PASS;
        });

        // Las ovejas recuperan la lana al comer hierba: cada segundo se la volvemos a quitar
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0 || !EstadoServidor.get(server).tieneCambio("ovejas_sin_lana")) return;
            for (ServerWorld mundo : server.getWorlds()) {
                for (Entity e : mundo.iterateEntities()) {
                    if (e instanceof SheepEntity oveja && !oveja.isSheared()) oveja.setSheared(true);
                }
            }
        });

        // Objetos catapulta: lo que suelta un jugador sale disparado hacia donde mira, como una flecha tensada
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (!(entidad instanceof ItemEntity objeto) || objeto.getCommandTags().contains(MARCA_OBJETO)) return;
            objeto.addCommandTag(MARCA_OBJETO);
            if (!(objeto.getOwner() instanceof ServerPlayerEntity jugador) || jugador.isSpectator()) return;
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("objetos_catapulta")) return;
            objeto.setVelocity(jugador.getRotationVector().multiply(2.5));
            objeto.velocityModified = true;
        });

        // Fuego eterno: si un jugador arde, el fuego no se consume solo; hay que usar agua
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!EstadoServidor.get(server).tieneCambio("fuego_eterno")) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isCreative() || p.isSpectator() || p.getFireTicks() <= 0) continue;
                // +20 y no "poner a 40": el fuego quema cuando el contador es múltiplo de 20; fijarlo a 40 cada tick
                // hacía que quemara en cada golpe permitido (el doble de lo normal)
                if (p.getFireTicks() < 20) p.setFireTicks(p.getFireTicks() + 20);
                if (server.getTicks() % 60 == 0) {
                    p.sendMessage(Text.literal("¡El fuego no se apaga solo! Busca agua").formatted(Formatting.GOLD), true);
                }
            }
        });

        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> aplicar(mundo.getServer(), entidad));

        // Esqueletos con doble arco: cada flecha que disparan sale acompañada de otra
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (!(entidad instanceof PersistentProjectileEntity flecha)) return;
            if (!(flecha.getOwner() instanceof SkeletonEntity) || flecha.getOwner() instanceof com.centrodesinformacion.desinformados.entidad.MobEstatica) return;
            if (flecha.getCommandTags().contains(MARCA_FLECHA)) return; // ya procesada o es la copia
            flecha.addCommandTag(MARCA_FLECHA);
            if (!EstadoServidor.get(mundo.getServer()).tieneCambio("esqueletos_doble_arco")) return;
            Tareas.programar(1, () -> segundaFlecha(flecha, mundo));
        });

        // Zombies adultos falsos: al morir se parten en 2 zombies bebé que se reparten la armadura
        ServerLivingEntityEvents.ALLOW_DEATH.register((entidad, fuente, cantidad) -> {
            if (entidad.getType() == EntityType.ZOMBIE && entidad instanceof ZombieEntity zombie && !zombie.isBaby()
                    && zombie.getWorld() instanceof ServerWorld mundo
                    && EstadoServidor.get(mundo.getServer()).tieneCambio("zombies_falsos")) {
                partirZombie(zombie, mundo);
            }
            return true;
        });
    }

    private static final String MARCA_FLECHA = "desinfo_flecha";
    private static final String MARCA_OBJETO = "desinfo_objeto";
    /** Creeper electrificado por el cambio (no por un rayo). */
    private static final String MARCA_ELECTRICO = "desinfo_electrico";

    private static void segundaFlecha(PersistentProjectileEntity original, ServerWorld mundo) {
        if (original.isRemoved()) return;
        Entity creada = original.getType().create(mundo);
        if (!(creada instanceof PersistentProjectileEntity copia)) return;
        copia.addCommandTag(MARCA_FLECHA);
        copia.setOwner(original.getOwner());
        copia.setDamage(original.getDamage());
        copia.pickupType = original.pickupType;
        // Misma trayectoria pero abierta unos grados hacia un lado (lo justo para que cueste esquivar las dos)
        Vec3d v = original.getVelocity().rotateY((float) Math.toRadians(mundo.random.nextBoolean() ? 7 : -7));
        copia.refreshPositionAndAngles(original.getX(), original.getY(), original.getZ(), original.getYaw(), original.getPitch());
        copia.setVelocity(v);
        mundo.spawnEntity(copia);
    }

    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static void partirZombie(ZombieEntity zombie, ServerWorld mundo) {
        ZombieEntity[] hijos = new ZombieEntity[2];
        for (int i = 0; i < 2; i++) {
            ZombieEntity hijo = EntityType.ZOMBIE.create(mundo);
            if (hijo == null) return;
            hijo.refreshPositionAndAngles(zombie.getX() + (i == 0 ? -0.3 : 0.3), zombie.getY(), zombie.getZ(),
                    zombie.getYaw(), 0f);
            hijo.setBaby(true);
            hijo.setVelocity((i == 0 ? -0.25 : 0.25), 0.35, (mundo.random.nextDouble() - 0.5) * 0.3);
            if (zombie.getTarget() != null) hijo.setTarget(zombie.getTarget());
            hijos[i] = hijo;
        }
        // Lo que recogió de un jugador (probabilidad 2.0) se sigue soltando seguro, y si era persistente lo siguen siendo
        var acceso = (com.centrodesinformacion.desinformados.mixin.MobAccessor) zombie;
        if (zombie.isPersistent()) for (ZombieEntity hijo : hijos) hijo.setPersistent();
        // La armadura se reparte por turnos: 1ª pieza al primero, 2ª al segundo, 3ª al primero...
        int turno = 0;
        for (EquipmentSlot slot : ARMADURA) {
            ItemStack pieza = zombie.getEquippedStack(slot);
            if (pieza.isEmpty()) continue;
            hijos[turno % 2].equipStack(slot, pieza.copy());
            hijos[turno % 2].setEquipmentDropChance(slot, acceso.desinformados$getDropChance(slot));
            zombie.equipStack(slot, ItemStack.EMPTY); // para que no se duplique al soltarla
            turno++;
        }
        // El arma, si tenía, se la queda el que menos armadura recibió
        ItemStack arma = zombie.getMainHandStack();
        if (!arma.isEmpty()) {
            hijos[turno % 2].equipStack(EquipmentSlot.MAINHAND, arma.copy());
            hijos[turno % 2].setEquipmentDropChance(EquipmentSlot.MAINHAND, acceso.desinformados$getDropChance(EquipmentSlot.MAINHAND));
            zombie.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        for (ZombieEntity hijo : hijos) mundo.spawnEntity(hijo);
        mundo.spawnParticles(ParticleTypes.POOF, zombie.getX(), zombie.getY() + 1, zombie.getZ(), 15, 0.3, 0.5, 0.3, 0.05);
        mundo.playSound(null, zombie.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.8f);
    }

    public static void aplicarATodos(MinecraftServer server) {
        for (ServerWorld mundo : server.getWorlds()) {
            for (Entity e : mundo.iterateEntities()) aplicar(server, e);
        }
    }

    private static void aplicar(MinecraftServer server, Entity entidad) {
        if (!(entidad instanceof LivingEntity vivo)) return;
        if (entidad instanceof com.centrodesinformacion.desinformados.entidad.MobEstatica) return; // las mutaciones no les afectan (aún)
        EstadoServidor estado = EstadoServidor.get(server);

        // Esqueletos con un segundo arco en la otra mano
        if (entidad.getType() == EntityType.SKELETON && entidad instanceof SkeletonEntity esqueleto) {
            boolean activo = estado.tieneCambio("esqueletos_doble_arco");
            ItemStack mano2 = esqueleto.getOffHandStack();
            if (activo && mano2.isEmpty()) {
                esqueleto.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.BOW));
                esqueleto.setEquipmentDropChance(EquipmentSlot.OFFHAND, 0f);
            } else if (!activo && mano2.isOf(Items.BOW)) {
                esqueleto.equipStack(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
            }
        }

        // Ovejas sin lana (y sin posibilidad de que les vuelva a crecer)
        if (entidad instanceof SheepEntity oveja && estado.tieneCambio("ovejas_sin_lana") && !oveja.isSheared()) {
            oveja.setSheared(true);
        }

        // Creepers electrificados (también los Creepers Oscuros). Solo se les quita la carga a los que cargó el mod:
        // los que ha cargado un rayo de verdad se quedan como están.
        if (entidad instanceof CreeperEntity creeper) {
            boolean activo = estado.tieneCambio("creepers_electrificados");
            var electrificado = CreeperAccessor.desinformados$getCharged();
            boolean cargado = creeper.getDataTracker().get(electrificado);
            if (activo && !cargado) {
                creeper.getDataTracker().set(electrificado, true);
                creeper.addCommandTag(MARCA_ELECTRICO);
            } else if (!activo && cargado && creeper.getCommandTags().contains(MARCA_ELECTRICO)) {
                creeper.getDataTracker().set(electrificado, false);
                creeper.removeCommandTag(MARCA_ELECTRICO);
            }
        }

        // Zombies pequeños un 50% más rápidos (cualquier tipo de zombie bebé)
        if (entidad instanceof ZombieEntity zombi) {
            boolean activo = zombi.isBaby() && estado.tieneCambio("bebes_rapidos");
            EntityAttributeInstance vel = zombi.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if (vel != null) {
                if (!activo) vel.removeModifier(BEBE_RAPIDO);
                else if (!vel.hasModifier(BEBE_RAPIDO)) {
                    vel.addPersistentModifier(new EntityAttributeModifier(BEBE_RAPIDO, 0.5, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }
            }
        }

        // Ale más poderoso: +50% vida, fuerza y velocidad, y un 25% más grande
        if (entidad instanceof AleEntity ale) {
            boolean activo = estado.tieneCambio("ale_poderoso");
            float antes = ale.getMaxHealth();
            modificador(ale, EntityAttributes.GENERIC_MAX_HEALTH, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_ATTACK_DAMAGE, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_MOVEMENT_SPEED, ALE_FUERTE, activo ? 0.5 : 0);
            modificador(ale, EntityAttributes.GENERIC_SCALE, ALE_FUERTE, activo ? 0.25 : 0);
            if (ale.getMaxHealth() > antes) ale.setHealth(ale.getHealth() + (ale.getMaxHealth() - antes));
            if (ale.getHealth() > ale.getMaxHealth()) ale.setHealth(ale.getMaxHealth());
        }

        // Travensaños furiosos: más vida (10 -> 12) y un 20% más rápidos
        if (entidad instanceof com.centrodesinformacion.desinformados.entidad.TravensanoEntity t) {
            boolean activo = estado.tieneCambio("travensanos_furiosos");
            float antes = t.getMaxHealth();
            modificador(t, EntityAttributes.GENERIC_MAX_HEALTH, TRAVENSANO_FURIOSO, activo ? 0.2 : 0);
            modificador(t, EntityAttributes.GENERIC_MOVEMENT_SPEED, TRAVENSANO_FURIOSO, activo ? 0.2 : 0);
            if (t.getMaxHealth() > antes) t.setHealth(t.getHealth() + (t.getMaxHealth() - antes));
            if (t.getHealth() > t.getMaxHealth()) t.setHealth(t.getMaxHealth());
        }

        // Arañas del tamaño de un pez globo (las arañas de cueva no cambian)
        if (entidad.getType() == EntityType.SPIDER) {
            escala(vivo, ARANA_PEQUENA, estado.tieneCambio("aranas_pequenas") ? -0.5 : 0);
        }
    }

    /** cambio = -0.5 hace el mob la mitad de grande; 0 lo deja normal. */
    private static void escala(LivingEntity vivo, Identifier id, double cambio) {
        EntityAttributeInstance escala = vivo.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if (escala == null) return;
        if (cambio == 0) {
            escala.removeModifier(id);
        } else if (!escala.hasModifier(id)) {
            escala.addPersistentModifier(new EntityAttributeModifier(id, cambio, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }
}

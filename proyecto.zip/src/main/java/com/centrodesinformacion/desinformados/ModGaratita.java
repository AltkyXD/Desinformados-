package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.Block;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Rarity;
import net.minecraft.util.Util;

import java.util.EnumMap;
import java.util.List;

/** Equipo de Garatita: el nivel por encima del netherite. Solo se consigue en el Conversor Difamónico. */
public class ModGaratita {
    // ---------- Herramientas (base = netherite) ----------
    private static ToolMaterial material(float velocidadMinado) {
        return new ToolMaterial() {
            @Override public int getDurability() { return 4062; } // el doble que el netherite
            @Override public float getMiningSpeedMultiplier() { return velocidadMinado; }
            @Override public float getAttackDamage() { return 4.0f; }
            @Override public TagKey<Block> getInverseTag() { return BlockTags.INCORRECT_FOR_NETHERITE_TOOL; }
            @Override public int getEnchantability() { return 15; }
            @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.GARATITA); }
        };
    }
    /** Igual que el netherite (velocidad 9). */
    public static final ToolMaterial MATERIAL = material(9.0f);
    /** Solo para el pico: mina mucho más rápido. */
    public static final ToolMaterial MATERIAL_PICO = material(14.0f);

    private static Item.Settings ajustes() {
        return new Item.Settings().fireproof().rarity(Rarity.RARE);
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Desinformados.id(id), item);
    }

    // Espada: netherite 8 de daño / 1.6 ataques por seg -> Garatita 11 de daño / 2.0
    public static final Item ESPADA = reg("espada_garatita", new SwordItem(MATERIAL,
            ajustes().attributeModifiers(SwordItem.createAttributeModifiers(MATERIAL, 6, -2.0f))));
    // Pico: igual que netherite pero mina más rápido (14 en vez de 9)
    public static final Item PICO = reg("pico_garatita", new PickaxeItem(MATERIAL_PICO,
            ajustes().attributeModifiers(MiningToolItem.createAttributeModifiers(MATERIAL_PICO, 1.0f, -2.8f))));
    // Hacha: netherite 10 de daño / 1.0 -> Garatita 12 de daño / 1.4
    public static final Item HACHA = reg("hacha_garatita", new AxeItem(MATERIAL,
            ajustes().attributeModifiers(MiningToolItem.createAttributeModifiers(MATERIAL, 7.0f, -2.6f))));
    // Pala: igual que la de netherite
    public static final Item PALA = reg("pala_garatita", new ShovelItem(MATERIAL,
            ajustes().attributeModifiers(MiningToolItem.createAttributeModifiers(MATERIAL, 1.5f, -3.0f))));
    // Azada: igual que la de netherite (¿en serio?)
    public static final Item AZADA = reg("azada_garatita", new HoeItem(MATERIAL,
            ajustes().attributeModifiers(MiningToolItem.createAttributeModifiers(MATERIAL, -4.0f, 0.0f))));

    // ---------- Armadura: netherite + 2 de armadura por pieza, + 10 % de velocidad por pieza ----------
    public static final RegistryEntry<ArmorMaterial> ARMADURA = Registry.registerReference(Registries.ARMOR_MATERIAL,
            Desinformados.id("garatita"), new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 5);
                        m.put(ArmorItem.Type.LEGGINGS, 8);
                        m.put(ArmorItem.Type.CHESTPLATE, 10);
                        m.put(ArmorItem.Type.HELMET, 5);
                        m.put(ArmorItem.Type.BODY, 13);
                    }),
                    15, SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE, () -> Ingredient.ofItems(ModItems.GARATITA),
                    List.of(new ArmorMaterial.Layer(Desinformados.id("garatita_netherite"))), 3.0f, 0.1f));   // forma de netherite con papel (la genera el cliente)

    /** Pieza de armadura que además da +10 % de velocidad. */
    public static class PiezaGaratita extends ArmorItem {
        private final com.google.common.base.Supplier<net.minecraft.component.type.AttributeModifiersComponent> modificadores;

        public PiezaGaratita(Type tipo, Item.Settings settings) {
            super(ARMADURA, tipo, settings);
            this.modificadores = com.google.common.base.Suppliers.memoize(() -> super.getAttributeModifiers().with(
                    net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED,
                    new net.minecraft.entity.attribute.EntityAttributeModifier(Desinformados.id("velocidad_garatita_" + tipo.getName()),
                            0.10, net.minecraft.entity.attribute.EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                    net.minecraft.component.type.AttributeModifierSlot.forEquipmentSlot(tipo.getEquipmentSlot())));
        }

        @Override
        public net.minecraft.component.type.AttributeModifiersComponent getAttributeModifiers() {
            return modificadores.get();
        }
    }

    private static Item armadura(String id, ArmorItem.Type tipo) {
        return reg(id, new PiezaGaratita(tipo, ajustes().maxDamage(tipo.getMaxDamage(74))));
    }

    public static final Item CASCO = armadura("casco_garatita", ArmorItem.Type.HELMET);
    public static final Item PETO = armadura("peto_garatita", ArmorItem.Type.CHESTPLATE);
    public static final Item PANTALONES = armadura("pantalones_garatita", ArmorItem.Type.LEGGINGS);
    public static final Item BOTAS = armadura("botas_garatita", ArmorItem.Type.BOOTS);

    public static void inicializar() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            e.add(ESPADA); e.add(HACHA);
            e.add(CASCO); e.add(PETO); e.add(PANTALONES); e.add(BOTAS);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(PICO); e.add(PALA); e.add(HACHA); e.add(AZADA);
            e.add(ModBloques.CONVERSOR.asItem());
        });
    }
}

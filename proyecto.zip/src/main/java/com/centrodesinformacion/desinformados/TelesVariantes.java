package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModVariantes;

import java.util.List;
import java.util.Map;

/** Las teles azules de las 15 variantes de mobs (cada una desbloquea su variante). */
public final class TelesVariantes {
    private TelesVariantes() {}

    /** Ids de las teles, en el orden en que deberían salir (las dos últimas son del Nether). */
    public static final List<String> IDS = List.of(
            "zombie_periodista", "pollo_bomba", "arana_tejedora", "vaca_loca",
            "creeper_saltarin", "esqueleto_francotirador", "abeja_asesina", "ahogado_pescador", "slime_viral", "zombie_ladron",
            "zombie_tanque", "bruja_influencer", "enderman_bromista",
            "blaze_helado", "esqueleto_wither_arquero");

    /** Para la Enciclopedia: nombre corto del mob de cada tele. */
    public static final Map<String, String> NOMBRES = Map.ofEntries(
            Map.entry("zombie_periodista", "Zombie Periodista"),
            Map.entry("esqueleto_francotirador", "Esqueleto Francotirador"),
            Map.entry("arana_tejedora", "Araña Tejedora"),
            Map.entry("creeper_saltarin", "Creeper Saltarín"),
            Map.entry("zombie_ladron", "Zombie Ladrón"),
            Map.entry("bruja_influencer", "Bruja Influencer"),
            Map.entry("slime_viral", "Slime Viral"),
            Map.entry("vaca_loca", "Vaca Loca"),
            Map.entry("pollo_bomba", "Pollo Bomba"),
            Map.entry("zombie_tanque", "Zombie Tanque"),
            Map.entry("enderman_bromista", "Enderman Bromista"),
            Map.entry("abeja_asesina", "Abeja Asesina"),
            Map.entry("blaze_helado", "Blaze Helado"),
            Map.entry("esqueleto_wither_arquero", "Esqueleto Wither Arquero"),
            Map.entry("ahogado_pescador", "Ahogado Pescador"));

    /** Crea las teles (lo llama Eventos al cargar). Se vuelven azules solas al estar en GRUPO_MOBS. */
    static void eventos() {
        Eventos.amarillo("zombie_periodista", "¡Llega el Zombie Periodista!",
                "Aparecerá en lugares oscuros, en la superficie y en cuevas. Es más rápido que un zombie normal y, si te pega, "
                        + "te hará brillar durante 15 segundos: todo el mundo te verá a través de las paredes. ¡EXCLUSIVA!",
                "El Centro de Desinformación ha contratado a un nuevo corresponsal. No duerme, no respira y no contrasta fuentes, "
                        + "pero publica más rápido que nadie. Si te muerde, eres noticia. Literalmente.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ZOMBIE_PERIODISTA));

        Eventos.amarillo("pollo_bomba", "¡Llega el Pollo Bomba!",
                "Aparecerá en la superficie a cualquier hora. Si estás a menos de 12 bloques irá a por ti y, cuando esté a menos de 2,5 bloques, "
                        + "encenderá la mecha: 1,5 segundos después explotará (sin romper bloques) y desaparecerá. No pone huevos.",
                "Pedimos pollos de corral y el proveedor del Centro de Desinformación entendió \"pollos de corral... de pólvora\". "
                        + "El albarán está firmado. No se admiten devoluciones, sobre todo porque explotan.",
                server -> Eventos.desbloquearMob(server, ModVariantes.POLLO_BOMBA));

        Eventos.amarillo("arana_tejedora", "¡Llega la Araña Tejedora!",
                "Aparecerá en cuevas. Cuando te muerde, teje una telaraña justo a tus pies (si hay hueco) para dejarte atrapado. "
                        + "Cada araña puede hacerlo una vez cada 10 segundos.",
                "El Centro de Desinformación externalizó la decoración de Halloween a una empresa de arañas. Nos cobraron por adelantado "
                        + "y, como se aburrían, ahora decoran a los clientes.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ARANA_TEJEDORA));

        Eventos.amarillo("vaca_loca", "¡Cuidado con la Vaca Loca!",
                "Aparecerán pocas, sobre la hierba y a cualquier hora. Es morada, tiene 8 corazones y es rápida: te atacará en cuanto te vea, "
                        + "te quitará 2,5 corazones por embestida y te mandará volando. No se puede criar, pero sí ordeñar (si te atreves).",
                "Para recortar gastos, el Centro de Desinformación cambió el pienso de las vacas por uno de oferta. Desde entonces están moradas, "
                        + "echan humo por la nariz y han empezado a leer los comentarios de internet. No es culpa suya.",
                server -> Eventos.desbloquearMob(server, ModVariantes.VACA_LOCA));

        Eventos.amarillo("creeper_saltarin", "¡Llega el Creeper Saltarín!",
                "Aparecerá en lugares oscuros. Si te tiene a entre 3 y 9 bloques y está en el suelo, pegará un salto hacia ti "
                        + "(como mucho uno cada 3 segundos). Su explosión es la de un creeper normal.",
                "Un creeper encontró unos muelles en el almacén del Centro de Desinformación y se los puso en las piernas. "
                        + "Ya no se acerca con sigilo: llega volando. El almacén sigue sin muelles y el inventario, sin cuadrar.",
                server -> Eventos.desbloquearMob(server, ModVariantes.CREEPER_SALTARIN));

        Eventos.amarillo("esqueleto_francotirador", "¡Cuidado con el Esqueleto Francotirador!",
                "Aparecerá en lugares oscuros. Te detecta desde 40 bloques y solo dispara una flecha cada 3 segundos, "
                        + "pero cada flecha hace un 50 % más de daño.",
                "Tras los recortes de presupuesto, el Centro de Desinformación solo puede pagarle a este esqueleto una flecha cada 3 segundos. "
                        + "Para compensar, le hemos dejado afilarlas. Y un monóculo, que da mucha seriedad.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ESQUELETO_FRANCOTIRADOR));

        Eventos.amarillo("abeja_asesina", "¡Llegan las Abejas Asesinas!",
                "Aparecerán de día en bosques, llanuras y praderas. Siempre están enfadadas con el jugador más cercano (a menos de 16 bloques), "
                        + "tienen 6 corazones y su picadura da Veneno II durante 8 segundos. No mueren al picar: pican cada 2 segundos.",
                "El Centro de Desinformación encargó abejas para producir miel ecológica. Llegaron con chaleco rojo y negro "
                        + "y una actitud muy poco ecológica. La miel sigue sin aparecer.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ABEJA_ASESINA));

        Eventos.amarillo("ahogado_pescador", "¡Llega el Ahogado Pescador!",
                "Aparecerá en el agua (océanos y ríos), a oscuras. Cada 3 segundos, si estás en el agua a menos de 10 bloques, "
                        + "te dará un tirón con su caña de unos 1,2 bloques hacia él.",
                "El Centro de Desinformación abrió una piscifactoría y contrató a un pescador. Llevaba años ahogado, "
                        + "pero el currículum era impecable. Ahora pesca jugadores, que según él dan más rendimiento.",
                server -> Eventos.desbloquearMob(server, ModVariantes.AHOGADO_PESCADOR));

        Eventos.amarillo("slime_viral", "¡El Slime Viral se está compartiendo!",
                "Aparecerá en la superficie por la noche. Cada vez que le haces daño hay un 25 % de probabilidad de que se copie: "
                        + "sale un Slime Viral pequeño a su lado (como mucho 8 a menos de 16 bloques).",
                "Un becario del Centro de Desinformación subió un vídeo de un slime y se hizo viral. Ahora, cada vez que alguien lo toca, "
                        + "se comparte. Hemos intentado borrarlo, pero ya lo tiene todo el mundo.",
                server -> Eventos.desbloquearMob(server, ModVariantes.SLIME_VIRAL));

        Eventos.amarillo("zombie_ladron", "¡Cuidado con el Zombie Ladrón!",
                "Aparecerá en lugares oscuros. Si te pega con las manos vacías, te robará UN montón de Rumores (el que más valga de tu inventario) "
                        + "y huirá invisible y con Velocidad II durante 8 segundos. Mátalo para recuperarlo: lo suelta siempre al morir. No roba nada más.",
                "Con la subida de precios de la tienda, un zombie decidió que trabajar no le compensaba. El Centro de Desinformación condena el robo "
                        + "y recuerda que los Rumores robados siguen pagando impuestos.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ZOMBIE_LADRON));

        Eventos.amarillo("zombie_tanque", "¡Llega el Zombie Tanque!",
                "Aparecerá en lugares oscuros. Es enorme, lento y va blindado: 25 corazones, 6 puntos de armadura, pega 3,5 corazones "
                        + "y no se le puede empujar. Nunca sale pequeño.",
                "Un zombie se pasó con los batidos de proteínas y alguien le atornilló planchas de metal \"por seguridad laboral\". "
                        + "El Centro de Desinformación no sabe quién fue. Fue el becario.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ZOMBIE_TANQUE));

        Eventos.amarillo("bruja_influencer", "¡Llega la Bruja Influencer!",
                "Aparecerá en lugares oscuros. Cada 20 segundos, si tiene a un jugador a menos de 16 bloques, llamará a 2 Seguidores (lepismas) "
                        + "que aparecen a su lado, hasta un máximo de 6 cerca de ella. Sus pociones son las de una bruja normal.",
                "Una bruja abrió un canal y ahora todo lo que hace es contenido. El Centro de Desinformación le ofreció un patrocinio, "
                        + "pero lo rechazó: dice que ya tiene suficientes seguidores. Y van a por ti.",
                server -> Eventos.desbloquearMob(server, ModVariantes.BRUJA_INFLUENCER));

        Eventos.amarillo("enderman_bromista", "¡Llega el Enderman Bromista!",
                "Aparecerá en lugares oscuros y también en el End. Si te pega, te gasta una broma: un efecto al azar "
                        + "(mareo, ceguera, levitación, lentitud, hambre, oscuridad, supersalto... o los controles al revés unos segundos).",
                "Los endermen llevan siglos llevándose bloques. Este ha descubierto que es mucho más divertido llevarse a la gente. "
                        + "El Centro de Desinformación lo considera una broma inocente. Las víctimas, no tanto.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ENDERMAN_BROMISTA));

        Eventos.amarillo("blaze_helado", "¡Llega el Blaze Helado!",
                "Aparecerá en cualquier bioma del Nether. Cada segundo congela a los jugadores que tenga a menos de 5 bloques: "
                        + "Lentitud II y escarcha que se acumula (si te quedas cerca unos segundos, empezarás a recibir daño por congelación). "
                        + "En vez de bolas de fuego lanza ráfagas de 3 bolas de nieve heladas (1 corazón, mucha escarcha y Lentitud II). Al ser de hielo, el fuego sí le hace daño.",
                "Para ahorrar en la factura, el Centro de Desinformación instaló aire acondicionado en el Nether. Un blaze se quedó demasiado "
                        + "cerca de la salida. Ahora está helado, de muy mal humor, y sigue tirando bolas de fuego por costumbre.",
                server -> Eventos.desbloquearMob(server, ModVariantes.BLAZE_HELADO));

        Eventos.amarillo("esqueleto_wither_arquero", "¡Llega el Esqueleto Wither Arquero!",
                "Aparecerá en lugares oscuros de cualquier bioma del Nether. Lleva arco: sus flechas salen ardiendo y, si te dan, "
                        + "te dejan Wither II durante 5 segundos.",
                "Los esqueletos wither se quejaron de que la espada de piedra no estaba a la altura de su imagen. "
                        + "El Centro de Desinformación les compró arcos. Nadie revisó qué flechas usaban.",
                server -> Eventos.desbloquearMob(server, ModVariantes.ESQUELETO_WITHER_ARQUERO));
    }
}

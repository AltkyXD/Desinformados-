package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Reglas del desafío: sin PvP, spawn protegido, minerales por fases y muerte = fuera del server. */
public class Reglas {
    private static final int TICKS_ANTES_DE_EXPULSAR = 60; // 3 segundos
    private static final Map<UUID, Integer> expulsionesPendientes = new HashMap<>();

    public static void registrar() {
        // 1) No se pueden matar entre ustedes (incluye flechas, tridentes, etc.)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof PlayerEntity && fuente.getAttacker() instanceof PlayerEntity atacante && atacante != entidad));

        // 2) Morir = quedar fuera del server hasta que te revivan
        ServerLivingEntityEvents.AFTER_DEATH.register((entidad, fuente) -> {
            if (entidad instanceof ServerPlayerEntity jugador) {
                String nombre = jugador.getGameProfile().getName();
                EstadoServidor.get(jugador.getServer()).agregarMuerto(jugador.getUuid(), nombre);
                jugador.getServer().getPlayerManager().broadcast(
                        Text.literal(nombre + " ha sido DESINFORMADO. Solo un Periódico Desinformado puede traerlo de vuelta.")
                                .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
                expulsionesPendientes.put(jugador.getUuid(), TICKS_ANTES_DE_EXPULSAR);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Map.Entry<UUID, Integer>> it = expulsionesPendientes.entrySet().iterator();
            while (it.hasNext()) {
                var e = it.next();
                int restante = e.getValue() - 1;
                if (restante <= 0) {
                    it.remove();
                    ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                    if (p != null) p.networkHandler.disconnect(mensajeExpulsion());
                } else {
                    e.setValue(restante);
                }
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            if (EstadoServidor.get(server).estaMuerto(handler.player.getUuid())) {
                handler.disconnect(mensajeExpulsion());
            }
        });

        // 3) Spawn protegido + 4) minerales progresivos
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (player.isCreative() || world.getServer() == null) return true;
            EstadoServidor estado = EstadoServidor.get(world.getServer());
            if (enSpawn(world, pos, estado)) {
                player.sendMessage(Text.literal("El spawn está protegido por el Centro de Desinformación").formatted(Formatting.RED), true);
                return false;
            }
            int faseNecesaria = Progresion.faseDe(state.getBlock());
            if (faseNecesaria > estado.getFase()) {
                player.sendMessage(Text.literal("Este mineral sigue bloqueado (se desbloquea en la fase " + faseNecesaria + ")")
                        .formatted(Formatting.YELLOW), true);
                return false;
            }
            return true;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient() || player.isCreative()) return ActionResult.PASS;
            Item item = player.getStackInHand(hand).getItem();
            if (!(item instanceof BlockItem || item instanceof BucketItem)) return ActionResult.PASS;
            if (enSpawn(world, hit.getBlockPos(), EstadoServidor.get(world.getServer()))) {
                player.sendMessage(Text.literal("No puedes construir en el spawn").formatted(Formatting.RED), true);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private static boolean enSpawn(World world, BlockPos pos, EstadoServidor estado) {
        if (world.getRegistryKey() != World.OVERWORLD) return false;
        BlockPos spawn = world.getSpawnPos();
        int r = estado.getRadioSpawn();
        return Math.abs(pos.getX() - spawn.getX()) <= r && Math.abs(pos.getZ() - spawn.getZ()) <= r;
    }

    private static Text mensajeExpulsion() {
        return Text.literal("Has sido DESINFORMADO\n\n").formatted(Formatting.DARK_RED, Formatting.BOLD)
                .append(Text.literal("No puedes volver hasta que un compañero use un\nPeriódico Desinformado para revivirte.")
                        .formatted(Formatting.GRAY));
    }
}

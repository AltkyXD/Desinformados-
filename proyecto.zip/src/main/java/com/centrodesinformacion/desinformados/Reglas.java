package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.CreeperOscuroEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import com.centrodesinformacion.desinformados.network.MuertePayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.GameMode;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Reglas del desafío: sin PvP, spawn protegido, minerales por fases y muerte = fuera del server. */
public class Reglas {
    private static final int TICKS_ANTES_DE_EXPULSAR = 60; // 3 segundos
    private static final Map<UUID, Integer> expulsionesPendientes = new HashMap<>();

    public static void registrar() {
        // 0) Al morir conservas todo (inventario y experiencia), también al ser revivido con periódico
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(server ->
                server.getGameRules().get(GameRules.KEEP_INVENTORY).set(true, server));

        // 1) No se pueden matar entre ustedes (incluye flechas, tridentes, etc.)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof PlayerEntity && fuente.getAttacker() instanceof PlayerEntity atacante && atacante != entidad));

        // Creeper Oscuro: su explosión te quita un contenedor de corazón
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) -> {
            if (entidad instanceof ServerPlayerEntity jugador && !jugador.isCreative()
                    && (fuente.getAttacker() instanceof CreeperOscuroEntity || fuente.getSource() instanceof CreeperOscuroEntity)) {
                Vida.cambiarRojos(jugador, -1);
                jugador.sendMessage(Text.literal("¡Un Creeper Oscuro te ha arrancado un corazón!").formatted(Formatting.DARK_PURPLE), true);
            }
            return true;
        });

        // 2) Vidas: cada jugador tiene 2. La primera muerte es normal (aviso de última vida).
        //    La última: animación para todos, espectador unos segundos y fuera del server.
        ServerLivingEntityEvents.ALLOW_DEATH.register((entidad, fuente, cantidad) -> {
            if (!(entidad instanceof ServerPlayerEntity jugador) || jugador.isCreative() || jugador.isSpectator()) return true;
            if (jugador.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING) || jugador.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return true;
            EstadoServidor estado = EstadoServidor.get(jugador.getServer());
            if (estado.getVidas(jugador.getUuid()) > 1) return true; // muerte normal
            eliminar(jugador, fuente.getDeathMessage(jugador));
            return false;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entidad, fuente) -> {
            if (entidad instanceof ServerPlayerEntity jugador && !jugador.isCreative()) {
                EstadoServidor estado = EstadoServidor.get(jugador.getServer());
                int quedan = Math.max(1, estado.getVidas(jugador.getUuid()) - 1);
                estado.setVidas(jugador.getUuid(), quedan);
                estado.setAlmas(jugador.getUuid(), 0f);
                estado.setRojos(jugador.getUuid(), 0);
                jugador.getServer().getPlayerManager().broadcast(
                        Text.literal(jugador.getGameProfile().getName() + " ha perdido una vida. Le queda " + quedan + ".")
                                .formatted(Formatting.DARK_RED), false);
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, seguiaVivo) -> {
            if (!seguiaVivo && EstadoServidor.get(nuevo.getServer()).getVidas(nuevo.getUuid()) == 1) {
                Tareas.programar(10, () -> ServerPlayNetworking.send(nuevo, new EventoTvPayload("calavera",
                        "¡ÚLTIMA VIDA!", "¡Estás a punto de ser Desinformado!")));
                nuevo.sendMessage(Text.literal("☠ ¡Estás a punto de ser Desinformado! Te queda tu última vida.")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Map.Entry<UUID, Integer>> it = expulsionesPendientes.entrySet().iterator();
            while (it.hasNext()) {
                var e = it.next();
                int restante = e.getValue() - 1;
                if (restante <= 0) {
                    it.remove();
                    ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                    if (p != null) p.networkHandler.disconnect(mensajeExpulsion());
                } else {
                    e.setValue(restante);
                }
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            EstadoServidor estado = EstadoServidor.get(server);
            if (estado.estaMuerto(handler.player.getUuid())) {
                handler.disconnect(mensajeExpulsion());
            } else if (estado.debeRestaurar(handler.player.getUuid())) {
                restaurar(handler.player);
            }
        });

        // 3) Spawn protegido + 4) minerales progresivos
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (player.isCreative() || world.getServer() == null) return true;
            EstadoServidor estado = EstadoServidor.get(world.getServer());
            if (enSpawn(world, pos, estado)) {
                player.sendMessage(Text.literal("El spawn está protegido por el Centro de Desinformación").formatted(Formatting.RED), true);
                return false;
            }
            int faseNecesaria = Progresion.faseDe(state.getBlock());
            if (faseNecesaria > estado.getFase()) {
                player.sendMessage(Text.literal("Este mineral sigue bloqueado (se desbloquea en la fase " + faseNecesaria + ")")
                        .formatted(Formatting.YELLOW), true);
                return false;
            }
            return true;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient() || player.isCreative()) return ActionResult.PASS;
            Item item = player.getStackInHand(hand).getItem();
            if (!(item instanceof BlockItem || item instanceof BucketItem)) return ActionResult.PASS;
            if (enSpawn(world, hit.getBlockPos(), EstadoServidor.get(world.getServer()))) {
                player.sendMessage(Text.literal("No puedes construir en el spawn").formatted(Formatting.RED), true);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    public static boolean enSpawn(World world, BlockPos pos, EstadoServidor estado) {
        if (world.getRegistryKey() != World.OVERWORLD) return false;
        BlockPos spawn = estado.getCentroProtegido() != null ? BlockPos.fromLong(estado.getCentroProtegido()) : world.getSpawnPos();
        int r = estado.getRadioSpawn();
        return Math.abs(pos.getX() - spawn.getX()) <= r && Math.abs(pos.getZ() - spawn.getZ()) <= r;
    }

    private static final int TICKS_ESPECTADOR = 160; // 8 segundos para ver la animación y dónde murió

    private static void eliminar(ServerPlayerEntity jugador, Text mensajeMuerte) {
        MinecraftServer server = jugador.getServer();
        EstadoServidor estado = EstadoServidor.get(server);
        String nombre = jugador.getGameProfile().getName();

        // Conserva todas sus cosas: al ser revivido vuelve con todo
        jugador.setHealth(jugador.getMaxHealth());
        jugador.clearStatusEffects();
        jugador.extinguish();
        jugador.changeGameMode(GameMode.SPECTATOR);

        estado.agregarMuerto(jugador.getUuid(), nombre);
        estado.setAlmas(jugador.getUuid(), 0f);
        estado.setRojos(jugador.getUuid(), 0);
        estado.setVidas(jugador.getUuid(), 0);
        estado.marcarRestaurar(jugador.getUuid(), true);
        Vida.aplicarTodo(jugador);

        server.getPlayerManager().broadcast(mensajeMuerte.copy().formatted(Formatting.GRAY), false);
        server.getPlayerManager().broadcast(
                Text.literal("☠ " + nombre + " ha sido DESINFORMADO. Solo un Periódico Desinformado puede traerlo de vuelta.")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
        MuertePayload paquete = new MuertePayload(nombre);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (ServerPlayNetworking.canSend(p, MuertePayload.ID)) ServerPlayNetworking.send(p, paquete);
        }
        expulsionesPendientes.put(jugador.getUuid(), TICKS_ESPECTADOR);
    }

    /** Devuelve a un revivido a supervivencia en el spawn, con 1 vida. */
    public static void restaurar(ServerPlayerEntity p) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        estado.marcarRestaurar(p.getUuid(), false);
        expulsionesPendientes.remove(p.getUuid());
        ServerWorld mundo = p.getServer().getOverworld();
        BlockPos spawn = mundo.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, mundo.getSpawnPos());
        p.teleport(mundo, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, p.getYaw(), p.getPitch());
        p.changeGameMode(GameMode.SURVIVAL);
        p.setHealth(p.getMaxHealth());
        Vida.aplicarTodo(p);
        p.sendMessage(Text.literal("¡Has vuelto! Te queda 1 vida, no la desperdicies.").formatted(Formatting.GREEN, Formatting.BOLD), false);
    }

    private static Text mensajeExpulsion() {
        return Text.literal("Has sido DESINFORMADO\n\n").formatted(Formatting.DARK_RED, Formatting.BOLD)
                .append(Text.literal("No puedes volver hasta que un compañero use un\nPeriódico Desinformado para revivirte.")
                        .formatted(Formatting.GRAY));
    }
}

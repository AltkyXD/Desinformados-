package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.BlackjackAccionPayload;
import com.centrodesinformacion.desinformados.network.BlackjackPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Mesa de Blackjack del casino. Se apuesta con los Rumores del inventario (de 10 a 1000, de 10 en 10).
 * - Gana quien se acerque más a 21 sin pasarse. As = 1 u 11; J, Q y K = 10.
 * - La banca pide carta hasta llegar a 17 y con 17 o más se planta.
 * - Ganar paga x2 (lo apostado + otro tanto); Blackjack (21 con las dos primeras cartas) paga x2,5; empate devuelve la apuesta.
 * - Con las dos primeras cartas se puede doblar: pagas otra vez la apuesta, recibes UNA carta y te plantas.
 * - Si la banca tiene Blackjack de salida, se descubre al momento (no se llega a doblar contra ella).
 * Mazo infinito (cada carta es al azar). Todo lo decide el servidor; el cliente solo dibuja.
 * Si te desconectas a mitad de mano te plantas solo, y lo que ganes va a tu cuenta del Banco.
 */
public final class Blackjack {
    public static final int MINIMA = 10, MAXIMA = 1000, PASO = 10;
    /** Carta boca abajo (la segunda de la banca mientras juegas). */
    public static final int OCULTA = -1;
    /** Fases que ve el cliente. */
    public static final int SIN_MANO = 0, JUGANDO = 1, TERMINADA = 2;

    private static final class Mano {
        final UUID jugador;
        final String nombre;
        final BlockPos mesa;
        int apuesta;
        final List<Integer> cartas = new ArrayList<>();
        final List<Integer> banca = new ArrayList<>();
        boolean terminada = false;
        int pago = 0;
        String mensaje = "";

        Mano(UUID jugador, String nombre, BlockPos mesa, int apuesta) {
            this.jugador = jugador; this.nombre = nombre; this.mesa = mesa; this.apuesta = apuesta;
        }
    }

    private static final Map<UUID, Mano> MANOS = new HashMap<>();
    private static final Map<UUID, BlockPos> ABIERTA = new HashMap<>();

    private Blackjack() {}

    // ------------------------------------------------------------------ cartas (también las usa el cliente)

    /** 0..51: rango = c % 13 (0 = As, 1..9 = 2..10, 10 = J, 11 = Q, 12 = K), palo = c / 13 (♠ ♥ ♦ ♣). */
    public static String rango(int c) {
        int r = c % 13;
        return switch (r) { case 0 -> "A"; case 10 -> "J"; case 11 -> "Q"; case 12 -> "K"; default -> String.valueOf(r + 1); };
    }

    public static String palo(int c) {
        return switch (c / 13) { case 0 -> "♠"; case 1 -> "♥"; case 2 -> "♦"; default -> "♣"; };
    }

    public static boolean roja(int c) {
        int p = c / 13;
        return p == 1 || p == 2;
    }

    /** Valor de la mano (las cartas ocultas no cuentan). Los ases valen 11 salvo que te pasen de 21. */
    public static int valor(List<Integer> cartas) {
        int total = 0, ases = 0;
        for (int c : cartas) {
            if (c < 0) continue;
            int r = c % 13;
            if (r == 0) { ases++; total += 11; } else total += Math.min(10, r + 1);
        }
        while (total > 21 && ases > 0) { total -= 10; ases--; }
        return total;
    }

    public static boolean esBlackjack(List<Integer> cartas) {
        return cartas.size() == 2 && valor(cartas) == 21;
    }

    private static int carta(Random r) {
        return r.nextInt(52);
    }

    // ------------------------------------------------------------------ registro

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(BlackjackAccionPayload.ID, (paquete, ctx) -> accion(ctx.player(), paquete));
        // Si se va a mitad de mano: se planta solo y lo que gane va al Banco (así no se puede huir de una mano mala)
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID u = handler.player.getUuid();
            ABIERTA.remove(u);
            Mano m = MANOS.remove(u);
            if (m != null && !m.terminada) {
                jugarBanca(m, server.getOverworld() != null ? server.getOverworld().getRandom() : Random.create());
                if (m.pago > 0) {
                    EstadoServidor e = EstadoServidor.get(server);
                    e.setSaldo(u, e.getSaldo(u) + m.pago);
                }
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (server.getOverworld() != null) {
                EstadoServidor e = EstadoServidor.get(server);
                for (Mano m : MANOS.values()) {
                    if (m.terminada) continue;
                    jugarBanca(m, server.getOverworld().getRandom());
                    if (m.pago > 0) e.setSaldo(m.jugador, e.getSaldo(m.jugador) + m.pago);
                }
            }
            MANOS.clear();
            ABIERTA.clear();
        });
    }

    public static void abrir(ServerPlayerEntity p, BlockPos pos) {
        ABIERTA.put(p.getUuid(), pos.toImmutable());
        enviar(p, true);
    }

    private static boolean cerca(ServerPlayerEntity p) {
        BlockPos pos = ABIERTA.get(p.getUuid());
        return pos != null && p.getBlockPos().isWithinDistance(pos, 8) && p.getWorld().getBlockState(pos).getBlock() instanceof BlackjackBlock;
    }

    private static void enviar(ServerPlayerEntity p, boolean abrir) {
        if (!ServerPlayNetworking.canSend(p, BlackjackPayload.ID)) return;
        Mano m = MANOS.get(p.getUuid());
        if (m == null) {
            ServerPlayNetworking.send(p, new BlackjackPayload(Tragamonedas.rumores(p), 0, SIN_MANO, 0, List.of(), List.of(), "", abrir));
            return;
        }
        List<Integer> banca = new ArrayList<>(m.banca);
        if (!m.terminada && banca.size() > 1) banca.set(1, OCULTA);       // la segunda carta de la banca, boca abajo
        ServerPlayNetworking.send(p, new BlackjackPayload(Tragamonedas.rumores(p), m.apuesta, m.terminada ? TERMINADA : JUGANDO,
                m.pago, List.copyOf(m.cartas), banca, m.mensaje, abrir));
    }

    // ------------------------------------------------------------------ jugadas

    private static void accion(ServerPlayerEntity p, BlackjackAccionPayload paquete) {
        if (!cerca(p)) return;
        Mano m = MANOS.get(p.getUuid());
        switch (paquete.accion()) {
            case "repartir" -> repartir(p, m, paquete.apuesta());
            case "pedir" -> { if (m != null && !m.terminada) pedir(p, m); }
            case "plantarse" -> { if (m != null && !m.terminada) { jugarBanca(m, p.getRandom()); terminar(p, m); } }
            case "doblar" -> { if (m != null && !m.terminada && m.cartas.size() == 2) doblar(p, m); }
            default -> { }
        }
        enviar(p, false);
    }

    private static void repartir(ServerPlayerEntity p, Mano vieja, int apuesta) {
        if (vieja != null && !vieja.terminada) return;                     // ya hay una mano en juego
        if (apuesta < MINIMA || apuesta > MAXIMA || apuesta % PASO != 0) return;
        if (!Tragamonedas.pagar(p, apuesta)) {
            p.sendMessage(Text.literal("No llevas " + apuesta + " Rumores en el inventario").formatted(Formatting.RED), true);
            return;
        }
        Mano m = new Mano(p.getUuid(), p.getGameProfile().getName(), ABIERTA.get(p.getUuid()), apuesta);
        MANOS.put(p.getUuid(), m);
        Random r = p.getRandom();
        m.cartas.add(carta(r));
        m.banca.add(carta(r));
        m.cartas.add(carta(r));
        m.banca.add(carta(r));
        sonido(p, m, SoundEvents.ITEM_BOOK_PAGE_TURN, 1f, 1.2f);
        // Blackjack de salida (tuyo o de la banca): se descubre todo y se acaba la mano
        if (esBlackjack(m.cartas) || esBlackjack(m.banca)) {
            liquidar(m);
            terminar(p, m);
        }
    }

    private static void pedir(ServerPlayerEntity p, Mano m) {
        m.cartas.add(carta(p.getRandom()));
        sonido(p, m, SoundEvents.ITEM_BOOK_PAGE_TURN, 1f, 1.3f);
        int v = valor(m.cartas);
        if (v > 21) {
            m.pago = 0;
            m.mensaje = "Te pasaste (" + v + "). Pierdes " + m.apuesta + ".";
            m.terminada = true;
            terminar(p, m);
        } else if (v == 21) {                                              // con 21 te plantas solo
            jugarBanca(m, p.getRandom());
            terminar(p, m);
        }
    }

    private static void doblar(ServerPlayerEntity p, Mano m) {
        if (!Tragamonedas.pagar(p, m.apuesta)) {
            p.sendMessage(Text.literal("Para doblar necesitas otros " + m.apuesta + " Rumores en el inventario").formatted(Formatting.RED), true);
            return;
        }
        m.apuesta *= 2;
        m.cartas.add(carta(p.getRandom()));
        sonido(p, m, SoundEvents.ITEM_BOOK_PAGE_TURN, 1f, 1.1f);
        if (valor(m.cartas) > 21) {
            m.pago = 0;
            m.mensaje = "Doblaste y te pasaste (" + valor(m.cartas) + "). Pierdes " + m.apuesta + ".";
            m.terminada = true;
        } else {
            jugarBanca(m, p.getRandom());
        }
        terminar(p, m);
    }

    /** La banca pide hasta 17 (si no te has pasado) y se reparte el premio. */
    private static void jugarBanca(Mano m, Random r) {
        if (m.terminada) return;
        if (valor(m.cartas) <= 21) {
            while (valor(m.banca) < 17) m.banca.add(carta(r));
        }
        liquidar(m);
    }

    /** Calcula lo que se cobra (incluida la apuesta) y deja la mano terminada. */
    private static void liquidar(Mano m) {
        int tu = valor(m.cartas), banca = valor(m.banca);
        boolean tuBj = esBlackjack(m.cartas), bancaBj = esBlackjack(m.banca);
        if (tuBj && bancaBj) {
            m.pago = m.apuesta;
            m.mensaje = "Los dos tenéis Blackjack: empate, recuperas " + m.apuesta + ".";
        } else if (tuBj) {
            m.pago = m.apuesta * 5 / 2;
            m.mensaje = "¡BLACKJACK! Cobras " + m.pago + " Rumores.";
        } else if (bancaBj) {
            m.pago = 0;
            m.mensaje = "La banca tiene Blackjack. Pierdes " + m.apuesta + ".";
        } else if (tu > 21) {
            m.pago = 0;
            m.mensaje = "Te pasaste (" + tu + "). Pierdes " + m.apuesta + ".";
        } else if (banca > 21) {
            m.pago = m.apuesta * 2;
            m.mensaje = "La banca se pasó (" + banca + "). ¡Cobras " + m.pago + "!";
        } else if (tu > banca) {
            m.pago = m.apuesta * 2;
            m.mensaje = tu + " contra " + banca + ". ¡Cobras " + m.pago + "!";
        } else if (tu == banca) {
            m.pago = m.apuesta;
            m.mensaje = "Empate a " + tu + ": recuperas " + m.apuesta + ".";
        } else {
            m.pago = 0;
            m.mensaje = tu + " contra " + banca + ". Pierdes " + m.apuesta + ".";
        }
        m.terminada = true;
    }

    /** Paga, avisa y hace los efectos de fin de mano. */
    private static void terminar(ServerPlayerEntity p, Mano m) {
        Misiones.sumar(p, "blackjack", 1);
        ServerWorld w = p.getServerWorld();
        BlockPos mesa = m.mesa != null ? m.mesa : p.getBlockPos();
        if (m.pago > 0) Tragamonedas.darRumores(p, m.pago);
        Formatting color = m.pago > m.apuesta ? Formatting.GREEN : m.pago == m.apuesta ? Formatting.YELLOW : Formatting.GRAY;
        p.sendMessage(Text.literal("Blackjack: ").formatted(Formatting.GOLD).append(Text.literal(m.mensaje).formatted(color)), false);
        if (m.pago > m.apuesta) {
            w.playSound(null, mesa, SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.BLOCKS, 0.9f, 1.3f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, mesa.getX() + 0.5, mesa.getY() + 1.2, mesa.getZ() + 0.5, 15, 0.4, 0.3, 0.4, 0.1);
            if (esBlackjack(m.cartas) && !esBlackjack(m.banca))
                w.getServer().getPlayerManager().broadcast(Text.literal("¡" + m.nombre + " sacó BLACKJACK y cobra " + m.pago + " Rumores!")
                        .formatted(Formatting.GREEN, Formatting.BOLD), false);
        } else if (m.pago == 0) {
            w.playSound(null, mesa, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 0.9f, 0.6f);
        }
    }

    private static void sonido(ServerPlayerEntity p, Mano m, net.minecraft.sound.SoundEvent s, float vol, float tono) {
        BlockPos mesa = m.mesa != null ? m.mesa : p.getBlockPos();
        p.getServerWorld().playSound(null, mesa, s, SoundCategory.BLOCKS, vol, tono);
    }
}

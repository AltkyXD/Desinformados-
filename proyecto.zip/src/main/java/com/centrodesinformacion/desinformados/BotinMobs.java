package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.JefeTeleEntity;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Los mobs que mata un jugador pueden soltar Rumores (monedas en el suelo). Cuanto más raro y fuerte el mob,
 * más probable y más cantidad. Extras:
 * - Saqueo: +5 % de probabilidad y +1 al máximo por nivel.
 * - Creeper cargado: siempre suelta, y el triple.
 * - Mob con su mutación activa (Travensaños furiosos, ghasts triples...): un 50 % más.
 * - "¡Iba forrado!": 1,5 % de que cualquier mob suelte además un Rumor Gris (50).
 * - Tope anti-granjas: como mucho 150 Rumores de mobs por jugador cada 20 minutos (los jefes no cuentan).
 * No sueltan nada: los Gatos Cubo, el Muñeco, los esbirros del jefe final ni los clones de la Interferencia.
 */
public final class BotinMobs {
    private record Botin(float prob, int min, int max, boolean jefe) {}

    private static final int TOPE = 150;
    private static final int VENTANA = 20 * 60 * 20;          // 20 minutos
    private static final float FORRADO = 0.015f;
    private static final RegistryKey<Enchantment> SAQUEO = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.ofVanilla("looting"));

    private static Map<EntityType<?>, Botin> tabla;
    private static Map<EntityType<?>, String> mutaciones;
    /** uuid -> {tick en que empezó su ventana de 20 min, Rumores ganados en ella, ya avisado (0/1)} */
    private static final Map<UUID, int[]> GANADO = new HashMap<>();

    private BotinMobs() {}

    private static void poner(Map<EntityType<?>, Botin> t, float prob, int min, int max, EntityType<?>... tipos) {
        for (EntityType<?> tipo : tipos) t.put(tipo, new Botin(prob, min, max, false));
    }

    private static Map<EntityType<?>, Botin> tabla() {
        if (tabla != null) return tabla;
        Map<EntityType<?>, Botin> t = new HashMap<>();
        // ---- Overworld comunes: poquito y de vez en cuando
        poner(t, 0.10f, 1, 3, EntityType.ZOMBIE, EntityType.HUSK, EntityType.SKELETON, EntityType.SPIDER);
        poner(t, 0.12f, 1, 4, EntityType.DROWNED, EntityType.ZOMBIE_VILLAGER, EntityType.STRAY, EntityType.BOGGED, EntityType.CAVE_SPIDER);
        poner(t, 0.12f, 2, 4, EntityType.CREEPER);
        poner(t, 0.06f, 1, 2, EntityType.SLIME);
        poner(t, 0.05f, 1, 2, EntityType.SILVERFISH, EntityType.ENDERMITE, EntityType.VEX, EntityType.ZOMBIFIED_PIGLIN);
        poner(t, 0.18f, 2, 6, EntityType.PHANTOM);
        // ---- Medianos
        poner(t, 0.15f, 3, 8, EntityType.ENDERMAN);
        poner(t, 0.25f, 5, 12, EntityType.WITCH);
        poner(t, 0.20f, 4, 10, EntityType.PILLAGER, EntityType.BLAZE, EntityType.GUARDIAN);
        poner(t, 0.30f, 8, 16, EntityType.VINDICATOR, EntityType.BREEZE);
        poner(t, 0.35f, 8, 20, EntityType.GHAST);
        poner(t, 0.20f, 5, 10, EntityType.HOGLIN);
        poner(t, 0.25f, 6, 12, EntityType.ZOGLIN, EntityType.SHULKER);
        poner(t, 0.25f, 6, 14, EntityType.WITHER_SKELETON);
        poner(t, 0.12f, 2, 6, EntityType.PIGLIN);
        poner(t, 0.08f, 1, 3, EntityType.MAGMA_CUBE);
        // ---- Fuertes
        poner(t, 0.60f, 20, 40, EntityType.EVOKER);
        poner(t, 0.70f, 25, 50, EntityType.RAVAGER);
        poner(t, 0.60f, 20, 35, EntityType.PIGLIN_BRUTE);
        // ---- Jefes (siempre, y no cuentan para el tope)
        t.put(EntityType.ELDER_GUARDIAN, new Botin(1f, 60, 100, true));
        t.put(EntityType.WARDEN, new Botin(1f, 150, 250, true));
        t.put(EntityType.WITHER, new Botin(1f, 300, 400, true));
        // ---- Mobs del Centro
        poner(t, 0.15f, 2, 5, ModEntidades.ZOMBIE_ESTATICA, ModEntidades.ESQUELETO_ESTATICA, ModEntidades.ARANA_ESTATICA, ModEntidades.CREEPER_ESTATICA,
                ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ESQUELETO_DIBUJO, ModEntidades.CREEPER_DIBUJO, ModEntidades.ARANA_DIBUJO);
        poner(t, 0.20f, 3, 7, ModEntidades.FURRO_DIBUJO);
        poner(t, 0.10f, 1, 4, ModEntidades.INTERFERENCIA);
        poner(t, 0.25f, 4, 10, ModEntidades.GARABATO, ModEntidades.TRAVENSANO, ModEntidades.FURRO);
        poner(t, 0.30f, 5, 12, ModEntidades.CUBO_BLANCO);
        poner(t, 0.30f, 6, 15, ModEntidades.CREEPER_FUEGO, ModEntidades.CUBO_ROJO, ModEntidades.ESQUELETO_RAFAGA);
        poner(t, 0.35f, 6, 14, ModEntidades.ZOMBIE_NARANJA, ModEntidades.ULISES);
        poner(t, 0.40f, 8, 18, ModEntidades.ANGEL);
        poner(t, 0.45f, 10, 25, ModEntidades.ALE);
        poner(t, 0.50f, 12, 25, ModEntidades.KEVIN);
        poner(t, 0.60f, 15, 30, ModEntidades.CREEPER_OSCURO, ModEntidades.BRANDON, ModEntidades.ALTKY);
        t.put(ModEntidades.JEFE_TELE, new Botin(1f, 500, 500, true));
        tabla = t;
        return t;
    }

    /** Mob -> mutación que lo hace más peligroso (si está activa, paga un 50 % más). */
    private static Map<EntityType<?>, String> mutaciones() {
        if (mutaciones != null) return mutaciones;
        Map<EntityType<?>, String> m = new HashMap<>();
        m.put(ModEntidades.TRAVENSANO, "travensanos_furiosos");
        m.put(ModEntidades.ALE, "ale_poderoso");
        m.put(ModEntidades.FURRO, "furros_manada");
        m.put(ModEntidades.INTERFERENCIA, "interferencias_clon");
        m.put(ModEntidades.GARABATO, "garabatos_altos");
        m.put(EntityType.ZOMBIE, "zombies_falsos");
        m.put(EntityType.SKELETON, "esqueletos_doble_arco");
        m.put(EntityType.SPIDER, "aranas_pequenas");
        m.put(EntityType.CREEPER, "creepers_electrificados");
        m.put(EntityType.GHAST, "ghasts_triples");
        m.put(EntityType.BLAZE, "blazes_dobles");
        m.put(EntityType.PIGLIN, "piglins_ladrones");
        m.put(EntityType.HOGLIN, "hoglins_gimnasio");
        m.put(EntityType.MAGMA_CUBE, "magma_ardiente");
        m.put(EntityType.WITHER_SKELETON, "wither_veneno");
        m.put(EntityType.ZOMBIFIED_PIGLIN, "zombificados_rencorosos");
        m.put(EntityType.ENDERMAN, "enderman_teletransporte");
        mutaciones = m;
        return m;
    }

    public static void registrar() {
        ServerLivingEntityEvents.AFTER_DEATH.register(BotinMobs::alMorir);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> GANADO.clear());   // los ticks vuelven a 0 en cada arranque
    }

    private static void alMorir(LivingEntity mob, net.minecraft.entity.damage.DamageSource fuente) {
        if (!(mob.getWorld() instanceof ServerWorld w)) return;
        if (!(fuente.getAttacker() instanceof ServerPlayerEntity p) || p.isCreative() || p.isSpectator()) return;
        if (mob.getCommandTags().contains(JefeTeleEntity.MARCA_ESBIRRO)) return;                       // los del jefe final, no
        if (mob.getType() == ModEntidades.INTERFERENCIA && mob.getCommandTags().contains(Mobs.MARCA_EVENTO)) return;   // clones
        Botin b = tabla().get(mob.getType());
        if (b == null) return;

        Random r = w.getRandom();
        int saqueo = nivelSaqueo(w, p.getMainHandStack());
        boolean cargado = mob instanceof CreeperEntity c && c.shouldRenderOverlay();
        float prob = cargado ? 1f : Math.min(1f, b.prob() + 0.05f * saqueo);
        if (!b.jefe() && r.nextFloat() >= prob) return;

        int cantidad = b.min() + r.nextInt(b.max() + saqueo - b.min() + 1);
        if (cargado) cantidad *= 3;
        String mutacion = mutaciones().get(mob.getType());
        if (mutacion != null && EstadoServidor.get(w.getServer()).tieneCambio(mutacion)) cantidad = Math.round(cantidad * 1.5f);
        boolean forrado = !b.jefe() && r.nextFloat() < FORRADO;
        if (forrado) cantidad += 50;

        if (!b.jefe()) {
            cantidad = Math.min(cantidad, quedan(p, w.getServer().getTicks()));
            if (cantidad <= 0) return;
            GANADO.get(p.getUuid())[1] += cantidad;
        }

        soltar(w, mob, cantidad, b.jefe());
        if (forrado) {
            p.sendMessage(Text.literal("¡Este mob iba forrado! +50 Rumores").formatted(Formatting.GOLD, Formatting.BOLD), true);
            w.playSound(null, mob.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.6f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, mob.getX(), mob.getY() + 0.8, mob.getZ(), 12, 0.4, 0.4, 0.4, 0.1);
        } else if (b.jefe()) {
            w.getServer().getPlayerManager().broadcast(Text.literal("¡" + p.getGameProfile().getName() + " ha hecho llover " + cantidad
                    + " Rumores al acabar con " + mob.getName().getString() + "!").formatted(Formatting.GOLD), false);
        }
    }

    /** Lo que le queda por ganar en su ventana de 20 minutos (y avisa una vez si ya no queda nada). */
    private static int quedan(ServerPlayerEntity p, int ahora) {
        int[] g = GANADO.computeIfAbsent(p.getUuid(), k -> new int[]{ahora, 0, 0});
        if (ahora - g[0] >= VENTANA || ahora < g[0]) { g[0] = ahora; g[1] = 0; g[2] = 0; }
        int quedan = TOPE - g[1];
        if (quedan <= 0 && g[2] == 0) {
            g[2] = 1;
            p.sendMessage(Text.literal("Los mobs ya no llevan más Rumores encima... vuelve dentro de un rato.").formatted(Formatting.GRAY), true);
        }
        return quedan;
    }

    private static int nivelSaqueo(ServerWorld w, ItemStack arma) {
        if (arma.isEmpty()) return 0;
        return w.getRegistryManager().get(RegistryKeys.ENCHANTMENT).getEntry(SAQUEO)
                .map(e -> EnchantmentHelper.getLevel(e, arma)).orElse(0);
    }

    /** Suelta la cantidad en monedas. Los jefes la sueltan en muchas monedas sueltas, como una lluvia. */
    private static void soltar(ServerWorld w, LivingEntity mob, int cantidad, boolean lluvia) {
        List<Item> monedas = List.of(ModItems.RUMOR_GRIS, ModItems.RUMOR_ROJO, ModItems.RUMOR_VERDE, ModItems.RUMOR_AZUL, ModItems.RUMOR_AMARILLO);
        int sueltas = 0;
        for (Item m : monedas) {
            int v = ((RumorItem) m).getValor();
            int n = cantidad / v;
            cantidad -= n * v;
            while (n > 0) {
                int lote = lluvia && sueltas < 24 ? 1 : Math.min(64, n);
                ItemEntity e = mob.dropStack(new ItemStack(m, lote));
                if (e != null && lluvia) {
                    e.setVelocity((w.getRandom().nextDouble() - 0.5) * 0.5, 0.35 + w.getRandom().nextDouble() * 0.3, (w.getRandom().nextDouble() - 0.5) * 0.5);
                    sueltas++;
                }
                n -= lote;
            }
        }
        w.playSound(null, mob.getBlockPos(), SoundEvents.BLOCK_CHAIN_PLACE, SoundCategory.NEUTRAL, 0.7f, 1.8f);
    }
}

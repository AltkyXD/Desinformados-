package com.centrodesinformacion.desinformados;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Periódico Desinformado: al usarlo muestra la lista de muertos para revivir a uno (clic en el chat). */
public class PeriodicoItem extends Item {
    public PeriodicoItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient() && user instanceof ServerPlayerEntity jugador) {
            var muertos = EstadoServidor.get(jugador.getServer()).getMuertos();
            if (muertos.isEmpty()) {
                jugador.sendMessage(Text.literal("Nadie necesita ser revivido... por ahora.").formatted(Formatting.GRAY), false);
            } else {
                jugador.sendMessage(Text.literal("¿A quién quieres revivir? (haz clic en su nombre)").formatted(Formatting.GOLD), false);
                for (String nombre : muertos.values()) {
                    jugador.sendMessage(Text.literal("  > " + nombre).formatted(Formatting.AQUA, Formatting.UNDERLINE)
                            .styled(s -> s
                                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/revivir " + nombre))
                                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                                            Text.literal("Gastar 1 periódico para revivir a " + nombre)))), false);
                }
            }
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.desinformados.periodico.tooltip").formatted(Formatting.GRAY));
    }
}

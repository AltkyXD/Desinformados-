package com.centrodesinformacion.desinformados;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

import java.util.HashMap;
import java.util.Map;

/** Qué minerales se desbloquean en cada fase. Cambia esta lista a tu gusto. */
public class Progresion {
    public static final int FASE_MAXIMA = 4;
    private static final Map<Block, Integer> FASES = new HashMap<>();

    static {
        fase(1, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE,
                Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        fase(2, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE, Blocks.REDSTONE_ORE,
                Blocks.DEEPSLATE_REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE, Blocks.NETHER_QUARTZ_ORE);
        fase(3, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE); // el diamante se puede picar siempre (solo su crafteo está bloqueado)
        fase(4, Blocks.ANCIENT_DEBRIS);
    }

    private static void fase(int numero, Block... bloques) {
        for (Block b : bloques) FASES.put(b, numero);
    }

    /** 0 = bloque normal (siempre se puede picar). */
    public static int faseDe(Block bloque) {
        return FASES.getOrDefault(bloque, 0);
    }

    public static String descripcion(int fase) {
        return switch (fase) {
            case 1 -> "carbón, cobre y hierro";
            case 2 -> "oro, redstone, lapislázuli y cuarzo";
            case 3 -> "esmeralda";
            case 4 -> "escombros ancestrales (netherite)";
            default -> "?";
        };
    }
}

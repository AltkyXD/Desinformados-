package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.intro.Final;
import com.centrodesinformacion.desinformados.intro.Intro;
import com.centrodesinformacion.desinformados.pasivas.Pasivas;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * La lógica de los 25 cambios de CambiosMundo. Cada efecto mira su marca en EstadoServidor en el momento
 * y se para en cuanto se quita. Los modificadores de atributos de los jugadores son temporales (no se guardan)
 * y se revisan cada segundo: se ponen y se quitan solos (también al reaparecer).
 * El "daño" del ambiente (astillas, lluvia ácida, agua helada) quita vida directamente: no gasta corazones de alma
 * y nunca baja de 1 corazón.
 */
final class CambiosMundoEfectos {
    private CambiosMundoEfectos() {}

    // ================================================================= datos fijos

    private static final Identifier MOD_MOCHILA = Desinformados.id("mochila_pesada");
    private static final Identifier MOD_AGOBIO = Desinformados.id("agobio_nether");
    private static final Identifier MOD_RECORTE = Desinformados.id("recorte_corazones");
    /** El modificador del desafío "Un solo corazón" (Desafios): mientras está puesto no se añaden recortes de vida. */
    private static final Identifier UN_CORAZON = Desinformados.id("un_corazon");

    private static final Set<Block> MENAS = Set.of(
            Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
            Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.NETHER_GOLD_ORE, Blocks.NETHER_QUARTZ_ORE);

    /** Bloques naturales a los que puede saltar una mena que se escapa. */
    private static final Set<Block> ROCAS = Set.of(Blocks.STONE, Blocks.DEEPSLATE, Blocks.GRANITE, Blocks.DIORITE,
            Blocks.ANDESITE, Blocks.TUFF, Blocks.NETHERRACK, Blocks.BLACKSTONE, Blocks.BASALT);

    private static final Map<Block, Block> A_PROFUNDA = Map.of(
            Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
            Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
    private static final Map<Block, Block> A_NORMAL = new HashMap<>();

    static {
        for (Map.Entry<Block, Block> par : A_PROFUNDA.entrySet()) A_NORMAL.put(par.getValue(), par.getKey());
    }

    private static final Set<Item> CRUDOS = Set.of(Items.BEEF, Items.PORKCHOP, Items.CHICKEN, Items.MUTTON, Items.RABBIT,
            Items.COD, Items.SALMON, Items.TROPICAL_FISH, Items.PUFFERFISH);
    private static final Set<Item> SOPAS = Set.of(Items.MUSHROOM_STEW, Items.BEETROOT_SOUP, Items.RABBIT_STEW, Items.SUSPICIOUS_STEW);
    private static final Set<Item> LUCES = Set.of(Items.TORCH, Items.SOUL_TORCH, Items.LANTERN, Items.SOUL_LANTERN,
            Items.JACK_O_LANTERN, Items.GLOWSTONE, Items.SEA_LANTERN, Items.SHROOMLIGHT);
    private static final Set<Item> METAL = Set.of(
            Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS,
            Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS,
            Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS);
    private static final Set<Item> CUERO = Set.of(Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS);
    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    /** Animales de granja que se avisan entre ellos (ninguno contraataca: lobos, abejas, osos... no entran). */
    private static final Set<EntityType<?>> CHIVATOS = Set.<EntityType<?>>of(EntityType.COW, EntityType.PIG, EntityType.SHEEP,
            EntityType.CHICKEN, EntityType.RABBIT, EntityType.MOOSHROOM);

    // ================================================================= estado en memoria (de esta sesión del servidor)

    /** Comida y saturación de cada jugador en el tick anterior. */
    private static final Map<UUID, float[]> NUTRICION = new HashMap<>();
    /** Lo que estaba comiendo cada jugador en el tick anterior. */
    private static final Map<UUID, Item> COMIENDO = new HashMap<>();
    private static final Map<UUID, Item> ULTIMA_COMIDA = new HashMap<>();
    private static final Map<UUID, Integer> RACHA = new HashMap<>();
    /** Ticks en los que comió (para el hipo). */
    private static final Map<UUID, Deque<Integer>> BOCADOS = new HashMap<>();
    private static final Map<UUID, Integer> HIPO_FIN = new HashMap<>();
    private static final Map<UUID, Integer> HIPO_PROXIMO = new HashMap<>();
    private static final Map<UUID, Integer> AIRE = new HashMap<>();
    private static final Map<UUID, RegistryKey<World>> DIMENSION = new HashMap<>();
    /** Segundos seguidos bajo tierra sin luz del sol. */
    private static final Map<UUID, Integer> BAJO_TIERRA = new HashMap<>();
    /** Segundos seguidos mojado. */
    private static final Map<UUID, Integer> MOJADO = new HashMap<>();
    /** Agua helada: jugador -> tick en que se metió en el agua (sin salir). */
    private static final Map<UUID, Integer> EN_AGUA = new HashMap<>();
    /** Resfriados: jugador -> tick en que se le pasa. */
    private static final Map<UUID, Integer> RESFRIADOS = new HashMap<>();
    private static final Map<UUID, Integer> ESTORNUDO = new HashMap<>();
    /** Recién curados: jugador -> tick hasta el que no se puede volver a resfriar. */
    private static final Map<UUID, Integer> INMUNES = new HashMap<>();
    /** Próxima "ordenación" del becario de cada jugador. */
    private static final Map<UUID, Integer> BECARIO = new HashMap<>();
    /** Efectos buenos ya aguados: jugador -> (efecto -> duración que tenía en la última revisión). */
    private static final Map<UUID, Map<RegistryEntry<StatusEffect>, Integer>> EFECTOS_VISTOS = new HashMap<>();
    /** Jugadores que están chisporroteando (va a caerles un rayo). */
    private static final Set<UUID> CARGADOS = new HashSet<>();
    private static int proximaRacha = -1;

    // ================================================================= registro

    static void registrar() {
        // Todo lo de memoria usa ticks de esta sesión: no vale para la siguiente (LAN, un jugador)
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> olvidarTodo());
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> olvidarSeguimiento(handler.player.getUuid()));
        ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, seguiaVivo) -> {
            // Al salir del End por el portal se "reaparece" vivo: eso sí es cambiar de dimensión (lo detecta el tick)
            if (seguiaVivo) return;
            olvidarSeguimiento(nuevo.getUuid());
            DIMENSION.put(nuevo.getUuid(), nuevo.getWorld().getRegistryKey());   // reaparecer en otra dimensión no da jet lag
        });

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> antesDeRomper(world, player, pos, state));
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> despuesDeRomper(world, player, pos, state));
        // En la fase de efectos (después de la normal): si un corazón de alma u otra regla cancela el golpe, aquí no pasa nada
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(MutacionesNether.FASE_EFECTOS, (victima, fuente, cantidad) -> {
            alRecibirGolpe(victima, fuente);
            return true;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> alUsarObjeto(player, world, hand));
        ServerTickEvents.END_SERVER_TICK.register(CambiosMundoEfectos::tick);
    }

    private static void olvidarSeguimiento(UUID id) {
        NUTRICION.remove(id);
        COMIENDO.remove(id);
        AIRE.remove(id);
        DIMENSION.remove(id);
        BAJO_TIERRA.remove(id);
        MOJADO.remove(id);
        EN_AGUA.remove(id);
        BOCADOS.remove(id);
    }

    private static void olvidarTodo() {
        NUTRICION.clear();
        COMIENDO.clear();
        ULTIMA_COMIDA.clear();
        RACHA.clear();
        BOCADOS.clear();
        HIPO_FIN.clear();
        HIPO_PROXIMO.clear();
        AIRE.clear();
        DIMENSION.clear();
        BAJO_TIERRA.clear();
        MOJADO.clear();
        EN_AGUA.clear();
        RESFRIADOS.clear();
        ESTORNUDO.clear();
        INMUNES.clear();
        BECARIO.clear();
        EFECTOS_VISTOS.clear();
        CARGADOS.clear();
        proximaRacha = -1;
    }

    // ================================================================= utilidades

    /** Juegan los vivos en supervivencia/aventura; ni espectadores, ni creativo, ni quien sigue en el cuarto de la intro. */
    static boolean juega(ServerPlayerEntity p) {
        return p.isAlive() && !p.isSpectator() && !p.isCreative() && p.getWorld().getRegistryKey() != Intro.CUARTO;
    }

    private static boolean activo(MinecraftServer server, String id) {
        return server != null && EstadoServidor.get(server).tieneCambio(id);
    }

    private static void aviso(ServerPlayerEntity p, String texto, Formatting color) {
        p.sendMessage(Text.literal(texto).formatted(color), true);
    }

    /** Quita vida sin pasar por el sistema de daño: no gasta corazones de alma y nunca baja de 1 corazón. */
    private static void quitarVida(ServerPlayerEntity p, float cantidad) {
        float nueva = Math.max(2f, p.getHealth() - cantidad);
        if (nueva < p.getHealth()) p.setHealth(nueva);
    }

    private static BlockPos cabeza(ServerPlayerEntity p) {
        return BlockPos.ofFloored(p.getX(), p.getEyeY(), p.getZ());
    }

    private static boolean dimensionVanilla(RegistryKey<World> k) {
        return k == World.OVERWORLD || k == World.NETHER || k == World.END;
    }

    private static boolean efectoVanilla(RegistryEntry<StatusEffect> tipo) {
        return tipo.getKey().map(k -> k.getValue().getNamespace().equals("minecraft")).orElse(false);
    }

    // ================================================================= tick

    private static void tick(MinecraftServer server) {
        EstadoServidor e = EstadoServidor.get(server);
        int ahora = server.getTicks();
        boolean pausa = Final.enCurso();   // durante la cinemática final no molestamos

        boolean dieta = e.tieneCambio(CambiosMundo.DIETA_VARIADA);
        boolean hipo = e.tieneCambio(CambiosMundo.HIPO);
        boolean resfriado = e.tieneCambio(CambiosMundo.RESFRIADO);
        boolean pulmones = e.tieneCambio(CambiosMundo.PULMONES_PEQUENOS);
        boolean helada = e.tieneCambio(CambiosMundo.AGUA_HELADA);
        boolean mareo = e.tieneCambio(CambiosMundo.MAREO_PORTALES);

        // Si se quita el cambio, lo que estaba en marcha se acaba ya
        if (!hipo && !HIPO_FIN.isEmpty()) {
            HIPO_FIN.clear();
            HIPO_PROXIMO.clear();
        }
        if (!resfriado && !RESFRIADOS.isEmpty()) {
            RESFRIADOS.clear();
            ESTORNUDO.clear();
        }
        if (!e.tieneCambio(CambiosMundo.POCIONES_AGUADAS) && !EFECTOS_VISTOS.isEmpty()) EFECTOS_VISTOS.clear();

        // ---- cambios del mundo (no dependen de cada jugador) ----
        if (ahora % 3 == 0 && e.tieneCambio(CambiosMundo.NOCHES_LARGAS)) alargarNoche(server);
        if (ahora % 100 == 0 && e.tieneCambio(CambiosMundo.TORMENTAS)) convertirEnTormenta(server);
        vientos(server, e, ahora, pausa);

        // ---- jugadores ----
        boolean segundo = ahora % 20 == 0;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            RegistryKey<World> dim = p.getWorld().getRegistryKey();
            RegistryKey<World> antes = DIMENSION.put(id, dim);
            boolean vale = juega(p);
            if (segundo) atributos(p, e, vale);    // también a los que no juegan: así se les quitan
            if (!vale) continue;

            if (mareo && !pausa && antes != null && antes != dim && dimensionVanilla(antes) && dimensionVanilla(dim)) jetLag(p);
            if (dieta || hipo || resfriado) vigilarComida(p, ahora, dieta, hipo, resfriado);
            if (pulmones) tickPulmones(p);
            else AIRE.remove(id);
            if (helada) tickFrio(p, ahora);
            if (hipo && !pausa) tickHipo(p, ahora);
            if (segundo && !pausa) cadaSegundo(p, e, ahora);
        }
    }

    private static void cadaSegundo(ServerPlayerEntity p, EstadoServidor e, int ahora) {
        ServerWorld w = p.getServerWorld();
        BlockPos cabeza = cabeza(p);
        boolean overworld = w.getRegistryKey() == World.OVERWORLD;

        if (ahora % 200 == 0 && e.tieneCambio(CambiosMundo.LLUVIA_ACIDA) && w.hasRain(cabeza)) lluviaAcida(p, w);
        if (ahora % 6000 == 0 && e.tieneCambio(CambiosMundo.COMIDA_CADUCA)) pudrirComida(p);
        if (e.tieneCambio(CambiosMundo.BECARIO_ORDENA)) becario(p, ahora);
        if (e.tieneCambio(CambiosMundo.CUEVAS_OSCURAS)) cuevaOscura(p, w, cabeza, overworld);
        if (overworld && e.tieneCambio(CambiosMundo.DESLUMBRAMIENTO)) deslumbrar(p, w, cabeza);
        if (e.tieneCambio(CambiosMundo.RESFRIADO)) tickResfriado(p, ahora);
        if (e.tieneCambio(CambiosMundo.POCIONES_AGUADAS)) aguarPociones(p);
        if (e.tieneCambio(CambiosMundo.RAYOS_METAL) && w.isThundering() && !CARGADOS.contains(p.getUuid())
                && w.hasRain(cabeza) && piezasDeMetal(p) >= 2 && p.getRandom().nextInt(30) == 0) cargarRayo(p, w);
    }

    // ================================================================= atributos (mochila, agobio, recorte)

    private static void atributos(ServerPlayerEntity p, EstadoServidor e, boolean vale) {
        // Mochila pesada: más de 27 huecos ocupados -> 15 % más lento
        EntityAttributeInstance velocidad = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (velocidad != null) {
            boolean pesa = vale && e.tieneCambio(CambiosMundo.MOCHILA_PESADA) && huecosOcupados(p) > 27;
            if (pesa && !velocidad.hasModifier(MOD_MOCHILA)) {
                velocidad.addTemporaryModifier(new EntityAttributeModifier(MOD_MOCHILA, -0.15, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                aviso(p, "Llevas la mochila a reventar: vas un 15 % más lento", Formatting.GOLD);
            } else if (!pesa && velocidad.hasModifier(MOD_MOCHILA)) {
                velocidad.removeModifier(MOD_MOCHILA);
            }
        }

        // Agobio del Nether (-2 corazones allí) y recorte de corazones (-1 siempre); Fondo de Roca se libra
        boolean agobio = e.tieneCambio(CambiosMundo.AGOBIO_NETHER);
        boolean recorte = e.tieneCambio(CambiosMundo.RECORTE_CORAZONES);
        boolean fondo = vale && (agobio || recorte) && Pasivas.tiene(p, "rock_bottom");
        boolean enNether = p.getWorld().getRegistryKey() == World.NETHER;
        if (vidaMaxima(p, MOD_AGOBIO, 4.0, vale && agobio && !fondo && enNether)) {
            aviso(p, "El calor del Nether te agobia: 2 corazones menos mientras estés aquí", Formatting.RED);
        }
        vidaMaxima(p, MOD_RECORTE, 2.0, vale && recorte && !fondo);
    }

    private static int huecosOcupados(ServerPlayerEntity p) {
        int n = 0;
        for (ItemStack s : p.getInventory().main) if (!s.isEmpty()) n++;
        return n;
    }

    /**
     * Pone (o quita) un recorte de vida máxima. Nunca deja al jugador con menos de 1 corazón (si no cabe, no se pone;
     * si otra cosa lo empuja por debajo, se quita). Devuelve true si se acaba de poner.
     */
    private static boolean vidaMaxima(ServerPlayerEntity p, Identifier mod, double cantidad, boolean debe) {
        EntityAttributeInstance vida = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vida == null) return false;
        boolean puesto = vida.hasModifier(mod);
        if (puesto && (!debe || vida.getValue() < 2.0)) {
            vida.removeModifier(mod);
        } else if (!puesto && debe && !vida.hasModifier(UN_CORAZON) && vida.getValue() - cantidad >= 2.0) {
            vida.addTemporaryModifier(new EntityAttributeModifier(mod, -cantidad, EntityAttributeModifier.Operation.ADD_VALUE));
            if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
            return true;
        }
        return false;
    }

    // ================================================================= romper bloques (astillas, menas)

    /** Menas escurridizas: a veces la mena salta a una piedra cercana en vez de romperse. */
    private static boolean antesDeRomper(World world, PlayerEntity player, BlockPos pos, BlockState state) {
        if (world.isClient() || !(world instanceof ServerWorld w) || !(player instanceof ServerPlayerEntity p) || !juega(p)) return true;
        if (!MENAS.contains(state.getBlock())) return true;
        EstadoServidor e = EstadoServidor.get(w.getServer());
        if (!e.tieneCambio(CambiosMundo.MENAS_ESCURRIDIZAS) || Reglas.enSpawn(w, pos, e)) return true;
        if (p.getRandom().nextFloat() >= 0.15f) return true;
        BlockPos destino = huecoParaMena(w, pos, e);
        if (destino == null) return true;                       // no hay piedra cerca: se rompe normal
        BlockState roca = w.getBlockState(destino);
        w.setBlockState(destino, variante(state.getBlock(), roca).getDefaultState());
        w.setBlockState(pos, roca);                             // se intercambian: donde estaba la mena queda la piedra
        w.spawnParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 8, 0.3, 0.3, 0.3, 0.02);
        w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, destino.getX() + 0.5, destino.getY() + 0.5, destino.getZ() + 0.5, 15, 0.5, 0.5, 0.5, 0.02);
        w.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.BLOCKS, 0.6f, 1.8f);
        aviso(p, "¡La mena se ha escapado! Está a menos de 3 bloques", Formatting.GOLD);
        return false;
    }

    /** Una piedra natural a 3 bloques como mucho; mejor si se ve (toca aire). */
    private static BlockPos huecoParaMena(ServerWorld w, BlockPos pos, EstadoServidor e) {
        BlockPos escondido = null;
        for (int i = 0; i < 40; i++) {
            BlockPos q = pos.add(w.random.nextInt(7) - 3, w.random.nextInt(7) - 3, w.random.nextInt(7) - 3);
            if (q.equals(pos) || !w.isChunkLoaded(q)) continue;
            if (!ROCAS.contains(w.getBlockState(q).getBlock()) || Reglas.enSpawn(w, q, e)) continue;
            if (tocaAire(w, q)) return q;
            if (escondido == null) escondido = q;
        }
        return escondido;
    }

    private static boolean tocaAire(ServerWorld w, BlockPos q) {
        for (Direction d : Direction.values()) {
            if (w.getBlockState(q.offset(d)).isAir()) return true;
        }
        return false;
    }

    /** La mena que aparece en pizarra profunda (o toba) es la versión de pizarra, y al revés. */
    private static Block variante(Block mena, BlockState roca) {
        boolean profunda = roca.isOf(Blocks.DEEPSLATE) || roca.isOf(Blocks.TUFF);
        Block otra = profunda ? A_PROFUNDA.get(mena) : A_NORMAL.get(mena);
        return otra != null ? otra : mena;
    }

    private static void despuesDeRomper(World world, PlayerEntity player, BlockPos pos, BlockState state) {
        if (world.isClient() || !(world instanceof ServerWorld w) || !(player instanceof ServerPlayerEntity p) || !juega(p)) return;
        EstadoServidor e = EstadoServidor.get(w.getServer());

        // Astillas: talar sin hacha duele
        if (e.tieneCambio(CambiosMundo.ASTILLAS) && state.isIn(BlockTags.LOGS) && !(p.getMainHandStack().getItem() instanceof AxeItem)) {
            quitarVida(p, 1f);
            w.spawnParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.3, 0.3, 0.3, 0.05);
            w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 0.7f, 1.3f);
            aviso(p, "¡Astillas! Usa un hacha para talar", Formatting.GOLD);
        }

        // Bolsas de gas en las menas
        if (e.tieneCambio(CambiosMundo.MENAS_GAS) && MENAS.contains(state.getBlock()) && p.getRandom().nextFloat() < 0.08f) {
            nubeDeGas(w, pos, p);
        }
    }

    private static void nubeDeGas(ServerWorld w, BlockPos pos, ServerPlayerEntity p) {
        // La nube es plana: se pone a la altura de los pies del jugador, encima de la mena (si no, no le tocaría)
        AreaEffectCloudEntity nube = new AreaEffectCloudEntity(w, pos.getX() + 0.5, p.getY(), pos.getZ() + 0.5);
        nube.setRadius(2.5f);
        nube.setDuration(120);
        nube.setWaitTime(10);
        nube.addEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 0));
        w.spawnEntity(nube);
        w.spawnParticles(ParticleTypes.SNEEZE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 30, 0.6, 0.6, 0.6, 0.02);
        w.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.8f, 0.6f);
        aviso(p, "¡Bolsa de gas! Aléjate de la mena", Formatting.DARK_GREEN);
    }

    // ================================================================= golpes (escudos, animales)

    private static void alRecibirGolpe(LivingEntity victima, DamageSource fuente) {
        MinecraftServer server = victima.getServer();
        if (server == null) return;

        // Escudos que cansan: después del golpe (1 tick), el escudo se baja y queda 3 segundos inútil
        if (victima instanceof ServerPlayerEntity p) {
            if (activo(server, CambiosMundo.ESCUDOS_CANSAN) && juega(p) && p.blockedByShield(fuente) && p.getRandom().nextFloat() < 0.25f) {
                Tareas.programar(1, () -> dormirBrazo(p));
            }
            return;
        }

        // Animales chivatos: si un jugador pega a uno, los de alrededor huyen
        if (victima instanceof AnimalEntity animal && CHIVATOS.contains(animal.getType())
                && fuente.getAttacker() instanceof ServerPlayerEntity atacante && juega(atacante)
                && activo(server, CambiosMundo.ANIMALES_CHIVATOS)) {
            avisarAnimales(animal, atacante);
        }
    }

    private static void dormirBrazo(ServerPlayerEntity p) {
        if (p.isRemoved() || !p.isAlive()) return;
        p.getItemCooldownManager().set(Items.SHIELD, 60);
        p.clearActiveItem();
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_SHIELD_BREAK, SoundCategory.PLAYERS, 0.8f, 1.2f);
        aviso(p, "¡Se te ha dormido el brazo! El escudo no sirve durante 3 segundos", Formatting.RED);
    }

    private static void avisarAnimales(AnimalEntity golpeado, ServerPlayerEntity jugador) {
        if (!(golpeado.getWorld() instanceof ServerWorld w)) return;
        List<AnimalEntity> vecinos = w.getEntitiesByClass(AnimalEntity.class, golpeado.getBoundingBox().expand(12),
                a -> a != golpeado && a.isAlive() && CHIVATOS.contains(a.getType()));
        for (AnimalEntity otro : vecinos) {
            double dx = otro.getX() - jugador.getX(), dz = otro.getZ() - jugador.getZ();
            double largo = Math.sqrt(dx * dx + dz * dz);
            if (largo < 0.5) {
                dx = 1;
                dz = 0;
                largo = 1;
            }
            otro.getNavigation().startMovingTo(otro.getX() + dx / largo * 12, otro.getY(), otro.getZ() + dz / largo * 12, 1.8);
        }
    }

    // ================================================================= usar objetos (cohetes)

    private static TypedActionResult<ItemStack> alUsarObjeto(PlayerEntity player, World world, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient() || !stack.isOf(Items.FIREWORK_ROCKET) || !player.isFallFlying()
                || !(player instanceof ServerPlayerEntity p) || !juega(p)
                || !activo(p.getServer(), CambiosMundo.COHETES_DEFECTUOSOS)
                || p.getRandom().nextInt(8) != 0) return TypedActionResult.pass(stack);
        stack.decrement(1);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 1, p.getZ(), 2, 0.2, 0.2, 0.2, 0);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.2f, 0.8f);
        p.setVelocity(p.getVelocity().multiply(0.4));
        p.velocityModified = true;
        p.damage(w.getDamageSources().explosion(null, null), 4f);
        aviso(p, "¡El cohete te ha explotado en la cara!", Formatting.RED);
        return TypedActionResult.fail(stack);
    }

    // ================================================================= mundo (noches, tormentas, viento)

    /** Noches un 50 % más largas: de noche, cada 3 ticks el reloj retrocede 1. Lejos de los bordes, para no "empezar" la noche dos veces. */
    private static void alargarNoche(MinecraftServer server) {
        if (!server.getGameRules().getBoolean(GameRules.DO_DAYLIGHT_CYCLE)) return;
        ServerWorld mundo = server.getOverworld();
        long t = mundo.getTimeOfDay();
        long hora = Math.floorMod(t, 24000L);
        if (hora >= 13100 && hora < 22900) mundo.setTimeOfDay(t - 1);
    }

    /** Si empieza a llover (la marca de lluvia, no el degradado), pasa a ser tormenta de 5 minutos. */
    private static void convertirEnTormenta(MinecraftServer server) {
        ServerWorld mundo = server.getOverworld();
        if (mundo.getLevelProperties().isRaining() && !mundo.getLevelProperties().isThundering()) {
            mundo.setWeather(0, 6000, true, true);
        }
    }

    private static void vientos(MinecraftServer server, EstadoServidor e, int ahora, boolean pausa) {
        if (!e.tieneCambio(CambiosMundo.RACHAS_VIENTO)) {
            proximaRacha = -1;
            return;
        }
        if (pausa) return;
        ServerWorld mundo = server.getOverworld();
        if (proximaRacha < 0) {
            proximaRacha = ahora + esperaRacha(mundo);
            return;
        }
        if (ahora < proximaRacha) return;
        proximaRacha = ahora + esperaRacha(mundo);
        double angulo = mundo.random.nextDouble() * Math.PI * 2;
        boolean alguien = false;
        for (ServerPlayerEntity p : mundo.getPlayers()) {
            if (!alViento(p, e)) continue;
            alguien = true;
            aviso(p, "¡Se acerca una racha de viento! Agáchate", Formatting.AQUA);
            mundo.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.WEATHER, 0.5f, 1.4f);
        }
        if (alguien) Tareas.programar(40, () -> soplar(server, angulo));
    }

    private static int esperaRacha(ServerWorld mundo) {
        return 20 * (180 + mundo.random.nextInt(181));   // 3-6 minutos
    }

    private static boolean alViento(ServerPlayerEntity p, EstadoServidor e) {
        return juega(p) && !p.hasVehicle() && !p.isTouchingWater()
                && p.getServerWorld().isSkyVisible(cabeza(p)) && !Reglas.enSpawn(p.getWorld(), p.getBlockPos(), e);
    }

    private static void soplar(MinecraftServer server, double angulo) {
        EstadoServidor e = EstadoServidor.get(server);
        if (!e.tieneCambio(CambiosMundo.RACHAS_VIENTO) || Final.enCurso()) return;
        ServerWorld mundo = server.getOverworld();
        double vx = Math.cos(angulo) * 0.7, vz = Math.sin(angulo) * 0.7;
        for (ServerPlayerEntity p : mundo.getPlayers()) {
            if (!alViento(p, e) || p.isSneaking()) continue;
            p.addVelocity(vx, 0.3, vz);
            p.velocityModified = true;
            mundo.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 12, 0.5, 0.5, 0.5, 0.05);
            mundo.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_ENDER_DRAGON_FLAP, SoundCategory.WEATHER, 0.8f, 1.3f);
            aviso(p, "¡Fiuuuu!", Formatting.AQUA);
        }
    }

    // ================================================================= cuerpo (comida, hipo, aire, frío, viajes)

    /** Detecta que alguien ha comido: estaba comiendo algo el tick anterior y ahora tiene más comida o saturación. */
    private static void vigilarComida(ServerPlayerEntity p, int ahora, boolean dieta, boolean hipo, boolean resfriado) {
        UUID id = p.getUuid();
        HungerManager hambre = p.getHungerManager();
        float[] antes = NUTRICION.put(id, new float[]{hambre.getFoodLevel(), hambre.getSaturationLevel()});
        Item comia = COMIENDO.get(id);
        if (antes != null && comia != null && hambre.getFoodLevel() + hambre.getSaturationLevel() > antes[0] + antes[1] + 0.01f) {
            haComido(p, comia, antes, ahora, dieta, hipo, resfriado);
        }
        ItemStack enUso = p.getActiveItem();
        if (p.isUsingItem() && !enUso.isEmpty() && enUso.getItem().getComponents().contains(DataComponentTypes.FOOD)) {
            COMIENDO.put(id, enUso.getItem());
        } else {
            COMIENDO.remove(id);
        }
    }

    private static void haComido(ServerPlayerEntity p, Item comida, float[] antes, int ahora, boolean dieta, boolean hipo, boolean resfriado) {
        UUID id = p.getUuid();

        // Dieta variada: la tercera vez seguida del mismo alimento llena la mitad y da náuseas
        if (dieta) {
            int racha = comida == ULTIMA_COMIDA.get(id) ? RACHA.getOrDefault(id, 1) + 1 : 1;
            ULTIMA_COMIDA.put(id, comida);
            RACHA.put(id, racha);
            if (racha >= 3) {
                HungerManager hambre = p.getHungerManager();
                int nivel = hambre.getFoodLevel();
                int ganada = nivel - (int) antes[0];
                if (ganada > 0) hambre.setFoodLevel(nivel - ganada / 2);
                float saturacion = hambre.getSaturationLevel();
                float satGanada = saturacion - antes[1];
                if (satGanada > 0) hambre.setSaturationLevel(Math.min(hambre.getFoodLevel(), saturacion - satGanada / 2f));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0));
                MutableText texto = Text.literal("¡Otra vez ").formatted(Formatting.GOLD)
                        .append(new ItemStack(comida).getName())
                        .append(Text.literal("! El nutricionista no lo aprueba: solo te llena la mitad"));
                p.sendMessage(texto, true);
            }
        }

        // Hipo: 3 comidas en menos de 30 segundos
        if (hipo && !HIPO_FIN.containsKey(id)) {
            Deque<Integer> bocados = BOCADOS.computeIfAbsent(id, k -> new ArrayDeque<>());
            bocados.addLast(ahora);
            while (!bocados.isEmpty() && ahora - bocados.peekFirst() > 600) bocados.pollFirst();
            if (bocados.size() >= 3) {
                bocados.clear();
                HIPO_FIN.put(id, ahora + 1200);
                HIPO_PROXIMO.put(id, ahora + 40);
                aviso(p, "¡Has comido demasiado deprisa y te ha dado hipo!", Formatting.YELLOW);
            }
        }

        // Una sopa cura el resfriado
        if (resfriado && SOPAS.contains(comida) && RESFRIADOS.containsKey(id)) {
            curarResfriado(p, ahora, "¡La sopa te ha curado el resfriado!");
        }
    }

    private static void tickHipo(ServerPlayerEntity p, int ahora) {
        UUID id = p.getUuid();
        Integer fin = HIPO_FIN.get(id);
        if (fin == null) return;
        if (ahora >= fin) {
            HIPO_FIN.remove(id);
            HIPO_PROXIMO.remove(id);
            aviso(p, "Se te ha pasado el hipo", Formatting.GRAY);
            return;
        }
        if (ahora < HIPO_PROXIMO.getOrDefault(id, 0)) return;
        HIPO_PROXIMO.put(id, ahora + 60 + p.getRandom().nextInt(61));   // cada 3-6 segundos
        if (p.isOnGround() && !p.hasVehicle() && !p.isTouchingWater()) {
            p.addVelocity(0, 0.3, 0);
            p.velocityModified = true;
        }
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_BURP, SoundCategory.PLAYERS, 0.7f, 1.8f);
        aviso(p, "¡Hic!", Formatting.YELLOW);
    }

    /** Pulmones de oferta: cada vez que Minecraft gasta aire bajo el agua, se gasta otro tanto (sin bajar de 0). */
    private static void tickPulmones(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (!p.isSubmergedInWater()) {
            AIRE.remove(id);
            return;
        }
        int aire = p.getAir();
        Integer antes = AIRE.put(id, aire);
        if (antes != null && aire > 0 && aire < antes) {
            int nuevo = Math.max(0, aire - (antes - aire));
            p.setAir(nuevo);
            AIRE.put(id, nuevo);
        }
    }

    /**
     * Agua helada: tras 20 segundos seguidos en el agua, la congelación se pone justo antes del daño de Minecraft
     * (que gastaría corazones de alma) y el daño lo ponemos nosotros cada 2 segundos, sin bajar de 1 corazón.
     * Una pieza de armadura de cuero protege del frío.
     */
    private static void tickFrio(ServerPlayerEntity p, int ahora) {
        UUID id = p.getUuid();
        if (!p.isTouchingWater() || p.hasVehicle() || llevaCuero(p)) {
            EN_AGUA.remove(id);                                             // al salir del agua la cuenta vuelve a empezar
            return;
        }
        int desde = EN_AGUA.computeIfAbsent(id, k -> ahora);
        int dentro = ahora - desde;
        if (dentro < 400) return;                                           // los primeros 20 segundos no pasa nada
        int tope = p.getMinFreezeDamageTicks() - 1;
        if (p.getFrozenTicks() < tope) p.setFrozenTicks(tope);              // pantalla escarchada desde el segundo 20
        if (dentro % 40 == 0) {
            quitarVida(p, 1f);
            ServerWorld w = p.getServerWorld();
            w.spawnParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
            w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_HURT_FREEZE, SoundCategory.PLAYERS, 0.8f, 1f);
            aviso(p, "¡El agua está helada! Sal del agua o ponte algo de cuero", Formatting.AQUA);
        }
    }

    private static boolean llevaCuero(ServerPlayerEntity p) {
        for (EquipmentSlot slot : ARMADURA) if (CUERO.contains(p.getEquippedStack(slot).getItem())) return true;
        return false;
    }

    private static void jetLag(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
        aviso(p, "¡Jet lag dimensional! Dale unos segundos al cuerpo", Formatting.LIGHT_PURPLE);
    }

    // ================================================================= cada segundo

    private static void lluviaAcida(ServerPlayerEntity p, ServerWorld w) {
        ItemStack casco = p.getEquippedStack(EquipmentSlot.HEAD);
        if (!casco.isEmpty()) {
            if (p.getRandom().nextBoolean()) casco.damage(1, p, EquipmentSlot.HEAD);   // no hace nada si no tiene durabilidad (calabaza...)
            return;
        }
        quitarVida(p, 1f);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getEyeY() + 0.3, p.getZ(), 5, 0.2, 0.1, 0.2, 0.01);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 0.6f, 1.6f);
        aviso(p, "¡La lluvia ácida te quema! Ponte algo en la cabeza", Formatting.GREEN);
    }

    private static void pudrirComida(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        List<ItemStack> crudos = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (CRUDOS.contains(s.getItem())) crudos.add(s);
        }
        if (crudos.isEmpty()) return;
        ItemStack elegido = crudos.get(p.getRandom().nextInt(crudos.size()));
        MutableText texto = Text.literal("Se te ha podrido 1 de ").formatted(Formatting.GOLD).append(elegido.getName());   // antes de gastarlo
        elegido.decrement(1);
        inv.offerOrDrop(new ItemStack(Items.ROTTEN_FLESH));
        p.sendMessage(texto, true);
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.PLAYERS, 0.6f, 0.8f);
    }

    private static void becario(ServerPlayerEntity p, int ahora) {
        UUID id = p.getUuid();
        Integer cuando = BECARIO.get(id);
        if (cuando == null) {
            BECARIO.put(id, ahora + esperaBecario(p));
            return;
        }
        if (ahora < cuando) return;
        // con un menú abierto o usando algo (comiendo, tensando el arco...) espera 10 segundos
        if (p.currentScreenHandler != p.playerScreenHandler || p.isUsingItem()) {
            BECARIO.put(id, ahora + 200);
            return;
        }
        BECARIO.put(id, ahora + esperaBecario(p));
        ordenarInventario(p);
    }

    private static int esperaBecario(ServerPlayerEntity p) {
        return 20 * 60 * 15 + p.getRandom().nextInt(20 * 60 * 10 + 1);   // 15-25 minutos
    }

    /** Cambia 2 huecos al azar de la barra rápida por 2 de la mochila (no toca armadura ni segunda mano). */
    private static void ordenarInventario(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        Set<Integer> usados = new HashSet<>();
        int hechos = 0;
        for (int intento = 0; intento < 20 && hechos < 2; intento++) {
            int a = p.getRandom().nextInt(9);
            int b = 9 + p.getRandom().nextInt(27);
            if (usados.contains(a)) continue;
            ItemStack enBarra = inv.getStack(a);
            ItemStack enMochila = inv.getStack(b);
            if (enBarra.isEmpty() && enMochila.isEmpty()) continue;
            usados.add(a);
            inv.setStack(a, enMochila);
            inv.setStack(b, enBarra);
            hechos++;
        }
        if (hechos == 0) return;
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 1f, 1.2f);
        aviso(p, "El becario te ha ordenado el inventario. De nada.", Formatting.YELLOW);
    }

    private static void cuevaOscura(ServerPlayerEntity p, ServerWorld w, BlockPos cabeza, boolean overworld) {
        StatusEffectInstance actual = p.getStatusEffect(StatusEffects.DARKNESS);
        boolean oscuro = overworld && p.getY() < 0 && w.getLightLevel(cabeza) <= 4 && !llevaLuz(p);
        if (oscuro) {
            if (actual == null) aviso(p, "Está muy oscuro: saca una antorcha", Formatting.DARK_GRAY);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, false, false, true));
        } else if (actual != null && actual.getDuration() <= 60 && actual.getAmplifier() == 0 && !actual.shouldShowParticles()) {
            p.removeStatusEffect(StatusEffects.DARKNESS);   // la nuestra se quita en cuanto hay luz
        }
    }

    private static boolean llevaLuz(ServerPlayerEntity p) {
        return LUCES.contains(p.getMainHandStack().getItem()) || LUCES.contains(p.getOffHandStack().getItem());
    }

    private static void deslumbrar(ServerPlayerEntity p, ServerWorld w, BlockPos cabeza) {
        UUID id = p.getUuid();
        if (p.getY() < 55 && w.getLightLevel(LightType.SKY, cabeza) == 0) {
            BAJO_TIERRA.merge(id, 1, Integer::sum);
        } else if (w.isSkyVisible(cabeza)) {
            Integer segundos = BAJO_TIERRA.remove(id);
            if (segundos != null && segundos >= 60 && w.isDay() && !w.isRaining()) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0));
                aviso(p, "¡El sol te deslumbra!", Formatting.YELLOW);
            }
        }
    }

    // ---- resfriado ----

    private static void tickResfriado(ServerPlayerEntity p, int ahora) {
        UUID id = p.getUuid();
        if (p.isWet()) {
            int mojado = MOJADO.merge(id, 1, Integer::sum);
            if (mojado >= 30 && !RESFRIADOS.containsKey(id) && ahora >= INMUNES.getOrDefault(id, 0)) resfriar(p, ahora, null);
        } else {
            MOJADO.remove(id);
        }
        Integer fin = RESFRIADOS.get(id);
        if (fin == null) return;
        if (ahora >= fin) curarResfriado(p, ahora, "Se te ha pasado el resfriado");
        else if (ahora >= ESTORNUDO.getOrDefault(id, 0)) estornudar(p, ahora);
    }

    private static void resfriar(ServerPlayerEntity p, int ahora, String quien) {
        UUID id = p.getUuid();
        RESFRIADOS.put(id, ahora + 6000);                                   // 5 minutos
        ESTORNUDO.put(id, ahora + 200 + p.getRandom().nextInt(401));       // el primero, a los 10-30 segundos
        MOJADO.remove(id);
        aviso(p, quien == null ? "¡Te has resfriado de tanto mojarte! Una sopa te curaría"
                : "¡" + quien + " te ha contagiado el resfriado! Una sopa te curaría", Formatting.AQUA);
    }

    private static void curarResfriado(ServerPlayerEntity p, int ahora, String mensaje) {
        UUID id = p.getUuid();
        RESFRIADOS.remove(id);
        ESTORNUDO.remove(id);
        INMUNES.put(id, ahora + 3600);                                     // 3 minutos sin poder volver a resfriarse
        aviso(p, mensaje, Formatting.GREEN);
    }

    private static void estornudar(ServerPlayerEntity p, int ahora) {
        ESTORNUDO.put(p.getUuid(), ahora + 600 + p.getRandom().nextInt(401));   // cada 30-50 segundos
        ServerWorld w = p.getServerWorld();
        Vec3d mira = p.getRotationVector();
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PANDA_SNEEZE, SoundCategory.PLAYERS, 1f, 1.1f);
        w.spawnParticles(ParticleTypes.SNEEZE, p.getX() + mira.x * 0.7, p.getEyeY() + mira.y * 0.7, p.getZ() + mira.z * 0.7,
                15, 0.2, 0.2, 0.2, 0.05);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0));
        if (!p.hasVehicle()) {
            p.addVelocity(-mira.x * 0.4, 0.1, -mira.z * 0.4);
            p.velocityModified = true;
        }
        aviso(p, "¡¡ACHÍS!!", Formatting.AQUA);
        String nombre = p.getGameProfile().getName();
        for (ServerPlayerEntity otro : w.getPlayers()) {
            if (otro == p || !juega(otro) || RESFRIADOS.containsKey(otro.getUuid()) || ahora < INMUNES.getOrDefault(otro.getUuid(), 0)) continue;
            if (otro.squaredDistanceTo(p) <= 16 && p.getRandom().nextFloat() < 0.3f) resfriar(otro, ahora, nombre);
        }
    }

    // ---- pociones aguadas ----

    /**
     * Los efectos buenos nuevos (o renovados: su duración sube) se cambian por la misma con la mitad de duración.
     * No se tocan los de faros y conductos (ambientales), los infinitos, los que no muestran icono (efectos internos
     * del mod, como la protección de la cinemática final) ni los efectos del mod (pastilla anti-Endcer).
     */
    private static void aguarPociones(ServerPlayerEntity p) {
        Map<RegistryEntry<StatusEffect>, Integer> vistos = EFECTOS_VISTOS.computeIfAbsent(p.getUuid(), k -> new HashMap<>());
        List<StatusEffectInstance> aguar = new ArrayList<>();
        Set<RegistryEntry<StatusEffect>> presentes = new HashSet<>();
        for (StatusEffectInstance ef : p.getStatusEffects()) {
            RegistryEntry<StatusEffect> tipo = ef.getEffectType();
            presentes.add(tipo);
            if (!tipo.value().isBeneficial() || ef.isAmbient() || ef.isInfinite() || !ef.shouldShowIcon() || !efectoVanilla(tipo)) continue;
            Integer antes = vistos.get(tipo);
            if (antes == null || ef.getDuration() > antes + 1) aguar.add(ef);
            else vistos.put(tipo, ef.getDuration());
        }
        vistos.keySet().retainAll(presentes);
        for (StatusEffectInstance ef : aguar) {
            int mitad = Math.max(20, ef.getDuration() / 2);
            p.setStatusEffect(new StatusEffectInstance(ef.getEffectType(), mitad, ef.getAmplifier(), ef.isAmbient(),
                    ef.shouldShowParticles(), ef.shouldShowIcon()), null);
            vistos.put(ef.getEffectType(), mitad);
        }
    }

    // ---- rayos que buscan el metal ----

    private static int piezasDeMetal(ServerPlayerEntity p) {
        int n = 0;
        for (EquipmentSlot slot : ARMADURA) if (METAL.contains(p.getEquippedStack(slot).getItem())) n++;
        return n;
    }

    private static void cargarRayo(ServerPlayerEntity p, ServerWorld w) {
        UUID id = p.getUuid();
        MinecraftServer server = w.getServer();
        Vec3d donde = p.getPos();
        CARGADOS.add(id);
        chisporrotear(w, p);
        aviso(p, "¡Estás chisporroteando! ¡Muévete!", Formatting.YELLOW);
        for (int t = 10; t <= 20; t += 10) {
            Tareas.programar(t, () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q != null && q.getWorld() == w && juega(q)) chisporrotear(w, q);
            });
        }
        Tareas.programar(30, () -> {
            CARGADOS.remove(id);
            if (!activo(server, CambiosMundo.RAYOS_METAL)) return;
            LightningEntity rayo = EntityType.LIGHTNING_BOLT.create(w);
            if (rayo != null) {
                rayo.setCosmetic(true);                 // solo el rayo de verdad: sin fuego en los bloques ni creepers cargados
                rayo.refreshPositionAfterTeleport(donde);
                w.spawnEntity(rayo);
            }
            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
            if (q == null || q.getWorld() != w || !juega(q)) return;
            double dx = q.getX() - donde.x, dz = q.getZ() - donde.z;
            if (dx * dx + dz * dz < 4.0 && Math.abs(q.getY() - donde.y) < 3) q.damage(w.getDamageSources().lightningBolt(), 5f);
        });
    }

    private static void chisporrotear(ServerWorld w, ServerPlayerEntity p) {
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.9, 0.4, 0.1);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_REDSTONE_TORCH_BURNOUT, SoundCategory.WEATHER, 1f, 1.5f);
    }
}

package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Reglas;
import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 20 desafíos rojos nuevos de PELIGRO del entorno: cielo, clima, terreno, bloques, agua, lava (hay que sobrevivir). */
final class DesafiosPeligros2 {
    private DesafiosPeligros2() {}

    static void registrarTodos() {

        // 1) Yunques que caen sobre una marca de humo (bajo tierra caen del techo)
        Desafios.registrar("lluvia_yunques", () -> new Desafio("Lluvia de yunques", 10, 90) {
            private final List<Golpe> pendientes = new ArrayList<>();

            public String descripcion() {
                return "Cada 1,5 segundos cae un yunque cerca de cada jugador (bajo tierra, desde el techo) y uno de cada tres va directo a ti. "
                        + "Donde va a caer sale humo del suelo: tienes 1,5 segundos para apartarte. Cada yunque quita 2 corazones (el casco amortigua un poco)";
            }

            protected void alEmpezar() {
                anunciar("El Centro ha subcontratado el reparto de yunques a una empresa de drones. Los drones no tienen brazos.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 30 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        ServerWorld w = p.getServerWorld();
                        int x = p.getBlockX(), z = p.getBlockZ();
                        if (random.nextInt(3) != 0) {
                            x += random.nextInt(7) - 3;
                            z += random.nextInt(7) - 3;
                        }
                        BlockPos pos = suelo(w, x, p.getBlockY(), z);
                        if (pos == null) pos = p.getBlockPos();
                        pendientes.add(new Golpe(w, Vec3d.ofBottomCenter(pos), t + 30));
                    }
                }
                List<ServerPlayerEntity> js = null;
                Iterator<Golpe> it = pendientes.iterator();
                while (it.hasNext()) {
                    Golpe g = it.next();
                    ServerWorld w = g.mundo();
                    Vec3d c = g.pos();
                    int falta = g.cuando() - t;
                    if (falta > 0) {
                        if (falta % 4 == 0) w.spawnParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.1, c.z, 3, 0.3, 0.02, 0.3, 0.0);
                        if (falta <= 8 && falta % 2 == 0) {
                            w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.FALLING_DUST, Blocks.ANVIL.getDefaultState()),
                                    c.x, c.y + falta * 0.5, c.z, 4, 0.25, 0.2, 0.25, 0.0);
                        }
                        continue;
                    }
                    it.remove();
                    w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 1f, 0.8f + random.nextFloat() * 0.3f);
                    w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.ANVIL.getDefaultState()), c.x, c.y + 0.3, c.z, 25, 0.3, 0.2, 0.3, 0.1);
                    w.spawnParticles(ParticleTypes.POOF, c.x, c.y + 0.2, c.z, 6, 0.4, 0.1, 0.4, 0.02);
                    if (js == null) js = jugadores();
                    for (ServerPlayerEntity p : js) {
                        if (p.getServerWorld() != w) continue;
                        if (Math.abs(p.getX() - c.x) < 0.9 && Math.abs(p.getZ() - c.z) < 0.9 && p.getY() > c.y - 1.5 && p.getY() < c.y + 2) {
                            p.damage(p.getDamageSources().fallingAnvil(null), 4f);
                            accion(p, "¡Yunque en la cabeza!", Formatting.RED);
                        }
                    }
                }
            }
        });

        // 2) Bombardeo en línea: una fila de bombas marcadas que estallan en cadena
        Desafios.registrar("bombardeo", () -> new Desafio("Bombardeo aéreo", 10, 90) {
            private final List<Golpe> bombas = new ArrayList<>();

            public String descripcion() {
                return "Cada 12 segundos suena una sirena y el Centro bombardea una línea de 20 bloques que pasa a tu lado (las bombas atraviesan la roca). "
                        + "Se marcan en el suelo con humo y fuego 2,5 segundos antes y estallan en cadena: sal de la línea hacia un lado. "
                        + "Cada bomba quita hasta 3 corazones y no rompe bloques";
            }

            protected void alEmpezar() {
                anunciar("El Centro compró un avión de segunda mano para repartir folletos. Los folletos eran bombas. Error de etiquetado.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 240 == 40) {                // la primera pasada a los 2 segundos, luego cada 12
                    for (ServerPlayerEntity p : jugadores()) {
                        ServerWorld w = p.getServerWorld();
                        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.EVENT_RAID_HORN.value(), SoundCategory.HOSTILE, 0.8f, 1.2f);
                        accion(p, "¡Bombardeo! Sal de la línea de humo", Formatting.RED);
                        double ang = random.nextDouble() * Math.PI * 2;
                        double dx = Math.cos(ang), dz = Math.sin(ang);
                        double lado = (random.nextDouble() - 0.5) * 3;      // la línea pasa a menos de 1,5 bloques de ti
                        double cx = p.getX() - dz * lado, cz = p.getZ() + dx * lado;
                        for (int i = 0; i <= 10; i++) {
                            double s = -10 + i * 2;
                            double bx = cx + dx * s, bz = cz + dz * s;
                            BlockPos pos = suelo(w, MathHelper.floor(bx), p.getBlockY(), MathHelper.floor(bz));
                            Vec3d c = pos != null ? Vec3d.ofBottomCenter(pos) : new Vec3d(bx, p.getY(), bz);
                            bombas.add(new Golpe(w, c, t + 50 + i * 3));
                        }
                    }
                }
                List<ServerPlayerEntity> js = null;
                Iterator<Golpe> it = bombas.iterator();
                while (it.hasNext()) {
                    Golpe g = it.next();
                    Vec3d c = g.pos();
                    int falta = g.cuando() - t;
                    if (falta > 0) {
                        if (falta % 5 == 0) {
                            g.mundo().spawnParticles(ParticleTypes.SMOKE, c.x, c.y + 0.1, c.z, 2, 0.15, 0.05, 0.15, 0.01);
                            g.mundo().spawnParticles(ParticleTypes.FLAME, c.x, c.y + 0.1, c.z, 1, 0.1, 0.0, 0.1, 0.0);
                        }
                        continue;
                    }
                    it.remove();
                    if (js == null) js = jugadores();
                    estallido(g.mundo(), c, 2.5, 6f, js, random.nextInt(3) == 0);
                }
            }
        });

        // 3) Socavones: agujeros temporales bajo los pies (todo se restaura)
        Desafios.registrar("socavones", Socavones::new);

        // 4) Marea invisible: un "agua" que sube y ahoga a quien cubra
        Desafios.registrar("marea_invisible", () -> new Desafio("Marea invisible", 10, 120) {
            private final Map<UUID, Marea> mareas = new HashMap<>();

            public String descripcion() {
                return "Un agua invisible sube desde donde estés: empieza 2 bloques bajo tus pies y sube 1 bloque cada 8 segundos (15 en total). "
                        + "Verás su superficie por las salpicaduras. Si te cubre la cabeza te ahogas como bajo el agua: ¡sube a lo alto! "
                        + "La respiración acuática te salva";
            }

            protected void alEmpezar() {
                anunciar("Se ha roto una tubería del Centro. El agua no se ve porque el becario la ha pasado por el filtro de desinformación.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                int subida = t / 160;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    // dentro de la tele las paredes no se pueden romper ni escalar: allí no sube
                    if (Dimensiones.esDelMod(w.getRegistryKey())) continue;
                    Marea m = mareas.get(p.getUuid());
                    if (m == null || m.jugador() != p || m.mundo() != w) {
                        // al empezar, al reaparecer o al cambiar de dimensión: el agua vuelve a quedar 2 bloques bajo sus pies
                        m = new Marea(p, w, MathHelper.floor(p.getY()) - 2 - subida);
                        mareas.put(p.getUuid(), m);
                    }
                    // nunca tan alta que no quepas debajo del techo del Nether (o del límite del mundo)
                    int tope = w.getRegistryKey() == World.NETHER ? 117 : w.getTopY() - 3;
                    int agua = Math.min(m.base() + subida, tope);
                    boolean cubierta = p.getEyeY() < agua;
                    if (t % 10 == 0) {
                        p.getServerWorld().spawnParticles(p, ParticleTypes.SPLASH, false, p.getX(), agua + 0.05, p.getZ(), 30, 3.0, 0.02, 3.0, 0.0);
                    }
                    if (t % 20 == 0) {
                        if (cubierta) {
                            accion(p, "¡Te ahogas! El agua llega a Y=" + agua + ": sube " + (int) Math.ceil(agua - p.getEyeY()) + " bloques", Formatting.RED);
                        } else {
                            accion(p, "Agua invisible en Y=" + agua + " · tu cabeza está en Y=" + MathHelper.floor(p.getEyeY()), Formatting.AQUA);
                        }
                    }
                    if (cubierta && !p.isSubmergedInWater()
                            && !p.hasStatusEffect(StatusEffects.WATER_BREATHING) && !p.hasStatusEffect(StatusEffects.CONDUIT_POWER)) {
                        int aire = p.getAir() - 5;       // fuera del agua el juego devuelve 4 por tick: así baja 1 por tick, como buceando
                        if (aire <= -20) {
                            aire = 0;
                            p.damage(p.getDamageSources().drown(), 2f);
                        }
                        p.setAir(aire);
                    }
                }
            }
        });

        // 5) Ola de frío: te congelas salvo cerca de una luz fuerte, con cuero o en el Nether
        Desafios.registrar("ola_frio", () -> new Desafio("Ola de frío", 10, 120) {
            public String descripcion() {
                return "Fuera del Nether te congelas como en nieve polvo: a los 7 segundos quedas helado, vas más lento y pierdes medio corazón cada 2 segundos. "
                        + "Te calienta tener una luz fuerte a 2 bloques (antorcha, farol, fuego, lava...), llevar una antorcha o un farol en la mano "
                        + "o cualquier pieza de cuero puesta";
            }

            protected void alEmpezar() {
                anunciar("Para ahorrar en la factura, el Centro ha puesto el aire acondicionado al mínimo. El mínimo son cuarenta bajo cero.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 10 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    // con calor no hacemos nada: el propio juego descongela 2 por tick
                    if (w.getRegistryKey() == World.NETHER || !p.canFreeze() || p.isOnFire() || p.isInLava() || hayCalor(p)) continue;
                    // +30 cada 10 ticks contra -20 del deshielo normal: helado (140) en 7 segundos
                    p.setFrozenTicks(Math.min(p.getMinFreezeDamageTicks() + 20, p.getFrozenTicks() + 30));
                    w.spawnParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1.2, p.getZ(), 5, 0.6, 0.6, 0.6, 0.01);
                    if (t % 40 == 0) {
                        accion(p, p.isFrozen() ? "¡Estás helado! Busca una antorcha o un fuego" : "Tienes frío... acércate a una luz fuerte", Formatting.AQUA);
                    }
                }
            }
        });

        // 6) Lluvia ácida: daño bajo el cielo abierto del Overworld
        Desafios.registrar("diluvio_acido", () -> new Desafio("Diluvio ácido", 10, 90) {
            public String descripcion() {
                return "Llueve ácido en todo el Overworld (también en desiertos y zonas nevadas): sin nada sobre la cabeza pierdes medio corazón cada segundo "
                        + "y tu armadura se desgasta. Ponte bajo techo, en una cueva, bajo el agua o pon un bloque encima de ti. En el Nether y el End no llueve";
            }

            protected void alEmpezar() {
                anunciar("Las nubes han leído las noticias del Centro y se han puesto tan amargas que llueven ácido.", Formatting.GRAY);
                server.getOverworld().setWeather(0, duracion + 200, true, false);
            }

            protected void cadaTick(int t) {
                if (t % 20 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    if (w.getRegistryKey() != World.OVERWORLD || !alCielo(w, p)) continue;
                    p.damage(p.getDamageSources().magic(), 1f);
                    for (EquipmentSlot slot : ARMADURA) {
                        ItemStack pieza = p.getEquippedStack(slot);
                        if (!pieza.isEmpty()) pieza.damage(1, p, slot);
                    }
                    w.spawnParticles(ParticleTypes.ITEM_SLIME, p.getX(), p.getY() + 2.2, p.getZ(), 8, 0.5, 0.3, 0.5, 0.0);
                    w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.WEATHER, 0.3f, 1.6f);
                    accion(p, "¡La lluvia ácida te quema! Ponte a cubierto", Formatting.GREEN);
                }
            }

            protected void limpiar() {
                server.getOverworld().setWeather(12000, 0, false, false);
            }
        });

        // 7) Vendaval: ráfagas que arrastran a quien esté al aire libre
        Desafios.registrar("vendaval", () -> new Desafio("Vendaval", 10, 90) {
            private double angulo = random.nextDouble() * Math.PI * 2;

            public String descripcion() {
                return "Cada 5 segundos sopla una ráfaga brutal (avisa un segundo antes y cambia de dirección): al aire libre te arrastra unos 8 bloques "
                        + "y los escombros te quitan medio corazón. Cuidado con precipicios y lava. Agáchate para aguantarla o ponte bajo techo "
                        + "(un bloque a menos de 8 sobre tu cabeza). En el End no sopla";
            }

            protected void alEmpezar() {
                anunciar("Alguien ha dejado abierta la ventana de la sala de reuniones. El Centro no está cerca, pero la corriente llega igual.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                int fase = t % 100;
                if (fase == 80) {
                    angulo += (random.nextDouble() - 0.5) * Math.PI;
                    double ax = Math.cos(angulo), az = Math.sin(angulo);
                    for (ServerPlayerEntity p : jugadores()) {
                        if (p.getServerWorld().getRegistryKey() == World.END) continue;
                        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.WEATHER, 0.6f, 1.5f);
                        accion(p, "¡Ráfaga hacia el " + rumbo(ax, az) + "! Agáchate o ponte a cubierto", Formatting.YELLOW);
                    }
                }
                double dx = Math.cos(angulo), dz = Math.sin(angulo);
                if (fase >= 80 && t % 2 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        ServerWorld w = p.getServerWorld();
                        if (w.getRegistryKey() == World.END) continue;
                        for (int i = 0; i < 3; i++) {
                            double ox = p.getX() - dx * 6 + (random.nextDouble() - 0.5) * 8;
                            double oz = p.getZ() - dz * 6 + (random.nextDouble() - 0.5) * 8;
                            // con 0 partículas, el "desplazamiento" es la velocidad: nubes volando en la dirección del viento
                            w.spawnParticles(ParticleTypes.CLOUD, ox, p.getY() + random.nextDouble() * 2.5, oz, 0, dx, 0.0, dz, 0.9);
                        }
                    }
                }
                if (fase != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    if (w.getRegistryKey() == World.END || p.isSneaking() || cubierto(w, p.getBlockPos(), 8)) continue;
                    p.damage(p.getDamageSources().generic(), 1f);
                    empujar(p, dx * 1.3, 0.45, dz * 1.3);
                    w.spawnParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1, p.getZ(), 8, 0.4, 0.4, 0.4, 0.05);
                }
            }
        });

        // 8) Tornado perseguidor
        Desafios.registrar("tornado", () -> new Desafio("Tornado", 10, 90) {
            private final Map<UUID, Tornado> tornados = new HashMap<>();

            public String descripcion() {
                return "Un tornado aparece a unos 15 bloques de cada jugador y lo persigue atravesando paredes, más lento que andando pero más rápido que agachado. "
                        + "Si te alcanza te zarandea (1 corazón) y te lanza unos 6 bloques por los aires; luego se aleja y vuelve. ¡No te quedes quieto!";
            }

            protected void alEmpezar() {
                anunciar("El ventilador del becario ha cobrado vida y ha salido a buscar a quien le puso la velocidad al máximo.", Formatting.GRAY);
            }

            private Tornado nuevo(ServerPlayerEntity p, double dist, int espera) {
                double a = random.nextDouble() * Math.PI * 2;
                return new Tornado(p.getServerWorld(), p.getX() + Math.cos(a) * dist, p.getY(), p.getZ() + Math.sin(a) * dist, espera);
            }

            protected void cadaTick(int t) {
                for (ServerPlayerEntity p : jugadores()) {
                    Tornado to = tornados.get(p.getUuid());
                    if (to == null || to.mundo != p.getServerWorld()
                            || (p.getX() - to.x) * (p.getX() - to.x) + (p.getZ() - to.z) * (p.getZ() - to.z) > 40 * 40) {
                        to = nuevo(p, 14 + random.nextInt(4), t + 20);
                        tornados.put(p.getUuid(), to);
                    }
                    double dx = p.getX() - to.x, dz = p.getZ() - to.z, d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 0.3) {
                        to.x += dx / d * 0.11;
                        to.z += dz / d * 0.11;
                    }
                    to.y += (p.getY() - to.y) * 0.08;
                    ServerWorld w = to.mundo;
                    if (t % 2 == 0) {
                        for (int i = 0; i < 6; i++) {
                            double h = (t * 0.15 + i * 1.2) % 7.0;
                            double r = 0.3 + h * 0.3;
                            double ang = t * 0.45 + i * 2.1 + h * 0.8;
                            w.spawnParticles(ParticleTypes.CLOUD, to.x + Math.cos(ang) * r, to.y + h, to.z + Math.sin(ang) * r, 1, 0.0, 0.0, 0.0, 0.0);
                        }
                        if (t % 4 == 0) w.spawnParticles(ParticleTypes.POOF, to.x, to.y + 0.2, to.z, 2, 0.6, 0.1, 0.6, 0.02);
                    }
                    if (t % 60 == 0) w.playSound(null, to.x, to.y, to.z, SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.WEATHER, 1f, 0.6f);
                    if (t >= to.espera && d < 1.8 && Math.abs(p.getY() - to.y) < 4) {
                        p.damage(p.getDamageSources().flyIntoWall(), 2f);
                        double a = random.nextDouble() * Math.PI * 2;
                        empujar(p, Math.cos(a) * 0.5, 1.05, Math.sin(a) * 0.5);
                        accion(p, "¡El tornado te ha atrapado!", Formatting.RED);
                        tornados.put(p.getUuid(), nuevo(p, 16, t + 60));   // se aleja y vuelve
                    }
                }
            }
        });

        // 9) Tormenta magnética: los rayos buscan la armadura de metal
        Desafios.registrar("tormenta_magnetica", () -> new Desafio("Tormenta magnética", 10, 90) {
            public String descripcion() {
                return "Cada 10 segundos cae un rayo sobre quien lleve armadura de metal (hierro, malla, oro o netherita): quita 1 corazón por cada pieza de metal puesta. "
                        + "1,5 segundos antes saltan chispas de tu armadura. Quítatela (cuero, diamante y tortuga no atraen rayos)... aunque los mobs te pegarán más";
            }

            protected void alEmpezar() {
                anunciar("Un fallo del reactor ha magnetizado las nubes. Ahora los rayos van a por el metal, como los imanes de la nevera.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                int fase = t % 200;
                if (fase < 170 && fase != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    int piezas = piezasMetal(p);
                    if (piezas == 0) continue;
                    ServerWorld w = p.getServerWorld();
                    if (fase >= 170) {
                        if (t % 4 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 6, 0.35, 0.6, 0.35, 0.1);
                        if (fase == 170) {
                            w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.WEATHER, 0.8f, 2f);
                            accion(p, "¡Tu armadura atrae el rayo! (" + piezas + (piezas == 1 ? " pieza" : " piezas") + " de metal)", Formatting.YELLOW);
                        }
                    } else {
                        LightningEntity rayo = EntityType.LIGHTNING_BOLT.create(w);
                        if (rayo != null) {
                            rayo.setCosmetic(true);       // solo se ve y se oye: ni fuego ni daño propio
                            rayo.refreshPositionAfterTeleport(p.getPos());
                            w.spawnEntity(rayo);
                        }
                        p.damage(p.getDamageSources().magic(), 2f * piezas);
                    }
                }
            }
        });

        // 10) Suelo electrificado: hay que estar en el aire en el momento de la descarga
        Desafios.registrar("suelo_electrico", () -> new Desafio("Suelo electrificado", 10, 90) {
            public String descripcion() {
                return "Cada 8 segundos el suelo da una descarga tras una cuenta atrás (3, 2, 1): quien esté tocando el suelo en ese instante pierde 1,5 corazones. "
                        + "Salta justo a tiempo, súbete a lana o a una alfombra, o ve montado";
            }

            protected void alEmpezar() {
                anunciar("El Centro ha instalado suelo radiante en todo el mundo. Lo conectó un electricista sin título.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                int fase = t % 160;
                if (fase == 100 || fase == 120 || fase == 140) {
                    int n = (160 - fase) / 20;
                    for (ServerPlayerEntity p : jugadores()) {
                        ServerWorld w = p.getServerWorld();
                        accion(p, "Descarga en " + n + "...", Formatting.YELLOW);
                        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), SoundCategory.BLOCKS, 1f, 0.6f + (3 - n) * 0.4f);
                        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 0.1, p.getZ(), 10, 1.5, 0.05, 1.5, 0.05);
                    }
                }
                if (fase != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 0.1, p.getZ(), 30, 2.5, 0.1, 2.5, 0.2);
                    if (aislado(p)) {
                        accion(p, "¡Te has librado de la descarga!", Formatting.GREEN);
                        continue;
                    }
                    p.damage(p.getDamageSources().magic(), 3f);
                    w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.BLOCKS, 0.6f, 1.8f);
                    accion(p, "¡ZAS! Descarga eléctrica", Formatting.RED);
                }
            }
        });

        // 11) Campo minado: minas casi invisibles alrededor de cada jugador
        Desafios.registrar("campo_minado", () -> new Desafio("Campo minado", 10, 120) {
            private final List<Mina> minas = new ArrayList<>();

            public String descripcion() {
                return "Cada 3 segundos se entierra una mina a entre 3 y 8 bloques de ti (hasta 12 por jugador). Solo las delata un hilillo de humo. "
                        + "Si pisas una oirás un clic y medio segundo después explota: hasta 3 corazones y un buen empujón (no rompe bloques). ¡Mira dónde pisas!";
            }

            protected void alEmpezar() {
                anunciar("El becario enterró las sorpresas de la fiesta de empresa por todo el mapa. No recuerda dónde. Ni qué eran.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                List<ServerPlayerEntity> js = jugadores();
                if (t % 60 == 0) {
                    for (ServerPlayerEntity p : js) {
                        UUID id = p.getUuid();
                        ServerWorld w = p.getServerWorld();
                        Vec3d aqui = p.getPos();
                        // las que se quedaron lejos dejan sitio a minas nuevas
                        minas.removeIf(m -> m.dueno.equals(id) && m.detona < 0
                                && (m.mundo != w || Vec3d.ofBottomCenter(m.pos).squaredDistanceTo(aqui) > 32 * 32));
                        int propias = 0;
                        for (Mina m : minas) if (m.dueno.equals(id)) propias++;
                        if (propias >= 12) continue;
                        BlockPos pos = posCerca(p, 3, 8);
                        if (pos.equals(p.getBlockPos())) continue;
                        boolean repetida = false;
                        for (Mina m : minas) {
                            if (m.mundo == w && m.pos.equals(pos)) { repetida = true; break; }
                        }
                        if (!repetida) minas.add(new Mina(w, pos.toImmutable(), id, t + 20));
                    }
                }
                Iterator<Mina> it = minas.iterator();
                while (it.hasNext()) {
                    Mina m = it.next();
                    Vec3d c = Vec3d.ofBottomCenter(m.pos);
                    if (m.detona >= 0) {
                        if (t >= m.detona) {
                            it.remove();
                            estallido(m.mundo, c, 3.0, 6f, js, true);
                        }
                        continue;
                    }
                    if (t % 20 == 0) m.mundo.spawnParticles(ParticleTypes.SMOKE, c.x, c.y + 0.05, c.z, 2, 0.08, 0.0, 0.08, 0.005);
                    if (t < m.armada) continue;
                    for (ServerPlayerEntity p : js) {
                        if (p.getServerWorld() != m.mundo) continue;
                        if (Math.abs(p.getX() - c.x) < 0.7 && Math.abs(p.getZ() - c.z) < 0.7 && Math.abs(p.getY() - c.y) < 0.6) {
                            m.detona = t + 10;
                            m.mundo.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_STONE_BUTTON_CLICK_ON, SoundCategory.BLOCKS, 1f, 1.5f);
                            accion(p, "*clic*", Formatting.RED);
                            break;
                        }
                    }
                }
            }
        });

        // 12) Géiseres: puntos fijos que revientan cada pocos segundos y te lanzan
        Desafios.registrar("geiseres", () -> new Desafio("Géiseres", 10, 90) {
            private final List<Geiser> geiseres = new ArrayList<>();

            public String descripcion() {
                return "Brotan géiseres a tu alrededor (hasta 7 por jugador, incluso bajo tus pies) que revientan cada 4-7 segundos. Siempre burbujean, "
                        + "y justo antes de reventar silban y echan vapor. Si estás encima te escaldan (1 corazón) y te lanzan unos 6 bloques hacia arriba: "
                        + "la caída también duele";
            }

            protected void alEmpezar() {
                anunciar("El Centro ha perforado el suelo en busca de petróleo. Ha encontrado agua hirviendo. Sigue perforando.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                List<ServerPlayerEntity> js = jugadores();
                if (t % 40 == 0) {
                    for (ServerPlayerEntity p : js) {
                        UUID id = p.getUuid();
                        ServerWorld w = p.getServerWorld();
                        Vec3d aqui = p.getPos();
                        geiseres.removeIf(g -> g.dueno.equals(id)
                                && (g.mundo != w || Vec3d.ofBottomCenter(g.pos).squaredDistanceTo(aqui) > 24 * 24));
                        int propios = 0;
                        for (Geiser g : geiseres) if (g.dueno.equals(id)) propios++;
                        if (propios >= 7) continue;
                        double a = random.nextDouble() * Math.PI * 2, d = random.nextDouble() * 9;
                        BlockPos pos = suelo(w, MathHelper.floor(p.getX() + Math.cos(a) * d), p.getBlockY(), MathHelper.floor(p.getZ() + Math.sin(a) * d));
                        if (pos == null) continue;
                        boolean repetido = false;
                        for (Geiser g : geiseres) {
                            if (g.mundo == w && g.pos.equals(pos)) { repetido = true; break; }
                        }
                        // el primer reventón tarda al menos 2 segundos: da tiempo a ver que ha brotado
                        if (!repetido) geiseres.add(new Geiser(w, pos.toImmutable(), id, 80 + random.nextInt(60), t + 40 + random.nextInt(40)));
                    }
                }
                for (Geiser g : geiseres) {
                    ServerWorld w = g.mundo;
                    Vec3d c = Vec3d.ofBottomCenter(g.pos);
                    int falta = g.siguiente - t;
                    if (falta > 25) {
                        if (t % 10 == 0) w.spawnParticles(ParticleTypes.SPLASH, c.x, c.y + 0.1, c.z, 3, 0.2, 0.0, 0.2, 0.0);
                    } else if (falta > 0) {
                        if (falta == 25) w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.7f, 0.6f);
                        if (t % 3 == 0) {
                            w.spawnParticles(ParticleTypes.CLOUD, c.x, c.y + 0.3, c.z, 3, 0.2, 0.2, 0.2, 0.02);
                            w.spawnParticles(ParticleTypes.SPLASH, c.x, c.y + 0.1, c.z, 6, 0.3, 0.0, 0.3, 0.0);
                        }
                    } else {
                        g.siguiente = t + g.periodo;
                        w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.BLOCKS, 1.2f, 0.6f);
                        w.spawnParticles(ParticleTypes.CLOUD, c.x, c.y + 2.5, c.z, 40, 0.25, 1.5, 0.25, 0.03);
                        w.spawnParticles(ParticleTypes.SPLASH, c.x, c.y + 1, c.z, 40, 0.4, 1.0, 0.4, 0.1);
                        for (ServerPlayerEntity p : js) {
                            if (p.getServerWorld() != w) continue;
                            if (Math.abs(p.getX() - c.x) < 0.8 && Math.abs(p.getZ() - c.z) < 0.8 && p.getY() > c.y - 0.5 && p.getY() < c.y + 2) {
                                p.damage(p.getDamageSources().hotFloor(), 2f);
                                empujar(p, (random.nextDouble() - 0.5) * 0.3, 1.0, (random.nextDouble() - 0.5) * 0.3);
                                accion(p, "¡El géiser te ha lanzado por los aires!", Formatting.RED);
                            }
                        }
                    }
                }
            }
        });

        // 13) Burbujas antigravedad: zonas que te hacen flotar y te suben con ellas
        Desafios.registrar("burbujas_antigravedad", () -> new Desafio("Burbujas antigravedad", 10, 90) {
            private final List<Burbuja> burbujas = new ArrayList<>();

            public String descripcion() {
                return "Aparecen burbujas antigravedad (esferas de chispas blancas de 5 bloques) a tu alrededor; suben despacio y revientan a los 10 segundos. "
                        + "Dentro flotas hacia arriba y te arrastran con ellas: sal por un lado cuanto antes o caerás desde muy alto. "
                        + "Un cubo de agua o la caída lenta te salvan";
            }

            protected void alEmpezar() {
                anunciar("La máquina de pompas de la fiesta del Centro se ha descalibrado. El departamento de física no da abasto.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                List<ServerPlayerEntity> js = jugadores();
                if (t % 50 == 0) {
                    for (ServerPlayerEntity p : js) {
                        UUID id = p.getUuid();
                        int propias = 0;
                        for (Burbuja b : burbujas) if (b.dueno.equals(id)) propias++;
                        if (propias >= 5) continue;
                        double a = random.nextDouble() * Math.PI * 2, d = 2 + random.nextDouble() * 7;
                        burbujas.add(new Burbuja(p.getServerWorld(), p.getX() + Math.cos(a) * d, p.getY() + 0.5, p.getZ() + Math.sin(a) * d, id, t));
                    }
                }
                Iterator<Burbuja> it = burbujas.iterator();
                while (it.hasNext()) {
                    Burbuja b = it.next();
                    ServerWorld w = b.mundo;
                    int edad = t - b.creada;
                    if (edad >= 200) {
                        it.remove();
                        w.spawnParticles(ParticleTypes.END_ROD, b.x, b.y, b.z, 30, 1.2, 1.2, 1.2, 0.15);
                        w.playSound(null, b.x, b.y, b.z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 1f, 1.4f);
                        continue;
                    }
                    if (edad > 20) b.y += 0.04;
                    if (t % 3 == 0) {
                        for (int i = 0; i < 6; i++) {
                            // un punto al azar de la superficie de la esfera
                            double u = random.nextDouble() * 2 - 1, ang = random.nextDouble() * Math.PI * 2, s = Math.sqrt(1 - u * u);
                            w.spawnParticles(ParticleTypes.END_ROD, b.x + s * Math.cos(ang) * RADIO_BURBUJA, b.y + u * RADIO_BURBUJA,
                                    b.z + s * Math.sin(ang) * RADIO_BURBUJA, 1, 0.0, 0.0, 0.0, 0.0);
                        }
                    }
                    if (edad < 20 || t % 2 != 0) continue;            // 1 segundo para formarse antes de hacer efecto
                    for (ServerPlayerEntity p : js) {
                        if (p.getServerWorld() != w) continue;
                        double dx = p.getX() - b.x, dy = p.getY() + 0.9 - b.y, dz = p.getZ() - b.z;
                        if (dx * dx + dy * dy + dz * dz < RADIO_BURBUJA * RADIO_BURBUJA) {
                            p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 8, 2, false, false));
                        }
                    }
                }
            }
        });

        // 14) Terremoto: sacudidas para todos y desprendimientos para quien esté bajo techo
        Desafios.registrar("terremoto", () -> new Desafio("Terremoto", 10, 90) {
            public String descripcion() {
                return "Cada 12 segundos hay un terremoto de 3 segundos: el suelo te sacude a saltitos y te marea. Si estás bajo techo "
                        + "(cuevas, casas, cualquier bloque a menos de 8 sobre tu cabeza) se desprenden piedras: 2 corazones por terremoto, algo menos con casco. "
                        + "Al aire libre solo te sacude (agáchate si estás al borde de algo)";
            }

            protected void alEmpezar() {
                anunciar("Los cimientos del Centro se están asentando. Sobre vosotros.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                int fase = (t + 180) % 240;       // el primero empieza a los 3 segundos
                if (fase == 220) {
                    for (ServerPlayerEntity p : jugadores()) {
                        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM.value(), SoundCategory.BLOCKS, 0.6f, 0.5f);
                        accion(p, "El suelo retumba...", Formatting.GOLD);
                    }
                }
                if (fase >= 60) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    if (fase == 0) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0, false, false));
                        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WITHER_BREAK_BLOCK, SoundCategory.BLOCKS, 0.5f, 0.5f);
                        accion(p, "¡TERREMOTO!", Formatting.GOLD);
                    }
                    if (fase % 6 == 0) {
                        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM.value(), SoundCategory.BLOCKS, 1f, 0.5f);
                        BlockState bajo = w.getBlockState(BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ()));
                        if (!bajo.isAir()) {
                            w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, bajo), p.getX(), p.getY() + 0.1, p.getZ(), 12, 1.5, 0.05, 1.5, 0.1);
                        }
                        if (p.isOnGround()) empujar(p, (random.nextDouble() - 0.5) * 0.4, 0.22, (random.nextDouble() - 0.5) * 0.4);
                    }
                    if (fase == 30) {
                        BlockState techo = techo(w, p.getBlockPos(), 8);
                        if (techo == null) continue;
                        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.FALLING_DUST, techo), p.getX(), p.getY() + 2.5, p.getZ(), 20, 0.6, 0.3, 0.6, 0.0);
                        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, techo), p.getX(), p.getY() + 1.8, p.getZ(), 20, 0.3, 0.3, 0.3, 0.1);
                        w.playSound(null, p.getX(), p.getY() + 2, p.getZ(), SoundEvents.BLOCK_STONE_HIT, SoundCategory.BLOCKS, 1f, 0.6f);
                        p.damage(p.getDamageSources().fallingBlock(null), 4f);
                        accion(p, "¡Se te cae el techo encima! Sal al aire libre", Formatting.RED);
                    }
                }
            }
        });

        // 15) Golpe de calor: termómetro que sube al correr y al sol
        Desafios.registrar("golpe_calor", () -> new Desafio("Golpe de calor", 10, 120) {
            private final Map<UUID, Float> temperatura = new HashMap<>();
            private final Map<UUID, Vec3d> antes = new HashMap<>();

            public String descripcion() {
                return "Un termómetro en la barra de acción sube al esprintar (mucho), al sol de día y en el Nether, y baja en el agua o la lluvia, "
                        + "a la sombra y estando quieto. Si llega al 100 % sufres un golpe de calor: 2 corazones, mareo y vuelve al 60 %. "
                        + "La resistencia al fuego evita el daño";
            }

            protected void alEmpezar() {
                anunciar("Se ha estropeado el termostato del planeta. El técnico llega el martes. De qué mes, no lo ha dicho.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 10 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    UUID id = p.getUuid();
                    ServerWorld w = p.getServerWorld();
                    Vec3d pos = p.getPos();
                    Vec3d previa = antes.put(id, pos);
                    boolean quieto = previa != null && previa.squaredDistanceTo(pos) < 0.04;
                    boolean nether = w.getRegistryKey() == World.NETHER;
                    boolean sol = w.getRegistryKey() == World.OVERWORLD && w.isDay() && alCielo(w, p);
                    float cambio = 0f;
                    if (p.isSprinting()) cambio += 4f;
                    if (sol || nether) cambio += 1.5f;
                    if (p.isTouchingWaterOrRain()) {
                        cambio -= 8f;
                    } else {
                        if (!sol && !nether) cambio -= 1.5f;
                        if (quieto) cambio -= 2.5f;
                    }
                    float temp = MathHelper.clamp(temperatura.getOrDefault(id, 30f) + cambio, 0f, 100f);
                    if (temp >= 100f) {
                        p.damage(p.getDamageSources().onFire(), 4f);
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
                        w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
                        titulo(p, Text.literal("¡GOLPE DE CALOR!").formatted(Formatting.RED, Formatting.BOLD),
                                Text.literal("Busca sombra o agua y no corras").formatted(Formatting.GOLD));
                        temp = 60f;
                    }
                    temperatura.put(id, temp);
                    int barras = Math.round(temp / 5f);
                    accion(p, "Temperatura [" + "|".repeat(barras) + ".".repeat(20 - barras) + "] " + Math.round(temp) + " %",
                            temp < 50f ? Formatting.GREEN : temp < 80f ? Formatting.GOLD : Formatting.RED);
                }
            }
        });

        // 16) La oscuridad muerde: daño con poca luz
        Desafios.registrar("oscuridad_muerde", () -> new Desafio("La oscuridad muerde", 10, 90) {
            public String descripcion() {
                return "Si la luz donde estás es menor de 6 (cuevas, de noche al aire libre, rincones del Nether...), la oscuridad te muerde: "
                        + "medio corazón cada 1,5 segundos. Quédate en sitios iluminados, pon antorchas o lleva en la mano una antorcha, un farol o un bloque que brille";
            }

            protected void alEmpezar() {
                anunciar("El Centro ha recortado el presupuesto de luz. La oscuridad, que trabaja gratis, se ha puesto a hacer horas extra.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 30 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (esLuz(p.getMainHandStack()) || esLuz(p.getOffHandStack())) continue;
                    ServerWorld w = p.getServerWorld();
                    BlockPos pies = p.getBlockPos();
                    int luz = Math.max(w.getLightLevel(pies), w.getLightLevel(pies.up()));
                    if (luz >= 6) continue;
                    p.damage(p.getDamageSources().magic(), 1f);
                    w.spawnParticles(ParticleTypes.SQUID_INK, p.getX(), p.getY() + 1, p.getZ(), 8, 0.4, 0.5, 0.4, 0.02);
                    accion(p, "La oscuridad te muerde (luz " + luz + "). ¡Busca luz!", Formatting.DARK_PURPLE);
                }
            }
        });

        // 17) Siseos fantasma: creepers que solo se oyen (y a veces explotan)
        Desafios.registrar("siseos_fantasma", () -> new Desafio("¿Has oído eso?", 10, 90) {
            private final Map<UUID, Integer> proximo = new HashMap<>();
            private final List<Golpe> reales = new ArrayList<>();

            public String descripcion() {
                return "Cada 4-7 segundos oirás el siseo de un creeper justo detrás de ti, pero no verás ninguno. La mitad de las veces es broma; "
                        + "la otra mitad, 1,5 segundos después hay una explosión ahí mismo (hasta 3,5 corazones, sin romper bloques). Cada vez que lo oigas, ¡aléjate!";
            }

            protected void alEmpezar() {
                anunciar("Para que los empleados no se duerman, el Centro ha puesto altavoces con sonidos de creeper. Algunos altavoces son creepers.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                List<ServerPlayerEntity> js = jugadores();
                for (ServerPlayerEntity p : js) {
                    int cuando = proximo.computeIfAbsent(p.getUuid(), u -> t + 20 + random.nextInt(60));
                    if (t < cuando) continue;
                    proximo.put(p.getUuid(), t + 80 + random.nextInt(60));
                    ServerWorld w = p.getServerWorld();
                    Vec3d mira = p.getRotationVector();
                    double hx = mira.x, hz = mira.z, h = Math.sqrt(hx * hx + hz * hz);
                    if (h < 0.01) {
                        double a = random.nextDouble() * Math.PI * 2;
                        hx = Math.cos(a);
                        hz = Math.sin(a);
                        h = 1;
                    }
                    double dist = 1.5 + random.nextDouble();
                    double x = p.getX() - hx / h * dist + (random.nextDouble() - 0.5);
                    double z = p.getZ() - hz / h * dist + (random.nextDouble() - 0.5);
                    BlockPos pos = suelo(w, MathHelper.floor(x), p.getBlockY(), MathHelper.floor(z));
                    Vec3d c = new Vec3d(x, pos != null ? pos.getY() : p.getY(), z);
                    w.playSound(null, c.x, c.y + 0.5, c.z, SoundEvents.ENTITY_CREEPER_PRIMED, SoundCategory.HOSTILE, 1f, 0.5f);
                    if (random.nextBoolean()) reales.add(new Golpe(w, c, t + 30));
                }
                Iterator<Golpe> it = reales.iterator();
                while (it.hasNext()) {
                    Golpe g = it.next();
                    if (t < g.cuando()) continue;
                    it.remove();
                    estallido(g.mundo(), g.pos(), 3.5, 7f, js, true);
                }
            }
        });

        // 18) Lluvia de flechas sobre quien esté al aire libre
        Desafios.registrar("lluvia_flechas", () -> new Desafio("Lluvia de flechas", 10, 75) {
            private final List<Flecha> flechas = new ArrayList<>();

            public String descripcion() {
                return "Llueven flechas sobre quien esté al aire libre (sin bloques a menos de 10 sobre la cabeza): 2 por segundo alrededor de cada jugador "
                        + "y muchas van directas a ti. Cada una quita 1 corazón (la armadura ayuda). Métete bajo techo, en una cueva o bajo un árbol, "
                        + "o levanta el escudo mirando arriba";
            }

            protected void alEmpezar() {
                anunciar("Un ejército de esqueletos ha alquilado las nubes por horas. El Centro aceptó porque pagaban por adelantado.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 10 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        ServerWorld w = p.getServerWorld();
                        BlockPos pies = p.getBlockPos();
                        if (cubierto(w, pies, 10)) continue;
                        int alto = 10;                    // tan arriba como se pueda (hasta 16), sin meterla en el techo del Nether
                        while (alto < 16 && w.getBlockState(pies.up(alto + 1)).isAir()) alto++;
                        double x = p.getX(), z = p.getZ();
                        if (random.nextInt(10) >= 3) {
                            x += (random.nextDouble() - 0.5) * 8;
                            z += (random.nextDouble() - 0.5) * 8;
                        }
                        ArrowEntity flecha = new ArrowEntity(w, x, pies.getY() + alto, z, new ItemStack(Items.ARROW), null);
                        flecha.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                        flecha.setDamage(1.0);
                        flecha.setVelocity((random.nextDouble() - 0.5) * 0.06, -1.4, (random.nextDouble() - 0.5) * 0.06);
                        if (w.spawnEntity(flecha)) flechas.add(new Flecha(flecha, t));
                    }
                }
                Iterator<Flecha> it = flechas.iterator();
                while (it.hasNext()) {
                    Flecha f = it.next();
                    if (f.flecha().isRemoved() || t - f.creada() > 100) {
                        f.flecha().discard();
                        it.remove();
                    }
                }
            }

            protected void limpiar() {
                for (Flecha f : flechas) f.flecha().discard();
                flechas.clear();
            }
        });

        // 19) Suelo hirviendo: no te puedes quedar quieto
        Desafios.registrar("suelo_hirviendo", () -> new Desafio("Suelo hirviendo", 10, 75) {
            private final Map<UUID, Vec3d> anclas = new HashMap<>();
            private final Map<UUID, Integer> quieto = new HashMap<>();

            public String descripcion() {
                return "El suelo arde: si te quedas en el mismo sitio (a menos de 1,5 bloques) echa humo a los 1,5 segundos y a los 2,5 te quema 1 corazón, "
                        + "y otro cada segundo que sigas ahí. ¡No pares de moverte! En el agua o montado estás a salvo, y la resistencia al fuego te protege";
            }

            protected void alEmpezar() {
                anunciar("El núcleo del planeta ha pedido un aumento de sueldo. Mientras se negocia, ha subido la calefacción.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 10 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    UUID id = p.getUuid();
                    Vec3d ahora = p.getPos();
                    Vec3d ancla = anclas.get(id);
                    if (ancla == null || ancla.squaredDistanceTo(ahora) > 2.25 || p.isTouchingWater() || p.hasVehicle()) {
                        anclas.put(id, ahora);
                        quieto.put(id, 0);
                        continue;
                    }
                    if (!p.isOnGround()) continue;        // en el aire no suma, pero saltar en el sitio tampoco te salva
                    int n = quieto.merge(id, 10, Integer::sum);
                    ServerWorld w = p.getServerWorld();
                    if (n >= 30) w.spawnParticles(ParticleTypes.SMOKE, p.getX(), p.getY() + 0.1, p.getZ(), 6, 0.3, 0.05, 0.3, 0.01);
                    if (n == 30) {
                        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.5f, 1.2f);
                        accion(p, "¡El suelo se calienta! Muévete", Formatting.GOLD);
                    }
                    if (n >= 50) {
                        p.damage(p.getDamageSources().hotFloor(), 2f);
                        w.spawnParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 0.1, p.getZ(), 10, 0.3, 0.05, 0.3, 0.02);
                        quieto.put(id, 30);               // si sigues ahí, otra quemadura en 1 segundo
                        accion(p, "¡Te quemas los pies!", Formatting.RED);
                    }
                }
            }
        });

        // 20) Alergia primaveral: estornudos cerca de la vegetación
        Desafios.registrar("alergia_polen", () -> new Desafio("Alergia primaveral", 10, 90) {
            public String descripcion() {
                return "Hay polen por todas partes: a menos de 3 bloques de hojas, flores, hierba o helechos estornudarás cada pocos segundos (más cuanta más vegetación). "
                        + "Cada estornudo quita medio corazón, te echa hacia atrás y a veces te marea. Aléjate de las plantas o ponte una calabaza tallada como mascarilla";
            }

            protected void alEmpezar() {
                anunciar("Las flores se han unido a la huelga de los árboles. Su arma de protesta: el polen.", Formatting.GRAY);
            }

            protected void cadaTick(int t) {
                if (t % 40 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (p.getEquippedStack(EquipmentSlot.HEAD).isOf(Items.CARVED_PUMPKIN)) continue;
                    ServerWorld w = p.getServerWorld();
                    int plantas = contarPolen(w, p.getBlockPos());
                    if (plantas < 3) continue;
                    w.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.getX(), p.getY() + 1.5, p.getZ(), 10, 1.5, 0.8, 1.5, 0.0);
                    if (random.nextDouble() >= Math.min(0.85, plantas / 15.0)) continue;
                    Vec3d mira = p.getRotationVector();
                    w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PANDA_SNEEZE, SoundCategory.PLAYERS, 1f, 1.4f);
                    w.spawnParticles(ParticleTypes.SNEEZE, p.getX() + mira.x * 0.6, p.getEyeY(), p.getZ() + mira.z * 0.6, 12, 0.15, 0.15, 0.15, 0.05);
                    p.damage(p.getDamageSources().magic(), 1f);
                    empujar(p, -mira.x * 0.5, 0.2, -mira.z * 0.5);
                    if (random.nextInt(3) == 0) p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 80, 0));
                    accion(p, "¡ACHÍS!", Formatting.YELLOW);
                }
            }
        });
    }

    // ======================================================================
    //                              DATOS
    // ======================================================================

    /** Algo que pasará en un sitio dentro de unos ticks (yunques, bombas, explosiones). */
    private record Golpe(ServerWorld mundo, Vec3d pos, int cuando) {}

    /** Nivel del agua invisible de un jugador (si cambia el objeto del jugador es que ha reaparecido). */
    private record Marea(ServerPlayerEntity jugador, ServerWorld mundo, int base) {}

    private record Flecha(ArrowEntity flecha, int creada) {}

    private static final double RADIO_BURBUJA = 2.5;

    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static final Set<Item> METAL = Set.of(
            Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS,
            Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS,
            Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS);

    /** Objetos que dan luz (y calor) al llevarlos en la mano. */
    private static final Set<Item> LUCES = Set.of(
            Items.TORCH, Items.SOUL_TORCH, Items.LANTERN, Items.SOUL_LANTERN, Items.LAVA_BUCKET,
            Items.GLOWSTONE, Items.JACK_O_LANTERN, Items.SEA_LANTERN, Items.SHROOMLIGHT);

    private static final class Tornado {
        final ServerWorld mundo;
        double x, y, z;
        int espera;

        Tornado(ServerWorld mundo, double x, double y, double z, int espera) {
            this.mundo = mundo;
            this.x = x;
            this.y = y;
            this.z = z;
            this.espera = espera;
        }
    }

    private static final class Mina {
        final ServerWorld mundo;
        final BlockPos pos;
        final UUID dueno;
        final int armada;
        int detona = -1;

        Mina(ServerWorld mundo, BlockPos pos, UUID dueno, int armada) {
            this.mundo = mundo;
            this.pos = pos;
            this.dueno = dueno;
            this.armada = armada;
        }
    }

    private static final class Geiser {
        final ServerWorld mundo;
        final BlockPos pos;
        final UUID dueno;
        final int periodo;
        int siguiente;

        Geiser(ServerWorld mundo, BlockPos pos, UUID dueno, int periodo, int siguiente) {
            this.mundo = mundo;
            this.pos = pos;
            this.dueno = dueno;
            this.periodo = periodo;
            this.siguiente = siguiente;
        }
    }

    private static final class Burbuja {
        final ServerWorld mundo;
        final double x, z;
        double y;
        final UUID dueno;
        final int creada;

        Burbuja(ServerWorld mundo, double x, double y, double z, UUID dueno, int creada) {
            this.mundo = mundo;
            this.x = x;
            this.y = y;
            this.z = z;
            this.dueno = dueno;
            this.creada = creada;
        }
    }

    // ======================================================================
    //                            HERRAMIENTAS
    // ======================================================================

    private static final int[] ALTURAS = {0, -1, 1, -2, 2, -3, -4};

    /** Hueco sin líquido con suelo firme debajo en la columna (x, z), cerca de la altura y. Null si no hay. */
    static BlockPos suelo(ServerWorld w, int x, int y, int z) {
        for (int dy : ALTURAS) {
            BlockPos pos = new BlockPos(x, y + dy, z);
            if (!w.isChunkLoaded(pos)) return null;
            BlockState s = w.getBlockState(pos);
            BlockPos abajo = pos.down();
            if (s.getCollisionShape(w, pos).isEmpty() && s.getFluidState().isEmpty()
                    && !w.getBlockState(abajo).getCollisionShape(w, abajo).isEmpty()) {
                return pos;
            }
        }
        return null;
    }

    /** Primer bloque sólido encima de la cabeza (de 2 a "alto" bloques sobre los pies), o null si no hay. */
    static BlockState techo(ServerWorld w, BlockPos pies, int alto) {
        for (int dy = 2; dy <= alto; dy++) {
            BlockPos q = pies.up(dy);
            BlockState s = w.getBlockState(q);
            if (!s.isAir() && !s.getCollisionShape(w, q).isEmpty()) return s;
        }
        return null;
    }

    static boolean cubierto(ServerWorld w, BlockPos pies, int alto) {
        return techo(w, pies, alto) != null;
    }

    /** Nada que frene la lluvia entre el jugador y el cielo (ni cristal, ni hojas, ni agua). */
    static boolean alCielo(ServerWorld w, ServerPlayerEntity p) {
        return w.getTopY(Heightmap.Type.MOTION_BLOCKING, p.getBlockX(), p.getBlockZ()) <= p.getBlockY() + 1;
    }

    /** Lanza al jugador con esa velocidad (el servidor se la manda al cliente en el siguiente tick). */
    static void empujar(ServerPlayerEntity p, double vx, double vy, double vz) {
        p.setVelocity(vx, vy, vz);
        p.velocityModified = true;
    }

    /**
     * Explosión falsa: partículas, sonido, daño y empujón a los jugadores cercanos, sin romper bloques.
     * El daño es de tipo "fuegos artificiales": la armadura y la protección contra explosiones lo reducen,
     * pero no se multiplica con la dificultad (el de explosión de verdad sí).
     */
    static void estallido(ServerWorld w, Vec3d c, double radio, float maxDanio, List<ServerPlayerEntity> jugadores, boolean sonido) {
        w.spawnParticles(ParticleTypes.EXPLOSION, c.x, c.y + 0.5, c.z, 2, 0.4, 0.3, 0.4, 0.0);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.5, c.z, 6, 0.5, 0.3, 0.5, 0.02);
        if (sonido) w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.BLOCKS, 1.6f, 0.9f);
        Vec3d centro = c.add(0, 0.5, 0);
        for (ServerPlayerEntity p : jugadores) {
            if (p.getServerWorld() != w) continue;
            double d = p.getPos().add(0, 0.9, 0).distanceTo(centro);
            if (d >= radio) continue;
            double fuerza = 1 - d / radio;
            p.damage(p.getDamageSources().fireworks(null, null), Math.max(1f, maxDanio * (float) fuerza));
            double dx = p.getX() - c.x, dz = p.getZ() - c.z, h = Math.sqrt(dx * dx + dz * dz);
            if (h > 0.01) empujar(p, dx / h * 0.9 * fuerza, 0.3 + 0.25 * fuerza, dz / h * 0.9 * fuerza);
            else empujar(p, 0, 0.55, 0);
        }
    }

    static String rumbo(double dx, double dz) {
        if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? "este" : "oeste";
        return dz > 0 ? "sur" : "norte";
    }

    static boolean esLuz(ItemStack s) {
        return LUCES.contains(s.getItem());
    }

    /** Luz fuerte (antorcha, farol, fuego, lava, hoguera...) a 2 bloques, o una luz en la mano. */
    static boolean hayCalor(ServerPlayerEntity p) {
        if (esLuz(p.getMainHandStack()) || esLuz(p.getOffHandStack())) return true;
        ServerWorld w = p.getServerWorld();
        BlockPos c = p.getBlockPos();
        for (BlockPos q : BlockPos.iterate(c.add(-2, -1, -2), c.add(2, 2, 2))) {
            if (w.getBlockState(q).getLuminance() >= 10) return true;
        }
        return false;
    }

    static int piezasMetal(ServerPlayerEntity p) {
        int n = 0;
        for (EquipmentSlot slot : ARMADURA) if (METAL.contains(p.getEquippedStack(slot).getItem())) n++;
        return n;
    }

    /** Sobre lana, alfombra, montado o en el aire: la descarga no te alcanza. */
    static boolean aislado(ServerPlayerEntity p) {
        if (!p.isOnGround() || p.hasVehicle()) return true;
        ServerWorld w = p.getServerWorld();
        BlockState pies = w.getBlockState(p.getBlockPos());
        BlockState abajo = w.getBlockState(BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ()));
        return pies.isIn(BlockTags.WOOL_CARPETS) || abajo.isIn(BlockTags.WOOL) || abajo.isIn(BlockTags.WOOL_CARPETS);
    }

    /** Hojas, flores, hierba y helechos a 3 bloques (7x5x7 bloques: barato cada 2 segundos). */
    static int contarPolen(ServerWorld w, BlockPos c) {
        int n = 0;
        for (BlockPos q : BlockPos.iterate(c.add(-3, -1, -3), c.add(3, 3, 3))) {
            BlockState s = w.getBlockState(q);
            if (s.isIn(BlockTags.LEAVES) || s.isIn(BlockTags.FLOWERS) || s.isOf(Blocks.SHORT_GRASS) || s.isOf(Blocks.TALL_GRASS)
                    || s.isOf(Blocks.FERN) || s.isOf(Blocks.LARGE_FERN)) {
                n++;
            }
        }
        return n;
    }

    // ======================================================================
    //                              SOCAVONES
    // ======================================================================

    /**
     * Cada 8 s se abre un agujero de 3x3 (hasta 3 de hondo) bajo cada jugador y a los 6 s se cierra.
     * Solo se quitan bloques naturales y macizos (sin bloque-entidad, rompibles, fuera del Centro), nunca junto a líquidos
     * ni encima de una cueva, y se guarda cada estado original para devolverlo tal cual (también si el desafío se corta).
     */
    static final class Socavones extends Desafio {
        /** Sin actualizar a los vecinos: no se caen plantas ni antorchas, no fluye el agua, no cae la arena. */
        private static final int OPCIONES = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

        private final List<Hoyo> hoyos = new ArrayList<>();

        private static final class Hoyo {
            final ServerWorld mundo;
            final BlockPos centro;                                // el bloque del suelo bajo los pies
            final int abre;
            int cierra = -1;
            final List<BlockPos> posiciones = new ArrayList<>(); // en el orden en que se quitaron (de arriba abajo)
            final List<BlockState> antes = new ArrayList<>();

            Hoyo(ServerWorld mundo, BlockPos centro, int abre) {
                this.mundo = mundo;
                this.centro = centro;
                this.abre = abre;
            }
        }

        Socavones() {
            super("Socavones", 10, 90);
        }

        public String descripcion() {
            return "Cada 8 segundos el suelo natural cruje bajo cada jugador y, 1,5 segundos después, se abre ahí un socavón de 3x3 y hasta 3 bloques de hondo. "
                    + "A los 6 segundos se cierra solo y todo queda como estaba: si sigues dentro te aplasta (2 corazones) y te escupe arriba. "
                    + "Al oír el crujido, apártate; si caes, sal rápido";
        }

        protected void alEmpezar() {
            anunciar("Las obras del metro del Centro van con retraso. Mucho retraso. Y justo por debajo de vuestros pies.", Formatting.GRAY);
        }

        protected void cadaTick(int t) {
            if (t % 160 == 60) {
                EstadoServidor estado = EstadoServidor.get(server);
                for (ServerPlayerEntity p : jugadores()) {
                    if (!p.isOnGround()) continue;
                    ServerWorld w = p.getServerWorld();
                    BlockPos centro = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
                    if (cerca(w, centro) || !excavable(w, centro, estado)) continue;
                    hoyos.add(new Hoyo(w, centro, t + 30));
                    w.playSound(null, centro.getX() + 0.5, centro.getY() + 1, centro.getZ() + 0.5, SoundEvents.ENTITY_WITHER_BREAK_BLOCK, SoundCategory.BLOCKS, 0.4f, 0.6f);
                    accion(p, "¡El suelo cruje bajo tus pies! Apártate", Formatting.RED);
                }
            }
            Iterator<Hoyo> it = hoyos.iterator();
            while (it.hasNext()) {
                Hoyo h = it.next();
                if (h.cierra < 0) {
                    if (t < h.abre) {
                        if (t % 4 == 0) grietas(h);
                        continue;
                    }
                    abrir(h);
                    if (h.posiciones.isEmpty()) {
                        it.remove();
                        continue;
                    }
                    h.cierra = t + 120;
                    h.mundo.playSound(null, h.centro.getX() + 0.5, h.centro.getY() + 0.5, h.centro.getZ() + 0.5, SoundEvents.BLOCK_GRAVEL_BREAK, SoundCategory.BLOCKS, 1f, 0.6f);
                } else if (t >= h.cierra) {
                    if (cerrar(h, true)) it.remove();
                    else h.cierra = t + 20;             // con el chunk sin cargar se reintenta (al acabar el desafío se cierra sí o sí)
                } else if (h.cierra - t == 40) {
                    for (ServerPlayerEntity p : jugadores()) {
                        if (p.getServerWorld() == h.mundo && dentro(p, h)) accion(p, "¡El socavón se cierra en 2 segundos! ¡Sal!", Formatting.RED);
                    }
                    grietas(h);
                }
            }
        }

        protected void limpiar() {
            for (Hoyo h : hoyos) if (h.cierra >= 0) cerrar(h, false);
            hoyos.clear();
        }

        /** ¿Hay ya otro socavón (abierto o a punto) que se solaparía con este? */
        private boolean cerca(ServerWorld w, BlockPos centro) {
            for (Hoyo h : hoyos) {
                if (h.mundo == w && Math.abs(h.centro.getX() - centro.getX()) <= 3 && Math.abs(h.centro.getZ() - centro.getZ()) <= 3
                        && Math.abs(h.centro.getY() - centro.getY()) <= 6) {
                    return true;
                }
            }
            return false;
        }

        private void grietas(Hoyo h) {
            BlockState s = h.mundo.getBlockState(h.centro);
            if (s.isAir()) return;
            h.mundo.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, s),
                    h.centro.getX() + 0.5, h.centro.getY() + 1.05, h.centro.getZ() + 0.5, 12, 1.0, 0.05, 1.0, 0.0);
            h.mundo.playSound(null, h.centro.getX() + 0.5, h.centro.getY() + 1, h.centro.getZ() + 0.5, SoundEvents.BLOCK_STONE_HIT, SoundCategory.BLOCKS, 0.6f, 0.6f);
        }

        /**
         * Bloque macizo de terreno natural (los que pueden atravesar las cuevas: piedra, pizarra, tierra, arena, grava, terracota,
         * netherrack, basalto...) que se puede quitar un rato sin romper nada. Nunca construcciones, redstone, TNT ni pistones.
         */
        private static boolean excavable(ServerWorld w, BlockPos q, EstadoServidor estado) {
            if (!w.isChunkLoaded(q) || Reglas.enSpawn(w, q, estado)) return false;
            BlockState s = w.getBlockState(q);
            if (s.isAir() || s.hasBlockEntity() || !s.getFluidState().isEmpty() || Reglas.prismarinaDeLaTele(w, s)) return false;
            if (!s.isIn(BlockTags.OVERWORLD_CARVER_REPLACEABLES) && !s.isIn(BlockTags.NETHER_CARVER_REPLACEABLES)) return false;
            float dureza = s.getHardness(w, q);
            if (dureza < 0 || dureza > 5f) return false;               // ni irrompibles, ni obsidiana y similares
            return s.isSolidBlock(w, q);
        }

        /** Hierba, helecho, capa de nieve... encima del agujero: se quita (y se devuelve) para que no suelte objetos. */
        private static boolean plantaQuitable(ServerWorld w, BlockPos q, BlockState s, EstadoServidor estado) {
            return !s.hasBlockEntity() && s.getFluidState().isEmpty() && s.isReplaceable() && !(s.getBlock() instanceof TallPlantBlock)
                    && w.getBlockState(q.up()).isAir() && !Reglas.enSpawn(w, q, estado);
        }

        /** Al lado no puede haber líquidos ni cosas frágiles (antorchas, escaleras, plantas...), solo aire o bloques macizos. */
        private static boolean vecinosSeguros(ServerWorld w, BlockPos q, Set<BlockPos> hueco) {
            for (Direction dir : Direction.values()) {
                BlockPos n = q.offset(dir);
                if (hueco.contains(n)) continue;
                BlockState s = w.getBlockState(n);
                if (!s.getFluidState().isEmpty()) return false;
                if (!s.isAir() && !s.isSolidBlock(w, n)) return false;
            }
            return true;
        }

        private void abrir(Hoyo h) {
            ServerWorld w = h.mundo;
            // cuadros, marcos y soportes de armadura se caerían o se quedarían enterrados: ahí no se abre
            if (!w.getEntitiesByClass(Entity.class, zona(h), ent -> ent instanceof AbstractDecorationEntity || ent instanceof ArmorStandEntity).isEmpty()) return;
            EstadoServidor estado = EstadoServidor.get(server);
            List<List<BlockPos>> columnas = new ArrayList<>();
            List<BlockPos> plantas = new ArrayList<>();   // la planta de encima de cada columna (o null)
            Set<BlockPos> hueco = new HashSet<>();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos arriba = h.centro.add(dx, 1, dz);
                    BlockState sa = w.getBlockState(arriba);
                    BlockPos planta = null;
                    if (!sa.isAir()) {
                        if (!plantaQuitable(w, arriba, sa, estado)) continue;
                        planta = arriba;
                    }
                    List<BlockPos> col = new ArrayList<>();
                    for (int d = 0; d < 3; d++) {
                        BlockPos q = h.centro.add(dx, -d, dz);
                        if (!excavable(w, q, estado)) break;
                        BlockState debajo = w.getBlockState(q.down());
                        if (debajo.isAir() || !debajo.getFluidState().isEmpty()) break;   // nunca se abre a una cueva ni a un líquido
                        col.add(q);
                    }
                    if (col.isEmpty()) continue;
                    columnas.add(col);
                    plantas.add(planta);
                    hueco.addAll(col);
                    if (planta != null) hueco.add(planta);
                }
            }
            // con un vecino frágil o líquido, la columna se corta en ese bloque (lo que queda debajo sigue en su sitio)
            for (List<BlockPos> col : columnas) {
                for (int i = 0; i < col.size(); i++) {
                    if (!vecinosSeguros(w, col.get(i), hueco)) {
                        List<BlockPos> fuera = col.subList(i, col.size());
                        hueco.removeAll(fuera);
                        fuera.clear();
                        break;
                    }
                }
            }
            for (int i = 0; i < columnas.size(); i++) {
                List<BlockPos> col = columnas.get(i);
                if (col.isEmpty()) continue;
                BlockPos planta = plantas.get(i);
                if (planta != null) quitar(h, planta);
                for (BlockPos q : col) quitar(h, q);
            }
        }

        private void quitar(Hoyo h, BlockPos q) {
            h.posiciones.add(q.toImmutable());
            h.antes.add(h.mundo.getBlockState(q));
            h.mundo.setBlockState(q, Blocks.AIR.getDefaultState(), OPCIONES);
        }

        /** La zona del socavón con margen (3x3 y de la planta de arriba al fondo). */
        private static Box zona(Hoyo h) {
            return new Box(h.centro).expand(1.0, 3.0, 1.0);
        }

        /** ¿Está la entidad metida en algún bloque macizo del socavón? */
        private static boolean dentro(Entity e, Hoyo h) {
            Box caja = e.getBoundingBox();
            for (int i = 0; i < h.posiciones.size(); i++) {
                BlockPos q = h.posiciones.get(i);
                if (!h.antes.get(i).isSolidBlock(h.mundo, q)) continue;   // las plantas no aplastan
                if (caja.intersects(new Box(q))) return true;
            }
            return false;
        }

        /** Devuelve cada bloque a su estado original (de abajo arriba). Con "normal", aplasta a quien siga dentro. */
        private boolean cerrar(Hoyo h, boolean normal) {
            ServerWorld w = h.mundo;
            if (normal) {
                for (BlockPos q : h.posiciones) if (!w.isChunkLoaded(q)) return false;
            }
            // primero se mira quién está dentro (luego los bloques ya ocupan su sitio): jugadores y también mobs (mascotas incluidas)
            List<LivingEntity> atrapados = new ArrayList<>();
            List<LivingEntity> enLaZona = w.getEntitiesByClass(LivingEntity.class, zona(h), vivo -> !vivo.isSpectator());
            for (LivingEntity e : enLaZona) {
                if (dentro(e, h)) atrapados.add(e);
            }
            for (int i = h.posiciones.size() - 1; i >= 0; i--) {
                BlockPos q = h.posiciones.get(i);
                if (w.getBlockState(q).hasBlockEntity()) continue;    // alguien ha puesto ahí un cofre o similar: se respeta
                w.setBlockState(q, h.antes.get(i), OPCIONES);
            }
            int arriba = h.centro.getY() + 1;
            for (LivingEntity e : atrapados) {
                e.requestTeleport(e.getX(), arriba, e.getZ());
                e.fallDistance = 0;
                if (normal && e instanceof ServerPlayerEntity p && participa(p)) {
                    p.damage(p.getDamageSources().inWall(), 4f);
                    accion(p, "¡El socavón se ha cerrado contigo dentro!", Formatting.RED);
                }
            }
            if (normal) {
                w.playSound(null, h.centro.getX() + 0.5, h.centro.getY() + 0.5, h.centro.getZ() + 0.5, SoundEvents.BLOCK_GRAVEL_BREAK, SoundCategory.BLOCKS, 1f, 0.5f);
            }
            return true;
        }
    }
}

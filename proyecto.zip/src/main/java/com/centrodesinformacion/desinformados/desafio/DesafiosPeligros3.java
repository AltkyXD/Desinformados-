package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.Danio;
import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.entidad.JefeTeleEntity;
import com.centrodesinformacion.desinformados.network.InvertidoPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/** 20 desafíos rojos nuevos de PELIGRO de mobs y del cuerpo: efectos, oleadas, inventario, controles (hay que sobrevivir). */
final class DesafiosPeligros3 {
    private DesafiosPeligros3() {}

    /** Etiqueta de los mobs que invocan estos desafíos (para quitarlos al acabar, aunque se hayan descargado). */
    static final String MARCA = "desinfo_peligro3";
    /** UUID de los mobs de estos desafíos que siguen en juego. Si uno con la MARCA se carga y no está aquí, sobra. */
    private static final Set<UUID> VIVOS = new HashSet<>();
    /** Desafíos de este archivo en marcha (para avisarles del daño). */
    private static final List<Peligro> EN_MARCHA = new ArrayList<>();

    private static final Identifier ENCOGER = Desinformados.id("peligro_encoger");
    private static final Identifier GIGANTE = Desinformados.id("peligro_gigante");
    private static final Identifier PLOMO = Desinformados.id("peligro_plomo");
    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    /** Un efecto de la ruleta. */
    private record Efecto(String nombre, RegistryEntry<StatusEffect> efecto, int nivel, int ticks) {}

    static void registrarTodos() {
        // Mobs de estos desafíos que vuelven a cargarse cuando ya no tocan (chunk descargado, servidor reiniciado...): fuera
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (entidad.getCommandTags().contains(MARCA) && !VIVOS.contains(entidad.getUuid())) Tareas.programar(1, entidad::discard);
        });
        // Las listas apuntan a entidades de esta sesión: no sirven para la siguiente (LAN, un jugador)
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            VIVOS.clear();
            EN_MARCHA.clear();
        });
        // Un solo modificador de daño para todos: solo mira, no cambia nada
        Danio.agregar((vivo, fuente, cantidad) -> {
            if (!EN_MARCHA.isEmpty()) {
                for (Peligro d : List.copyOf(EN_MARCHA)) d.alDanio(vivo, fuente, cantidad);
            }
            return cantidad;
        });

        // ======================================================================
        //                                 MOBS
        // ======================================================================

        Desafios.registrar("guarderia_zombie", () -> new Peligro("Guardería zombie", 90) {
            public String descripcion() {
                return "Cada 5 segundos aparecerá un zombie bebé cerca de cada jugador (como mucho 4 a la vez por jugador). "
                        + "Son pequeños y muy rápidos: pelea con la espalda contra una pared. Al sol se queman";
            }
            protected String excusa() {
                return "La guardería zombie del Centro ha cerrado por recortes de presupuesto. Los niños se han ido de excursión. Hacia vosotros.";
            }
            protected void paso(int t) {
                if (!cada(t, 5)) return;
                for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.ZOMBIE, 5, 10, 4, z -> z.setBaby(true));
            }
        });

        Desafios.registrar("el_cazador", () -> new Peligro("El Cazador", 120) {
            private UUID presa;
            private ZombieEntity cazador;
            private int vuelve = 0;

            public String descripcion() {
                return "Un Cazador (un zombie brillante con 15 corazones que corre como un zombie bebé) perseguirá a un jugador al azar "
                        + "y cambiará de presa cada 30 segundos. Si la presa se aleja, reaparece a 10-16 bloques de ella; si lo matáis, vuelve a los 10 segundos. "
                        + "Pega como un zombie normal: ayudad a la presa";
            }
            protected String excusa() {
                return "Recursos Humanos contrató a un cazador de talentos. Por un error en el contrato, caza a los talentos.";
            }
            protected void empezar() { nuevaPresa(); }
            protected void paso(int t) {
                if (cada(t, 30)) nuevaPresa();
                if (t % 20 != 0) return;
                ServerPlayerEntity p = presa == null ? null : server.getPlayerManager().getPlayer(presa);
                if (p == null || !Desafio.participa(p)) {
                    nuevaPresa();
                    p = presa == null ? null : server.getPlayerManager().getPlayer(presa);
                    if (p == null || !Desafio.participa(p)) return;
                }
                if (cazador != null && cazador.isDead()) {
                    cazador = null;
                    vuelve = t + 200;
                    anunciar("¡El Cazador ha caído! Volverá en 10 segundos...", Formatting.GOLD);
                } else if (cazador != null && cazador.isRemoved()) {
                    cazador = null;     // se quedó lejos o en otra dimensión: reaparece junto a la presa
                }
                if (cazador == null && t >= vuelve) cazador = sacar(p, EntityType.ZOMBIE, 10, 16, 1, DesafiosPeligros3::armarCazador);
            }
            private void nuevaPresa() {
                List<ServerPlayerEntity> js = jugadores();
                if (js.size() > 1 && presa != null) js.removeIf(j -> j.getUuid().equals(presa));
                if (js.isEmpty()) {
                    presa = null;
                    return;
                }
                ServerPlayerEntity p = js.get(random.nextInt(js.size()));
                if (p.getUuid().equals(presa)) return;     // solo queda él: sigue siendo la presa
                presa = p.getUuid();
                if (cazador != null) {
                    quitar(cazador);
                    cazador = null;
                }
                titulo(p, Text.literal("¡El Cazador va a por ti!").formatted(Formatting.DARK_RED, Formatting.BOLD),
                        Text.literal("Corre o pelea").formatted(Formatting.RED));
                anunciar("El Cazador persigue ahora a " + p.getGameProfile().getName(), Formatting.RED);
            }
        });

        Desafios.registrar("clones_malvados", () -> new Peligro("Clones malvados", 90) {
            public String descripcion() {
                return "Cada 20 segundos aparecerá cerca de cada jugador su clon: un zombie con una copia de tu armadura y de lo que tengas en la mano "
                        + "(si lleva algo en la mano tiene Debilidad, y al morir no suelta las copias). Como mucho 1 clon por jugador a la vez. "
                        + "Si vas sin casco, tu clon arderá al sol";
            }
            protected String excusa() {
                return "El becario ha hecho copias de seguridad de los jugadores con la fotocopiadora del Centro. Han salido con mal carácter.";
            }
            protected void paso(int t) {
                if (t != 60 && !cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (sacar(p, EntityType.ZOMBIE, 6, 10, 1, z -> copiar(p, z)) != null) accion(p, "¡Ha aparecido tu clon!", Formatting.RED);
                }
            }
        });

        Desafios.registrar("flechas_explosivas", () -> new Peligro("Flechas explosivas", 90) {
            /** Flecha -> dónde estaba el tick anterior. */
            private final Map<PersistentProjectileEntity, Vec3d> flechas = new IdentityHashMap<>();

            public String descripcion() {
                return "Las flechas de los esqueletos explotarán al impactar (explosión pequeña: hace daño pero no rompe bloques). "
                        + "Cada 15 segundos aparecerá un esqueleto con casco cerca de cada jugador (máx. 2). Usa escudo, cúbrete o pelea cuerpo a cuerpo";
            }
            protected String excusa() {
                return "Los esqueletos han cambiado de proveedor de puntas de flecha. Es el mismo que el de los creepers.";
            }
            protected void paso(int t) {
                // 1) Flechas que ya seguimos: si han dado a algo o se han clavado, explotan
                Iterator<Map.Entry<PersistentProjectileEntity, Vec3d>> it = flechas.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<PersistentProjectileEntity, Vec3d> e = it.next();
                    PersistentProjectileEntity f = e.getKey();
                    if (f.isRemoved()) {
                        Entity.RemovalReason razon = f.getRemovalReason();
                        if ((razon == Entity.RemovalReason.KILLED || razon == Entity.RemovalReason.DISCARDED) && f.getWorld() instanceof ServerWorld w) {
                            Vec3d donde = e.getValue();
                            explosion(w, donde.x, donde.y, donde.z, 1.0f);
                        }
                        it.remove();
                    } else if (f.getPos().squaredDistanceTo(e.getValue()) < 1.0E-4) {    // ya no se mueve: clavada
                        if (f.getWorld() instanceof ServerWorld w) explosion(w, f.getX(), f.getY(), f.getZ(), 1.0f);
                        f.discard();
                        it.remove();
                    } else {
                        e.setValue(f.getPos());
                    }
                }
                // 2) Flechas recién disparadas por esqueletos cerca de los jugadores
                if (t % 2 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        for (PersistentProjectileEntity nueva : p.getServerWorld().getEntitiesByClass(PersistentProjectileEntity.class,
                                p.getBoundingBox().expand(40), x -> x.age < 20 && x.getVelocity().lengthSquared() > 0.25
                                        && x.getOwner() instanceof AbstractSkeletonEntity)) {
                            flechas.putIfAbsent(nueva, nueva.getPos());
                        }
                    }
                }
                // 3) Esqueletos
                if (t == 40 || cada(t, 15)) {
                    for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.SKELETON, 10, 16, 2, DesafiosPeligros3::conArco);
                }
            }
            protected void alLimpiar() { flechas.clear(); }
        });

        Desafios.registrar("enjambre_furioso", () -> new Peligro("Enjambre furioso", 90) {
            public String descripcion() {
                return "Cada 20 segundos llegarán 2 abejas furiosas a por cada jugador (como mucho 3 a la vez por jugador). "
                        + "Su picadura envenena y, después de picar, mueren. Pelea o escóndete bajo el agua";
            }
            protected String excusa() {
                return "El Centro instaló colmenas para parecer más ecológico. Las abejas han leído la letra pequeña del contrato.";
            }
            protected void paso(int t) {
                if (t != 40 && !cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    for (int i = 0; i < 2; i++) sacar(p, EntityType.BEE, 6, 10, 3, b -> enfadar(b, p));
                }
            }
        });

        Desafios.registrar("rocas_con_bicho", () -> new Peligro("Rocas con bicho", 120) {
            public String descripcion() {
                return "Cada bloque que rompas tiene un 15% de probabilidad de llevar dentro una araña de cueva, que saldrá a por ti "
                        + "(como mucho 3 vivas por jugador). Su mordisco envenena. Piensa antes de picar";
            }
            protected String excusa() {
                return "El servicio de fumigación del Centro se ha declarado en huelga. Los bichos lo han celebrado mudándose a las piedras.";
            }
            protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado) {
                if (random.nextInt(100) >= 15) return;
                if (sacarEn(p, EntityType.CAVE_SPIDER, pos, 3, null) != null) accion(p, "¡Había una araña dentro!", Formatting.DARK_RED);
            }
        });

        Desafios.registrar("hidra", () -> new Peligro("Hidra", 90) {
            public String descripcion() {
                return "Cada golpe que le des a un zombie, esqueleto, araña o creeper (sin matarlo) tiene un 25% de probabilidad de duplicarlo: "
                        + "saldrá una copia a su lado. Cada 20 segundos aparecerá además un zombie con casco cerca de cada jugador. "
                        + "Como mucho 4 mobs del desafío por jugador a la vez. Mata rápido y con golpes fuertes";
            }
            protected String excusa() {
                return "Recursos Humanos ha autorizado a los mobs a hacer horas extra. Como no les llegaban las horas, se han duplicado.";
            }
            protected void alDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {
                if (!(fuente.getAttacker() instanceof ServerPlayerEntity p) || !Desafio.participa(p)) return;
                if (!(vivo instanceof MobEntity mob) || !duplicable(mob.getType()) || mob.getHealth() <= cantidad) return;
                if (random.nextInt(4) != 0) return;
                Tareas.programar(1, () -> duplicar(p, mob));
            }
            private void duplicar(ServerPlayerEntity p, MobEntity original) {
                if (!estaEnCurso() || !original.isAlive() || !Desafio.participa(p) || vivos(p) >= 4) return;
                Entity nuevo = original.getType().create(original.getWorld());
                if (!(nuevo instanceof MobEntity copia)) return;
                copia.refreshPositionAndAngles(original.getX() + random.nextDouble() - 0.5, original.getY(),
                        original.getZ() + random.nextDouble() - 0.5, original.getYaw(), 0f);
                if (copia instanceof AbstractSkeletonEntity) conArco(copia);
                else if (copia instanceof ZombieEntity zombie) {
                    casco(zombie);
                    if (original.isBaby()) zombie.setBaby(true);
                }
                if (soltar(p, copia) && original.getWorld() instanceof ServerWorld w) {
                    w.spawnParticles(ParticleTypes.POOF, original.getX(), original.getY() + 1, original.getZ(), 12, 0.4, 0.5, 0.4, 0.05);
                    w.playSound(null, original.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.6f);
                    accion(p, "¡Se ha duplicado!", Formatting.RED);
                }
            }
            protected void paso(int t) {
                if (!cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
            }
        });

        Desafios.registrar("mobs_invisibles", () -> new Peligro("Mobs invisibles", 90) {
            private final Set<LivingEntity> tocados = new HashSet<>();

            public String descripcion() {
                return "Los mobs hostiles a menos de 32 bloques de cada jugador se volverán invisibles: solo se les verá la armadura y lo que lleven en la mano. "
                        + "Cada 20 segundos aparecerá además un zombie con casco cerca de cada jugador (máx. 2). Escucha bien";
            }
            protected String excusa() {
                return "El Centro ha dejado de pagar la factura de las texturas de los mobs. Siguen ahí. Simplemente ya no se ven.";
            }
            protected void paso(int t) {
                if (t % 20 != 0) return;
                tocados.removeIf(Entity::isRemoved);
                for (ServerPlayerEntity p : jugadores()) {
                    for (HostileEntity m : p.getServerWorld().getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(32), DesafiosPeligros3::normal)) {
                        m.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 60, 0, false, false));
                        tocados.add(m);
                    }
                    if (cada(t, 20)) sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
                }
            }
            protected void alLimpiar() {
                for (LivingEntity m : tocados) if (!m.isRemoved()) quitarEfecto(m, StatusEffects.INVISIBILITY, 60);
                tocados.clear();
            }
        });

        Desafios.registrar("parpadeos", () -> new Peligro("Parpadeos", 90) {
            public String descripcion() {
                return "Cada 12 segundos te quedarás ciego durante 4 segundos y, cada vez que parpadees, aparecerá un zombie con casco cerca de ti "
                        + "(como mucho 3 a la vez). Escucha sus pasos y no camines a ciegas cerca de lava o precipicios";
            }
            protected String excusa() {
                return "Se han fundido las bombillas de vuestros ojos. El técnico llega en 90 segundos. Mientras tanto, parpadeos.";
            }
            protected void paso(int t) {
                if (!cada(t, 12)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0));
                    sonar(p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.4f);
                    sacar(p, EntityType.ZOMBIE, 5, 9, 3, DesafiosPeligros3::casco);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) quitarEfecto(p, StatusEffects.BLINDNESS, 80);
            }
        });

        // ======================================================================
        //                          CUERPO Y CONTROLES
        // ======================================================================

        Desafios.registrar("mundo_gigante", () -> new Peligro("Mundo de gigantes", 120) {
            private final Set<LivingEntity> crecidos = new HashSet<>();

            public String descripcion() {
                return "Encogeréis a la mitad de tamaño y pegaréis un 40% menos, y los mobs hostiles a menos de 24 bloques de vosotros crecerán un 50% "
                        + "(llegan más lejos con sus golpes). Cada 20 segundos aparecerá un zombie con casco cerca de cada jugador (máx. 2). "
                        + "Al acabar recuperaréis vuestro tamaño: no os quedéis metidos en huecos de 1 bloque";
            }
            protected String excusa() {
                return "Para ahorrar en tela, el proveedor ha fabricado a los jugadores en talla S. Los mobs se han quedado con las XL que sobraban.";
            }
            protected void paso(int t) {
                if (t % 20 != 0) return;
                crecidos.removeIf(Entity::isRemoved);
                for (ServerPlayerEntity p : jugadores()) {
                    poner(p, EntityAttributes.GENERIC_SCALE, ENCOGER, -0.5);
                    poner(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, ENCOGER, -0.4);
                    for (HostileEntity m : p.getServerWorld().getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(24), DesafiosPeligros3::normal)) {
                        if (crecidos.add(m)) poner(m, EntityAttributes.GENERIC_SCALE, GIGANTE, 0.5);
                    }
                    if (cada(t, 20)) sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    quitarMod(p, EntityAttributes.GENERIC_SCALE, ENCOGER);
                    quitarMod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, ENCOGER);
                }
                for (LivingEntity m : crecidos) if (!m.isRemoved()) quitarMod(m, EntityAttributes.GENERIC_SCALE, GIGANTE);
                crecidos.clear();
            }
        });

        Desafios.registrar("calambres", () -> new Peligro("Calambres", 90) {
            /** Cuartos de segundo que lleva cada uno esprintando desde el último calambre. */
            private final Map<UUID, Integer> corriendo = new HashMap<>();

            public String descripcion() {
                return "Prohibido esprintar: por cada segundo que pases esprintando (también nadando rápido) te dará un calambre: "
                        + "medio corazón de daño (nunca por debajo de 2 corazones) y Lentitud II 3 segundos. "
                        + "Cada 15 segundos aparecerá además una momia (husk) cerca de cada jugador (máx. 3). Camina y pelea";
            }
            protected String excusa() {
                return "El Centro ha recortado el presupuesto de potasio. Sin plátanos no hay sprint.";
            }
            protected void paso(int t) {
                if (t % 5 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        if (!p.isSprinting()) continue;
                        int n = corriendo.merge(p.getUuid(), 1, Integer::sum);
                        if (n < 4) continue;
                        corriendo.put(p.getUuid(), 0);
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
                        if (p.getHealth() >= 5f) p.damage(p.getDamageSources().magic(), 1f);     // nunca por debajo de 2 corazones
                        accion(p, "¡Calambre! No corras", Formatting.RED);
                    }
                }
                if (cada(t, 15)) {
                    for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.HUSK, 7, 12, 3, null);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) quitarEfecto(p, StatusEffects.SLOWNESS, 60);
            }
        });

        Desafios.registrar("armadura_plomo", () -> new Peligro("Armadura de plomo", 120) {
            public String descripcion() {
                return "Cada pieza que lleves en las casillas de armadura (élitros y calabazas incluidos) te hará un 10% más lento, hasta un 40%. "
                        + "Quítatela si quieres correr... pero cada 20 segundos aparecerá un zombie con casco cerca de cada jugador (máx. 2). "
                        + "Tú eliges: protección o velocidad";
            }
            protected String excusa() {
                return "Por un error de inventario, toda la armadura del servidor se ha cambiado por plomo pintado. Nadie lo ha notado. Bueno, vuestras piernas sí.";
            }
            protected void paso(int t) {
                if (t % 10 == 0) {
                    for (ServerPlayerEntity p : jugadores()) {
                        int n = piezas(p);
                        if (n > 0) poner(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, PLOMO, -0.1 * n);
                        else quitarMod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, PLOMO);
                    }
                }
                if (cada(t, 20)) {
                    for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) quitarMod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, PLOMO);
            }
        });

        Desafios.registrar("ruleta_efectos", () -> new Peligro("Ruleta de efectos", 120) {
            private final List<Efecto> malos = List.of(
                    new Efecto("Lentitud II", StatusEffects.SLOWNESS, 1, 200),
                    new Efecto("Fatiga minera II", StatusEffects.MINING_FATIGUE, 1, 200),
                    new Efecto("Debilidad", StatusEffects.WEAKNESS, 0, 200),
                    new Efecto("Ceguera", StatusEffects.BLINDNESS, 0, 100),
                    new Efecto("Náuseas", StatusEffects.NAUSEA, 0, 200),
                    new Efecto("Hambre III", StatusEffects.HUNGER, 2, 200),
                    new Efecto("Veneno", StatusEffects.POISON, 0, 100),
                    new Efecto("Oscuridad", StatusEffects.DARKNESS, 0, 200),
                    new Efecto("Brillo", StatusEffects.GLOWING, 0, 200));
            private final List<Efecto> buenos = List.of(
                    new Efecto("Velocidad II", StatusEffects.SPEED, 1, 200),
                    new Efecto("Salto II", StatusEffects.JUMP_BOOST, 1, 200),
                    new Efecto("Regeneración", StatusEffects.REGENERATION, 0, 200),
                    new Efecto("Resistencia", StatusEffects.RESISTANCE, 0, 200),
                    new Efecto("Prisa II", StatusEffects.HASTE, 1, 200));
            /** El último efecto que le tocó a cada uno (lo que hay que quitar al acabar). */
            private final Map<UUID, RegistryEntry<StatusEffect>> ultimo = new HashMap<>();

            public String descripcion() {
                return "Cada 15 segundos a cada jugador le tocará un efecto al azar durante 10 segundos (Ceguera y Veneno, 5). "
                        + "7 de cada 10 veces será malo (Lentitud II, Fatiga minera II, Debilidad, Ceguera, Náuseas, Hambre III, Veneno, Oscuridad o Brillo) "
                        + "y 3 de cada 10, bueno (Velocidad II, Salto II, Regeneración, Resistencia o Prisa II)";
            }
            protected String excusa() {
                return "El botiquín del Centro lo ha ordenado el becario. Ninguna etiqueta coincide con lo que hay dentro.";
            }
            protected void paso(int t) {
                if (t != 20 && !cada(t, 15)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    boolean bueno = random.nextInt(10) < 3;
                    List<Efecto> lista = bueno ? buenos : malos;
                    Efecto e = lista.get(random.nextInt(lista.size()));
                    RegistryEntry<StatusEffect> antes = ultimo.put(p.getUuid(), e.efecto());
                    if (antes != null && antes != e.efecto()) quitarEfecto(p, antes, 200);
                    p.addStatusEffect(new StatusEffectInstance(e.efecto(), e.ticks(), e.nivel()));
                    accion(p, "Ruleta: " + e.nombre() + " (" + e.ticks() / 20 + " s)", bueno ? Formatting.GREEN : Formatting.RED);
                    sonar(p, SoundEvents.BLOCK_LEVER_CLICK, bueno ? 1.8f : 0.6f);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    RegistryEntry<StatusEffect> ef = ultimo.get(p.getUuid());
                    if (ef != null) quitarEfecto(p, ef, 200);
                }
                ultimo.clear();
            }
        });

        Desafios.registrar("cortocircuito", () -> new Peligro("Cortocircuito", 90) {
            public String descripcion() {
                return "Cada 15 segundos tus controles se invertirán durante 5 segundos: adelante es atrás, izquierda es derecha y la cámara va al revés. "
                        + "Cada cortocircuito trae además un zombie con casco cerca de ti (máx. 2). Si estás junto a lava o un precipicio, suelta las teclas";
            }
            protected String excusa() {
                return "Alguien ha derramado café sobre el mando de vuestros personajes. El becario jura que no fue él. Fue él.";
            }
            protected void paso(int t) {
                if (!cada(t, 15)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (ServerPlayNetworking.canSend(p, InvertidoPayload.ID)) ServerPlayNetworking.send(p, new InvertidoPayload(100));
                    titulo(p, Text.literal("¡Cortocircuito!").formatted(Formatting.YELLOW, Formatting.BOLD),
                            Text.literal("Controles invertidos 5 segundos").formatted(Formatting.GOLD));
                    p.getServerWorld().spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 20, 0.4, 0.6, 0.4, 0.1);
                    sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
                }
            }
            protected void alLimpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    if (ServerPlayNetworking.canSend(p, InvertidoPayload.ID)) ServerPlayNetworking.send(p, new InvertidoPayload(0));
                }
            }
        });

        Desafios.registrar("hemorragia", () -> new Peligro("Hemorragia", 120) {
            /** Jugador -> {sangrados que le quedan, comprobaciones seguidas agachado}. */
            private final Map<UUID, int[]> sangrando = new HashMap<>();

            public String descripcion() {
                return "Cada golpe que te dé un mob te hará sangrar: perderás medio corazón cada 2 segundos, 3 veces (nunca por debajo de 1 corazón y medio). "
                        + "Agáchate 1 segundo seguido para taponar la herida. Cada 20 segundos aparecerá además una araña cerca de cada jugador (máx. 2)";
            }
            protected String excusa() {
                return "Las tiritas del Centro las fabricaba el becario. Con papel. Y celo.";
            }
            protected void alDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {
                if (!(vivo instanceof ServerPlayerEntity p) || !Desafio.participa(p) || !(fuente.getAttacker() instanceof MobEntity)) return;
                sangrando.put(p.getUuid(), new int[]{3, 0});
                accion(p, "¡Sangras! Agáchate para taponar la herida", Formatting.DARK_RED);
            }
            protected void paso(int t) {
                if (t % 10 == 0 && !sangrando.isEmpty()) {
                    Iterator<Map.Entry<UUID, int[]>> it = sangrando.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry<UUID, int[]> e = it.next();
                        ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                        if (p == null || !Desafio.participa(p)) {
                            it.remove();
                            continue;
                        }
                        int[] s = e.getValue();
                        if (p.isSneaking()) {
                            if (++s[1] >= 2) {
                                it.remove();
                                accion(p, "Herida taponada", Formatting.GREEN);
                                continue;
                            }
                        } else {
                            s[1] = 0;
                        }
                        if (t % 40 == 0) {
                            if (p.getHealth() >= 4f) p.damage(p.getDamageSources().magic(), 1f);   // nunca por debajo de 1,5 corazones
                            p.getServerWorld().spawnParticles(ParticleTypes.DAMAGE_INDICATOR, p.getX(), p.getY() + 1, p.getZ(), 4, 0.3, 0.4, 0.3, 0.05);
                            if (--s[0] <= 0) {
                                it.remove();
                                accion(p, "Ha dejado de sangrar", Formatting.GRAY);
                            }
                        }
                    }
                }
                if (cada(t, 20)) {
                    for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.SPIDER, 6, 10, 2, null);
                }
            }
            protected void alLimpiar() { sangrando.clear(); }
        });

        Desafios.registrar("karma_instantaneo", () -> new Peligro("Karma instantáneo", 90) {
            public String descripcion() {
                return "El 30% del daño que hagas a cualquier mob te lo harás también a ti, flechas incluidas "
                        + "(como mucho 1 corazón y medio por golpe; el karma nunca te baja de 1 corazón). "
                        + "Cada 20 segundos aparecerá además un zombie con casco cerca de cada jugador (máx. 2): pelea con cabeza";
            }
            protected String excusa() {
                return "El Centro ha pasado el karma a modo instantáneo. Antes tardaba años en volver. Ahora tarda un tick.";
            }
            protected void alDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {
                if (!(vivo instanceof MobEntity) || !(fuente.getAttacker() instanceof ServerPlayerEntity p) || !Desafio.participa(p)) return;
                float parte = Math.min(3f, cantidad * 0.3f);
                if (parte < 0.25f) return;
                Tareas.programar(1, () -> {
                    if (estaEnCurso() && Desafio.participa(p)) doler(p, parte, "Karma");
                });
            }
            protected void paso(int t) {
                if (!cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.ZOMBIE, 7, 12, 2, DesafiosPeligros3::casco);
            }
        });

        // ======================================================================
        //                       VIDA COMPARTIDA E INVENTARIO
        // ======================================================================

        Desafios.registrar("dolor_compartido", () -> new Peligro("Dolor compartido", 90) {
            public String descripcion() {
                return "Cada vez que un jugador reciba daño, todos los demás recibiréis la mitad de ese daño (como mucho 2 corazones por golpe). "
                        + "El dolor compartido nunca os bajará de 1 corazón, pero cuidado con lo que venga después. Con un solo jugador no pasa nada";
            }
            protected String excusa() {
                return "Curso obligatorio de trabajo en equipo: a partir de ahora, lo que le duele a uno os duele a todos. Sin excepciones. Sin anestesia.";
            }
            protected void alDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {
                if (!(vivo instanceof ServerPlayerEntity herido) || !Desafio.participa(herido)) return;
                float parte = Math.min(4f, cantidad * 0.5f);
                if (parte < 0.5f) return;
                UUID id = herido.getUuid();
                String nombre = herido.getGameProfile().getName();
                Tareas.programar(1, () -> {
                    if (!estaEnCurso()) return;
                    for (ServerPlayerEntity p : jugadores()) {
                        if (!p.getUuid().equals(id)) doler(p, parte, "Dolor de " + nombre);
                    }
                });
            }
        });

        Desafios.registrar("vidas_cruzadas", () -> new Peligro("Vidas cruzadas", 120) {
            public String descripcion() {
                return "Cada 20 segundos la vida se repartirá al azar: a cada jugador le tocará la de otro compañero (en proporción a su vida máxima, "
                        + "nunca menos de 2 corazones). Si alguien está bajo de vida le puede tocar a cualquiera: curaos todos. Con un solo jugador no pasa nada";
            }
            protected String excusa() {
                return "Por un error administrativo se han mezclado las fichas médicas de los jugadores. El Centro lo considera un ejercicio de empatía.";
            }
            protected void paso(int t) {
                if (!cada(t, 20)) return;
                List<ServerPlayerEntity> js = jugadores();
                if (js.size() < 2) {
                    for (ServerPlayerEntity p : js) accion(p, "Estás solo: no hay con quién cruzar la vida", Formatting.GRAY);
                    return;
                }
                Collections.shuffle(js, random);
                int n = js.size();
                float[] parte = new float[n];
                for (int i = 0; i < n; i++) parte[i] = js.get(i).getHealth() / js.get(i).getMaxHealth();
                for (int i = 0; i < n; i++) {
                    ServerPlayerEntity p = js.get(i);
                    int de = (i + 1) % n;     // cada uno recibe la del siguiente: nadie se queda con la suya
                    float nueva = Math.min(p.getMaxHealth(), Math.max(4f, parte[de] * p.getMaxHealth()));
                    p.setHealth(nueva);
                    accion(p, "Ahora tienes la vida de " + js.get(de).getGameProfile().getName() + ": " + corazones(nueva), Formatting.LIGHT_PURPLE);
                    sonar(p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.6f);
                }
            }
        });

        Desafios.registrar("barra_revuelta", () -> new Peligro("Barra revuelta", 90) {
            public String descripcion() {
                return "Cada 10 segundos se mezclarán al azar los objetos de tu barra rápida (no se pierde nada, solo cambian de casilla). "
                        + "Cada 20 segundos aparecerá además un esqueleto con casco cerca de cada jugador (máx. 2). Mira antes de pegar";
            }
            protected String excusa() {
                return "El servicio de limpieza ha pasado por vuestros bolsillos. Lo ha ordenado todo. A su manera.";
            }
            protected void paso(int t) {
                if (cada(t, 10)) {
                    for (ServerPlayerEntity p : jugadores()) {
                        PlayerInventory inv = p.getInventory();
                        List<ItemStack> barra = new ArrayList<>(9);
                        for (int i = 0; i < 9; i++) barra.add(inv.getStack(i));
                        Collections.shuffle(barra, random);
                        for (int i = 0; i < 9; i++) inv.setStack(i, barra.get(i));
                        accion(p, "¡Tu barra se ha revuelto!", Formatting.GOLD);
                        sonar(p, SoundEvents.ITEM_BOOK_PAGE_TURN, 0.7f);
                    }
                }
                if (t == 40 || cada(t, 20)) {
                    for (ServerPlayerEntity p : jugadores()) sacar(p, EntityType.SKELETON, 8, 14, 2, DesafiosPeligros3::conArco);
                }
            }
        });

        Desafios.registrar("patata_caliente", () -> new Peligro("Patata caliente", 90) {
            /** Jugador -> casilla que se ha calentado. */
            private final Map<UUID, Integer> calientes = new HashMap<>();
            private int desde = -1;

            public String descripcion() {
                return "Cada 12 segundos, lo que tengas en la mano se pondrá al rojo vivo: tienes 3 segundos para cambiar de casilla. "
                        + "Si al acabar sigues con esa casilla seleccionada, te quemará (1 corazón, salvo que te queden 2 o menos) "
                        + "y el objeto caerá a tus pies (no se pierde ni arde: recógelo)";
            }
            protected String excusa() {
                return "El proveedor de fuego del Centro ha regalado una muestra gratuita a cada objeto del servidor.";
            }
            protected void paso(int t) {
                if (cada(t, 12)) {
                    desde = t;
                    calientes.clear();
                    for (ServerPlayerEntity p : jugadores()) {
                        int casilla = p.getInventory().selectedSlot;
                        ItemStack s = p.getInventory().getStack(casilla);
                        if (s.isEmpty()) {
                            accion(p, "Tenías la mano vacía: te libras", Formatting.GREEN);
                            continue;
                        }
                        calientes.put(p.getUuid(), casilla);
                        titulo(p, Text.literal("¡QUEMA!").formatted(Formatting.GOLD, Formatting.BOLD),
                                Text.literal("Cambia de casilla: " + s.getName().getString()).formatted(Formatting.RED));
                        sonar(p, SoundEvents.BLOCK_FIRE_EXTINGUISH, 1.2f);
                    }
                }
                if (desde < 0) return;
                int pasado = t - desde;
                if (pasado % 10 == 0 && pasado < 60) {
                    for (ServerPlayerEntity p : jugadores()) {
                        Integer casilla = calientes.get(p.getUuid());
                        if (casilla == null || p.getInventory().selectedSlot != casilla) continue;
                        p.getServerWorld().spawnParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 5, 0.3, 0.3, 0.3, 0.01);
                        if (pasado % 20 == 0) accion(p, "¡Cambia de casilla! " + (3 - pasado / 20) + "...", Formatting.GOLD);
                    }
                }
                if (pasado < 60) return;
                for (ServerPlayerEntity p : jugadores()) {
                    Integer casilla = calientes.get(p.getUuid());
                    if (casilla == null) continue;
                    PlayerInventory inv = p.getInventory();
                    if (inv.selectedSlot != casilla || inv.getStack(casilla).isEmpty()) {
                        accion(p, "¡Por los pelos!", Formatting.GREEN);
                        continue;
                    }
                    ItemStack s = inv.removeStack(casilla);
                    ItemEntity suelto = new ItemEntity(p.getWorld(), p.getX(), p.getY() + 0.3, p.getZ(), s);
                    suelto.setPickupDelay(30);
                    suelto.setInvulnerable(true);       // ni lava, ni fuego, ni cactus
                    suelto.setVelocity(0, 0.15, 0);
                    p.getWorld().spawnEntity(suelto);
                    if (p.getHealth() > 4f) p.damage(p.getDamageSources().magic(), 2f);
                    p.getServerWorld().spawnParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 15, 0.3, 0.4, 0.3, 0.03);
                    sonar(p, SoundEvents.BLOCK_FIRE_EXTINGUISH, 0.8f);
                    accion(p, "¡Te has quemado! Se te ha caído al suelo", Formatting.RED);
                }
                calientes.clear();
                desde = -1;
            }
        });
    }

    // ======================================================================
    //                          BASE DE ESTOS DESAFÍOS
    // ======================================================================

    /**
     * Desafío de peligro con mobs apuntados: se limita cuántos tiene cada jugador, persiguen siempre a su jugador,
     * se quitan si se alejan mucho y desaparecen todos al acabar. También puede enterarse del daño (alDanio).
     * Las clases hijas usan empezar / paso / alLimpiar en lugar de alEmpezar / cadaTick / limpiar.
     */
    abstract static class Peligro extends Desafio {
        /** Jugador -> mobs que le ha sacado este desafío. */
        private final Map<UUID, List<MobEntity>> mobs = new HashMap<>();

        Peligro(String titulo, int duracionSegundos) {
            super(titulo, 10, duracionSegundos);
        }

        /** Frase del Centro que sale en el chat al empezar (null = ninguna). */
        protected String excusa() { return null; }
        protected void empezar() {}
        protected void paso(int t) {}
        protected void alLimpiar() {}
        /** Daño que recibe cualquier ser vivo (ya descontada la armadura). Solo mirar: el daño de aquí se programa para el tick siguiente. */
        protected void alDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {}

        @Override
        protected final void alEmpezar() {
            EN_MARCHA.add(this);
            String e = excusa();
            if (e != null) anunciar(e, Formatting.GRAY);
            empezar();
        }

        @Override
        protected final void cadaTick(int t) {
            if (t % 20 == 0) reenfocar();
            paso(t);
        }

        @Override
        protected final void limpiar() {
            EN_MARCHA.remove(this);
            for (List<MobEntity> lista : mobs.values()) for (MobEntity m : lista) quitar(m);
            mobs.clear();
            // Los que cambiaron de dimensión o se recargaron fuera de la lista
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                for (MobEntity m : p.getServerWorld().getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(64),
                        x -> x.getCommandTags().contains(MARCA) && !VIVOS.contains(x.getUuid()))) {
                    m.discard();
                }
            }
            alLimpiar();
        }

        /** Mobs de este desafío que siguen vivos para este jugador. */
        protected int vivos(ServerPlayerEntity p) {
            List<MobEntity> lista = mobs.get(p.getUuid());
            if (lista == null) return 0;
            lista.removeIf(DesafiosPeligros3::olvidado);
            return lista.size();
        }

        /** Cada segundo: que cada mob persiga a su jugador; si se ha ido lejos (o el jugador ya no juega), fuera. */
        private void reenfocar() {
            for (Map.Entry<UUID, List<MobEntity>> e : mobs.entrySet()) {
                ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                boolean juega = p != null && Desafio.participa(p);
                for (MobEntity m : e.getValue()) {
                    if (!m.isAlive()) continue;
                    if (!juega || m.getWorld() != p.getWorld() || m.squaredDistanceTo(p) > 48 * 48) quitar(m);
                    else if (m.getTarget() != p) m.setTarget(p);
                }
                e.getValue().removeIf(DesafiosPeligros3::olvidado);
            }
        }

        /** Saca un mob cerca del jugador (a min-max bloques). null si ya tiene "maximo" vivos o no hay hueco cerca. */
        protected <T extends MobEntity> T sacar(ServerPlayerEntity p, EntityType<T> tipo, int min, int max, int maximo, Consumer<T> preparar) {
            if (vivos(p) >= maximo) return null;
            BlockPos pos = posCerca(p, min, max);
            if (pos.equals(p.getBlockPos())) return null;      // sin hueco cerca: esta vez se libra
            return sacarEn(p, tipo, pos, maximo, preparar);
        }

        /** Saca un mob en este bloque para este jugador. */
        protected <T extends MobEntity> T sacarEn(ServerPlayerEntity p, EntityType<T> tipo, BlockPos pos, int maximo, Consumer<T> preparar) {
            if (vivos(p) >= maximo) return null;
            T m = tipo.create(p.getServerWorld());
            if (m == null) return null;
            m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, random.nextFloat() * 360f, 0f);
            if (preparar != null) preparar.accept(m);
            return soltar(p, m) ? m : null;
        }

        /** Mete en el mundo un mob ya creado y colocado: marcas, sin recoger objetos, apuntado y a por el jugador. */
        protected boolean soltar(ServerPlayerEntity p, MobEntity m) {
            m.addCommandTag(Mobs.MARCA_EVENTO);   // que exista aunque su tipo esté bloqueado
            m.addCommandTag(MARCA);
            m.setCanPickUpLoot(false);            // al quitarlo no se lleva nada de nadie
            VIVOS.add(m.getUuid());
            if (!m.getWorld().spawnEntity(m)) {
                VIVOS.remove(m.getUuid());
                return false;
            }
            mobs.computeIfAbsent(p.getUuid(), u -> new ArrayList<>()).add(m);
            m.setTarget(p);
            return true;
        }
    }

    // ======================================================================
    //                              HERRAMIENTAS
    // ======================================================================

    /** Quita un mob de estos desafíos (si se había descargado, lo quitará ENTITY_LOAD al volver). */
    static void quitar(MobEntity m) {
        VIVOS.remove(m.getUuid());
        if (!m.isRemoved()) m.discard();
    }

    /** Para removeIf: los que ya no están (muertos, quitados o descargados) se olvidan. */
    private static boolean olvidado(MobEntity m) {
        if (m.isAlive()) return false;
        VIVOS.remove(m.getUuid());
        return true;
    }

    /** Casco de cuero (para que no se quemen al sol) que no se suelta. */
    static void casco(MobEntity m) {
        m.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
        m.setEquipmentDropChance(EquipmentSlot.HEAD, 0f);
    }

    /** Esqueletos: su equipo de siempre (arco) y casco para el sol. */
    static void conArco(MobEntity m) {
        if (m.getWorld() instanceof ServerWorld w) m.initialize(w, w.getLocalDifficulty(m.getBlockPos()), SpawnReason.EVENT, null);
        casco(m);
    }

    /** El Cazador: 15 corazones, rápido, con nombre, brillante y con casco. */
    static void armarCazador(ZombieEntity z) {
        casco(z);
        EntityAttributeInstance vida = z.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vida != null) vida.setBaseValue(30.0);
        z.setHealth(30f);
        EntityAttributeInstance velocidad = z.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (velocidad != null) velocidad.setBaseValue(0.345);     // como un zombie bebé (0,23 x 1,5)
        z.setCustomName(Text.literal("El Cazador").formatted(Formatting.DARK_RED));
        z.setCustomNameVisible(true);
        z.setGlowing(true);
    }

    /** Clon: copia de la armadura y de la mano del jugador, que nunca se suelta (no se duplica nada). */
    static void copiar(ServerPlayerEntity p, MobEntity m) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
        for (EquipmentSlot slot : slots) {
            ItemStack s = p.getEquippedStack(slot);
            if (!s.isEmpty() && !s.isOf(Items.TOTEM_OF_UNDYING)) m.equipStack(slot, s.copy());
            m.setEquipmentDropChance(slot, 0f);
        }
        if (!m.getMainHandStack().isEmpty()) m.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 20 * 600, 0, false, false));
        m.setCustomName(Text.literal("Clon de " + p.getGameProfile().getName()).formatted(Formatting.RED));
        m.setCustomNameVisible(true);
    }

    static void enfadar(BeeEntity abeja, ServerPlayerEntity p) {
        abeja.setAngerTime(800);
        abeja.setAngryAt(p.getUuid());
    }

    /** Mobs que se pueden duplicar con la Hidra (solo los de siempre). */
    static boolean duplicable(EntityType<?> tipo) {
        return tipo == EntityType.ZOMBIE || tipo == EntityType.HUSK || tipo == EntityType.DROWNED
                || tipo == EntityType.SKELETON || tipo == EntityType.STRAY
                || tipo == EntityType.SPIDER || tipo == EntityType.CAVE_SPIDER || tipo == EntityType.CREEPER;
    }

    /** Hostiles normales: ni jefes ni el Warden. */
    static boolean normal(LivingEntity e) {
        return !(e instanceof WitherEntity) && !(e instanceof WardenEntity) && !(e instanceof JefeTeleEntity);
    }

    static int piezas(ServerPlayerEntity p) {
        int n = 0;
        for (EquipmentSlot s : ARMADURA) if (!p.getEquippedStack(s).isEmpty()) n++;
        return n;
    }

    /** Pone (o actualiza) un multiplicador temporal (no se guarda en el mundo). 0.5 = +50%. */
    static void poner(LivingEntity vivo, RegistryEntry<EntityAttribute> atributo, Identifier id, double valor) {
        EntityAttributeInstance inst = vivo.getAttributeInstance(atributo);
        if (inst == null) return;
        EntityAttributeModifier actual = inst.getModifier(id);
        if (actual != null && actual.value() == valor) return;
        inst.removeModifier(id);
        inst.addTemporaryModifier(new EntityAttributeModifier(id, valor, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    static void quitarMod(LivingEntity vivo, RegistryEntry<EntityAttribute> atributo, Identifier id) {
        EntityAttributeInstance inst = vivo.getAttributeInstance(atributo);
        if (inst != null) inst.removeModifier(id);
    }

    /** Quita un efecto solo si es de los cortos que pone el desafío (las pociones largas de verdad se quedan). */
    static void quitarEfecto(LivingEntity vivo, RegistryEntry<StatusEffect> efecto, int maxTicks) {
        StatusEffectInstance e = vivo.getStatusEffect(efecto);
        if (e != null && !e.isInfinite() && e.getDuration() <= maxTicks) vivo.removeStatusEffect(efecto);
    }

    /** Quita vida sin matar nunca (deja como mínimo 1 corazón). */
    static void doler(ServerPlayerEntity p, float cantidad, String motivo) {
        float antes = p.getHealth();
        float despues = Math.max(2f, antes - cantidad);
        if (despues >= antes) return;
        p.setHealth(despues);
        sonar(p, SoundEvents.ENTITY_PLAYER_HURT, 1f);
        p.sendMessage(Text.literal(motivo + ": -" + corazones(antes - despues)).formatted(Formatting.RED), true);
    }

    static void sonar(ServerPlayerEntity p, SoundEvent sonido, float tono) {
        p.getServerWorld().playSound(null, p.getBlockPos(), sonido, SoundCategory.PLAYERS, 0.8f, tono);
    }

    /** 3 -> "1,5 ❤" */
    static String corazones(float vida) {
        float c = Math.round(vida) / 2f;
        return (c == (int) c ? String.valueOf((int) c) : String.valueOf(c).replace('.', ',')) + " ❤";
    }
}

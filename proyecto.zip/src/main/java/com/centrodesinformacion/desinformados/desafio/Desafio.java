package com.centrodesinformacion.desinformados.desafio;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Desafío rojo: aviso (cuenta atrás) -> duración -> fin.
 * Muestra una barra de jefe con el tiempo. Afecta solo a jugadores vivos en supervivencia/aventura.
 */
public abstract class Desafio {
    /** Tiempo de aviso de todos los desafíos rojos. Cámbialo aquí si quieres otro. */
    public static final int AVISO_SEGUNDOS = 10;

    protected final String titulo;
    protected final int aviso;
    protected final int duracion;
    protected final Random random = new Random();
    protected MinecraftServer server;

    private int tick = 0;
    private int inicio = -1;
    private boolean terminado = false;
    private ServerBossBar barra;

    protected Desafio(String titulo, int avisoSegundos, int duracionSegundos) {
        this.titulo = titulo;
        this.aviso = AVISO_SEGUNDOS * 20; // todos los desafíos avisan con 10 segundos
        this.duracion = duracionSegundos * 20;
    }

    public String getTitulo() { return titulo; }

    /** Texto que sale debajo de la tele. */
    public abstract String descripcion();

    public String textoTele() {
        return descripcion() + " · Empieza en " + tiempo(aviso) + (duracion > 0 ? " · Dura " + tiempo(duracion) : "");
    }

    // ---------------- Ganchos que cada desafío puede usar ----------------
    protected void alEmpezar() {}
    protected void cadaTick(int t) {}           // t = ticks desde que empezó
    protected void alTerminar() {}              // solo si termina normalmente (castigos)
    protected void limpiar() {}                 // siempre al acabar (quitar efectos)
    protected void alSaltar(ServerPlayerEntity p) {}
    protected void alComer(ServerPlayerEntity p) {}
    protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado) {}
    protected void alGolpearBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado) {}
    protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado, BlockHitResult hit, ItemStack enMano) {}
    protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) {}

    // ---------------- Ciclo de vida ----------------
    void iniciar(MinecraftServer server) {
        this.server = server;
        this.barra = new ServerBossBar(Text.literal(titulo), BossBar.Color.YELLOW, BossBar.Style.PROGRESS);
    }

    /** Si este jugador debe ver el borde rojo. Los de objetivo lo quitan al completarse. */
    public boolean bordeActivo(ServerPlayerEntity p) { return !terminado; }

    public boolean estaEnCurso() { return inicio >= 0 && !terminado; }
    public boolean estaTerminado() { return terminado; }

    void tick() {
        if (terminado) return;
        tick++;
        if (tick % 20 == 1) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) barra.addPlayer(p);
        }
        if (inicio < 0) {
            int restante = aviso - tick;
            barra.setName(Text.literal(titulo + " · empieza en " + reloj(restante)));
            barra.setPercent(aviso > 0 ? MathHelper.clamp(restante / (float) aviso, 0f, 1f) : 0f);
            if (restante > 0 && restante <= 60 && restante % 20 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    titulo(p, Text.literal(String.valueOf(restante / 20)).formatted(Formatting.RED, Formatting.BOLD), Text.empty());
                    sonido(p);
                }
            }
            if (restante <= 0) {
                inicio = tick;
                barra.setColor(BossBar.Color.RED);
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    titulo(p, Text.literal("¡EMPIEZA!").formatted(Formatting.DARK_RED, Formatting.BOLD),
                            Text.literal(titulo).formatted(Formatting.RED));
                }
                alEmpezar();
                if (duracion <= 0) terminar(false);
            }
        } else {
            int t = tick - inicio;
            int restante = duracion - t;
            barra.setName(Text.literal(titulo + " · " + reloj(restante)));
            barra.setPercent(MathHelper.clamp(restante / (float) duracion, 0f, 1f));
            cadaTick(t);
            if (t >= duracion) terminar(false);
        }
    }

    public void terminar(boolean forzado) {
        if (terminado) return;
        terminado = true;
        if (inicio >= 0) {
            if (!forzado) alTerminar();
            limpiar();
        }
        barra.clearPlayers();
        server.getPlayerManager().broadcast(Text.literal("Desafío terminado: " + titulo).formatted(Formatting.GRAY), false);
    }

    // ---------------- Herramientas ----------------
    protected List<ServerPlayerEntity> jugadores() {
        List<ServerPlayerEntity> lista = new ArrayList<>();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.isAlive() && !p.isSpectator() && !p.isCreative()) lista.add(p);
        }
        return lista;
    }

    protected static boolean cada(int t, int segundos) {
        return t % (segundos * 20) == 0;
    }

    protected void titulo(ServerPlayerEntity p, Text titulo, Text subtitulo) {
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 30, 10));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(subtitulo));
        p.networkHandler.sendPacket(new TitleS2CPacket(titulo));
    }

    protected void accion(ServerPlayerEntity p, String mensaje, Formatting color) {
        p.sendMessage(Text.literal(mensaje).formatted(color), true);
    }

    protected void anunciar(String mensaje, Formatting color) {
        server.getPlayerManager().broadcast(Text.literal(mensaje).formatted(color), false);
    }

    protected void sonido(ServerPlayerEntity p) {
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.MASTER, 1f, 1.5f);
    }

    /** Hueco libre cerca del jugador (a su altura, ±3 bloques). */
    protected BlockPos posCerca(ServerPlayerEntity p, int min, int max) {
        ServerWorld w = p.getServerWorld();
        BlockPos base = p.getBlockPos();
        for (int i = 0; i < 20; i++) {
            double angulo = random.nextDouble() * Math.PI * 2;
            int dist = min + random.nextInt(max - min + 1);
            int x = base.getX() + (int) Math.round(Math.cos(angulo) * dist);
            int z = base.getZ() + (int) Math.round(Math.sin(angulo) * dist);
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos pos = new BlockPos(x, base.getY() + dy, z);
                if (w.isAir(pos) && w.isAir(pos.up()) && w.getBlockState(pos.down()).isSolidBlock(w, pos.down())) return pos;
            }
        }
        return base;
    }

    /** El hueco libre más alto encima del jugador (hasta "alto" bloques). */
    protected BlockPos encima(ServerPlayerEntity p, int alto) {
        ServerWorld w = p.getServerWorld();
        BlockPos base = p.getBlockPos();
        int libre = 0;
        for (int dy = 2; dy <= alto; dy++) {
            if (w.isAir(base.up(dy)) && w.isAir(base.up(dy + 1))) libre = dy; else break;
        }
        return libre > 0 ? base.up(libre) : base;
    }

    protected void rayo(ServerWorld w, BlockPos pos) {
        LightningEntity r = EntityType.LIGHTNING_BOLT.create(w);
        if (r != null) {
            r.refreshPositionAfterTeleport(Vec3d.ofBottomCenter(pos));
            w.spawnEntity(r);
        }
    }

    /** Explosión que hace daño pero no rompe bloques. */
    protected void explosion(ServerWorld w, double x, double y, double z, float fuerza) {
        w.createExplosion(null, x, y, z, fuerza, World.ExplosionSourceType.NONE);
    }

    protected MobEntity invocar(EntityType<? extends MobEntity> tipo, ServerWorld w, BlockPos pos) {
        return tipo.spawn(w, pos, SpawnReason.EVENT);
    }

    static String reloj(int ticks) {
        int s = Math.max(0, (ticks + 19) / 20);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    static String tiempo(int ticks) {
        int s = ticks / 20;
        if (s < 60) return s + " seg";
        if (s % 60 == 0) return (s / 60) + " min";
        return (s / 60) + " min " + (s % 60) + " seg";
    }
}

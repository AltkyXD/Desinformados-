package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** 19 desafíos rojos nuevos CON OBJETIVO: hacer algo, llegar a un sitio, moverse o pelear (quien no lo consiga, castigo). */
final class DesafiosObjetivos3 {
    private DesafiosObjetivos3() {}

    /** Rumbos de la "Brújula humana": norte = -Z, sur = +Z, este = +X, oeste = -X. */
    private static final String[] RUMBOS = {"NORTE", "SUR", "ESTE", "OESTE"};
    private static final int[] RUMBO_X = {0, 0, 1, -1};
    private static final int[] RUMBO_Z = {-1, 1, 0, 0};

    static void registrarTodos() {

        // ======================================================================
        //                              MOVERSE
        // ======================================================================

        Desafios.registrar("saltimbanqui", () -> new DesafioObjetivo("Saltimbanqui", 10, 60) {
            private final Map<UUID, Integer> saltos = new HashMap<>();
            public String descripcion() { return "Salta 50 veces antes de que acabe el tiempo. Quien falle tendrá Lentitud II durante 2 minutos"; }
            protected void alSaltar(ServerPlayerEntity p) {
                if (completado(p)) return;
                int n = saltos.merge(p.getUuid(), 1, Integer::sum);
                accion(p, "Saltos: " + n + "/50", Formatting.GOLD);
                if (n >= 50) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 2400, 1)); }
        });

        Desafios.registrar("maraton", () -> new DesafioObjetivo("Maratón", 10, 120) {
            private final Recorrido recorrido = new Recorrido();
            public String descripcion() {
                return "Recorre 250 bloques en horizontal como quieras: andando, corriendo, nadando, en barca, a caballo... "
                        + "Quien falle perderá 3 muslos de comida (sin bajar de 1) y toda la saturación";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                double d = recorrido.sumar(p, true, 4.0);
                if (server.getTicks() % 20 == 0) accion(p, "Recorrido: " + (int) d + "/250 bloques", Formatting.GOLD);
                return d >= 250;
            }
            protected void castigo(ServerPlayerEntity p) {
                var hambre = p.getHungerManager();
                hambre.setFoodLevel(Math.max(2, hambre.getFoodLevel() - 6));
                hambre.setSaturationLevel(0f);
                accion(p, "Te has quedado sin fuelle", Formatting.RED);
            }
        });

        Desafios.registrar("modo_ninja", () -> new DesafioObjetivo("Modo ninja", 10, 90) {
            private final Recorrido recorrido = new Recorrido();
            public String descripcion() {
                return "Recorre 40 bloques andando agachado. Quien falle brillará durante 3 minutos (todos le verán a través de las paredes) "
                        + "y tendrá Lentitud durante 1 minuto";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                double d = recorrido.sumar(p, p.isSneaking() && p.isOnGround() && !p.hasVehicle(), 1.0);
                if (server.getTicks() % 20 == 0) accion(p, "Agachado: " + (int) d + "/40 bloques", Formatting.GOLD);
                return d >= 40;
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 3600, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1200, 0));
            }
        });

        Desafios.registrar("sentadillas", () -> new DesafioObjetivo("Sentadillas", 10, 40) {
            private final Map<UUID, Boolean> abajo = new HashMap<>();
            private final Map<UUID, Integer> cuenta = new HashMap<>();
            public String descripcion() { return "Agáchate y levántate 30 veces. Quien falle tendrá agujetas: Lentitud y Debilidad durante 1 minuto"; }
            protected boolean cumple(ServerPlayerEntity p) {
                boolean ahora = p.isSneaking();
                Boolean antes = abajo.put(p.getUuid(), ahora);
                if (antes == null || antes || !ahora) return false;   // solo cuenta al pasar de pie a agachado
                int n = cuenta.merge(p.getUuid(), 1, Integer::sum);
                accion(p, "Sentadillas: " + n + "/30", Formatting.GOLD);
                return n >= 30;
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1200, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 1200, 0));
            }
        });

        Desafios.registrar("peonza", () -> new DesafioObjetivo("Peonza", 10, 40) {
            private final Map<UUID, Float> ultimo = new HashMap<>();
            private final Map<UUID, Double> giro = new HashMap<>();
            public String descripcion() { return "Da 10 vueltas completas sobre ti mismo girando la cámara, siempre hacia el mismo lado. Quien falle tendrá Náuseas 20 segundos"; }
            protected boolean cumple(ServerPlayerEntity p) {
                float yaw = p.getYaw();
                Float antes = ultimo.put(p.getUuid(), yaw);
                if (antes == null) return false;
                double cambio = MathHelper.wrapDegrees(yaw - antes);
                double total = giro.merge(p.getUuid(), cambio, Double::sum);
                if (server.getTicks() % 10 == 0) accion(p, "Vueltas: " + (int) (Math.abs(total) / 360.0) + "/10", Formatting.GOLD);
                return Math.abs(total) >= 3600;
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 400, 0)); }
        });

        Desafios.registrar("salto_de_fe", () -> new DesafioObjetivo("Salto de fe", 10, 120) {
            public String descripcion() {
                return "Déjate caer desde al menos 8 bloques de altura de una sola vez (si caes al agua, no duele). "
                        + "Quien falle perderá 3 corazones (nunca te dejará por debajo de medio corazón)";
            }
            // en el servidor la caída se va sumando tick a tick y el último tramo no llega a verse: 6,5 ≈ 8 bloques reales
            protected boolean cumple(ServerPlayerEntity p) { return p.fallDistance >= 6.5f && !p.isFallFlying(); }
            protected void castigo(ServerPlayerEntity p) { herir(p, 6f); }
        });

        // ======================================================================
        //                           IR A ALGÚN SITIO
        // ======================================================================

        Desafios.registrar("ascensor", () -> new DesafioObjetivo("Ascensor", 10, 150) {
            private final Partida partida = new Partida();
            public String descripcion() {
                return "Sube 25 bloques por encima de la altura a la que empieces (pilares, escaleras, escalando... como quieras). "
                        + "Quien falle tendrá Lentitud II y Fatiga minera durante 1 minuto";
            }
            private int objetivo(ServerPlayerEntity p) {
                ServerWorld w = p.getServerWorld();
                int techo = w.getRegistryKey() == World.NETHER ? 118 : w.getTopY() - 5;   // el techo de bedrock del Nether
                return Math.min(MathHelper.floor(partida.de(p).y) + 25, techo);
            }
            protected boolean cumple(ServerPlayerEntity p) {
                int meta = objetivo(p);
                if (server.getTicks() % 20 == 0) accion(p, "Sube hasta la capa " + meta + " (estás en la " + p.getBlockY() + ")", Formatting.GOLD);
                return p.getY() >= meta;
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1200, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 1200, 0));
            }
        });

        Desafios.registrar("topo", () -> new DesafioObjetivo("Topo", 10, 150) {
            private final Partida partida = new Partida();
            public String descripcion() { return "Baja 20 bloques por debajo de la altura a la que empieces. Quien falle tendrá Ceguera durante 30 segundos"; }
            private int objetivo(ServerPlayerEntity p) {
                return Math.max(MathHelper.floor(partida.de(p).y) - 20, p.getServerWorld().getBottomY() + 6);   // sin pelearse con la bedrock
            }
            protected boolean cumple(ServerPlayerEntity p) {
                int meta = objetivo(p);
                if (server.getTicks() % 20 == 0) accion(p, "Baja hasta la capa " + meta + " (estás en la " + p.getBlockY() + ")", Formatting.GOLD);
                return p.getY() <= meta;
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 600, 0)); }
        });

        Desafios.registrar("ida_y_vuelta", () -> new DesafioObjetivo("Ida y vuelta", 10, 150) {
            private final Partida partida = new Partida();
            private final Map<UUID, Vec3d> alejado = new HashMap<>();   // el punto de partida del que ya se alejó 30 bloques
            public String descripcion() {
                return "Aléjate al menos 30 bloques del sitio donde empieces y vuelve a él (a menos de 3 bloques; lo verás marcado con partículas). "
                        + "Quien falle tendrá un zombi bebé pegado a los talones";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                Vec3d o = partida.de(p);
                double d = horizontal(p, o);
                boolean vuelta = alejado.get(p.getUuid()) == o;   // mismo objeto: si cambia de dimensión, vuelta a empezar
                if (!vuelta && d >= 30) {
                    alejado.put(p.getUuid(), o);
                    vuelta = true;
                    accion(p, "¡Bien! Ahora vuelve al punto de partida", Formatting.GREEN);
                }
                if (vuelta && d <= 3) return true;
                if (server.getTicks() % 10 == 0) marcar(p, o);
                if (server.getTicks() % 20 == 0) {
                    if (vuelta) accion(p, "Vuelve: estás a " + (int) d + " bloques del punto de partida", Formatting.GOLD);
                    else accion(p, "Aléjate: " + (int) d + "/30 bloques", Formatting.GOLD);
                }
                return false;
            }
            protected void castigo(ServerPlayerEntity p) {
                ServerWorld w = p.getServerWorld();
                MobEntity zombi = crear(EntityType.ZOMBIE, w, posCerca(p, 2, 4));
                if (zombi == null) return;
                zombi.setBaby(true);
                zombi.setTarget(p);
                w.spawnEntityAndPassengers(zombi);
            }
        });

        Desafios.registrar("brujula", () -> new DesafioObjetivo("Brújula humana", 10, 120) {
            private final int rumbo = random.nextInt(RUMBOS.length);
            private final Partida partida = new Partida();
            public String descripcion() {
                return "Avanza 40 bloques hacia el " + RUMBOS[rumbo] + " desde donde empieces (con F3 ves hacia dónde miras). "
                        + "Quien falle verá cómo el becario le «ordena» el inventario (todo mezclado, no se pierde nada)";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                Vec3d o = partida.de(p);
                double avance = (p.getX() - o.x) * RUMBO_X[rumbo] + (p.getZ() - o.z) * RUMBO_Z[rumbo];
                if (server.getTicks() % 20 == 0) accion(p, "Hacia el " + RUMBOS[rumbo] + ": " + MathHelper.floor(avance) + "/40 bloques", Formatting.GOLD);
                return avance >= 40;
            }
            protected void castigo(ServerPlayerEntity p) {
                desordenar(p, random);
                accion(p, "El becario te ha «ordenado» el inventario", Formatting.RED);
            }
        });

        Desafios.registrar("catador_suelos", () -> new DesafioObjetivo("Catador de suelos", 10, 150) {
            private final Map<UUID, Set<Block>> pisados = new HashMap<>();
            public String descripcion() { return "Ponte de pie sobre 8 tipos de bloque distintos (vale colocarlos tú). Quien falle tendrá Debilidad durante 2 minutos"; }
            protected boolean cumple(ServerPlayerEntity p) {
                if (!p.isOnGround()) return false;
                BlockPos abajo = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
                BlockState s = p.getServerWorld().getBlockState(abajo);
                if (s.isAir()) return false;
                Set<Block> lista = pisados.computeIfAbsent(p.getUuid(), u -> new HashSet<>());
                if (lista.add(s.getBlock())) {
                    p.sendMessage(Text.literal("Suelos: " + lista.size() + "/8 · nuevo: ").formatted(Formatting.GOLD).append(s.getBlock().getName()), true);
                }
                return lista.size() >= 8;
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 2400, 0)); }
        });

        Desafios.registrar("a_oscuras", () -> new DesafioObjetivo("A oscuras", 10, 90) {
            public String descripcion() {
                return "Métete en un sitio totalmente a oscuras: nivel de luz 0 o 1 (tápate con bloques; la noche no basta). "
                        + "Quien falle tendrá Oscuridad durante 1 minuto";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                ServerWorld w = p.getServerWorld();
                BlockPos pies = p.getBlockPos();
                // luz "cruda" del cielo (no depende de la hora): de noche al aire libre sigue siendo 15
                int luz = Math.max(Math.max(w.getLightLevel(LightType.BLOCK, pies), w.getLightLevel(LightType.SKY, pies)),
                        Math.max(w.getLightLevel(LightType.BLOCK, pies.up()), w.getLightLevel(LightType.SKY, pies.up())));
                if (server.getTicks() % 20 == 0) accion(p, "Luz donde estás: " + luz + " (necesitas 0 o 1)", Formatting.GOLD);
                return luz <= 1;
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 1200, 0)); }
        });

        // ======================================================================
        //                       CERCA O LEJOS DE LOS DEMÁS
        // ======================================================================

        Desafios.registrar("distancia_social", () -> new DesafioObjetivo("Distancia social", 10, 90) {
            private final Map<UUID, Integer> seguidos = new HashMap<>();
            public String descripcion() {
                return "Pasa 20 segundos seguidos a más de 20 bloques de cualquier otro jugador. "
                        + "Quien falle tendrá Hambre II durante 40 segundos y Náuseas 10 segundos";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                int n = cercano(p, 20) ? 0 : seguidos.getOrDefault(p.getUuid(), 0) + 1;
                seguidos.put(p.getUuid(), n);
                if (server.getTicks() % 20 == 0) {
                    if (n == 0) accion(p, "¡Hay alguien a menos de 20 bloques! Aléjate", Formatting.RED);
                    else accion(p, "A solas: " + n / 20 + "/20 segundos", Formatting.GOLD);
                }
                return n >= 400;
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 800, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
            }
        });

        Desafios.registrar("abrazo_grupal", () -> new DesafioObjetivo("Abrazo grupal", 10, 180) {
            private final Set<UUID> revisados = new HashSet<>();
            private final Map<UUID, Integer> seguidos = new HashMap<>();
            public String descripcion() {
                return "Pasa 10 segundos seguidos a menos de 5 bloques de otro jugador. Quien al empezar no tenga a nadie a menos de 150 bloques "
                        + "(en su dimensión) se libra. Quien falle tendrá Debilidad II y Lentitud durante 1 minuto";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                if (revisados.add(p.getUuid()) && !cercano(p, 150)) {
                    accion(p, "No hay nadie cerca: el Centro te perdona el abrazo", Formatting.GREEN);
                    return true;
                }
                int n = cercano(p, 5) ? seguidos.getOrDefault(p.getUuid(), 0) + 1 : 0;
                seguidos.put(p.getUuid(), n);
                if (server.getTicks() % 20 == 0) {
                    if (n == 0) accion(p, "Busca a alguien y quédate a menos de 5 bloques", Formatting.GOLD);
                    else accion(p, "Abrazo: " + n / 20 + "/10 segundos", Formatting.GOLD);
                }
                return n >= 200;
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 1200, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1200, 0));
            }
        });

        // ======================================================================
        //                            PELEAR Y HACER
        // ======================================================================

        Desafios.registrar("karate", () -> new DesafioObjetivo("Kárate", 10, 120) {
            private final List<MobEntity> sparring = new ArrayList<>();
            public String descripcion() {
                return "Mata un mob a puñetazos, con la mano vacía (te ponemos un husk al lado para practicar). "
                        + "Quien falle recibirá la visita de 2 husks más";
            }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) {
                    MobEntity m = aparecer(EntityType.HUSK, p.getServerWorld(), posCerca(p, 3, 6), p);
                    if (m != null) sparring.add(m);
                }
            }
            protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) {
                if (muerto instanceof MobEntity && p.getMainHandStack().isEmpty()) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) {
                for (int i = 0; i < 2; i++) aparecer(EntityType.HUSK, p.getServerWorld(), posCerca(p, 3, 6), p);
            }
            protected void limpiar() {
                for (MobEntity m : sparring) if (m.isAlive()) m.discard();   // los de práctica que sobren se van
                sparring.clear();
            }
        });

        Desafios.registrar("safari", () -> new DesafioObjetivo("Safari", 10, 180) {
            private final Map<UUID, Set<EntityType<?>>> especies = new HashMap<>();
            public String descripcion() {
                return "Mata 3 tipos de mob distintos (hostiles o pacíficos, da igual). Quien falle tendrá a su lado un zombi, un esqueleto y una araña";
            }
            protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) {
                if (!(muerto instanceof MobEntity) || completado(p)) return;
                Set<EntityType<?>> lista = especies.computeIfAbsent(p.getUuid(), u -> new HashSet<>());
                if (!lista.add(muerto.getType())) {
                    accion(p, "Ese tipo ya lo tenías: busca otro", Formatting.YELLOW);
                    return;
                }
                p.sendMessage(Text.literal("Especies: " + lista.size() + "/3 · ").formatted(Formatting.GOLD).append(muerto.getType().getName()), true);
                if (lista.size() >= 3) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) {
                ServerWorld w = p.getServerWorld();
                aparecer(EntityType.ZOMBIE, w, posCerca(p, 3, 6), p);
                aparecer(EntityType.SKELETON, w, posCerca(p, 3, 6), p);
                aparecer(EntityType.SPIDER, w, posCerca(p, 3, 6), p);
            }
        });

        Desafios.registrar("plaga_endermites", () -> new DesafioObjetivo("Plaga", 10, 75) {
            private final List<MobEntity> plaga = new ArrayList<>();
            private final Map<UUID, Integer> muertos = new HashMap<>();
            public String descripcion() {
                return "Aparecerán 4 endermites a tu alrededor: mata 4 endermites. Quien falle tendrá Veneno durante 8 segundos (el veneno no mata)";
            }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) {
                    for (int i = 0; i < 4; i++) {
                        MobEntity m = aparecer(EntityType.ENDERMITE, p.getServerWorld(), posCerca(p, 3, 6), p);
                        if (m != null) plaga.add(m);
                    }
                }
            }
            protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) {
                if (muerto.getType() != EntityType.ENDERMITE || completado(p)) return;
                int n = muertos.merge(p.getUuid(), 1, Integer::sum);
                accion(p, "Endermites: " + n + "/4", Formatting.GOLD);
                if (n >= 4) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 160, 0)); }
            protected void limpiar() {
                for (MobEntity m : plaga) if (m.isAlive()) m.discard();   // fumigación al terminar
                plaga.clear();
            }
        });

        Desafios.registrar("sacrificio", () -> new DesafioObjetivo("Sacrificio", 10, 90) {
            private final Map<UUID, Float> vida = new HashMap<>();
            private final Map<UUID, Float> perdida = new HashMap<>();
            public String descripcion() {
                return "Pierde al menos 3 corazones de vida como quieras: caídas, cactus, mobs... "
                        + "Quien falle perderá 4 corazones de golpe (nunca te dejará por debajo de medio corazón)";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                float ahora = p.getHealth();
                Float antes = vida.put(p.getUuid(), ahora);
                float total = perdida.getOrDefault(p.getUuid(), 0f);
                if (antes != null && ahora < antes) {   // curarse no resta: solo se suman las bajadas
                    total += antes - ahora;
                    perdida.put(p.getUuid(), total);
                    accion(p, "Vida perdida: " + (int) (total / 2f) + "/3 corazones", Formatting.GOLD);
                }
                return total >= 6f;
            }
            protected void castigo(ServerPlayerEntity p) { herir(p, 8f); }
        });

        Desafios.registrar("a_mano_limpia", () -> new DesafioObjetivo("A mano limpia", 10, 120) {
            private final Map<UUID, Integer> rotos = new HashMap<>();
            public String descripcion() {
                return "Rompe 10 bloques con la mano vacía (lo que se rompe al instante, como plantas o antorchas, no cuenta). "
                        + "Quien falle tendrá Fatiga minera II durante 2 minutos";
            }
            protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado) {
                if (completado(p) || !p.getMainHandStack().isEmpty() || estado.getHardness(p.getServerWorld(), pos) <= 0f) return;
                int n = rotos.merge(p.getUuid(), 1, Integer::sum);
                accion(p, "A mano: " + n + "/10 bloques", Formatting.GOLD);
                if (n >= 10) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 2400, 1)); }
        });
    }

    // ======================================================================
    //                             HERRAMIENTAS
    // ======================================================================

    /** Punto de partida de cada jugador (se fija la primera vez que se mira; si cambia de dimensión, se vuelve a fijar). */
    private static final class Partida {
        private final Map<UUID, Vec3d> pos = new HashMap<>();
        private final Map<UUID, RegistryKey<World>> mundo = new HashMap<>();

        Vec3d de(ServerPlayerEntity p) {
            RegistryKey<World> aqui = p.getWorld().getRegistryKey();
            if (!aqui.equals(mundo.get(p.getUuid()))) {
                mundo.put(p.getUuid(), aqui);
                pos.put(p.getUuid(), p.getPos());
            }
            return pos.get(p.getUuid());
        }
    }

    /** Bloques recorridos en horizontal. Los saltos de más de "max" bloques en un tick (teletransportes, portales) no cuentan. */
    private static final class Recorrido {
        private final Map<UUID, Vec3d> ultima = new HashMap<>();
        private final Map<UUID, Double> total = new HashMap<>();

        double sumar(ServerPlayerEntity p, boolean cuenta, double max) {
            Vec3d antes = ultima.put(p.getUuid(), p.getPos());
            if (cuenta && antes != null) {
                double dx = p.getX() - antes.x, dz = p.getZ() - antes.z;
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < max) total.merge(p.getUuid(), d, Double::sum);
            }
            return total.getOrDefault(p.getUuid(), 0.0);
        }
    }

    private static double horizontal(ServerPlayerEntity p, Vec3d o) {
        double dx = p.getX() - o.x, dz = p.getZ() - o.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Columna de partículas en un punto; solo la ve ese jugador (y desde lejos). */
    private static void marcar(ServerPlayerEntity p, Vec3d o) {
        p.getServerWorld().spawnParticles(p, ParticleTypes.END_ROD, true, o.x, o.y + 0.8, o.z, 6, 0.05, 0.6, 0.05, 0.0);
    }

    /** ¿Hay otro jugador que participe a menos de "radio" bloques, en la misma dimensión? */
    private static boolean cercano(ServerPlayerEntity p, double radio) {
        for (ServerPlayerEntity otro : p.getServerWorld().getPlayers()) {
            if (otro != p && Desafio.participa(otro) && otro.squaredDistanceTo(p) <= radio * radio) return true;
        }
        return false;
    }

    /** Quita vida sin matar nunca: como mucho te deja en medio corazón (sin pasar por los multiplicadores de daño). */
    private static void herir(ServerPlayerEntity p, float cantidad) {
        float vida = Math.max(1f, p.getHealth() - cantidad);
        if (vida < p.getHealth()) p.setHealth(vida);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1f, 1f);
    }

    /** Mob del desafío, marcado como de evento (existe aunque su tipo esté bloqueado). Falta añadirlo con spawnEntity. */
    private static MobEntity crear(EntityType<? extends MobEntity> tipo, ServerWorld w, BlockPos pos) {
        MobEntity m = tipo.create(w);
        if (m == null) return null;
        m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, w.random.nextFloat() * 360f, 0f);
        m.initialize(w, w.getLocalDifficulty(pos), SpawnReason.EVENT, null);
        m.addCommandTag(Mobs.MARCA_EVENTO);
        return m;
    }

    /** Crea el mob, le da un objetivo y lo añade al mundo. */
    private static MobEntity aparecer(EntityType<? extends MobEntity> tipo, ServerWorld w, BlockPos pos, ServerPlayerEntity objetivo) {
        MobEntity m = crear(tipo, w, pos);
        if (m == null) return null;
        m.setTarget(objetivo);
        w.spawnEntityAndPassengers(m);   // por si initialize le ha montado un jinete (araña con esqueleto)
        return m;
    }

    /** El becario "ordena" el inventario: mezcla los 36 huecos (barra rápida incluida). No se pierde nada. */
    private static void desordenar(ServerPlayerEntity p, Random r) {
        PlayerInventory inv = p.getInventory();
        int n = inv.main.size();
        List<ItemStack> cosas = new ArrayList<>(n);
        for (int i = 0; i < n; i++) cosas.add(inv.getStack(i));
        Collections.shuffle(cosas, r);
        for (int i = 0; i < n; i++) inv.setStack(i, cosas.get(i));
    }
}

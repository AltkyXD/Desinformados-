package com.centrodesinformacion.desinformados.desafio;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Desafío con objetivo: quien no lo consiga antes de que acabe el tiempo recibe el castigo. */
public abstract class DesafioObjetivo extends Desafio {
    private final Set<UUID> completados = new HashSet<>();

    protected DesafioObjetivo(String titulo, int avisoSegundos, int duracionSegundos) {
        super(titulo, avisoSegundos, duracionSegundos);
    }

    /** Se comprueba cada tick. Para objetivos basados en eventos usa completar(p) directamente. */
    protected boolean cumple(ServerPlayerEntity p) { return false; }

    protected abstract void castigo(ServerPlayerEntity p);

    protected boolean completado(ServerPlayerEntity p) { return completados.contains(p.getUuid()); }

    protected final void completar(ServerPlayerEntity p) {
        if (!estaEnCurso() || !completados.add(p.getUuid())) return;
        titulo(p, Text.literal("¡CONSEGUIDO!").formatted(Formatting.GREEN, Formatting.BOLD), Text.literal(titulo).formatted(Formatting.GRAY));
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1f, 1f);
        anunciar(p.getGameProfile().getName() + " ha superado el desafío", Formatting.GREEN);
    }

    @Override
    protected void cadaTick(int t) {
        for (ServerPlayerEntity p : jugadores()) {
            if (!completado(p) && cumple(p)) completar(p);
        }
    }

    @Override
    protected void alTerminar() {
        for (ServerPlayerEntity p : jugadores()) {
            if (!completado(p)) {
                anunciar(p.getGameProfile().getName() + " no lo consiguió...", Formatting.RED);
                castigo(p);
            }
        }
    }
}

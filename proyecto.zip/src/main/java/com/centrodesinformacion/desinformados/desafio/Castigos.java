package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.Vida;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Castigos de los desafíos rojos con objetivo, según su dificultad: cuanto MÁS FÁCIL es el desafío, MÁS DURO es el castigo.
 * Nunca es daño (se curaría al momento): corazones máximos (los mismos que quita el Creeper Oscuro: vuelven al morir),
 * comida y cosas del inventario.
 * <p>
 * Vaciar el inventario para librarse no sirve: si al fallar te quedan tan pocas cosas como las que se iban a borrar
 * y al empezar tenías más, en vez de borrar cosas se quitan muchos más corazones.
 */
public final class Castigos {
    private Castigos() {}

    public enum Nivel {
        //          nombre        corazones  sin comida  cosas  corazones si lo vació
        MUY_FACIL("MUY FÁCIL", 3, true, 3, 8),
        FACIL("FÁCIL", 2, true, 2, 6),
        NORMAL("NORMAL", 1, false, 1, 4),
        DIFICIL("DIFÍCIL", 1, false, 0, 0);

        final String nombre;
        final int corazones;
        final boolean sinComida;
        final int cosas;
        final int corazonesSiVacio;

        Nivel(String nombre, int corazones, boolean sinComida, int cosas, int corazonesSiVacio) {
            this.nombre = nombre;
            this.corazones = corazones;
            this.sinComida = sinComida;
            this.cosas = cosas;
            this.corazonesSiVacio = corazonesSiVacio;
        }
    }

    private static final Map<String, Nivel> NIVELES = new HashMap<>();

    private static void poner(Nivel n, String... ids) {
        for (String id : ids) NIVELES.put(id, n);
    }

    static {
        // Se hacen en segundos o casi sin moverse
        poner(Nivel.MUY_FACIL, "toca_madera", "come_algo", "mojate", "mira_cielo", "sube_bloque", "mata_mob", "agachate", "no_te_muevas",
                "fabrica_mesa", "jardineria", "pedido_urgente", "timbre", "manos_vacias", "pila_exacta", "saltimbanqui", "sentadillas",
                "peonza", "modo_ninja", "brujula", "ida_y_vuelta", "sacrificio");
        // Fáciles, pero hay que hacer algo
        poner(Nivel.FACIL, "firma_aqui", "obras_express", "muro_contencion", "kit_de_piedra", "hagase_la_luz", "maraton", "salto_de_fe",
                "topo", "ascensor", "distancia_social", "catador_suelos", "a_oscuras", "abrazo_grupal", "plaga_endermites", "a_mano_limpia");
        // Hace falta tener o conseguir materiales
        poner(Nivel.NORMAL, "a_la_cama", "ponte_casco", "hoguera", "llena_cubo", "base_expres", "cantera", "al_horno", "fiebre_mineral",
                "karate", "safari");
        // Difíciles de verdad
        poner(Nivel.DIFICIL, "escalada", "fondo_mundo", "cazarrecompensas", "bloque_prohibido");
    }

    /** Nivel de un desafío (los que no están en la lista, NORMAL). */
    static Nivel nivel(String id) {
        if (id == null) return Nivel.NORMAL;
        return NIVELES.getOrDefault(id, Nivel.NORMAL);
    }

    /** Lo que sale en la tele: la dificultad y el castigo. */
    static String texto(Nivel n) {
        StringBuilder s = new StringBuilder("Desafío " + n.nombre + ". Si fallas: −" + n.corazones
                + (n.corazones == 1 ? " corazón" : " corazones") + " para siempre (hasta que mueras)");
        s.append(n.sinComida ? ", te quedas sin comida" : ", pierdes la mitad de la comida");
        if (n.cosas > 0) {
            s.append(" y se borran ").append(n.cosas).append(n.cosas == 1 ? " cosa" : " cosas").append(" de tu inventario")
                    .append(" (vaciarlo para librarte te costaría −").append(n.corazonesSiVacio).append(" corazones)");
        }
        return s.toString();
    }

    /** Quita de la descripción el castigo antiguo ("Quien falle ...") para poner el nuevo. */
    static String sinCastigoViejo(String descripcion) {
        int corte = -1;
        for (String marca : new String[]{". Quien falle", ". A quien falle", ". Quien se levante", ". Quien se mueva", ". Quien lo toque"}) {
            int i = descripcion.indexOf(marca);
            if (i >= 0 && (corte < 0 || i < corte)) corte = i;
        }
        String d = corte >= 0 ? descripcion.substring(0, corte) : descripcion;
        while (d.endsWith(".") || d.endsWith(" ")) d = d.substring(0, d.length() - 1);
        return d;
    }

    /** Huecos del inventario que cuentan como "cosas": los 36 normales y la mano izquierda (la armadura no). */
    private static List<Integer> huecosConCosas(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        List<Integer> huecos = new ArrayList<>();
        for (int i = 0; i < 36; i++) if (!inv.getStack(i).isEmpty()) huecos.add(i);
        if (!p.getOffHandStack().isEmpty()) huecos.add(-1);
        return huecos;
    }

    /** Cuántas cosas (montones) lleva encima. */
    static int cosas(ServerPlayerEntity p) {
        return huecosConCosas(p).size();
    }

    /**
     * Aplica el castigo del nivel. cosasAlEmpezar: las que llevaba cuando empezó el desafío (null si no se sabe).
     */
    static void aplicar(ServerPlayerEntity p, Nivel n, String titulo, Integer cosasAlEmpezar) {
        String nombre = p.getGameProfile().getName();
        List<String> partes = new ArrayList<>();
        int corazones = n.corazones;

        // ---- Inventario (o muchos más corazones si lo ha vaciado para librarse)
        List<String> borradas = new ArrayList<>();
        if (n.cosas > 0) {
            List<Integer> huecos = huecosConCosas(p);
            boolean loVacio = huecos.size() <= n.cosas && cosasAlEmpezar != null && cosasAlEmpezar > n.cosas;
            if (loVacio) {
                corazones = n.corazonesSiVacio;
                partes.add("ha vaciado el inventario para librarse");
            } else {
                Collections.shuffle(huecos);
                for (int k = 0; k < Math.min(n.cosas, huecos.size()); k++) {
                    int hueco = huecos.get(k);
                    ItemStack s = hueco < 0 ? p.getOffHandStack() : p.getInventory().getStack(hueco);
                    borradas.add(s.getCount() + " " + s.getName().getString());
                    if (hueco < 0) p.getInventory().offHand.set(0, ItemStack.EMPTY);
                    else p.getInventory().setStack(hueco, ItemStack.EMPTY);
                }
                if (!borradas.isEmpty()) partes.add("a la basura: " + String.join(", ", borradas));
            }
        }

        // ---- Corazones máximos (los quita Vida, igual que el Creeper Oscuro; Fondo de Roca protege)
        Vida.cambiarRojos(p, -corazones);
        partes.add(0, "−" + corazones + (corazones == 1 ? " corazón" : " corazones"));

        // ---- Comida
        HungerManager hambre = p.getHungerManager();
        if (n.sinComida) {
            hambre.setFoodLevel(0);
            partes.add(1, "sin comida");
        } else {
            hambre.setFoodLevel(hambre.getFoodLevel() / 2);
            partes.add(1, "media comida");
        }
        hambre.setSaturationLevel(0f);

        // ---- Avisos
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 60, 15));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(String.join(" · ", partes)).formatted(Formatting.GRAY)));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("SANCIONADO").formatted(Formatting.DARK_RED, Formatting.BOLD)));
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.PLAYERS, 0.8f, 1.2f);
        p.getServer().getPlayerManager().broadcast(Text.literal("[SANCIÓN] El Centro de Desinformación sanciona a " + nombre + " por no superar «"
                + titulo + "» (" + n.nombre.toLowerCase() + "): " + String.join(", ", partes) + ".").formatted(Formatting.RED), false);
        if (n == Nivel.MUY_FACIL) {
            p.getServer().getPlayerManager().broadcast(Text.literal("Era de los fáciles. El becario lo ha apuntado en la pizarra de la vergüenza.")
                    .formatted(Formatting.GRAY, Formatting.ITALIC), false);
        }
    }
}

package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Eventos;
import com.centrodesinformacion.desinformados.Reglas;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.entidad.GarabatoEntity;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.*;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Todos los desafíos rojos. Se lanzan con /desinfo lanzar <id>.
 * Formato: registrar("id", () -> new Desafio("Título", avisoSegundos, duracionSegundos) { ... });
 */
public class Desafios {
    public static final Map<String, Supplier<Desafio>> TODOS = new LinkedHashMap<>();
    private static final List<Desafio> ACTIVOS = new ArrayList<>();
    private static final Map<UUID, Integer> SALTOS = new HashMap<>();
    private static final Map<UUID, Float> COMIDA = new HashMap<>();
    private static final Map<UUID, Boolean> BORDE = new HashMap<>();

    private static final Identifier UN_CORAZON = Desinformados.id("un_corazon");

    private static void registrar(String id, Supplier<Desafio> creador) {
        TODOS.put(id, creador);
    }

    static {
        // ======================================================================
        //                           DESAFÍOS NORMALES
        // ======================================================================

        registrar("creeper_sorpresa", () -> new Desafio("¡Creeper sorpresa!", 20, 0) {
            public String descripcion() { return "Aparecerá un creeper justo donde estés"; }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) invocar(EntityType.CREEPER, p.getServerWorld(), p.getBlockPos());
            }
        });

        registrar("lluvia_creepers", () -> new Desafio("Lluvia de creepers", 60, 60) {
            public String descripcion() { return "Caerán creepers del cielo sobre cada jugador cada 10 segundos"; }
            protected void cadaTick(int t) {
                if (!cada(t, 10)) return;
                for (ServerPlayerEntity p : jugadores()) invocar(EntityType.CREEPER, p.getServerWorld(), encima(p, 12));
            }
        });

        registrar("suelo_lava", () -> new Desafio("El suelo es lava", 60, 60) {
            public String descripcion() { return "Cada 3 segundos el bloque bajo tus pies se convertirá en magma"; }
            protected void cadaTick(int t) {
                if (!cada(t, 3)) return;
                EstadoServidor estado = EstadoServidor.get(server);
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    BlockPos abajo = BlockPos.ofFloored(p.getX(), p.getY() - 0.5, p.getZ());
                    BlockState s = w.getBlockState(abajo);
                    if (!s.isAir() && !s.hasBlockEntity() && s.getFluidState().isEmpty()
                            && s.getHardness(w, abajo) >= 0 && !Reglas.enSpawn(w, abajo, estado)) {
                        w.setBlockState(abajo, Blocks.MAGMA_BLOCK.getDefaultState());
                    }
                }
            }
        });

        registrar("gravedad_loca", () -> new Desafio("Gravedad loca", 60, 120) {
            public String descripcion() { return "Cada 15 segundos puedes salir volando por los aires"; }
            protected void cadaTick(int t) {
                if (!cada(t, 15)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (random.nextBoolean()) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 40, 1 + random.nextInt(3)));
                    }
                }
            }
        });

        registrar("noche_infernal", () -> new Desafio("Noche infernal", 60, 180) {
            public String descripcion() { return "Se hará de noche y aparecerán mobs con armadura de diamante"; }
            protected void alEmpezar() { server.getOverworld().setTimeOfDay(13000); }
            protected void cadaTick(int t) {
                if (!cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    EntityType<? extends MobEntity> tipo = random.nextBoolean() ? EntityType.ZOMBIE : EntityType.SKELETON;
                    MobEntity m = invocar(tipo, p.getServerWorld(), posCerca(p, 8, 14));
                    if (m != null) {
                        m.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
                        m.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
                        m.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
                        m.equipStack(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
                        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                            m.setEquipmentDropChance(slot, 0f);
                        }
                    }
                }
            }
        });

        registrar("hambre_extrema", () -> new Desafio("Hambre extrema", 30, 120) {
            public String descripcion() { return "La comida bajará 5 veces más rápido"; }
            protected void cadaTick(int t) {
                if (!cada(t, 10)) return;
                for (ServerPlayerEntity p : jugadores()) p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 220, 2));
            }
            protected void limpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) p.removeStatusEffect(StatusEffects.HUNGER);
            }
        });

        registrar("mobs_potenciados", () -> new Desafio("Mobs potenciados", 60, 180) {
            public String descripcion() { return "Zombies y arañas tendrán Fuerza II y Velocidad II"; }
            protected void cadaTick(int t) {
                if (t % 20 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    for (HostileEntity m : p.getServerWorld().getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(48),
                            e -> e instanceof ZombieEntity || e instanceof SpiderEntity)) {
                        m.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 60, 1));
                        m.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 1));
                    }
                }
            }
        });

        registrar("prohibido_saltar", () -> new Desafio("Prohibido saltar", 30, 60) {
            public String descripcion() { return "Cada salto te quitará medio corazón"; }
            protected void alSaltar(ServerPlayerEntity p) {
                p.damage(p.getDamageSources().magic(), 1f);
                accion(p, "¡No saltes!", Formatting.RED);
            }
        });

        registrar("inventario_maldito", () -> new Desafio("Inventario maldito", 60, 60) {
            public String descripcion() { return "Cada 20 segundos se borrará un objeto al azar de tu inventario. ¡Guarda tus cosas en cofres!"; }
            protected void cadaTick(int t) {
                if (t == 0 || !cada(t, 20)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    PlayerInventory inv = p.getInventory();
                    List<Integer> llenos = new ArrayList<>();
                    for (int i = 0; i < inv.size(); i++) if (!inv.getStack(i).isEmpty()) llenos.add(i);
                    if (llenos.isEmpty()) continue;
                    int slot = llenos.get(random.nextInt(llenos.size()));
                    ItemStack s = inv.getStack(slot);
                    accion(p, "Se ha borrado: " + s.getCount() + "x " + s.getName().getString(), Formatting.DARK_RED);
                    inv.setStack(slot, ItemStack.EMPTY);
                }
            }
        });

        registrar("tormenta_rayos", () -> new Desafio("Tormenta de rayos", 60, 60) {
            public String descripcion() { return "Caerá un rayo cerca de cada jugador cada 5 segundos"; }
            protected void cadaTick(int t) {
                if (!cada(t, 5)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    int x = p.getBlockX() + random.nextInt(11) - 5;
                    int z = p.getBlockZ() + random.nextInt(11) - 5;
                    rayo(w, w.getTopPosition(Heightmap.Type.MOTION_BLOCKING, new BlockPos(x, 0, z)));
                }
            }
        });

        registrar("apagon", () -> new Desafio("Apagón", 60, 90) {
            public String descripcion() { return "Todos quedarán ciegos, excepto quien esté bajo la capa 0"; }
            protected void cadaTick(int t) {
                if (t % 10 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (p.getY() >= 0) p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0));
                    else p.removeStatusEffect(StatusEffects.BLINDNESS);
                }
            }
            protected void limpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) p.removeStatusEffect(StatusEffects.BLINDNESS);
            }
        });

        registrar("todo_explota", () -> new TodoExplota(false));
        registrar("todo_explota_suerte", () -> new TodoExplota(true));

        registrar("agua_toxica", () -> new Desafio("Agua tóxica", 30, 120) {
            public String descripcion() { return "Tocar el agua te dará Veneno II"; }
            protected void cadaTick(int t) {
                if (t % 10 != 0) return;
                for (ServerPlayerEntity p : jugadores()) {
                    if (p.isTouchingWater()) p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 60, 1));
                }
            }
        });

        registrar("mareo_total", () -> new Desafio("Mareo total", 30, 90) {
            public String descripcion() { return "Cada 30 segundos tendrás náuseas y lentitud"; }
            protected void cadaTick(int t) {
                if (!cada(t, 30)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 1));
                }
            }
        });

        registrar("mineria_explosiva", () -> new Desafio("Minería explosiva", 60, 120) {
            private final Map<UUID, Integer> minados = new HashMap<>();
            public String descripcion() { return "Cada 20 bloques que mines aparecerá una TNT encendida a tu lado"; }
            protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState estado) {
                int n = minados.merge(p.getUuid(), 1, Integer::sum);
                if (n % 20 == 0) {
                    ServerWorld w = p.getServerWorld();
                    TntEntity tnt = new TntEntity(w, p.getX() + random.nextDouble() * 2 - 1, p.getY(), p.getZ() + random.nextDouble() * 2 - 1, p);
                    tnt.setFuse(60);
                    w.spawnEntity(tnt);
                    accion(p, "¡TNT!", Formatting.RED);
                } else {
                    accion(p, "Próxima TNT en " + (20 - n % 20) + " bloques", Formatting.GOLD);
                }
            }
        });

        registrar("un_corazon", () -> new Desafio("Un solo corazón", 60, 60) {
            public String descripcion() { return "Todos quedaréis con 1 corazón máximo"; }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) {
                    EntityAttributeInstance vida = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                    if (vida == null) continue;
                    vida.removeModifier(UN_CORAZON);
                    vida.addTemporaryModifier(new EntityAttributeModifier(UN_CORAZON, 2.0 - vida.getValue(), EntityAttributeModifier.Operation.ADD_VALUE));
                    if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
                }
            }
            protected void limpiar() {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    EntityAttributeInstance vida = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                    if (vida != null) vida.removeModifier(UN_CORAZON);
                }
            }
        });

        registrar("asedio", () -> new Desafio("Asedio", 60, 180) {
            public String descripcion() { return "Sobrevive a 3 oleadas de mobs que aparecerán a tu alrededor"; }
            protected void cadaTick(int t) {
                if (t != 0 && t != 60 * 20 && t != 120 * 20) return;
                int oleada = t / (60 * 20) + 1;
                for (ServerPlayerEntity p : jugadores()) {
                    titulo(p, net.minecraft.text.Text.literal("Oleada " + oleada + "/3").formatted(Formatting.DARK_RED, Formatting.BOLD), net.minecraft.text.Text.empty());
                    for (int i = 0; i < 3 + oleada; i++) {
                        EntityType<? extends MobEntity> tipo = switch (random.nextInt(3)) {
                            case 0 -> EntityType.ZOMBIE;
                            case 1 -> EntityType.SKELETON;
                            default -> EntityType.SPIDER;
                        };
                        invocar(tipo, p.getServerWorld(), posCerca(p, 5, 9));
                    }
                }
            }
        });

        registrar("agachate", () -> new Desafio("Agáchate", 30, 30) {
            private final Set<UUID> fallados = new HashSet<>();
            public String descripcion() { return "Mantente agachado sin soltar. Quien se levante, explota"; }
            protected void cadaTick(int t) {
                if (t < 20) return; // 1 segundo de margen
                for (ServerPlayerEntity p : jugadores()) {
                    if (!p.isSneaking() && fallados.add(p.getUuid())) {
                        explosion(p.getServerWorld(), p.getX(), p.getY(), p.getZ(), 2f);
                        anunciar(p.getGameProfile().getName() + " se ha levantado...", Formatting.RED);
                    }
                }
            }
        });

        registrar("bloque_prohibido", () -> new BloqueProhibido());

        registrar("garabatos_furiosos", () -> new Desafio("Garabatos furiosos", 60, 90) {
            public String descripcion() {
                return "Aparecerán Garabatos a tu alrededor sin parar y, si te tocan, te mandarán a la capa más alta del mundo aunque tengas techo. Cuidado con la caída";
            }
            protected void alEmpezar() { GarabatoEntity.modoCielo = true; }
            protected void cadaTick(int t) {
                if (!cada(t, 8)) return;
                for (ServerPlayerEntity p : jugadores()) {
                    ServerWorld w = p.getServerWorld();
                    for (int i = 0; i < 2; i++) {
                        double ang = random.nextDouble() * Math.PI * 2;
                        int dist = 8 + random.nextInt(9);
                        BlockPos base = new BlockPos(p.getBlockX() + (int) (Math.cos(ang) * dist), 0, p.getBlockZ() + (int) (Math.sin(ang) * dist));
                        BlockPos pos = w.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, base);
                        if (Math.abs(pos.getY() - p.getBlockY()) > 12) pos = posCerca(p, 6, 12); // en cuevas: cerca de ti
                        GarabatoEntity g = ModEntidades.GARABATO.create(w);
                        if (g == null) continue;
                        g.addCommandTag(Mobs.MARCA_EVENTO);
                        g.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, random.nextFloat() * 360f, 0f);
                        g.setTarget(p);
                        w.spawnEntity(g);
                    }
                }
            }
            protected void limpiar() { GarabatoEntity.modoCielo = false; }
        });

        registrar("no_te_muevas", () -> new Desafio("No te muevas", 30, 60) {
            private final Map<UUID, Vec3d> inicio = new HashMap<>();
            private final Set<UUID> fallados = new HashSet<>();
            public String descripcion() { return "Quien se aleje más de 5 bloques de donde está recibirá un rayo"; }
            protected void cadaTick(int t) {
                for (ServerPlayerEntity p : jugadores()) {
                    Vec3d desde = inicio.computeIfAbsent(p.getUuid(), u -> p.getPos());
                    if (!fallados.contains(p.getUuid()) && p.getPos().distanceTo(desde) > 5) {
                        fallados.add(p.getUuid());
                        rayo(p.getServerWorld(), p.getBlockPos());
                        anunciar(p.getGameProfile().getName() + " se ha movido...", Formatting.RED);
                    }
                }
            }
        });

        // ======================================================================
        //                        DESAFÍOS CON OBJETIVO
        // ======================================================================

        registrar("escalada", () -> new DesafioObjetivo("Escalada rápida", 60, 180) {
            public String descripcion() { return "Llega a la capa 320. Quien falle pierde 5 corazones"; }
            protected boolean cumple(ServerPlayerEntity p) { return p.getY() >= 320; }
            protected void castigo(ServerPlayerEntity p) { p.damage(p.getDamageSources().magic(), 10f); }
        });

        registrar("fondo_mundo", () -> new DesafioObjetivo("Al fondo del mundo", 60, 300) {
            public String descripcion() { return "Llega a la capa -50. Quien falle, explota"; }
            protected boolean cumple(ServerPlayerEntity p) { return p.getY() <= -50; }
            protected void castigo(ServerPlayerEntity p) { explosion(p.getServerWorld(), p.getX(), p.getY(), p.getZ(), 3f); }
        });

        registrar("toca_madera", () -> new DesafioObjetivo("Toca madera", 30, 30) {
            public String descripcion() { return "Golpea o rompe un tronco de árbol. Quien falle pierde 3 corazones"; }
            protected void alGolpearBloque(ServerPlayerEntity p, BlockPos pos, BlockState s) { if (s.isIn(BlockTags.LOGS)) completar(p); }
            protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState s) { if (s.isIn(BlockTags.LOGS)) completar(p); }
            protected void castigo(ServerPlayerEntity p) { p.damage(p.getDamageSources().magic(), 6f); }
        });

        registrar("come_algo", () -> new DesafioObjetivo("Come algo", 60, 45) {
            public String descripcion() { return "Come cualquier comida. Quien falle tendrá Hambre extrema 2 minutos"; }
            protected void alComer(ServerPlayerEntity p) { completar(p); }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 2400, 2)); }
        });

        registrar("a_la_cama", () -> new DesafioObjetivo("A la cama", 60, 120) {
            public String descripcion() { return "Duerme o haz clic en una cama. Quien falle tendrá visita de un phantom"; }
            protected boolean cumple(ServerPlayerEntity p) { return p.isSleeping(); }
            protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) {
                if (s.getBlock() instanceof BedBlock) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { invocar(EntityType.PHANTOM, p.getServerWorld(), encima(p, 4)); }
        });

        registrar("ponte_casco", () -> new DesafioObjetivo("Ponte casco", 60, 120) {
            public String descripcion() { return "Equípate cualquier casco (el de cuero sirve). Quien falle recibirá un yunque en la cabeza"; }
            protected boolean cumple(ServerPlayerEntity p) {
                return p.getEquippedStack(EquipmentSlot.HEAD).getItem() instanceof ArmorItem casco && casco.getSlotType() == EquipmentSlot.HEAD;
            }
            protected void castigo(ServerPlayerEntity p) {
                FallingBlockEntity yunque = FallingBlockEntity.spawnFromBlock(p.getServerWorld(), encima(p, 8), Blocks.ANVIL.getDefaultState());
                yunque.setHurtEntities(2f, 40);
            }
        });

        registrar("cazarrecompensas", () -> new DesafioObjetivo("Cazarrecompensas", 60, 300) {
            private final Map<UUID, Integer> muertes = new HashMap<>();
            public String descripcion() { return "Mata 15 mobs hostiles. Quien falle recibirá una oleada de zombies"; }
            protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) {
                if (!(muerto instanceof Monster) || completado(p)) return;
                int n = muertes.merge(p.getUuid(), 1, Integer::sum);
                accion(p, "Mobs: " + n + "/15", Formatting.GOLD);
                if (n >= 15) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) {
                for (int i = 0; i < 6; i++) invocar(EntityType.ZOMBIE, p.getServerWorld(), posCerca(p, 4, 8));
            }
        });

        registrar("mojate", () -> new DesafioObjetivo("Mójate", 30, 60) {
            public String descripcion() { return "Métete al agua. Quien falle arderá"; }
            protected boolean cumple(ServerPlayerEntity p) { return p.isTouchingWater(); }
            protected void castigo(ServerPlayerEntity p) { p.setOnFireFor(8f); }
        });

        registrar("mira_cielo", () -> new DesafioObjetivo("Mira al cielo", 30, 30) {
            public String descripcion() { return "Ponte en un lugar con el cielo abierto sobre ti. Quien falle recibirá un rayo"; }
            protected boolean cumple(ServerPlayerEntity p) { return p.getServerWorld().isSkyVisible(p.getBlockPos().up()); }
            protected void castigo(ServerPlayerEntity p) { rayo(p.getServerWorld(), p.getBlockPos()); }
        });

        registrar("mata_mob", () -> new DesafioObjetivo("Mata un mob", 60, 60) {
            public String descripcion() { return "Mata cualquier mob, hostil o pacífico. Quien falle tendrá Debilidad 3 minutos"; }
            protected void alMatar(ServerPlayerEntity p, LivingEntity muerto) { if (muerto instanceof MobEntity) completar(p); }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 3600, 0)); }
        });

        registrar("sube_bloque", () -> new DesafioObjetivo("Sube un bloque", 30, 30) {
            private final Map<UUID, Set<BlockPos>> puestos = new HashMap<>();
            public String descripcion() { return "Súbete encima de un bloque que hayas puesto tú. Quien falle tendrá Lentitud 2 minutos"; }
            protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) {
                if (mano.getItem() instanceof BlockItem) {
                    Set<BlockPos> lista = puestos.computeIfAbsent(p.getUuid(), u -> new HashSet<>());
                    lista.add(pos.offset(hit.getSide()).toImmutable());
                    lista.add(pos.toImmutable());
                }
            }
            protected boolean cumple(ServerPlayerEntity p) {
                Set<BlockPos> lista = puestos.get(p.getUuid());
                if (lista == null || !p.isOnGround()) return false;
                BlockPos abajo = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
                return lista.contains(abajo) && !p.getServerWorld().isAir(abajo);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 2400, 1)); }
        });
    }

    // ---------------- Desafíos con más lógica ----------------

    /** Todo explota: interactuar con bloques útiles provoca una pequeña explosión (sin romper bloques). */
    static class TodoExplota extends Desafio {
        private final boolean suerte;

        TodoExplota(boolean suerte) {
            super(suerte ? "Todo explota (a veces)" : "Todo explota", 60, 120);
            this.suerte = suerte;
        }

        public String descripcion() {
            return suerte ? "Cofres, puertas, mesas, hornos y camas pueden explotar al usarlos (1 de cada 3)"
                    : "Cofres, puertas, mesas, hornos y camas explotarán al usarlos";
        }

        protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) {
            if (!interactuable(s) || (suerte && random.nextInt(3) != 0)) return;
            explosion(p.getServerWorld(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1.5f);
        }

        private static boolean interactuable(BlockState s) {
            Block b = s.getBlock();
            return s.hasBlockEntity() || b instanceof DoorBlock || b instanceof TrapdoorBlock || b instanceof FenceGateBlock
                    || b instanceof CraftingTableBlock || b instanceof ButtonBlock || b instanceof LeverBlock
                    || b instanceof AnvilBlock || b instanceof GrindstoneBlock || b instanceof StonecutterBlock
                    || b instanceof LoomBlock || b instanceof CartographyTableBlock || b instanceof NoteBlock
                    || b instanceof RepeaterBlock;
        }
    }

    /** Bloque prohibido: se elige uno al azar y se revela en el aviso. */
    static class BloqueProhibido extends Desafio {
        private static final Block[] BLOQUES = {Blocks.GRASS_BLOCK, Blocks.DIRT, Blocks.STONE, Blocks.COBBLESTONE,
                Blocks.SAND, Blocks.GRAVEL, Blocks.DEEPSLATE, Blocks.OAK_LOG, Blocks.ANDESITE, Blocks.OAK_LEAVES};
        private static final String[] NOMBRES = {"Bloque de hierba", "Tierra", "Piedra", "Roca", "Arena", "Grava",
                "Pizarra profunda", "Tronco de roble", "Andesita", "Hojas de roble"};

        private final Block bloque;
        private final String nombre;
        private final Map<UUID, Integer> espera = new HashMap<>();

        BloqueProhibido() {
            super("Bloque prohibido", 60, 120);
            int i = new Random().nextInt(BLOQUES.length);
            bloque = BLOQUES[i];
            nombre = NOMBRES[i];
        }

        public String descripcion() { return "El bloque prohibido es: " + nombre.toUpperCase() + ". Quien lo toque recibirá daño"; }

        protected void cadaTick(int t) {
            for (ServerPlayerEntity p : jugadores()) {
                ServerWorld w = p.getServerWorld();
                BlockPos pies = p.getBlockPos();
                BlockPos abajo = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
                if (w.getBlockState(abajo).isOf(bloque) || w.getBlockState(pies).isOf(bloque) || w.getBlockState(pies.up()).isOf(bloque)) {
                    castigar(p);
                }
            }
        }

        protected void alRomperBloque(ServerPlayerEntity p, BlockPos pos, BlockState s) { if (s.isOf(bloque)) castigar(p); }
        protected void alGolpearBloque(ServerPlayerEntity p, BlockPos pos, BlockState s) { if (s.isOf(bloque)) castigar(p); }
        protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) { if (s.isOf(bloque)) castigar(p); }

        private void castigar(ServerPlayerEntity p) {
            int ahora = p.getServer().getTicks();
            if (espera.getOrDefault(p.getUuid(), -100) + 20 > ahora) return;
            espera.put(p.getUuid(), ahora);
            p.damage(p.getDamageSources().magic(), 3f);
            accion(p, "¡Has tocado " + nombre + "!", Formatting.RED);
        }
    }

    // ======================================================================
    //                              GESTIÓN
    // ======================================================================

    public static boolean existe(String id) { return TODOS.containsKey(id); }

    public static Desafio lanzar(MinecraftServer server, String id) {
        Desafio d = TODOS.get(id).get();
        d.iniciar(server);
        ACTIVOS.add(d);
        Eventos.mostrarTele(server, "rojo", d.getTitulo(), d.textoTele());
        return d;
    }

    public static int detenerTodos() {
        int n = ACTIVOS.size();
        for (Desafio d : List.copyOf(ACTIVOS)) d.terminar(true);
        ACTIVOS.clear();
        return n;
    }

    private static void paraCada(Consumer<Desafio> accion) {
        for (Desafio d : List.copyOf(ACTIVOS)) if (d.estaEnCurso()) accion.accept(d);
    }

    public static void registrarEventos() {
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> BORDE.remove(h.player.getUuid()));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (Desafio d : List.copyOf(ACTIVOS)) d.tick();
            ACTIVOS.removeIf(Desafio::estaTerminado);

            // Borde rojo: activo mientras haya un desafío que este jugador no haya superado
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                boolean activo = false;
                for (Desafio d : ACTIVOS) if (d.bordeActivo(p)) { activo = true; break; }
                if (!Boolean.valueOf(activo).equals(BORDE.get(p.getUuid()))
                        && net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(p, com.centrodesinformacion.desinformados.network.BordePayload.ID)) {
                    BORDE.put(p.getUuid(), activo);
                    net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.centrodesinformacion.desinformados.network.BordePayload(activo));
                }
            }

            // Detectar saltos y comida
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                int saltos = p.getStatHandler().getStat(Stats.CUSTOM, Stats.JUMP);
                Integer antes = SALTOS.put(p.getUuid(), saltos);
                if (antes != null && saltos > antes) paraCada(d -> d.alSaltar(p));

                float comida = p.getHungerManager().getFoodLevel() + p.getHungerManager().getSaturationLevel();
                Float antesComida = COMIDA.put(p.getUuid(), comida);
                if (antesComida != null && comida > antesComida + 0.01f) paraCada(d -> d.alComer(p));
            }
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (player instanceof ServerPlayerEntity p) paraCada(d -> d.alRomperBloque(p, pos, state));
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direccion) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity p) {
                BlockState s = world.getBlockState(pos);
                paraCada(d -> d.alGolpearBloque(p, pos, s));
            }
            return ActionResult.PASS;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient() && hand == Hand.MAIN_HAND && player instanceof ServerPlayerEntity p) {
                BlockPos pos = hit.getBlockPos();
                BlockState s = world.getBlockState(pos);
                ItemStack mano = player.getStackInHand(hand);
                paraCada(d -> d.alUsarBloque(p, pos, s, hit, mano));
            }
            return ActionResult.PASS;
        });

        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, asesino, muerto) -> {
            if (asesino instanceof ServerPlayerEntity p) paraCada(d -> d.alMatar(p, muerto));
        });
    }
}

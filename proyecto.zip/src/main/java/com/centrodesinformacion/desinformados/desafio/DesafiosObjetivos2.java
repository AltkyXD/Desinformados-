package com.centrodesinformacion.desinformados.desafio;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Tareas;
import net.minecraft.block.AbstractFurnaceBlock;
import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.BambooShootBlock;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.CactusBlock;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.CaveVinesHeadBlock;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.FlowerBlock;
import net.minecraft.block.FungusBlock;
import net.minecraft.block.KelpBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.MushroomPlantBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.SugarCaneBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.TorchBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShovelItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/** 17 desafíos rojos nuevos CON OBJETIVO: conseguir, fabricar, colocar o tener cosas (quien no lo consiga, castigo). */
final class DesafiosObjetivos2 {
    private DesafiosObjetivos2() {}

    // ======================================================================
    //                                LISTAS
    // ======================================================================

    /** Lo que sale de un horno/ahumador/horno de fundición (y casi nunca de una mesa de crafteo). */
    private static final Item[] FUNDIDOS = {
            Items.STONE, Items.SMOOTH_STONE, Items.GLASS, Items.CHARCOAL, Items.BRICK, Items.NETHER_BRICK,
            Items.COOKED_BEEF, Items.COOKED_PORKCHOP, Items.COOKED_CHICKEN, Items.COOKED_MUTTON, Items.COOKED_RABBIT,
            Items.COOKED_COD, Items.COOKED_SALMON, Items.BAKED_POTATO, Items.DEEPSLATE, Items.TERRACOTTA, Items.GREEN_DYE,
            Items.SMOOTH_SANDSTONE, Items.SMOOTH_RED_SANDSTONE, Items.SMOOTH_QUARTZ, Items.SMOOTH_BASALT,
            Items.CRACKED_STONE_BRICKS, Items.CRACKED_DEEPSLATE_BRICKS, Items.CRACKED_DEEPSLATE_TILES,
            Items.CRACKED_NETHER_BRICKS, Items.CRACKED_POLISHED_BLACKSTONE_BRICKS, Items.POPPED_CHORUS_FRUIT, Items.SPONGE,
            Items.IRON_INGOT, Items.GOLD_INGOT, Items.COPPER_INGOT, Items.NETHERITE_SCRAP, Items.QUARTZ};

    /** Piedra de cualquier tipo (también la del Nether y el End). */
    private static final Item[] PIEDRAS = {
            Items.COBBLESTONE, Items.COBBLED_DEEPSLATE, Items.STONE, Items.DEEPSLATE, Items.ANDESITE, Items.DIORITE,
            Items.GRANITE, Items.TUFF, Items.CALCITE, Items.BLACKSTONE, Items.NETHERRACK, Items.BASALT, Items.END_STONE,
            Items.SANDSTONE, Items.RED_SANDSTONE, Items.DRIPSTONE_BLOCK, Items.MOSSY_COBBLESTONE};

    /** Minerales sueltos (y las menas, por si alguien pica con toque de seda). */
    private static final Item[] MINERALES = {
            Items.COAL, Items.RAW_IRON, Items.RAW_COPPER, Items.RAW_GOLD, Items.LAPIS_LAZULI, Items.REDSTONE,
            Items.DIAMOND, Items.EMERALD, Items.QUARTZ, Items.GOLD_NUGGET, Items.ANCIENT_DEBRIS,
            Items.COAL_ORE, Items.DEEPSLATE_COAL_ORE, Items.IRON_ORE, Items.DEEPSLATE_IRON_ORE, Items.COPPER_ORE,
            Items.DEEPSLATE_COPPER_ORE, Items.GOLD_ORE, Items.DEEPSLATE_GOLD_ORE, Items.NETHER_GOLD_ORE,
            Items.NETHER_QUARTZ_ORE, Items.LAPIS_ORE, Items.DEEPSLATE_LAPIS_ORE, Items.REDSTONE_ORE,
            Items.DEEPSLATE_REDSTONE_ORE, Items.DIAMOND_ORE, Items.DEEPSLATE_DIAMOND_ORE, Items.EMERALD_ORE,
            Items.DEEPSLATE_EMERALD_ORE};

    private static final Item[] CUBOS_LLENOS = {
            Items.WATER_BUCKET, Items.LAVA_BUCKET, Items.MILK_BUCKET, Items.POWDER_SNOW_BUCKET, Items.COD_BUCKET,
            Items.SALMON_BUCKET, Items.PUFFERFISH_BUCKET, Items.TROPICAL_FISH_BUCKET, Items.AXOLOTL_BUCKET, Items.TADPOLE_BUCKET};

    /** Pedidos sencillos, solo con madera (también la del Nether). */
    private static final Item[][] PEDIDOS = {
            {Items.STICK},
            {Items.OAK_PLANKS, Items.SPRUCE_PLANKS, Items.BIRCH_PLANKS, Items.JUNGLE_PLANKS, Items.ACACIA_PLANKS, Items.DARK_OAK_PLANKS,
                    Items.MANGROVE_PLANKS, Items.CHERRY_PLANKS, Items.BAMBOO_PLANKS, Items.CRIMSON_PLANKS, Items.WARPED_PLANKS},
            {Items.BOWL},
            {Items.OAK_BUTTON, Items.SPRUCE_BUTTON, Items.BIRCH_BUTTON, Items.JUNGLE_BUTTON, Items.ACACIA_BUTTON, Items.DARK_OAK_BUTTON,
                    Items.MANGROVE_BUTTON, Items.CHERRY_BUTTON, Items.BAMBOO_BUTTON, Items.CRIMSON_BUTTON, Items.WARPED_BUTTON},
            {Items.OAK_PRESSURE_PLATE, Items.SPRUCE_PRESSURE_PLATE, Items.BIRCH_PRESSURE_PLATE, Items.JUNGLE_PRESSURE_PLATE,
                    Items.ACACIA_PRESSURE_PLATE, Items.DARK_OAK_PRESSURE_PLATE, Items.MANGROVE_PRESSURE_PLATE, Items.CHERRY_PRESSURE_PLATE,
                    Items.BAMBOO_PRESSURE_PLATE, Items.CRIMSON_PRESSURE_PLATE, Items.WARPED_PRESSURE_PLATE},
            {Items.CHEST}};
    private static final String[] NOMBRES_PEDIDOS = {"PALOS", "TABLONES DE MADERA (de cualquier tipo)", "UN CUENCO",
            "UN BOTÓN DE MADERA", "UNA PLACA DE PRESIÓN DE MADERA", "UN COFRE"};

    /** Lo que hay que tener en la mano para la foto de grupo (ver valeParaFoto). */
    private static final String[] FOTO = {"UN PALO", "UNA ANTORCHA", "UNA MESA DE CRAFTEO", "COMIDA (la que sea)",
            "UNA PALA (la que sea)", "UN BLOQUE DE PIEDRA (roca, piedra, pizarra profunda, piedra negra o netherrack)"};
    private static final Item[] PIEDRAS_FOTO = {Items.COBBLESTONE, Items.STONE, Items.COBBLED_DEEPSLATE, Items.DEEPSLATE,
            Items.BLACKSTONE, Items.NETHERRACK};

    // ======================================================================
    //                          LOS 17 DESAFÍOS
    // ======================================================================

    static void registrarTodos() {
        // ------------------------------ FABRICAR ------------------------------

        Desafios.registrar("fabrica_mesa", () -> new Contador("¡Fabrica una mesa!", 90, 1, "Mesas") {
            public String descripcion() {
                return "Fabrica una mesa de crafteo (las que ya lleves encima no cuentan). Quien falle tendrá Fatiga minera II 1 minuto";
            }
            protected int valor(ServerPlayerEntity p) { return fabricados(p, Items.CRAFTING_TABLE); }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 1200, 1)); }
        });

        Desafios.registrar("kit_de_piedra", () -> new DesafioObjetivo("Kit de piedra", 10, 180) {
            private final Item[] kit = {Items.STONE_PICKAXE, Items.STONE_AXE, Items.STONE_SHOVEL, Items.STONE_SWORD};
            private final Map<UUID, int[]> base = new HashMap<>();
            private final Map<UUID, Integer> visto = new HashMap<>();
            public String descripcion() {
                return "Fabrica un pico, un hacha, una pala y una espada de piedra (vale roca, pizarra profunda o piedra negra). Quien falle tendrá Debilidad 2 minutos";
            }
            private int[] foto(ServerPlayerEntity p) {
                int[] v = new int[kit.length];
                for (int k = 0; k < kit.length; k++) v[k] = p.getStatHandler().getStat(Stats.CRAFTED, kit[k]);
                return v;
            }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) base.put(p.getUuid(), foto(p));
            }
            protected boolean cumple(ServerPlayerEntity p) {
                int[] b = base.computeIfAbsent(p.getUuid(), u -> foto(p));
                int[] v = foto(p);
                int hechas = 0;
                for (int k = 0; k < kit.length; k++) if (v[k] > b[k]) hechas++;
                Integer antes = visto.put(p.getUuid(), hechas);
                if (hechas > 0 && (antes == null || antes != hechas)) accion(p, "Herramientas de piedra: " + hechas + "/" + kit.length, Formatting.GOLD);
                return hechas >= kit.length;
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 2400, 0)); }
            protected void limpiar() { base.clear(); visto.clear(); }
        });

        Desafios.registrar("pedido_urgente", () -> new Contador("Pedido urgente", 150, 1, "Pedido") {
            private final int elegido = random.nextInt(PEDIDOS.length);
            public String descripcion() {
                return "Pedido urgente del Centro (para ayer): fabrica " + NOMBRES_PEDIDOS[elegido]
                        + " (lo que ya lleves encima no cuenta). Quien falle recibirá a 2 zombis repartidores muy enfadados";
            }
            protected int valor(ServerPlayerEntity p) { return fabricados(p, PEDIDOS[elegido]); }
            protected void castigo(ServerPlayerEntity p) {
                for (int k = 0; k < 2; k++) soltar(EntityType.ZOMBIE, p.getServerWorld(), posCerca(p, 3, 6), "Repartidor enfadado");
            }
        });

        // ------------------------------ FUNDIR ------------------------------

        Desafios.registrar("al_horno", () -> new Contador("¡Al horno!", 480, 3, "Sacado del horno") {
            public String descripcion() {
                return "Saca 3 cosas fundidas o cocinadas de un horno, ahumador u horno de fundición (piedra, cristal, carbón vegetal, lingotes, carne...). "
                        + "Quien falle se quedará con el hambre a 3 muslos como mucho";
            }
            protected int valor(ServerPlayerEntity p) { return fabricados(p, FUNDIDOS); }
            protected void castigo(ServerPlayerEntity p) {
                p.getHungerManager().setFoodLevel(Math.min(p.getHungerManager().getFoodLevel(), 6));
                p.getHungerManager().setSaturationLevel(0f);
                accion(p, "Se te ha quemado la comida", Formatting.RED);
            }
        });

        // ------------------------------ COLOCAR ------------------------------

        Desafios.registrar("hagase_la_luz", () -> new Colocar("Hágase la luz", 120) {
            public String descripcion() {
                return "Coloca 8 antorchas (normales o de almas) o farolillos, y que sigan puestas (poner y quitar la misma no vale). "
                        + "Quien falle tendrá Oscuridad 1 minuto";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (esLuz(s)) progreso(p, vigentes(p, DesafiosObjetivos2::esLuz), 8, "Luces");
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 1200, 0)); }
        });

        Desafios.registrar("jardineria", () -> new Colocar("Jardinería exprés", 120) {
            public String descripcion() {
                return "Planta algo: un brote, semillas, patatas, zanahorias, bayas, una flor, un champiñón, un hongo del Nether, verrugas, "
                        + "caña de azúcar, un cactus o algas. Quien falle tendrá Veneno 15 segundos por alergia (no mata)";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (esPlanta(s.getBlock())) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 300, 0)); }
        });

        Desafios.registrar("obras_express", () -> new Colocar("Obras exprés", 90) {
            public String descripcion() {
                return "Coloca 40 bloques, los que sean, y que sigan puestos (poner y quitar el mismo no vale). "
                        + "Quien falle tendrá Lentitud II 1 minuto y medio";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                progreso(p, vigentes(p, estado -> !estado.isAir()), 40, "Bloques");
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1800, 1)); }
        });

        Desafios.registrar("muro_contencion", () -> new Colocar("Muro de contención", 120) {
            public String descripcion() {
                return "Construye un muro de 3x3 en vertical (3 de ancho y 3 de alto) con bloques puestos por ti. "
                        + "Quien falle perderá 3 corazones (nunca el último)";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (completado(p)) return;
                ServerWorld w = p.getServerWorld();
                // el mejor cuadrado de 3x3 vertical (de norte a sur o de este a oeste) que contiene este bloque
                int mejor = 0;
                for (int eje = 0; eje < 2; eje++) {
                    for (int a = -2; a <= 0; a++) {
                        for (int b = -2; b <= 0; b++) {
                            int llenos = 0;
                            for (int i = 0; i < 3; i++) {
                                for (int j = 0; j < 3; j++) {
                                    BlockPos q = eje == 0 ? pos.add(a + i, b + j, 0) : pos.add(0, b + j, a + i);
                                    if (mio(p, q) && !w.isAir(q)) llenos++;
                                }
                            }
                            mejor = Math.max(mejor, llenos);
                        }
                    }
                }
                accion(p, "Muro: " + mejor + "/9", Formatting.GOLD);
                if (mejor >= 9) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { quitarVida(p, 6f); }
        });

        Desafios.registrar("timbre", () -> new Colocar("Llama al timbre", 120) {
            public String descripcion() {
                return "Coloca un botón y púlsalo. Quien falle recibirá la visita de 4 lepismas";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (s.getBlock() instanceof ButtonBlock && !completado(p)) accion(p, "¡Ahora púlsalo!", Formatting.GOLD);
            }
            protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) {
                super.alUsarBloque(p, pos, s, hit, mano);
                if (!(s.getBlock() instanceof ButtonBlock) || !mio(p, pos)) return;
                ServerWorld w = p.getServerWorld();
                BlockPos boton = pos.toImmutable();
                // se mira un tick después si de verdad se ha pulsado (agachado con algo en la mano no se pulsa)
                Tareas.programar(1, () -> {
                    BlockState ahora = w.getBlockState(boton);
                    if (ahora.getBlock() instanceof ButtonBlock && ahora.get(Properties.POWERED)) completar(p);
                });
            }
            protected void castigo(ServerPlayerEntity p) {
                for (int k = 0; k < 4; k++) soltar(EntityType.SILVERFISH, p.getServerWorld(), posCerca(p, 2, 5), null);
            }
        });

        Desafios.registrar("firma_aqui", () -> new Colocar("Firma aquí", 120) {
            public String descripcion() {
                return "Coloca un cartel (de pie, en la pared o colgante). Quien falle tendrá Hambre III 1 minuto: la burocracia da mucha hambre";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (s.getBlock() instanceof AbstractSignBlock) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 1200, 2)); }
        });

        Desafios.registrar("hoguera", () -> new Colocar("Hoguera de campamento", 180) {
            public String descripcion() {
                return "Coloca una hoguera (normal o de almas). Quien falle pasará frío: Lentitud y Fatiga minera 1 minuto";
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (s.getBlock() instanceof CampfireBlock) completar(p);
            }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 1200, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 1200, 0));
            }
        });

        Desafios.registrar("base_expres", () -> new Colocar("Base exprés", 150) {
            public String descripcion() {
                return "Monta una base: coloca una mesa de crafteo, un horno (vale ahumador u horno de fundición) y un cofre (o barril), "
                        + "a 3 bloques o menos unos de otros. Quien falle recibirá la visita de 2 esqueletos";
            }
            /** 0 = mesa, 1 = horno, 2 = cofre; -1 = otra cosa. */
            private int tipo(BlockState s) {
                if (s.isOf(Blocks.CRAFTING_TABLE)) return 0;
                if (s.getBlock() instanceof AbstractFurnaceBlock) return 1;
                if (s.getBlock() instanceof ChestBlock || s.getBlock() instanceof BarrelBlock) return 2;
                return -1;
            }
            private boolean cerca(BlockPos a, BlockPos b) {
                return Math.abs(a.getX() - b.getX()) <= 3 && Math.abs(a.getY() - b.getY()) <= 3 && Math.abs(a.getZ() - b.getZ()) <= 3;
            }
            protected void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState s) {
                if (completado(p) || tipo(s) < 0) return;
                ServerWorld w = p.getServerWorld();
                List<BlockPos> mesas = new ArrayList<>();
                List<BlockPos> hornos = new ArrayList<>();
                List<BlockPos> cofres = new ArrayList<>();
                for (BlockPos q : misBloques(p)) {   // solo los que siguen en su sitio
                    int t = tipo(w.getBlockState(q));
                    if (t == 0) mesas.add(q);
                    else if (t == 1) hornos.add(q);
                    else if (t == 2) cofres.add(q);
                }
                for (BlockPos m : mesas) {
                    for (BlockPos h : hornos) {
                        for (BlockPos c : cofres) {
                            if (cerca(m, h) && cerca(m, c) && cerca(h, c)) {
                                completar(p);
                                return;
                            }
                        }
                    }
                }
                int partes = (mesas.isEmpty() ? 0 : 1) + (hornos.isEmpty() ? 0 : 1) + (cofres.isEmpty() ? 0 : 1);
                accion(p, "Base: " + partes + "/3 (mesa, horno y cofre juntos)", Formatting.GOLD);
            }
            protected void castigo(ServerPlayerEntity p) {
                for (int k = 0; k < 2; k++) soltar(EntityType.SKELETON, p.getServerWorld(), posCerca(p, 4, 8), null);
            }
        });

        // ------------------------------ CONSEGUIR ------------------------------

        Desafios.registrar("cantera", () -> new Contador("Cantera", 150, 64, "Piedra") {
            public String descripcion() {
                return "Recoge 64 bloques de piedra de cualquier tipo (roca, piedra, pizarra profunda, andesita, granito, diorita, toba, piedra negra, "
                        + "netherrack, arenisca...). Tirarlos y volverlos a coger no cuenta. Quien falle tendrá Fatiga minera III 45 segundos";
            }
            protected int valor(ServerPlayerEntity p) { return recogidos(p, PIEDRAS); }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 900, 2)); }
        });

        Desafios.registrar("fiebre_mineral", () -> new Contador("Fiebre del mineral", 240, 1, "Minerales") {
            public String descripcion() {
                return "Pica y recoge cualquier mineral: carbón, hierro, cobre u oro en bruto, lapislázuli, redstone, diamante, esmeralda, "
                        + "cuarzo o pepitas de oro del Nether. Quien falle tendrá Hambre III y Fatiga minera 1 minuto";
            }
            protected int valor(ServerPlayerEntity p) { return recogidos(p, MINERALES); }
            protected void castigo(ServerPlayerEntity p) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 1200, 2));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 1200, 0));
            }
        });

        Desafios.registrar("llena_cubo", () -> new DesafioObjetivo("Llena el cubo", 10, 150) {
            /** Por jugador: {cubos y frascos llenados (estadística), cubos llenos en el inventario}. */
            private final Map<UUID, int[]> base = new HashMap<>();
            public String descripcion() {
                return "Llena un cubo (de agua, lava, nieve en polvo, leche o con un pez) o un frasco de agua. Quien falle tendrá Lentitud III 30 segundos";
            }
            private int[] foto(ServerPlayerEntity p) {
                int llenados = p.getStatHandler().getStat(Stats.USED, Items.BUCKET) + p.getStatHandler().getStat(Stats.USED, Items.GLASS_BOTTLE);
                int llenos = 0;
                for (Item cubo : CUBOS_LLENOS) llenos += p.getInventory().count(cubo);
                return new int[]{llenados, llenos};
            }
            protected void alEmpezar() {
                for (ServerPlayerEntity p : jugadores()) base.put(p.getUuid(), foto(p));
            }
            protected boolean cumple(ServerPlayerEntity p) {
                int[] b = base.computeIfAbsent(p.getUuid(), u -> foto(p));
                if (server.getTicks() % 5 != 0) return false;
                int[] v = foto(p);
                // la leche y los peces no suben la estadística: por eso también se mira si tiene más cubos llenos que al empezar
                return v[0] > b[0] || v[1] > b[1];
            }
            protected void castigo(ServerPlayerEntity p) { p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 600, 2)); }
            protected void limpiar() { base.clear(); }
        });

        // ------------------------------ TENER ------------------------------

        Desafios.registrar("manos_vacias", () -> new DesafioObjetivo("¡Manos vacías!", 10, 30) {
            public String descripcion() {
                return "Deja vacías a la vez las 9 casillas de tu barra rápida y la mano izquierda (guárdalo en el inventario o en un cofre). "
                        + "A quien falle se le desordenará todo el inventario (sin perder nada)";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                PlayerInventory inv = p.getInventory();
                for (int k = 0; k < 9; k++) if (!inv.getStack(k).isEmpty()) return false;
                return p.getOffHandStack().isEmpty();
            }
            protected void castigo(ServerPlayerEntity p) {
                desordenar(p, random);
                accion(p, "¡Se te ha desordenado el inventario!", Formatting.RED);
            }
        });

        Desafios.registrar("pila_exacta", () -> new DesafioObjetivo("Cuenta bien", 10, 45) {
            private final int n = numeroRaro(random);
            public String descripcion() {
                return "Pon en la PRIMERA casilla de tu barra rápida una pila de exactamente " + n + " objetos (de lo que sea). "
                        + "Quien falle perderá medio corazón por cada objeto de diferencia (como mucho 5 corazones, nunca el último)";
            }
            protected boolean cumple(ServerPlayerEntity p) {
                ItemStack s = p.getInventory().getStack(0);
                return !s.isEmpty() && s.getCount() == n;
            }
            protected void castigo(ServerPlayerEntity p) {
                ItemStack s = p.getInventory().getStack(0);
                int dif = s.isEmpty() ? n : Math.abs(s.getCount() - n);
                accion(p, "Te has equivocado por " + dif, Formatting.RED);
                quitarVida(p, Math.min(10, Math.max(1, dif)));
            }
        });

    }

    // ======================================================================
    //                             HERRAMIENTAS
    // ======================================================================

    /** Cuenta cuánto sube un valor (estadísticas del juego) desde que empieza el desafío: lo de antes no vale. */
    private abstract static class Contador extends DesafioObjetivo {
        private final Map<UUID, Integer> base = new HashMap<>();
        private final Map<UUID, Integer> visto = new HashMap<>();
        private final int meta;
        private final String etiqueta;

        Contador(String titulo, int duracion, int meta, String etiqueta) {
            super(titulo, 10, duracion);
            this.meta = meta;
            this.etiqueta = etiqueta;
        }

        /** Valor total (de siempre); el desafío cuenta lo que sube a partir del inicio. */
        protected abstract int valor(ServerPlayerEntity p);

        @Override
        protected void alEmpezar() {
            for (ServerPlayerEntity p : jugadores()) base.put(p.getUuid(), valor(p));
        }

        @Override
        protected boolean cumple(ServerPlayerEntity p) {
            int v = valor(p);
            Integer b = base.get(p.getUuid());
            if (b == null) {                    // ha entrado con el desafío ya empezado: cuenta desde ahora
                base.put(p.getUuid(), v);
                return false;
            }
            int hecho = Math.max(0, v - b);
            Integer antes = visto.put(p.getUuid(), hecho);
            if (meta > 1 && hecho > 0 && (antes == null || antes != hecho)) {
                accion(p, etiqueta + ": " + Math.min(hecho, meta) + "/" + meta, Formatting.GOLD);
            }
            return hecho >= meta;
        }

        @Override
        protected void limpiar() {
            base.clear();
            visto.clear();
        }
    }

    /**
     * Detecta los bloques que pone cada jugador: al usar un bloque con un objeto de bloque en la mano,
     * un tick después se mira si ha aparecido ese bloque donde se hizo clic o al lado.
     */
    private abstract static class Colocar extends DesafioObjetivo {
        /** Bloques puestos por cada jugador durante el desafío (en la dimensión de "mundos"). */
        private final Map<UUID, Set<BlockPos>> puestos = new HashMap<>();
        /** Dimensión donde ha puesto esos bloques: si se cambia de dimensión y pone otro, empieza de cero. */
        private final Map<UUID, RegistryKey<World>> mundos = new HashMap<>();

        Colocar(String titulo, int duracion) {
            super(titulo, 10, duracion);
        }

        /** El jugador acaba de poner este bloque (ya está en el mundo). */
        protected abstract void alColocar(ServerPlayerEntity p, BlockPos pos, BlockState estado);

        @Override
        protected void alUsarBloque(ServerPlayerEntity p, BlockPos pos, BlockState s, BlockHitResult hit, ItemStack mano) {
            if (!(mano.getItem() instanceof BlockItem bi)) return;
            // se copia ahora: si era el último, un tick después la mano ya está vacía
            Item item = mano.getItem();
            Block bloque = bi.getBlock();
            ServerWorld w = p.getServerWorld();
            BlockPos aqui = pos.toImmutable();
            BlockPos lado = pos.offset(hit.getSide()).toImmutable();
            BlockState antesLado = w.getBlockState(lado);
            Tareas.programar(1, () -> {
                if (!estaEnCurso()) return;
                BlockState ahoraAqui = w.getBlockState(aqui);
                if (ahoraAqui != s && esDe(ahoraAqui, bloque, item)) {
                    apuntar(p, w, aqui, ahoraAqui);
                    return;
                }
                BlockState ahoraLado = w.getBlockState(lado);
                if (ahoraLado != antesLado && esDe(ahoraLado, bloque, item)) apuntar(p, w, lado, ahoraLado);
            });
        }

        private void apuntar(ServerPlayerEntity p, ServerWorld w, BlockPos pos, BlockState estado) {
            UUID id = p.getUuid();
            RegistryKey<World> antes = mundos.put(id, w.getRegistryKey());
            if (antes == null || !antes.equals(w.getRegistryKey())) puestos.remove(id);
            puestos.computeIfAbsent(id, u -> new HashSet<>()).add(pos);
            alColocar(p, pos, estado);
        }

        /** Las antorchas de pared, carteles de pared, semillas... son otro bloque, pero su objeto es el mismo. */
        private static boolean esDe(BlockState s, Block bloque, Item item) {
            return s.isOf(bloque) || s.getBlock().asItem() == item;
        }

        /** ¿Este bloque lo ha puesto este jugador durante el desafío (en la dimensión donde está ahora)? */
        protected boolean mio(ServerPlayerEntity p, BlockPos pos) {
            Set<BlockPos> set = puestos.get(p.getUuid());
            return set != null && set.contains(pos) && p.getServerWorld().getRegistryKey().equals(mundos.get(p.getUuid()));
        }

        /** Los bloques que ha puesto en la dimensión donde está ahora y con el chunk cargado (nunca se cargan chunks). */
        protected List<BlockPos> misBloques(ServerPlayerEntity p) {
            List<BlockPos> lista = new ArrayList<>();
            Set<BlockPos> set = puestos.get(p.getUuid());
            ServerWorld w = p.getServerWorld();
            if (set == null || !w.getRegistryKey().equals(mundos.get(p.getUuid()))) return lista;
            for (BlockPos q : set) if (w.isChunkLoaded(q)) lista.add(q);
            return lista;
        }

        /** Cuántos de los bloques que ha puesto siguen en su sitio y valen (poner y quitar el mismo no suma). */
        protected int vigentes(ServerPlayerEntity p, Predicate<BlockState> vale) {
            ServerWorld w = p.getServerWorld();
            int n = 0;
            for (BlockPos q : misBloques(p)) if (vale.test(w.getBlockState(q))) n++;
            return n;
        }

        /** Enseña el progreso y completa al llegar a la meta. */
        protected void progreso(ServerPlayerEntity p, int n, int meta, String etiqueta) {
            if (completado(p)) return;
            accion(p, etiqueta + ": " + Math.min(n, meta) + "/" + meta, Formatting.GOLD);
            if (n >= meta) completar(p);
        }

        @Override
        protected void limpiar() {
            puestos.clear();
            mundos.clear();
        }
    }

    private static int fabricados(ServerPlayerEntity p, Item... items) {
        int n = 0;
        for (Item item : items) n += p.getStatHandler().getStat(Stats.CRAFTED, item);
        return n;
    }

    /** Recogidos del suelo menos los que ha tirado él mismo (tirar y volver a coger no cuenta). */
    private static int recogidos(ServerPlayerEntity p, Item... items) {
        int n = 0;
        for (Item item : items) {
            n += p.getStatHandler().getStat(Stats.PICKED_UP, item) - p.getStatHandler().getStat(Stats.DROPPED, item);
        }
        return n;
    }

    private static boolean esLuz(BlockState s) {
        return s.getBlock() instanceof TorchBlock || s.getBlock() instanceof LanternBlock;
    }

    private static boolean esPlanta(Block b) {
        return b instanceof PlantBlock || b instanceof CropBlock || b instanceof SaplingBlock || b instanceof FlowerBlock
                || b instanceof MushroomPlantBlock || b instanceof FungusBlock || b instanceof SweetBerryBushBlock
                || b instanceof NetherWartBlock || b instanceof CocoaBlock || b instanceof SugarCaneBlock || b instanceof CactusBlock
                || b instanceof BambooShootBlock || b instanceof BambooBlock || b instanceof KelpBlock || b instanceof CaveVinesHeadBlock;
    }

    private static boolean valeParaFoto(int elegido, ItemStack s) {
        if (s.isEmpty()) return false;
        return switch (elegido) {
            case 0 -> s.isOf(Items.STICK);
            case 1 -> s.isOf(Items.TORCH) || s.isOf(Items.SOUL_TORCH);
            case 2 -> s.isOf(Items.CRAFTING_TABLE);
            case 3 -> s.getItem().getComponents().contains(DataComponentTypes.FOOD);
            case 4 -> s.getItem() instanceof ShovelItem;
            default -> esUnoDe(s, PIEDRAS_FOTO);
        };
    }

    private static boolean esUnoDe(ItemStack s, Item[] items) {
        for (Item item : items) if (s.isOf(item)) return true;
        return false;
    }

    /** Entre 13 y 61, sin los números "fáciles" de pila (16, 32, 48). */
    private static int numeroRaro(Random r) {
        int n = 13 + r.nextInt(49);
        return (n == 16 || n == 32 || n == 48) ? n + 1 : n;
    }

    /** Quita vida sin matar nunca: como mucho deja al jugador con medio corazón. */
    private static void quitarVida(ServerPlayerEntity p, float cantidad) {
        float vida = p.getHealth();
        float nueva = Math.max(1f, vida - cantidad);
        if (nueva >= vida) return;
        p.setHealth(nueva);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1f, 1f);
    }

    /** Mezcla las 36 casillas del inventario principal (barra rápida incluida). No se pierde nada. */
    private static void desordenar(ServerPlayerEntity p, Random r) {
        PlayerInventory inv = p.getInventory();
        List<ItemStack> cosas = new ArrayList<>();
        for (int k = 0; k < 36; k++) cosas.add(inv.getStack(k));
        Collections.shuffle(cosas, r);
        for (int k = 0; k < 36; k++) inv.setStack(k, cosas.get(k));
    }

    /** Mob de castigo; la marca va antes de entrar al mundo para que exista aunque su tipo esté bloqueado. */
    private static <T extends MobEntity> void soltar(EntityType<T> tipo, ServerWorld w, BlockPos pos, String nombre) {
        tipo.spawn(w, m -> {
            m.addCommandTag(Mobs.MARCA_EVENTO);
            if (nombre != null) m.setCustomName(Text.literal(nombre));
        }, pos, SpawnReason.EVENT, false, false);
    }
}

package com.centrodesinformacion.desinformados.intro;

import com.centrodesinformacion.desinformados.network.FinalFinPayload;
import com.centrodesinformacion.desinformados.network.FinalPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Final del desafío: al usar el Orbe de Estática (lo suelta La Desinformación al morir) TODOS ven la cinemática final:
 * El Gato se despide, la señal se rompe, pantalla negra, el título y los créditos.
 * Al terminar, cada jugador vuelve a su hogar (su cama, o el spawn del mundo si no tiene).
 */
public final class Final {
    private static final Set<UUID> VIENDO = new HashSet<>();
    /** Marca (en EstadoServidor) de que la serie ya terminó: morir ya no tiene consecuencias. */
    public static final String SERIE_TERMINADA = "sys:serie_terminada";
    private static final String TITULO_FINAL = "La serie acabó";
    private static final String MENSAJE_FINAL = "Ya pueden morir sin miedo. El casino y las dificultades siguen igual, "
            + "así que tomen esto como un mundo diferente. Espero que les haya gustado.";

    public static boolean serieTerminada(MinecraftServer server) {
        return com.centrodesinformacion.desinformados.EstadoServidor.get(server).tieneCambio(SERIE_TERMINADA);
    }

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(FinalFinPayload.ID, (paquete, ctx) -> ctx.server().execute(() -> terminar(ctx.player())));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> VIENDO.remove(handler.player.getUuid()));
    }

    public static boolean enCurso() {
        return !VIENDO.isEmpty();
    }

    /** Empieza la cinemática final para todos los que estén conectados. */
    public static boolean empezar(MinecraftServer server) {
        if (enCurso()) return false;
        // la serie se acaba: a partir de ahora morir ya no cuesta vidas, y los eliminados pueden volver
        com.centrodesinformacion.desinformados.EstadoServidor estado = com.centrodesinformacion.desinformados.EstadoServidor.get(server);
        estado.agregarCambio(SERIE_TERMINADA);
        for (UUID muerto : new ArrayList<>(estado.getMuertos().keySet())) {
            estado.quitarMuerto(muerto);
            estado.setVidas(muerto, 1);
            estado.marcarRestaurar(muerto, true);
            ServerPlayerEntity enLinea = server.getPlayerManager().getPlayer(muerto);
            if (enLinea != null) com.centrodesinformacion.desinformados.Reglas.restaurar(enLinea);
        }
        List<ServerPlayerEntity> todos = new ArrayList<>(server.getPlayerManager().getPlayerList());
        List<String> nombres = new ArrayList<>();
        for (ServerPlayerEntity p : todos) nombres.add(p.getGameProfile().getName());
        FinalPayload paquete = new FinalPayload(String.join(",", nombres));
        for (ServerPlayerEntity p : todos) {
            VIENDO.add(p.getUuid());
            // que nada les haga daño mientras ven el final
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 60 * 5, 4, false, false, false));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 20 * 60 * 5, 0, false, false, false));
            if (ServerPlayNetworking.canSend(p, FinalPayload.ID)) ServerPlayNetworking.send(p, paquete);
            else terminar(p);
        }
        return true;
    }

    static void terminar(ServerPlayerEntity p) {
        if (!VIENDO.remove(p.getUuid())) return;
        p.removeStatusEffect(StatusEffects.RESISTANCE);
        p.removeStatusEffect(StatusEffects.FIRE_RESISTANCE);
        aCasa(p);
        // El último mensaje: una TELE VERDE (cuando ya se ha ido el negro), y luego queda escrito en el chat como los demás anuncios
        MinecraftServer server = p.getServer();
        UUID id = p.getUuid();
        if (server == null) return;
        com.centrodesinformacion.desinformados.Tareas.programar(70, () -> {
            ServerPlayerEntity ahora = server.getPlayerManager().getPlayer(id);
            if (ahora == null) return;
            if (ServerPlayNetworking.canSend(ahora, com.centrodesinformacion.desinformados.network.EventoTvPayload.ID))
                ServerPlayNetworking.send(ahora, new com.centrodesinformacion.desinformados.network.EventoTvPayload("verde", TITULO_FINAL, MENSAJE_FINAL));
            com.centrodesinformacion.desinformados.Tareas.programar(172, () -> {
                ServerPlayerEntity luego = server.getPlayerManager().getPlayer(id);
                if (luego == null) return;
                luego.sendMessage(Text.literal("━━━━━━━━━━━━━━━━━━━━━━━━").formatted(Formatting.GREEN), false);
                luego.sendMessage(Text.literal("[ANUNCIO] ").formatted(Formatting.GREEN, Formatting.BOLD)
                        .append(Text.literal(TITULO_FINAL).formatted(Formatting.GREEN)), false);
                luego.sendMessage(Text.literal(MENSAJE_FINAL).formatted(Formatting.GREEN), false);
                luego.sendMessage(Text.literal("━━━━━━━━━━━━━━━━━━━━━━━━").formatted(Formatting.GREEN), false);
            });
        });
    }

    /** Vuelve a su hogar: su cama (si tiene) o el spawn del mundo. */
    private static void aCasa(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        BlockPos cama = p.getSpawnPointPosition();
        ServerWorld mundo = cama != null ? server.getWorld(p.getSpawnPointDimension()) : null;
        double x, y, z;
        if (mundo != null) {
            x = cama.getX() + 0.5; y = cama.getY() + 0.6; z = cama.getZ() + 0.5;
        } else {
            mundo = server.getOverworld();
            BlockPos spawn = mundo.getSpawnPos();
            if (!mundo.getBlockState(spawn).getCollisionShape(mundo, spawn).isEmpty() || !mundo.getBlockState(spawn.up()).getCollisionShape(mundo, spawn.up()).isEmpty())
                spawn = mundo.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, spawn);
            x = spawn.getX() + 0.5; y = spawn.getY(); z = spawn.getZ() + 0.5;
        }
        p.teleport(mundo, x, y, z, p.getYaw(), p.getPitch());
        p.fallDistance = 0;
    }
}

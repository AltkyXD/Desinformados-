package com.centrodesinformacion.desinformados.intro;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.ModBloques;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.network.IntroFinPayload;
import com.centrodesinformacion.desinformados.network.IntroPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.GameMode;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Bienvenida a la serie: la primera vez que un jugador entra, aparece en un cuartito oscuro
 * con una tele vieja. No puede romper nada; solo darle clic derecho a la tele. Eso lanza la
 * cinemática (en el cliente) y al terminar aparece en el Centro de Desinformación.
 */
public class Intro {
    public static final RegistryKey<World> CUARTO = RegistryKey.of(RegistryKeys.WORLD, Desinformados.id("cuarto_intro"));

    private static final String VISTA = "sys:intro_vista_";      // + uuid
    private static final String APAGADA = "sys:intro_apagada";
    private static final String CENTRO = "sys:intro_centro_";    // + x;y;z;yaw
    private static final int SEPARACION = 64;                     // cada jugador tiene su propio cuarto
    private static final int ALTURA = 64;
    private static final int RESPALDO = 20 * 150;                 // si el cliente no avisa, a los 2,5 min sale solo

    private static final Map<UUID, Integer> SALAS = new HashMap<>();
    private static final Map<UUID, Integer> VIENDO = new HashMap<>();
    private static final Map<UUID, GameMode> MODO_PREVIO = new HashMap<>();
    private static int siguienteSala = 0;

    public static void registrar() {
        // Nada más entrar por primera vez: al cuarto
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            if (!necesitaIntro(server, p)) return;
            Tareas.programar(10, () -> {
                ServerPlayerEntity ahora = server.getPlayerManager().getPlayer(p.getUuid());
                if (ahora != null && !ahora.isDisconnected()) enviarAlCuarto(ahora);
            });
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> VIENDO.remove(handler.player.getUuid()));

        // En el cuarto nada te hace daño
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof ServerPlayerEntity p && p.getWorld().getRegistryKey() == CUARTO));

        ServerPlayNetworking.registerGlobalReceiver(IntroFinPayload.ID, (paquete, contexto) ->
                contexto.server().execute(() -> {
                    if (VIENDO.containsKey(contexto.player().getUuid())) terminar(contexto.player());
                }));

        ServerTickEvents.END_SERVER_TICK.register(Intro::tick);
    }

    private static void tick(MinecraftServer server) {
        // Respaldo por si el cliente nunca avisa que acabó
        VIENDO.replaceAll((u, t) -> t - 1);
        for (var e : Map.copyOf(VIENDO).entrySet()) {
            if (e.getValue() > 0) continue;
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            VIENDO.remove(e.getKey());
            if (p != null) terminar(p);
        }
        if (server.getTicks() % 20 != 0) return;
        ServerWorld cuarto = server.getWorld(CUARTO);
        if (cuarto == null) return;
        for (ServerPlayerEntity p : java.util.List.copyOf(cuarto.getPlayers())) {
            p.getHungerManager().setFoodLevel(20);
            if (!SALAS.containsKey(p.getUuid()) || p.getY() < ALTURA - 2) {
                // reinició el server estando aquí, o se salió del cuarto de alguna forma
                if (estaVista(server, p.getUuid())) terminar(p); else enviarAlCuarto(p);
                continue;
            }
            if (!VIENDO.containsKey(p.getUuid()) && server.getTicks() % 60 == 0) {
                p.sendMessage(Text.literal("Haz clic derecho en la tele").formatted(Formatting.GRAY, Formatting.ITALIC), true);
            }
        }
    }

    // ------------------------------------------------------------------ estado

    private static boolean estaVista(MinecraftServer server, UUID u) {
        return EstadoServidor.get(server).tieneCambio(VISTA + u);
    }

    public static boolean necesitaIntro(MinecraftServer server, ServerPlayerEntity p) {
        EstadoServidor e = EstadoServidor.get(server);
        return !e.tieneCambio(APAGADA) && !e.tieneCambio(VISTA + p.getUuid()) && !e.estaMuerto(p.getUuid());
    }

    public static void activar(MinecraftServer server, boolean si) {
        EstadoServidor e = EstadoServidor.get(server);
        if (si) e.quitarCambio(APAGADA); else e.agregarCambio(APAGADA);
    }

    public static boolean activada(MinecraftServer server) {
        return !EstadoServidor.get(server).tieneCambio(APAGADA);
    }

    /** Guarda dónde aparecen al terminar la cinemática. */
    public static void fijarCentro(ServerPlayerEntity p) {
        EstadoServidor e = EstadoServidor.get(p.getServer());
        for (String c : java.util.List.copyOf(e.getCambios())) if (c.startsWith(CENTRO)) e.quitarCambio(c);
        e.agregarCambio(CENTRO + p.getBlockX() + ";" + p.getBlockY() + ";" + p.getBlockZ() + ";" + Math.round(p.getYaw()));
    }

    /** Vuelve a mandar al jugador al cuarto (para probar o repetir la bienvenida). */
    public static void reiniciar(ServerPlayerEntity p) {
        EstadoServidor.get(p.getServer()).quitarCambio(VISTA + p.getUuid());
        enviarAlCuarto(p);
    }

    // ------------------------------------------------------------------ flujo

    public static void enviarAlCuarto(ServerPlayerEntity p) {
        ServerWorld mundo = p.getServer().getWorld(CUARTO);
        if (mundo == null) return;
        int sala = SALAS.computeIfAbsent(p.getUuid(), k -> siguienteSala++);
        BlockPos o = new BlockPos(sala * SEPARACION, ALTURA, 0);
        construir(mundo, o);
        if (p.getWorld().getRegistryKey() != CUARTO) {
            GameMode previo = p.interactionManager.getGameMode();
            MODO_PREVIO.put(p.getUuid(), previo == GameMode.ADVENTURE ? GameMode.SURVIVAL : previo);
        }
        VIENDO.remove(p.getUuid());
        p.changeGameMode(GameMode.ADVENTURE);
        p.teleport(mundo, o.getX() + 0.5, o.getY() + 1, o.getZ() + 1.5, 180f, 8f);
        p.setHealth(p.getMaxHealth());
        p.extinguish();
        p.setFireTicks(0);
        mundo.playSound(null, p.getBlockPos(), net.minecraft.sound.SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, SoundCategory.BLOCKS, 0.8f, 0.8f);
    }

    public static void usarTele(ServerPlayerEntity p) {
        if (p.getWorld().getRegistryKey() != CUARTO || VIENDO.containsKey(p.getUuid())) return;
        if (!ServerPlayNetworking.canSend(p, IntroPayload.ID)) { terminar(p); return; }
        VIENDO.put(p.getUuid(), RESPALDO);
        ServerPlayNetworking.send(p, new IntroPayload(p.getGameProfile().getName()));
    }

    private static void terminar(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        VIENDO.remove(p.getUuid());
        EstadoServidor e = EstadoServidor.get(server);
        boolean primeraVez = !e.tieneCambio(VISTA + p.getUuid());
        e.agregarCambio(VISTA + p.getUuid());

        ServerWorld destino = server.getOverworld();
        double x, y, z;
        float yaw = p.getYaw();
        String centro = e.getCambios().stream().filter(c -> c.startsWith(CENTRO)).findFirst().orElse(null);
        if (centro != null) {
            String[] partes = centro.substring(CENTRO.length()).split(";");
            x = Integer.parseInt(partes[0]) + 0.5;
            y = Integer.parseInt(partes[1]);
            z = Integer.parseInt(partes[2]) + 0.5;
            yaw = Integer.parseInt(partes[3]);
        } else {
            BlockPos s = destino.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, destino.getSpawnPos());
            x = s.getX() + 0.5; y = s.getY(); z = s.getZ() + 0.5;
        }
        p.changeGameMode(MODO_PREVIO.getOrDefault(p.getUuid(), GameMode.SURVIVAL));
        MODO_PREVIO.remove(p.getUuid());
        p.teleport(destino, x, y, z, yaw, 0f);
        p.setHealth(p.getMaxHealth());
        p.getHungerManager().setFoodLevel(20);
        p.setSpawnPoint(World.OVERWORLD, BlockPos.ofFloored(x, y, z), yaw, true, false);

        if (primeraVez) {
            server.getPlayerManager().broadcast(Text.literal("✦ " + p.getGameProfile().getName()
                    + " ha llegado al Centro de Desinformación.").formatted(Formatting.GREEN), false);
        }
    }

    // ------------------------------------------------------------------ el cuarto

    /**
     * Cuarto de 7x7 por dentro, madera oscura, alfombra roja, un sillón mirando a la tele,
     * estanterías y un farol colgando. Todo irrompible porque el jugador está en modo aventura.
     */
    private static void construir(ServerWorld w, BlockPos o) {
        BlockState muro = Blocks.DARK_OAK_PLANKS.getDefaultState();
        BlockState columna = Blocks.STRIPPED_DARK_OAK_LOG.getDefaultState().with(PillarBlock.AXIS, Direction.Axis.Y);
        BlockState suelo = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState zocalo = Blocks.STRIPPED_SPRUCE_LOG.getDefaultState().with(PillarBlock.AXIS, Direction.Axis.X);
        BlockState techo = Blocks.DARK_OAK_PLANKS.getDefaultState();
        BlockState viga = Blocks.STRIPPED_DARK_OAK_LOG.getDefaultState().with(PillarBlock.AXIS, Direction.Axis.Z);

        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                for (int y = 0; y <= 5; y++) {
                    BlockPos q = o.add(x, y, z);
                    boolean borde = Math.abs(x) == 4 || Math.abs(z) == 4;
                    BlockState b;
                    if (y == 0) b = suelo;
                    else if (y == 5) b = (x == 0 && !borde) ? viga : techo;
                    else if (Math.abs(x) == 4 && Math.abs(z) == 4) b = columna;
                    else if (borde) b = y == 1 ? (Math.abs(z) == 4 ? zocalo : zocalo.with(PillarBlock.AXIS, Direction.Axis.Z)) : muro;
                    else b = Blocks.AIR.getDefaultState();
                    w.setBlockState(q, b, net.minecraft.block.Block.NOTIFY_LISTENERS);
                }
            }
        }
        // Alfombra
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                boolean orilla = Math.abs(x) == 2 || Math.abs(z) == 2;
                w.setBlockState(o.add(x, 1, z), (orilla ? Blocks.YELLOW_CARPET : Blocks.RED_CARPET).getDefaultState(), 2);
            }
        }
        // Mueble y tele (mirando al sur, hacia el jugador)
        BlockState losa = Blocks.DARK_OAK_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP);
        for (int x = -1; x <= 1; x++) w.setBlockState(o.add(x, 1, -3), losa, 2);
        w.setBlockState(o.add(0, 2, -3), ModBloques.TELE_INTRO.getDefaultState().with(HorizontalFacingBlock.FACING, Direction.SOUTH), 2);
        w.setBlockState(o.add(-1, 2, -3), Blocks.POTTED_FERN.getDefaultState(), 2);
        w.setBlockState(o.add(1, 2, -3), Blocks.CANDLE.getDefaultState()
                .with(net.minecraft.block.CandleBlock.CANDLES, 2).with(net.minecraft.block.CandleBlock.LIT, true), 2);
        // Sillón detrás del jugador
        BlockState asiento = Blocks.DARK_OAK_STAIRS.getDefaultState().with(StairsBlock.FACING, Direction.SOUTH);
        for (int x = -1; x <= 1; x++) w.setBlockState(o.add(x, 1, 3), asiento, 2);
        w.setBlockState(o.add(-2, 1, 3), Blocks.DARK_OAK_TRAPDOOR.getDefaultState()
                .with(net.minecraft.block.TrapdoorBlock.FACING, Direction.WEST).with(net.minecraft.block.TrapdoorBlock.OPEN, true), 2);
        w.setBlockState(o.add(2, 1, 3), Blocks.DARK_OAK_TRAPDOOR.getDefaultState()
                .with(net.minecraft.block.TrapdoorBlock.FACING, Direction.EAST).with(net.minecraft.block.TrapdoorBlock.OPEN, true), 2);
        // Estanterías en las esquinas del fondo
        for (int y = 1; y <= 3; y++) {
            w.setBlockState(o.add(-3, y, -3), Blocks.BOOKSHELF.getDefaultState(), 2);
            w.setBlockState(o.add(3, y, -3), Blocks.BOOKSHELF.getDefaultState(), 2);
        }
        w.setBlockState(o.add(-3, 1, 2), Blocks.BARREL.getDefaultState(), 2);
        w.setBlockState(o.add(3, 1, 2), Blocks.POTTED_DEAD_BUSH.getDefaultState(), 2);
        // Farol colgando del techo
        w.setBlockState(o.add(0, 4, 0), Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true), 2);
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

import java.util.ArrayList;
import java.util.List;

/**
 * Para cambiar cuánto daño se recibe sin escribir mixins nuevos.
 * Se aplica en LivingEntity.modifyAppliedDamage (después de la armadura y la protección), en el servidor,
 * a cualquier ser vivo (jugadores incluidos). Cada modificador recibe la cantidad que dejó el anterior.
 */
public final class Danio {
    private Danio() {}

    @FunctionalInterface
    public interface Modificador {
        /** Devuelve la cantidad nueva (la misma si no toca cambiar nada). */
        float aplicar(LivingEntity vivo, DamageSource fuente, float cantidad);
    }

    private static final List<Modificador> MODIFICADORES = new ArrayList<>();

    /** Registrar en el arranque (onInitialize), no durante la partida. */
    public static void agregar(Modificador m) {
        MODIFICADORES.add(m);
    }

    /** Lo llama LivingEntityMixin. */
    public static float modificar(LivingEntity vivo, DamageSource fuente, float cantidad) {
        if (vivo.getWorld().isClient() || cantidad <= 0) return cantidad;
        float c = cantidad;
        for (Modificador m : MODIFICADORES) {
            c = m.aplicar(vivo, fuente, c);
            if (!(c > 0)) return 0f;     // también si da NaN
        }
        return c;
    }
}

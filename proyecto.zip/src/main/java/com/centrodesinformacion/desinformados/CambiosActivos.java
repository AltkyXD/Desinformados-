package com.centrodesinformacion.desinformados;

import java.util.HashSet;
import java.util.Set;

/**
 * Para comprobar un cambio de dificultad desde código que corre en servidor Y cliente (mixins de movimiento).
 * En el servidor mira el estado del mundo; en el cliente, la copia que manda el servidor.
 */
public class CambiosActivos {
    public static final Set<String> CLIENTE = new HashSet<>();

    public static boolean servidor(String id) {
        return Desinformados.SERVER != null && EstadoServidor.get(Desinformados.SERVER).tieneCambio(id);
    }

    public static boolean en(net.minecraft.world.World mundo, String id) {
        return mundo.isClient() ? CLIENTE.contains(id) : servidor(id);
    }
}

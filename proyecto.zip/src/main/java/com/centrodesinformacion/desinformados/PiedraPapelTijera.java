package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.PptAccionPayload;
import com.centrodesinformacion.desinformados.network.PptPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Mesa de Piedra, Papel o Tijera para dos jugadores, con Rumores del inventario.
 * 1. El primero que usa la mesa se sienta en el asiento 1 y el segundo en el 2.
 * 2. Cada uno propone una apuesta (10-1000). La partida empieza cuando LOS DOS proponen lo mismo y pulsan "De acuerdo";
 *    entonces se cobra a los dos y el bote es el doble.
 * 3. Cada uno elige en secreto. Papel gana a Piedra, Tijera a Papel y Piedra a Tijera. El que gana se lleva el bote.
 *    Empate: se vuelve a elegir (el bote sigue en la mesa).
 * 4. Hay 30 s para elegir: si solo eligió uno, gana ese; si no eligió nadie, se devuelve a los dos.
 *    Si alguien se desconecta mientras se elige, se devuelve a los dos (nadie gana nada por irse).
 */
public final class PiedraPapelTijera {
    public static final int MINIMA = 10, MAXIMA = 1000, PASO = 10;
    public static final int ESPERANDO = 0, ACORDANDO = 1, ELIGIENDO = 2, RESULTADO = 3;
    public static final String[] JUGADAS = {"Piedra", "Papel", "Tijera"};
    private static final int TIEMPO_ELEGIR = 20 * 30, TIEMPO_RESULTADO = 20 * 5, DISTANCIA = 10;

    private static final class Mesa {
        final BlockPos pos;
        final UUID[] jugador = new UUID[2];
        final String[] nombre = {"", ""};
        final int[] propuesta = {MINIMA, MINIMA};
        final boolean[] ok = new boolean[2];
        final int[] eleccion = {-1, -1};
        final int[] ultima = {-1, -1};          // jugadas a la vista (tras un empate o al acabar)
        int fase = ESPERANDO, apuesta = 0, ticks = 0;
        String mensaje = "";

        Mesa(BlockPos pos) { this.pos = pos; }

        int asiento(UUID u) { return u.equals(jugador[0]) ? 0 : u.equals(jugador[1]) ? 1 : -1; }
        boolean llena() { return jugador[0] != null && jugador[1] != null; }
        boolean vacia() { return jugador[0] == null && jugador[1] == null; }
    }

    private static final Map<BlockPos, Mesa> MESAS = new HashMap<>();
    /** Quién tiene abierta qué mesa (para mandarle los cambios). */
    private static final Map<UUID, BlockPos> VIENDO = new HashMap<>();

    private PiedraPapelTijera() {}

    // ------------------------------------------------------------------ registro

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(PptAccionPayload.ID, (paquete, ctx) -> accion(ctx.player(), paquete));
        ServerTickEvents.END_SERVER_TICK.register(PiedraPapelTijera::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID u = handler.player.getUuid();
            VIENDO.remove(u);
            for (Mesa m : new ArrayList<>(MESAS.values())) {
                int i = m.asiento(u);
                if (i < 0) continue;
                if (m.fase == ELIGIENDO) devolver(server, m, "Tu rival se ha desconectado: se os devuelve la apuesta.");
                levantar(server, m, i);
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (server.getOverworld() != null)
                for (Mesa m : MESAS.values()) if (m.fase == ELIGIENDO) devolver(server, m, "");
            MESAS.clear();
            VIENDO.clear();
        });
    }

    // ------------------------------------------------------------------ abrir y sentarse

    public static void abrir(ServerPlayerEntity p, BlockPos pos) {
        BlockPos clave = pos.toImmutable();
        VIENDO.put(p.getUuid(), clave);
        Mesa m = MESAS.computeIfAbsent(clave, Mesa::new);
        if (m.asiento(p.getUuid()) < 0 && m.fase != ELIGIENDO && m.fase != RESULTADO) {
            for (int i = 0; i < 2; i++) {
                if (m.jugador[i] != null) continue;
                m.jugador[i] = p.getUuid();
                m.nombre[i] = p.getGameProfile().getName();
                m.propuesta[i] = m.jugador[1 - i] != null ? m.propuesta[1 - i] : MINIMA;   // empieza igualando al que ya estaba
                m.ok[0] = m.ok[1] = false;
                m.mensaje = m.llena() ? "Poned la misma apuesta y pulsad \"De acuerdo\" los dos." : "";
                if (m.llena()) m.fase = ACORDANDO;
                if (m.jugador[1 - i] != null) avisar(p.getServer(), m.jugador[1 - i], Text.literal(m.nombre[i] + " se ha sentado a jugar contigo a Piedra, Papel o Tijera"));
                break;
            }
        }
        enviar(p, m, true);
        enviarATodos(p.getServer(), m, p.getUuid());
    }

    private static void levantar(MinecraftServer s, Mesa m, int i) {
        m.jugador[i] = null;
        m.nombre[i] = "";
        m.ok[0] = m.ok[1] = false;
        m.eleccion[0] = m.eleccion[1] = -1;
        m.fase = ESPERANDO;
        m.mensaje = "";
        if (m.vacia()) MESAS.remove(m.pos);
        else enviarATodos(s, m, null);
    }

    // ------------------------------------------------------------------ jugadas

    private static void accion(ServerPlayerEntity p, PptAccionPayload paquete) {
        BlockPos pos = VIENDO.get(p.getUuid());
        Mesa m = pos == null ? null : MESAS.get(pos);
        if (m == null || !p.getBlockPos().isWithinDistance(pos, DISTANCIA)
                || !(p.getWorld().getBlockState(pos).getBlock() instanceof PiedraPapelTijeraBlock)) return;
        int i = m.asiento(p.getUuid());
        if (i < 0) return;                                          // solo los que están sentados
        int otro = 1 - i;
        switch (paquete.accion()) {
            case "apuesta" -> {
                if (m.fase != ESPERANDO && m.fase != ACORDANDO) return;
                int v = paquete.valor();
                if (v < MINIMA || v > MAXIMA || v % PASO != 0) return;
                m.propuesta[i] = v;
                m.ok[i] = false;
                if (m.propuesta[otro] != v) m.ok[otro] = false;     // el otro aceptó otra cantidad
                m.mensaje = "";
            }
            case "acuerdo" -> {
                if (m.fase != ACORDANDO) return;
                if (m.propuesta[0] != m.propuesta[1]) {
                    m.ok[i] = false;
                    m.mensaje = "Tenéis que apostar lo mismo: " + m.nombre[0] + " pone " + m.propuesta[0] + " y " + m.nombre[1] + " pone " + m.propuesta[1] + ".";
                } else {
                    m.ok[i] = !m.ok[i];
                    if (m.ok[0] && m.ok[1]) empezar(p.getServer(), m);
                }
            }
            case "elegir" -> {
                int v = paquete.valor();
                if (m.fase != ELIGIENDO || m.eleccion[i] >= 0 || v < 0 || v > 2) return;
                m.eleccion[i] = v;
                sonido(p.getServer(), m, SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), 1.2f);
                if (m.eleccion[otro] >= 0) resolver(p.getServer(), m);
                else avisar(p.getServer(), m.jugador[otro], Text.literal(m.nombre[i] + " ya ha elegido"));
            }
            case "salir" -> {
                if (m.fase == ELIGIENDO) return;                     // con el dinero en la mesa no se puede uno ir
                VIENDO.remove(p.getUuid());
                levantar(p.getServer(), m, i);
                return;
            }
            default -> { return; }
        }
        enviarATodos(p.getServer(), m, null);
    }

    private static void empezar(MinecraftServer s, Mesa m) {
        ServerPlayerEntity a = s.getPlayerManager().getPlayer(m.jugador[0]), b = s.getPlayerManager().getPlayer(m.jugador[1]);
        int apuesta = m.propuesta[0];
        m.ok[0] = m.ok[1] = false;
        if (a == null || b == null) return;
        if (Tragamonedas.rumores(a) < apuesta || Tragamonedas.rumores(b) < apuesta) {
            String quien = Tragamonedas.rumores(a) < apuesta ? m.nombre[0] : m.nombre[1];
            m.mensaje = quien + " no lleva " + apuesta + " Rumores en el inventario.";
            return;
        }
        Tragamonedas.pagar(a, apuesta);
        Tragamonedas.pagar(b, apuesta);
        m.apuesta = apuesta;
        m.fase = ELIGIENDO;
        m.ticks = 0;
        m.eleccion[0] = m.eleccion[1] = -1;
        m.ultima[0] = m.ultima[1] = -1;
        m.mensaje = "¡Bote de " + (apuesta * 2) + " Rumores! Elegid en secreto.";
        sonido(s, m, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f);
    }

    /** Papel gana a Piedra, Tijera a Papel, Piedra a Tijera. */
    private static void resolver(MinecraftServer s, Mesa m) {
        int a = m.eleccion[0], b = m.eleccion[1];
        m.ultima[0] = a;
        m.ultima[1] = b;
        if (a == b) {
            m.eleccion[0] = m.eleccion[1] = -1;
            m.ticks = 0;
            m.mensaje = "¡Empate! " + JUGADAS[a] + " contra " + JUGADAS[b] + ". Volved a elegir.";
            sonido(s, m, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.0f);
            return;
        }
        int gana = (a - b + 3) % 3 == 1 ? 0 : 1;
        pagar(s, m, gana, m.apuesta * 2);
        m.mensaje = "¡" + m.nombre[gana] + " gana con " + JUGADAS[m.ultima[gana]] + " y se lleva " + (m.apuesta * 2) + " Rumores!";
        terminar(s, m, gana);
    }

    private static void terminar(MinecraftServer s, Mesa m, int gana) {
        m.fase = RESULTADO;
        m.ticks = 0;
        m.eleccion[0] = m.eleccion[1] = -1;
        for (int i = 0; i < 2; i++) {
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(m.jugador[i]);
            if (p != null) p.sendMessage(Text.literal("Piedra, Papel o Tijera: ").formatted(Formatting.GOLD)
                    .append(Text.literal(m.mensaje).formatted(gana < 0 ? Formatting.YELLOW : i == gana ? Formatting.GREEN : Formatting.GRAY)), false);
        }
        if (gana >= 0) {
            sonido(s, m, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.2f);
            ServerWorld w = s.getOverworld();
            ServerPlayerEntity g = s.getPlayerManager().getPlayer(m.jugador[gana]);
            if (g != null) w = g.getServerWorld();
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, m.pos.getX() + 0.5, m.pos.getY() + 1.2, m.pos.getZ() + 0.5, 15, 0.4, 0.3, 0.4, 0.1);
            if (m.apuesta * 2 >= 500)
                s.getPlayerManager().broadcast(Text.literal("¡" + m.nombre[gana] + " le ha ganado " + (m.apuesta * 2) + " Rumores a " + m.nombre[1 - gana]
                        + " a Piedra, Papel o Tijera!").formatted(Formatting.GOLD), false);
        }
        m.apuesta = 0;
    }

    /** Paga el bote: al inventario si está conectado, si no a su cuenta del Banco. */
    private static void pagar(MinecraftServer s, Mesa m, int i, int cantidad) {
        if (cantidad <= 0 || m.jugador[i] == null) return;
        ServerPlayerEntity p = s.getPlayerManager().getPlayer(m.jugador[i]);
        if (p != null && !p.isDisconnected()) Tragamonedas.darRumores(p, cantidad);
        else {
            EstadoServidor e = EstadoServidor.get(s);
            e.setSaldo(m.jugador[i], e.getSaldo(m.jugador[i]) + cantidad);
        }
    }

    /** Devuelve la apuesta a los dos (desconexión, nadie eligió, servidor que se apaga). */
    private static void devolver(MinecraftServer s, Mesa m, String motivo) {
        pagar(s, m, 0, m.apuesta);
        pagar(s, m, 1, m.apuesta);
        m.mensaje = motivo;
        m.apuesta = 0;
        m.fase = RESULTADO;
        m.ticks = 0;
        m.eleccion[0] = m.eleccion[1] = -1;
        for (int i = 0; i < 2; i++) if (!motivo.isEmpty() && m.jugador[i] != null) avisar(s, m.jugador[i], Text.literal(motivo));
    }

    // ------------------------------------------------------------------ tiempo

    private static void tick(MinecraftServer s) {
        if (MESAS.isEmpty()) return;
        Iterator<Mesa> it = MESAS.values().iterator();
        List<Mesa> cambiadas = new ArrayList<>();
        while (it.hasNext()) {
            Mesa m = it.next();
            // Los que se alejan de la mesa (sin dinero en juego) se levantan solos
            if (m.fase != ELIGIENDO && s.getTicks() % 20 == 0) {
                for (int i = 0; i < 2; i++) {
                    if (m.jugador[i] == null) continue;
                    ServerPlayerEntity p = s.getPlayerManager().getPlayer(m.jugador[i]);
                    if (p == null || !p.getBlockPos().isWithinDistance(m.pos, DISTANCIA + 6)) {
                        m.jugador[i] = null; m.nombre[i] = ""; m.ok[0] = m.ok[1] = false; m.fase = ESPERANDO; m.mensaje = "";
                        cambiadas.add(m);
                    }
                }
                if (m.vacia()) { it.remove(); continue; }
            }
            if (m.fase == ELIGIENDO) {
                m.ticks++;
                if (m.ticks % 20 == 0) cambiadas.add(m);                     // la cuenta atrás
                if (m.ticks >= TIEMPO_ELEGIR) {
                    int eligio = m.eleccion[0] >= 0 && m.eleccion[1] < 0 ? 0 : m.eleccion[1] >= 0 && m.eleccion[0] < 0 ? 1 : -1;
                    if (eligio >= 0) {
                        pagar(s, m, eligio, m.apuesta * 2);
                        m.ultima[0] = m.eleccion[0];
                        m.ultima[1] = m.eleccion[1];
                        m.mensaje = m.nombre[1 - eligio] + " no eligió a tiempo: " + m.nombre[eligio] + " se lleva " + (m.apuesta * 2) + " Rumores.";
                        terminar(s, m, eligio);
                    } else {
                        devolver(s, m, "Nadie eligió a tiempo: se os devuelve la apuesta.");
                    }
                    cambiadas.add(m);
                }
            } else if (m.fase == RESULTADO) {
                if (++m.ticks >= TIEMPO_RESULTADO) {                          // revancha: vuelven a acordar la apuesta
                    m.fase = m.llena() ? ACORDANDO : ESPERANDO;
                    m.ok[0] = m.ok[1] = false;
                    m.ultima[0] = m.ultima[1] = -1;
                    m.mensaje = m.llena() ? "¿Revancha? Poned la apuesta y pulsad \"De acuerdo\"." : "";
                    cambiadas.add(m);
                }
            }
        }
        for (Mesa m : cambiadas) if (MESAS.containsKey(m.pos)) enviarATodos(s, m, null);
    }

    // ------------------------------------------------------------------ red

    private static void enviarATodos(MinecraftServer s, Mesa m, UUID salvo) {
        for (Map.Entry<UUID, BlockPos> e : VIENDO.entrySet()) {
            if (!e.getValue().equals(m.pos) || e.getKey().equals(salvo)) continue;
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(e.getKey());
            if (p != null) enviar(p, m, false);
        }
    }

    private static void enviar(ServerPlayerEntity p, Mesa m, boolean abrir) {
        if (!ServerPlayNetworking.canSend(p, PptPayload.ID)) return;
        int yo = m.asiento(p.getUuid());
        int miEleccion = yo >= 0 ? m.eleccion[yo] : -1;
        boolean rivalEligio = yo >= 0 && m.eleccion[1 - yo] >= 0;
        int segundos = m.fase == ELIGIENDO ? Math.max(0, (TIEMPO_ELEGIR - m.ticks + 19) / 20) : 0;
        ServerPlayNetworking.send(p, new PptPayload(m.fase, m.nombre[0], m.nombre[1], m.propuesta[0], m.propuesta[1], m.ok[0], m.ok[1],
                yo, miEleccion, rivalEligio, m.ultima[0], m.ultima[1], m.apuesta * 2, segundos, Tragamonedas.rumores(p), m.mensaje, abrir));
    }

    private static void avisar(MinecraftServer s, UUID u, Text t) {
        ServerPlayerEntity p = u == null ? null : s.getPlayerManager().getPlayer(u);
        if (p != null) p.sendMessage(t.copy().formatted(Formatting.LIGHT_PURPLE), true);
    }

    private static void sonido(MinecraftServer s, Mesa m, SoundEvent ev, float tono) {
        for (UUID u : m.jugador) {
            ServerPlayerEntity p = u == null ? null : s.getPlayerManager().getPlayer(u);
            if (p != null) { p.getServerWorld().playSound(null, m.pos, ev, SoundCategory.BLOCKS, 0.8f, tono); return; }
        }
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Rumor: la moneda oficial del Centro de Desinformación. Cada color tiene un valor. */
public class RumorItem extends Item {
    private final int valor;
    private final Formatting color;

    public RumorItem(Settings settings, int valor, Formatting color) {
        super(settings);
        this.valor = valor;
        this.color = color;
    }

    public int getValor() {
        return valor;
    }

    @Override
    public Text getName(ItemStack stack) {
        return super.getName(stack).copy().formatted(color);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("Vale " + valor + (valor == 1 ? " Rumor" : " Rumores")).formatted(color));
        tooltip.add(Text.translatable("item.desinformados.rumor.tooltip").formatted(Formatting.GRAY, Formatting.ITALIC));
    }
}

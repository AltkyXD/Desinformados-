package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.intro.Final;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Los mobs del Nether van aparte de la lista automática:
 * - Cuando alguien pisa el Nether por primera vez, empieza una cuenta de 30 minutos de juego.
 * - Al acabar sale la tele azul "nether_poblado" (Creeper de Fuego, Cubo Rojo, Esqueleto Ráfaga...).
 * - Después, cada 20-40 minutos al azar, una de las 8 mejoras de los mobs del Nether (y del enderman), sin repetir.
 * Solo cuenta el tiempo con alguien jugando y espera si hay un desafío, el jefe o la cinemática (igual que las teles automáticas).
 */
public final class ColaNether {
    public static final List<String> MEJORAS = List.of("ghasts_triples", "blazes_dobles", "piglins_ladrones", "hoglins_gimnasio",
            "magma_ardiente", "wither_veneno", "zombificados_rencorosos", "enderman_teletransporte");
    private static final String PISADO = "sys:nether_pisado";
    private static final String RELOJ_MOBS = "nether_mobs", RELOJ_MEJORA = "nether_mejora";
    private static final int ESPERA_MOBS = 20 * 60 * 30;
    private static final int MIN = 20 * 60 * 20, MAX = 20 * 60 * 40;
    private static final int REINTENTO = 20 * 60;
    private static final Random AZAR = new Random();

    private ColaNether() {}

    public static void registrar() {
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((jugador, origen, destino) -> {
            if (destino.getRegistryKey() != World.NETHER || jugador.isSpectator()) return;
            MinecraftServer s = destino.getServer();
            EstadoServidor e = EstadoServidor.get(s);
            if (e.tieneCambio(PISADO)) return;
            e.agregarCambio(PISADO);
            if (!lanzada(s, "nether_poblado")) e.setReloj(RELOJ_MOBS, ESPERA_MOBS);
            else if (e.getReloj(RELOJ_MEJORA) < 0 && siguiente(s) != null) e.setReloj(RELOJ_MEJORA, azar());   // se lanzó a mano antes: arrancan las mejoras
            ProgramaTeles.avisarAdmins(s, Text.literal(jugador.getGameProfile().getName() + " ha pisado el Nether: los mobs del Nether llegan en 30 minutos de juego.")
                    .formatted(Formatting.GRAY));
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (s.getTicks() % 20 != 0 || !hayJugando(s)) return;
            EstadoServidor e = EstadoServidor.get(s);
            // En pausa con /desinfo auto pausar (si la lista se acabó sola, sigue) y parada del todo con la serie terminada
            if (Final.serieTerminada(s) || (!e.isAutoActivo() && ProgramaTeles.siguiente(s) != null)) return;
            int mobs = e.getReloj(RELOJ_MOBS);
            if (mobs >= 0) {
                mobs -= 20;
                if (mobs == 20 * 60) ProgramaTeles.avisarAdmins(s, Text.literal("Los mobs del Nether llegan en 1 minuto.").formatted(Formatting.GRAY));
                if (mobs > 0) { e.setReloj(RELOJ_MOBS, mobs); return; }
                if (ProgramaTeles.puedeSalirOtra(s) != null) { e.setReloj(RELOJ_MOBS, REINTENTO); return; }
                e.quitarReloj(RELOJ_MOBS);
                if (!lanzada(s, "nether_poblado")) lanzar(s, "nether_poblado");   // si ya se lanzó a mano, no se repite
                e.setReloj(RELOJ_MEJORA, azar());
                return;
            }
            int mejora = e.getReloj(RELOJ_MEJORA);
            if (mejora >= 0) {
                mejora -= 20;
                if (mejora > 0) { e.setReloj(RELOJ_MEJORA, mejora); return; }
                if (ProgramaTeles.puedeSalirOtra(s) != null) { e.setReloj(RELOJ_MEJORA, REINTENTO); return; }
                String id = siguiente(s);
                if (id == null) { e.quitarReloj(RELOJ_MEJORA); return; }
                lanzar(s, id);
                if (siguiente(s) != null) e.setReloj(RELOJ_MEJORA, azar());
                else e.quitarReloj(RELOJ_MEJORA);
            }
        });
        CommandRegistrationCallback.EVENT.register((d, acceso, entorno) -> d.register(literal("desinfo").requires(src -> src.hasPermissionLevel(2))
                .then(literal("auto").then(literal("nether")
                        .executes(ColaNether::estado)
                        .then(literal("ahora").executes(ColaNether::ahora))))));
    }

    private static int azar() {
        return MIN + AZAR.nextInt(MAX - MIN + 1);
    }

    private static boolean lanzada(MinecraftServer s, String id) {
        return EstadoServidor.get(s).tieneCambio("evento:" + id);
    }

    /** Una mejora al azar que no haya salido todavía. */
    private static String siguiente(MinecraftServer s) {
        List<String> libres = new ArrayList<>();
        for (String id : MEJORAS) if (!lanzada(s, id)) libres.add(id);
        return libres.isEmpty() ? null : libres.get(AZAR.nextInt(libres.size()));
    }

    private static void lanzar(MinecraftServer s, String id) {
        Eventos.Evento ev = Eventos.TODOS.get(id);
        if (ev == null) return;
        Eventos.lanzar(s, ev);
        ProgramaTeles.marcarTele(s);
        ProgramaTeles.avisarAdmins(s, Text.literal("Nether: ").formatted(Formatting.GRAY).append(Text.literal(ev.titulo()).formatted(Formatting.GOLD)));
    }

    private static boolean hayJugando(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) if (!p.isSpectator()) return true;
        return false;
    }

    private static String tiempo(int ticks) {
        int seg = Math.max(0, ticks / 20);
        return seg / 60 + " min " + seg % 60 + " s";
    }

    private static int estado(CommandContext<ServerCommandSource> c) {
        MinecraftServer s = c.getSource().getServer();
        EstadoServidor e = EstadoServidor.get(s);
        int quedan = 0;
        for (String id : MEJORAS) if (!lanzada(s, id)) quedan++;
        String txt;
        if (!e.tieneCambio(PISADO)) txt = "Nadie ha pisado el Nether todavía: la cuenta de 30 minutos empieza cuando entre el primero.";
        else if (e.getReloj(RELOJ_MOBS) >= 0) txt = "Los mobs del Nether llegan en " + tiempo(e.getReloj(RELOJ_MOBS)) + ".";
        else if (e.getReloj(RELOJ_MEJORA) >= 0) txt = "Próxima mejora del Nether en " + tiempo(e.getReloj(RELOJ_MEJORA)) + " (quedan " + quedan + " de 8).";
        else txt = quedan == 0 ? "Ya salieron los mobs del Nether y las 8 mejoras." : "Cola del Nether parada (quedan " + quedan + " mejoras). Usa /desinfo auto nether ahora.";
        c.getSource().sendFeedback(() -> Text.literal(txt).formatted(Formatting.GOLD), false);
        return 1;
    }

    private static int ahora(CommandContext<ServerCommandSource> c) {
        MinecraftServer s = c.getSource().getServer();
        EstadoServidor e = EstadoServidor.get(s);
        e.agregarCambio(PISADO);
        if (!lanzada(s, "nether_poblado")) {
            e.quitarReloj(RELOJ_MOBS);
            lanzar(s, "nether_poblado");
            e.setReloj(RELOJ_MEJORA, azar());
            return 1;
        }
        String id = siguiente(s);
        if (id == null) { c.getSource().sendError(Text.literal("Ya salieron todas las mejoras del Nether.")); return 0; }
        lanzar(s, id);
        if (siguiente(s) != null) e.setReloj(RELOJ_MEJORA, azar());
        else e.quitarReloj(RELOJ_MEJORA);
        return 1;
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.AleEntity;
import com.centrodesinformacion.desinformados.entidad.CuboBlancoEntity;
import com.centrodesinformacion.desinformados.entidad.EsqueletoRafagaEntity;
import com.centrodesinformacion.desinformados.entidad.FurroEntity;
import com.centrodesinformacion.desinformados.entidad.GarabatoEntity;
import com.centrodesinformacion.desinformados.entidad.JefeTeleEntity;
import com.centrodesinformacion.desinformados.entidad.KevinEntity;
import com.centrodesinformacion.desinformados.entidad.MobEstatica;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import com.centrodesinformacion.desinformados.entidad.TravensanoEntity;
import com.centrodesinformacion.desinformados.entidad.UlisesEntity;
import com.centrodesinformacion.desinformados.entidad.ZombieNaranjaEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 21 mutaciones de mobs nuevas (teles naranjas). (cubos_mitosis, garabatos_esquivos, saqueadores_berserker y creeper_fuego_llamarada
 * se quitaron: sus constantes y su código siguen, pero ya no hay tele que las active.) Cada una es un cambio guardado en EstadoServidor con el mismo id que su tele:
 * si se quita (/desinfo desactivar todo), lo que hace en marcha deja de pasar y aplicarATodos quita sus modificadores y su equipo.
 * <p>
 * Los efectos de los golpes van por {@link Danio} (solo cuentan los golpes que de verdad entran: ni los parados con escudo,
 * ni los de durante la invulnerabilidad de después de otro golpe, ni los que se come un corazón de alma).
 */
public final class MutacionesExtra {
    private MutacionesExtra() {}

    // ------------------------------------------------------------------ ids (orden de aparición: 1A ... 5)
    static final String COCES = "animales_coces";                    // 1A
    static final String ZOMBIES = "zombies_agarran";                 // 1A
    static final String FURROS = "furros_esponjosos";                // 1B
    static final String ARANAS = "aranas_saltarinas";                // 1B
    static final String MITOSIS = "cubos_mitosis";                   // 1B
    static final String GARABATOS = "garabatos_esquivos";            // 2A
    static final String CREEPERS = "creepers_silenciosos";           // 2A
    static final String MURCIELAGOS = "murcielagos_vampiros";        // 2A
    static final String BRONCEADO = "zombie_naranja_bronceado";      // 2B
    static final String TRAVENSANOS = "travensanos_glotones";        // 2B
    static final String AHOGADOS = "ahogados_tridente";              // 2B
    static final String RECICLADOS = "esqueletos_reciclados";        // 2B
    static final String KEVIN = "kevin_pinchos";                     // 3A
    static final String BRUJAS = "brujas_rencorosas";                // 3A
    static final String LOBOS = "lobos_nocturnos";                   // 3A
    static final String ULISES = "ulises_desamor";                   // 3B
    static final String ALE = "ale_lanzador";                        // 3B
    static final String SLIMES = "slimes_trampolin";                 // 3B
    static final String PHANTOMS = "phantoms_gigantes";              // 3B
    static final String BERSERKER = "saqueadores_berserker";         // 4A
    static final String PECECILLOS = "pececillos_mineros";           // 4A
    static final String LLAMARADA = "creeper_fuego_llamarada";       // 4B (tras "nether_poblado")
    static final String RAFAGA = "rafaga_incendiaria";               // 4B (tras "nether_poblado")
    static final String VAGABUNDOS = "vagabundos_congelan";          // 4B
    static final String ENDERMEN = "endermen_solidarios";            // 5

    /** Ids de todas las mutaciones de este archivo, en el orden en que deberían salir. */
    public static final List<String> IDS = List.of(
            COCES, ZOMBIES,
            FURROS, ARANAS,
            CREEPERS, MURCIELAGOS,
            BRONCEADO, TRAVENSANOS, AHOGADOS, RECICLADOS,
            KEVIN, BRUJAS, LOBOS,
            ULISES, ALE, SLIMES, PHANTOMS,
            PECECILLOS,
            RAFAGA, VAGABUNDOS,
            ENDERMEN);

    /** Para la Enciclopedia: a quién afecta cada mutación ("mob:<id de la tele azul>" o el nombre de un mob de siempre). */
    public static final Map<String, List<String>> AFECTA = Map.ofEntries(
            Map.entry(COCES, List.of("Vacas", "Cerdos", "Ovejas")),
            Map.entry(ZOMBIES, List.of("Zombies", "Husks", "Ahogados", "Aldeanos zombie")),
            Map.entry(FURROS, List.of("mob:furros")),
            Map.entry(ARANAS, List.of("Arañas", "Arañas de cueva")),
            Map.entry(CREEPERS, List.of("Creepers")),
            Map.entry(MURCIELAGOS, List.of("Murciélagos")),
            Map.entry(BRONCEADO, List.of("mob:zombie_naranja")),
            Map.entry(TRAVENSANOS, List.of("mob:travensanos")),
            Map.entry(AHOGADOS, List.of("Ahogados")),
            Map.entry(RECICLADOS, List.of("Esqueletos")),
            Map.entry(KEVIN, List.of("mob:brandon_kevin")),
            Map.entry(BRUJAS, List.of("Brujas")),
            Map.entry(LOBOS, List.of("Lobos")),
            Map.entry(ULISES, List.of("mob:ulises")),
            Map.entry(ALE, List.of("mob:ale")),
            Map.entry(SLIMES, List.of("Slimes")),
            Map.entry(PHANTOMS, List.of("Phantoms")),
            Map.entry(PECECILLOS, List.of("Pececillos de plata")),
            Map.entry(RAFAGA, List.of("mob:nether_poblado")),
            Map.entry(VAGABUNDOS, List.of("Esqueletos vagabundos")),
            Map.entry(ENDERMEN, List.of("Endermen")));

    // ------------------------------------------------------------------ marcas y modificadores
    /** Creeper silenciado por la mutación (los que ya eran silenciosos de antes no se tocan). */
    private static final String SILENCIO = "desinfo_silencio";
    /** Ahogado que lleva el tridente regalado por la mutación. */
    private static final String TRIDENTE = "desinfo_tridente";
    /** Cubo Blanco pequeño nacido de una mitosis (ya no se divide más). */
    private static final String HIJO = "desinfo_mitosis";
    /** Esqueleto que ya se ha reciclado una vez. */
    private static final String RECICLADO = "desinfo_reciclado";
    /** Saqueador o vindicador que ya se ha enfurecido. */
    private static final String FURIA = "desinfo_furia";
    /** Flecha del Esqueleto Ráfaga ya encendida. */
    private static final String ARDIENTE = "desinfo_ardiente";

    private static final Identifier ID_PHANTOM = Desinformados.id("phantom_gigante");
    private static final Identifier ID_MITOSIS = Desinformados.id("cubo_mitosis");

    private static final EquipmentSlot[] ARMADURA = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    /** Congelación de las flechas de los vagabundos: 140 = empieza a doler; +400 = 10 s congelado (baja de 2 en 2). */
    private static final int CONGELADO = 140 + 400;

    /** Último mordisco de murciélago de cada jugador (tick del servidor). */
    private static final Map<UUID, Integer> MORDISCOS = new HashMap<>();

    // ------------------------------------------------------------------ teles

    private static void tele(String id, String titulo, String descripcion, String excusa) {
        Eventos.amarillo(id, titulo, descripcion, excusa, server -> {
            EstadoServidor.get(server).agregarCambio(id);
            Modificaciones.aplicarATodos(server);
        });
    }

    /** Crea las teles (lo llama Eventos al cargar). */
    static void eventos() {
        tele(COCES, "¡Los animales de granja se defienden!",
                "A partir de ahora, al pegar a una vaca, champiñaca, cerdo u oveja adulta, hay un 30% de probabilidad de que te devuelva "
                        + "una coz: 1 corazón de daño y un buen empujón.",
                "El Centro de Desinformación organizó un curso de defensa personal para granjeros. No se apuntó ningún granjero, "
                        + "pero las vacas no faltaron a ninguna clase y han sacado matrícula de honor.");

        tele(ZOMBIES, "¡Los zombies te agarran!",
                "A partir de ahora cada golpe cuerpo a cuerpo de un zombie (también husks, ahogados y aldeanos zombie) te agarra del tobillo "
                        + "y te deja con Lentitud II durante 2 segundos.",
                "Los zombies han hecho el curso de atención al cliente del Centro de Desinformación. La lección principal era "
                        + "\"no dejes que el cliente se vaya sin despedirse\". Se la han tomado al pie de la letra. Y del tobillo.");

        tele(FURROS, "¡Los Furros se han hecho la permanente!",
                "A partir de ahora las flechas y demás proyectiles solo hacen la mitad de daño a los Furros (también a los dibujados). "
                        + "Toca abrazarlos de cerca.",
                "Los Furros fueron a la peluquería del Centro de Desinformación y pidieron \"mucho volumen\". Ahora las flechas se les "
                        + "quedan enredadas en el pelo y ellos dicen que son accesorios.");

        tele(ARANAS, "¡Las arañas saltan!",
                "A partir de ahora las arañas y las arañas de cueva que te persigan se lanzarán de un salto sobre ti desde hasta 10 bloques "
                        + "de distancia, como mucho una vez cada 3 segundos.",
                "Las arañas vieron un documental sobre arañas saltadoras y se sintieron muy identificadas. El Centro de Desinformación "
                        + "no ha podido demostrar que no lo sean, así que ya es oficial.");

        tele(CREEPERS, "¡Creepers en modo silencio!",
                "A partir de ahora los creepers no hacen ningún ruido: ni pasos, ni quejidos, ni el siseo de antes de explotar. "
                        + "La explosión sí se oye (aunque para entonces ya da igual). Los Creepers Oscuros no cambian.",
                "Tras varias quejas de los vecinos por el ruido, el Centro de Desinformación ha obligado a los creepers a hacer un curso "
                        + "de convivencia. Ahora explotan en silencio, por respeto al descanso de los demás.");

        tele(MURCIELAGOS, "¡Murciélagos con hambre!",
                "A partir de ahora los murciélagos despiertos vuelan hacia ti si estás a menos de 8 bloques y, si te rozan, te muerden: "
                        + "medio corazón por mordisco (como mucho un mordisco cada 2 segundos).",
                "Hemos cambiado la dieta de los murciélagos de las cuevas por otra más rica en hierro. El hierro más cercano que "
                        + "encontraron estaba dentro de vosotros.");

        tele(BRONCEADO, "¡El Zombie Naranja toma el sol!",
                "A partir de ahora, mientras le dé el sol (de día, sin lluvia y al aire libre), el Zombie Naranja se cura medio corazón "
                        + "cada segundo. De noche, con lluvia o bajo techo, no.",
                "El Zombie Naranja se ha comprado una crema bronceadora con factor de regeneración. Dice que es \"vitamina D\". "
                        + "El Centro de Desinformación lo ha verificado y lo considera totalmente cierto.");

        tele(TRAVENSANOS, "¡Los Travensaños tienen hambre!",
                "A partir de ahora, cada vez que un Travensaño te quite vida, también te quitará 1 punto de comida (medio muslo) "
                        + "de la barra de hambre.",
                "Los Travensaños viven todo el año en la playa y se alimentan de bocadillos ajenos. Ahora que viven en vuestro cuello, "
                        + "el bocadillo ajeno es el vuestro.");

        tele(AHOGADOS, "¡Ahogados armados!",
                "A partir de ahora la mitad de los ahogados que no lleven ya algo en la mano aparecen con un tridente y te lo lanzan desde lejos. "
                        + "Los tridentes regalados no se sueltan al morir (ni con Botín).",
                "Un camión del Centro de Desinformación que transportaba tenedores gigantes volcó cerca de la costa. "
                        + "Los ahogados lo han considerado un regalo. Nuestro seguro, una pérdida total.");

        tele(RECICLADOS, "¡Los esqueletos se reciclan!",
                "A partir de ahora, cuando muera un esqueleto, hay un 50% de probabilidad de que sus huesos se vuelvan a montar "
                        + "a los 3 segundos, en el mismo sitio y con la mitad de vida. Cada esqueleto solo se recicla una vez.",
                "El Centro de Desinformación se ha comprometido con el medio ambiente y ha puesto contenedores para reciclar huesos. "
                        + "Los esqueletos, al enterarse, han decidido reciclarse a sí mismos. Es la única medida ecológica que nos ha salido bien.");

        tele(KEVIN, "¡Kevin se ha puesto pinchos!",
                "A partir de ahora cada golpe cuerpo a cuerpo que le des a Kevin (también los que se come por Brandon) te devuelve "
                        + "un 20% del daño, como mínimo medio corazón. Las flechas no.",
                "Kevin ha leído que la mejor defensa es un buen ataque y se ha comprado en un mercadillo una camiseta con pinchos. "
                        + "Brandon dice que le queda genial. Brandon miente.");

        tele(BRUJAS, "¡Las brujas maldicen al morir!",
                "A partir de ahora, al morir, las brujas sueltan una maldición: todos los jugadores a menos de 5 bloques reciben Veneno "
                        + "durante 8 segundos (unos 3 corazones). Mejor matarlas de lejos.",
                "Las brujas han contratado un seguro de vida con el Centro de Desinformación. No cubre absolutamente nada, "
                        + "pero incluye de regalo una maldición para quien les dé el último golpe.");

        tele(LOBOS, "¡Los lobos no son de fiar de noche!",
                "A partir de ahora, de noche, los lobos salvajes adultos atacarán a cualquiera que se acerque a menos de 8 bloques. "
                        + "De día vuelven a ser buenos chicos (y se pueden domesticar).",
                "Los lobos se han enterado de que hay luna llena. El Centro de Desinformación no sabe qué tiene que ver una cosa con la otra, "
                        + "pero ha preferido no hacer más preguntas para no alarmar a la población.");

        tele(ULISES, "¡Ulises te rompe el corazón!",
                "A partir de ahora el rayo de Ulises, además de quitarte la mitad de la vida, te deja con el corazón roto: "
                        + "Debilidad I y Lentitud I durante 10 segundos.",
                "El clon de Ulises ha empezado a escribir poesía. Ahora su rayo no solo proyecta: también recita. "
                        + "Los efectos secundarios incluyen tristeza, falta de fuerzas y ganas de escribirle a tu ex.");

        tele(ALE, "¡Ale lanza Travensaños!",
                "A partir de ahora, si Ale va a por ti y estás a entre 5 y 15 bloques, te lanzará un Travensaño por los aires "
                        + "cada 10 segundos (como mucho habrá 4 Travensaños a su alrededor).",
                "Ale ha pasado del press de banca al lanzamiento de peso. Como el gimnasio del Centro de Desinformación no tiene pesas "
                        + "homologadas, usa lo que tiene más a mano. Los Travensaños dicen que vuelan muy a gusto.");

        tele(SLIMES, "¡Los slimes son camas elásticas!",
                "A partir de ahora, si un slime te golpea, te lanza unos 5 bloques hacia arriba. La caída corre de tu cuenta.",
                "Los slimes han descubierto que son elásticos. El Centro de Desinformación ha intentado explicarles que eso no los "
                        + "convierte en camas elásticas, pero no tienen orejas.");

        tele(PHANTOMS, "¡Phantoms tamaño familiar!",
                "A partir de ahora los phantoms son el doble de grandes, tienen un 50% más de vida y pegan un 50% más fuerte.",
                "Los phantoms se alimentan de vuestras horas sin dormir. Con el ritmo de trabajo que lleváis, han comido tanto que ya no "
                        + "caben por la puerta. El Centro de Desinformación recomienda dormir más. El Centro de Desinformación no duerme desde hace años.");

        tele(PECECILLOS, "¡El subsuelo está infestado!",
                "A partir de ahora, al picar piedra, pizarra profunda o toba por debajo de la capa 0, hay un 2% de probabilidad "
                        + "de que salga un pececillo de plata del bloque.",
                "Para abaratar costes, el Centro de Desinformación ha rellenado el subsuelo con material reciclado. "
                        + "El material reciclado estaba vivo. Y tenía hambre.");

        tele(RAFAGA, "¡Ráfagas incendiarias!",
                "A partir de ahora las flechas del Esqueleto Ráfaga salen ardiendo: cada una que te alcance te prende fuego durante 5 segundos.",
                "El Esqueleto Ráfaga ha descubierto que en el Nether las flechas se encienden solas si se acercan un poco a la lava. "
                        + "Ahora las acerca mucho.");

        tele(VAGABUNDOS, "¡Flechas congeladas!",
                "A partir de ahora las flechas de los esqueletos vagabundos (strays) te congelan como la nieve polvo durante 10 segundos: "
                        + "te frenan y te quitan medio corazón cada 2 segundos. Llevar puesta una pieza de armadura de cuero te protege.",
                "Los esqueletos vagabundos han dejado de mojar las flechas en pociones y ahora las guardan en el congelador. "
                        + "Dicen que así se conservan mejor. Vosotros no.");

        tele(ENDERMEN, "¡Los endermans se apoyan entre ellos!",
                "A partir de ahora, si le pegas a un enderman, todos los endermans a menos de 16 bloques irán a por ti. "
                        + "En el End no, que allí son demasiados.",
                "Los endermans han creado un chat de vecinos. Ahora, cuando uno recibe un golpe, se entera todo el barrio en segundos. "
                        + "El Centro de Desinformación ha intentado que lo silencien, pero nadie se atreve a mirarlos a los ojos.");
    }

    // ------------------------------------------------------------------ ganchos

    /** Ganchos de juego (lo llama Desinformados.onInitialize). */
    public static void registrar() {
        // Golpes que de verdad entran (después de armadura, escudo e invulnerabilidad)
        Danio.agregar(MutacionesExtra::alRecibirDanio);

        // Mobs que aparecen o se cargan: equipo, silencio y modificadores. Flechas del Esqueleto Ráfaga: ardiendo.
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (entidad instanceof PersistentProjectileEntity flecha) {
                if (flecha.getOwner() instanceof EsqueletoRafagaEntity && !flecha.getCommandTags().contains(ARDIENTE)
                        && activo(mundo.getServer(), RAFAGA)) {
                    flecha.addCommandTag(ARDIENTE);
                    flecha.setOnFireFor(100f);
                }
                return;
            }
            aplicar(mundo.getServer(), entidad);
        });

        // El tridente regalado se quita justo antes de morir: así no lo suelta ni con Botín
        ServerLivingEntityEvents.ALLOW_DEATH.register((vivo, fuente, cantidad) -> {
            if (vivo.getType() == EntityType.DROWNED && vivo.getCommandTags().contains(TRIDENTE)
                    && vivo.getMainHandStack().isOf(Items.TRIDENT)) {
                vivo.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            return true;
        });

        // Muertes: mitosis, reciclaje, maldición y llamarada
        ServerLivingEntityEvents.AFTER_DEATH.register((muerto, fuente) -> {
            if (!(muerto.getWorld() instanceof ServerWorld w)) return;
            EntityType<?> tipo = muerto.getType();
            boolean cubo = tipo == ModEntidades.CUBO_BLANCO, esqueleto = tipo == EntityType.SKELETON,
                    bruja = tipo == EntityType.WITCH, fuego = tipo == ModEntidades.CREEPER_FUEGO;
            if (!cubo && !esqueleto && !bruja && !fuego) return;
            EstadoServidor estado = EstadoServidor.get(w.getServer());
            if (cubo) {
                if (estado.tieneCambio(MITOSIS) && !muerto.getCommandTags().contains(HIJO) && puedeVolver(w, muerto, fuente, estado)) mitosis(w, muerto);
            } else if (esqueleto) {
                if (estado.tieneCambio(RECICLADOS) && !muerto.getCommandTags().contains(RECICLADO) && puedeVolver(w, muerto, fuente, estado)
                        && w.getRandom().nextBoolean()) reciclar(w, muerto);
            } else if (bruja) {
                if (estado.tieneCambio(BRUJAS)) maldicion(w, muerto);
            } else if (estado.tieneCambio(LLAMARADA)) {
                llamarada(w, muerto);
            }
        });

        // Pececillos de plata al picar piedra por debajo de la capa 0
        PlayerBlockBreakEvents.AFTER.register((mundo, jugador, pos, bloque, be) -> {
            if (!(mundo instanceof ServerWorld w) || !(jugador instanceof ServerPlayerEntity p) || !valido(p) || pos.getY() >= 0) return;
            if (!bloque.isOf(Blocks.STONE) && !bloque.isOf(Blocks.DEEPSLATE) && !bloque.isOf(Blocks.TUFF)) return;
            if (p.getRandom().nextFloat() >= 0.02f || !activo(w.getServer(), PECECILLOS)) return;
            MobEntity pez = EntityType.SILVERFISH.create(w);
            if (pez == null) return;
            pez.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.getRandom().nextFloat() * 360f, 0f);
            pez.setTarget(p);
            w.spawnEntity(pez);
            w.spawnParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 10, 0.3, 0.3, 0.3, 0.02);
        });

        // Cosas que miran alrededor de los jugadores (nunca todos los mobs del mundo)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int ahora = server.getTicks();
            if (ahora % 2 != 0) return;
            EstadoServidor estado = EstadoServidor.get(server);
            boolean bichos = estado.tieneCambio(MURCIELAGOS);
            boolean cadaSegundo = ahora % 20 == 0;
            boolean aranas = cadaSegundo && estado.tieneCambio(ARANAS);
            boolean sol = cadaSegundo && estado.tieneCambio(BRONCEADO);
            boolean lanzador = cadaSegundo && estado.tieneCambio(ALE);
            boolean lobos = ahora % 40 == 0 && estado.tieneCambio(LOBOS);
            if (!bichos && !aranas && !sol && !lanzador && !lobos) return;
            Set<Entity> curados = new HashSet<>();   // un Zombie Naranja cerca de dos jugadores solo se cura una vez
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (!valido(p)) continue;
                ServerWorld w = p.getServerWorld();
                if (bichos) murcielagos(w, p, ahora);
                if (aranas) aranasSaltan(w, p);
                if (sol) broncear(w, p, curados);
                if (lanzador) aleLanza(w, p, estado);
                if (lobos) lobosDeNoche(w, p);
            }
        });

        // Los ticks del servidor vuelven a 0 en cada arranque
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> MORDISCOS.clear());
    }

    /** Aplica/quita las mutaciones a los mobs que ya existen (lo llama Modificaciones.aplicarATodos). */
    public static void aplicarATodos(MinecraftServer server) {
        for (ServerWorld mundo : server.getWorlds()) {
            for (Entity e : mundo.iterateEntities()) aplicar(server, e);
        }
    }

    // ------------------------------------------------------------------ utilidades

    private static boolean activo(MinecraftServer s, String id) {
        return s != null && EstadoServidor.get(s).tieneCambio(id);
    }

    /** Jugador que participa: vivo, ni espectador ni creativo. */
    private static boolean valido(ServerPlayerEntity p) {
        return p.isAlive() && !p.isSpectator() && !p.isCreative();
    }

    /** Pone (o quita, con 0) un multiplicador sobre un atributo. 0.5 = +50%. */
    private static void modificador(LivingEntity vivo, RegistryEntry<EntityAttribute> atributo, Identifier id, double cambio) {
        EntityAttributeInstance inst = vivo.getAttributeInstance(atributo);
        if (inst == null) return;
        if (cambio == 0) inst.removeModifier(id);
        else if (!inst.hasModifier(id)) {
            inst.addPersistentModifier(new EntityAttributeModifier(id, cambio, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    /** Tras cambiar la vida máxima: si sube, se suma la diferencia; si baja, no se pasa del máximo. */
    private static void ajustarVida(LivingEntity vivo, float antes) {
        if (vivo.getMaxHealth() > antes) vivo.setHealth(vivo.getHealth() + (vivo.getMaxHealth() - antes));
        if (vivo.getHealth() > vivo.getMaxHealth()) vivo.setHealth(vivo.getMaxHealth());
    }

    private static boolean esZombie(Entity e) {
        EntityType<?> t = e.getType();
        return t == EntityType.ZOMBIE || t == EntityType.HUSK || t == EntityType.DROWNED || t == EntityType.ZOMBIE_VILLAGER;
    }

    private static boolean llevaCuero(ServerPlayerEntity p) {
        for (EquipmentSlot slot : ARMADURA) if (p.getEquippedStack(slot).isIn(ItemTags.FREEZE_IMMUNE_WEARABLES)) return true;
        return false;
    }

    /** Ni muertes por el vacío o /kill, ni dentro del Centro (allí no aparecen hostiles). */
    private static boolean puedeVolver(ServerWorld w, LivingEntity muerto, DamageSource fuente, EstadoServidor estado) {
        return !fuente.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY) && !Reglas.enSpawn(w, muerto.getBlockPos(), estado);
    }

    // ------------------------------------------------------------------ mobs que aparecen / existen

    private static void aplicar(MinecraftServer server, Entity e) {
        if (server == null || !(e instanceof LivingEntity vivo) || e instanceof MobEstatica) return;
        EntityType<?> tipo = e.getType();

        if (tipo == EntityType.CREEPER) {
            // Creepers silenciosos (solo los normales: los Creepers Oscuros no)
            boolean activo = activo(server, CREEPERS);
            if (activo && !e.isSilent()) {
                e.setSilent(true);
                e.addCommandTag(SILENCIO);
            } else if (!activo && e.getCommandTags().contains(SILENCIO)) {
                e.setSilent(false);
                e.removeCommandTag(SILENCIO);
            }
        } else if (tipo == EntityType.DROWNED && e instanceof MobEntity ahogado) {
            // Ahogados con tridente: la mitad (fija para cada ahogado, sale de su UUID) de los que no llevaban nada en la mano
            boolean activo = activo(server, AHOGADOS);
            boolean leToca = (ahogado.getUuid().getLeastSignificantBits() & 1L) == 0L;
            if (activo && leToca && ahogado.getMainHandStack().isEmpty()) {
                ahogado.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.TRIDENT));
                ahogado.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
                ahogado.addCommandTag(TRIDENTE);
            } else if (!activo && ahogado.getCommandTags().contains(TRIDENTE)) {
                if (ahogado.getMainHandStack().isOf(Items.TRIDENT)) ahogado.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                ahogado.removeCommandTag(TRIDENTE);
            }
        } else if (tipo == EntityType.PHANTOM) {
            // Phantoms gigantes: el doble de grandes, +50% vida y +50% daño
            boolean activo = activo(server, PHANTOMS);
            float antes = vivo.getMaxHealth();
            modificador(vivo, EntityAttributes.GENERIC_SCALE, ID_PHANTOM, activo ? 1.0 : 0);
            modificador(vivo, EntityAttributes.GENERIC_MAX_HEALTH, ID_PHANTOM, activo ? 0.5 : 0);
            modificador(vivo, EntityAttributes.GENERIC_ATTACK_DAMAGE, ID_PHANTOM, activo ? 0.5 : 0);
            ajustarVida(vivo, antes);
        } else if (tipo == ModEntidades.CUBO_BLANCO && e.getCommandTags().contains(HIJO)) {
            // Cubos pequeños de la mitosis: sin la mutación vuelven a su tamaño normal
            boolean activo = activo(server, MITOSIS);
            float antes = vivo.getMaxHealth();
            modificador(vivo, EntityAttributes.GENERIC_SCALE, ID_MITOSIS, activo ? -0.5 : 0);
            modificador(vivo, EntityAttributes.GENERIC_MAX_HEALTH, ID_MITOSIS, activo ? -0.5 : 0);
            ajustarVida(vivo, antes);
        }
    }

    // ------------------------------------------------------------------ golpes

    /** Gancho de Danio: no cambia el daño salvo el de los proyectiles a los Furros; el resto son efectos del golpe. */
    private static float alRecibirDanio(LivingEntity vivo, DamageSource fuente, float cantidad) {
        MinecraftServer s = vivo.getServer();
        if (s == null) return cantidad;
        EstadoServidor estado = EstadoServidor.get(s);
        Entity atacante = fuente.getAttacker();
        if (vivo instanceof ServerPlayerEntity p) {
            if (atacante != null && valido(p)) golpeAJugador(estado, p, atacante, fuente);
            return cantidad;
        }
        float resultado = cantidad;
        if (vivo instanceof FurroEntity && fuente.isIn(DamageTypeTags.IS_PROJECTILE) && estado.tieneCambio(FURROS)) resultado = cantidad * 0.5f;
        golpeAMob(estado, vivo, atacante, fuente, resultado);
        return resultado;
    }

    private static void golpeAJugador(EstadoServidor estado, ServerPlayerEntity p, Entity atacante, DamageSource fuente) {
        if (esZombie(atacante) && fuente.getSource() == atacante && estado.tieneCambio(ZOMBIES)) {
            // Te agarran del tobillo
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1));
        } else if (atacante instanceof TravensanoEntity && estado.tieneCambio(TRAVENSANOS)) {
            // Se comen tu bocadillo: 1 punto de comida por golpe
            HungerManager hambre = p.getHungerManager();
            if (hambre.getFoodLevel() > 0) {
                hambre.setFoodLevel(hambre.getFoodLevel() - 1);
                p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_VILLAGER_YES, SoundCategory.HOSTILE, 0.6f, 1.7f);
                p.sendMessage(Text.literal("El Travensaño se está comiendo tu bocadillo").formatted(Formatting.LIGHT_PURPLE), true);
            }
        } else if (atacante instanceof UlisesEntity && estado.tieneCambio(ULISES)) {
            // Corazón roto
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
        } else if (atacante.getType() == EntityType.SLIME && fuente.getSource() == atacante && estado.tieneCambio(SLIMES)) {
            // Cama elástica: un tick después, para que el empujón normal del golpe no lo pise
            Tareas.programar(1, () -> {
                if (!p.isAlive() || p.isSpectator()) return;
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, 0.9, v.z);
                p.velocityModified = true;
                p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.6f);
            });
        } else if (atacante.getType() == EntityType.STRAY && fuente.getSource() instanceof PersistentProjectileEntity
                && estado.tieneCambio(VAGABUNDOS) && !llevaCuero(p)) {
            // Congelado como en la nieve polvo
            p.setFrozenTicks(Math.max(p.getFrozenTicks(), CONGELADO));
            ServerWorld w = p.getServerWorld();
            w.spawnParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getBodyY(0.6), p.getZ(), 20, 0.3, 0.5, 0.3, 0.02);
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.HOSTILE, 0.5f, 1.8f);
        }
    }

    private static void golpeAMob(EstadoServidor estado, LivingEntity vivo, Entity atacante, DamageSource fuente, float cantidad) {
        EntityType<?> tipo = vivo.getType();
        // Saqueadores y vindicadores: por debajo de la mitad de vida se enfurecen (lo mire quien lo mire)
        if ((tipo == EntityType.PILLAGER || tipo == EntityType.VINDICATOR) && !vivo.getCommandTags().contains(FURIA)
                && estado.tieneCambio(BERSERKER)) {
            Tareas.programar(1, () -> enfurecer(vivo));
        }
        if (!(atacante instanceof ServerPlayerEntity p) || !valido(p)) return;

        if ((tipo == EntityType.COW || tipo == EntityType.MOOSHROOM || tipo == EntityType.PIG || tipo == EntityType.SHEEP)
                && !vivo.isBaby() && fuente.getSource() == p && estado.tieneCambio(COCES) && p.getRandom().nextFloat() < 0.3f) {
            Tareas.programar(1, () -> coz(vivo, p));
        } else if (vivo instanceof GarabatoEntity && estado.tieneCambio(GARABATOS) && p.getRandom().nextFloat() < 0.35f) {
            Tareas.programar(1, () -> esquivar(vivo));
        } else if (vivo instanceof KevinEntity && fuente.getSource() == p && estado.tieneCambio(KEVIN)) {
            float devuelto = Math.max(1f, cantidad * 0.2f);
            Tareas.programar(1, () -> pinchar(vivo, p, devuelto));
        } else if (tipo == EntityType.ENDERMAN && vivo.getWorld().getRegistryKey() != World.END && estado.tieneCambio(ENDERMEN)) {
            avisarEndermen(vivo, p);
        }
    }

    private static void enfurecer(LivingEntity mob) {
        if (!mob.isAlive() || mob.getCommandTags().contains(FURIA) || mob.getHealth() > mob.getMaxHealth() / 2f) return;
        if (!(mob.getWorld() instanceof ServerWorld w)) return;
        mob.addCommandTag(FURIA);
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 0));
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 1));
        w.spawnParticles(ParticleTypes.ANGRY_VILLAGER, mob.getX(), mob.getY() + 2.1, mob.getZ(), 6, 0.4, 0.3, 0.4, 0);
        w.playSound(null, mob.getBlockPos(), SoundEvents.ENTITY_RAVAGER_ROAR, SoundCategory.HOSTILE, 0.6f, 1.7f);
    }

    /** La coz: 1 corazón y un empujón hacia atrás. */
    private static void coz(LivingEntity animal, ServerPlayerEntity p) {
        if (!animal.isAlive() || !valido(p) || p.squaredDistanceTo(animal) > 36) return;
        p.damage(animal.getDamageSources().mobAttack(animal), 2f);
        Vec3d lejos = new Vec3d(p.getX() - animal.getX(), 0, p.getZ() - animal.getZ());
        lejos = lejos.lengthSquared() < 1.0E-4 ? new Vec3d(1, 0, 0) : lejos.normalize();
        p.addVelocity(lejos.x * 0.9, 0.35, lejos.z * 0.9);
        p.velocityModified = true;
        p.getServerWorld().playSound(null, animal.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.NEUTRAL, 0.9f, 0.6f);
        p.sendMessage(Text.literal("¡Coz!").formatted(Formatting.GOLD, Formatting.BOLD), true);
    }

    /** El Garabato se borra y se vuelve a dibujar a unos 4 bloques. */
    private static void esquivar(LivingEntity g) {
        if (!g.isAlive() || !(g.getWorld() instanceof ServerWorld w)) return;
        double ox = g.getX(), oy = g.getY(), oz = g.getZ();
        for (int i = 0; i < 12; i++) {
            double ang = g.getRandom().nextDouble() * Math.PI * 2;
            double x = ox + Math.cos(ang) * 4, z = oz + Math.sin(ang) * 4;
            double y = oy + g.getRandom().nextInt(3) - 1;
            if (g.teleport(x, y, z, false)) {
                w.spawnParticles(ParticleTypes.SQUID_INK, ox, oy + 1, oz, 15, 0.3, 0.6, 0.3, 0.02);
                w.spawnParticles(ParticleTypes.SQUID_INK, g.getX(), g.getY() + 1, g.getZ(), 15, 0.3, 0.6, 0.3, 0.02);
                w.playSound(null, g.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.HOSTILE, 1f, 1.3f);
                return;
            }
        }
    }

    /** Pinchos de Kevin: el jugador recibe parte del golpe. */
    private static void pinchar(LivingEntity kevin, ServerPlayerEntity p, float cantidad) {
        if (!valido(p)) return;
        p.damage(kevin.getDamageSources().thorns(kevin), cantidad);
        p.getServerWorld().spawnParticles(ParticleTypes.CRIT, p.getX(), p.getBodyY(0.6), p.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
    }

    /** Todos los endermans de alrededor van a por quien pegó al primero. */
    private static void avisarEndermen(LivingEntity golpeado, ServerPlayerEntity p) {
        List<EndermanEntity> otros = golpeado.getWorld().getEntitiesByClass(EndermanEntity.class, golpeado.getBoundingBox().expand(16),
                en -> en != golpeado && en.isAlive() && en.getTarget() == null);
        if (otros.isEmpty()) return;
        for (EndermanEntity en : otros) en.setTarget(p);
        golpeado.getWorld().playSound(null, golpeado.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_SCREAM, SoundCategory.HOSTILE, 1f, 0.7f);
    }

    // ------------------------------------------------------------------ muertes

    /** El Cubo Blanco se parte en dos cubos pequeños (la mitad de grandes, 5 corazones). */
    private static void mitosis(ServerWorld w, LivingEntity padre) {
        boolean esbirro = padre.getCommandTags().contains(JefeTeleEntity.MARCA_ESBIRRO);
        LivingEntity objetivo = padre instanceof MobEntity m ? m.getTarget() : null;
        for (int i = 0; i < 2; i++) {
            CuboBlancoEntity hijo = ModEntidades.CUBO_BLANCO.create(w);
            if (hijo == null) return;
            double lado = i == 0 ? -0.35 : 0.35;
            hijo.refreshPositionAndAngles(padre.getX() + lado, padre.getY(), padre.getZ(), w.getRandom().nextFloat() * 360f, 0f);
            hijo.initialize(w, w.getLocalDifficulty(padre.getBlockPos()), SpawnReason.MOB_SUMMONED, null);
            hijo.addCommandTag(HIJO);
            hijo.addCommandTag(Mobs.MARCA_EVENTO);                                   // existe aunque su tipo esté bloqueado
            if (esbirro) hijo.addCommandTag(JefeTeleEntity.MARCA_ESBIRRO);           // se va con la tele
            modificador(hijo, EntityAttributes.GENERIC_SCALE, ID_MITOSIS, -0.5);
            modificador(hijo, EntityAttributes.GENERIC_MAX_HEALTH, ID_MITOSIS, -0.5);
            hijo.setHealth(hijo.getMaxHealth());
            hijo.setVelocity(lado, 0.3, (w.getRandom().nextDouble() - 0.5) * 0.3);
            if (objetivo != null && objetivo.isAlive()) hijo.setTarget(objetivo);
            w.spawnEntity(hijo);
        }
        w.spawnParticles(ParticleTypes.WHITE_ASH, padre.getX(), padre.getY() + 0.5, padre.getZ(), 30, 0.4, 0.4, 0.4, 0.05);
        w.playSound(null, padre.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 1.4f);
    }

    /** A los 3 segundos el esqueleto se vuelve a montar con la mitad de vida (y sin soltar su equipo otra vez). */
    private static void reciclar(ServerWorld w, LivingEntity muerto) {
        double x = muerto.getX(), y = muerto.getY(), z = muerto.getZ();
        float yaw = muerto.getYaw();
        BlockPos pos = muerto.getBlockPos();
        boolean esbirro = muerto.getCommandTags().contains(JefeTeleEntity.MARCA_ESBIRRO);
        Tareas.programar(60, () -> {
            if (!w.isChunkLoaded(pos)) return;
            MobEntity nuevo = EntityType.SKELETON.create(w);
            if (nuevo == null) return;
            nuevo.refreshPositionAndAngles(x, y, z, yaw, 0f);
            nuevo.initialize(w, w.getLocalDifficulty(pos), SpawnReason.MOB_SUMMONED, null);
            for (EquipmentSlot slot : EquipmentSlot.values()) nuevo.setEquipmentDropChance(slot, 0f);
            nuevo.addCommandTag(RECICLADO);
            if (esbirro) nuevo.addCommandTag(JefeTeleEntity.MARCA_ESBIRRO);
            nuevo.setHealth(nuevo.getMaxHealth() / 2f);
            w.spawnEntity(nuevo);
            w.spawnParticles(ParticleTypes.POOF, x, y + 1, z, 15, 0.3, 0.6, 0.3, 0.02);
            w.playSound(null, pos, SoundEvents.BLOCK_CHAIN_PLACE, SoundCategory.HOSTILE, 1f, 0.6f);
        });
    }

    /** Veneno 8 s a los jugadores a menos de 5 bloques de la bruja. */
    private static void maldicion(ServerWorld w, LivingEntity bruja) {
        w.spawnParticles(ParticleTypes.WITCH, bruja.getX(), bruja.getY() + 1, bruja.getZ(), 60, 2.0, 0.8, 2.0, 0.05);
        w.playSound(null, bruja.getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.HOSTILE, 0.6f, 1.4f);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (!valido(p) || p.squaredDistanceTo(bruja) > 25) continue;
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 160, 0));
            p.sendMessage(Text.literal("La bruja te ha maldecido antes de morir").formatted(Formatting.DARK_PURPLE), true);
        }
    }

    /** Llamarada del Creeper de Fuego al morir: 6 s ardiendo a menos de 4 bloques. */
    private static void llamarada(ServerWorld w, LivingEntity creeper) {
        w.spawnParticles(ParticleTypes.FLAME, creeper.getX(), creeper.getY() + 1, creeper.getZ(), 60, 1.2, 0.8, 1.2, 0.06);
        w.playSound(null, creeper.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 0.5f, 1.6f);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (valido(p) && p.squaredDistanceTo(creeper) <= 16) p.setOnFireFor(6f);
        }
    }

    // ------------------------------------------------------------------ cerca de los jugadores (servidor)

    /** Cada 2 ticks: los murciélagos despiertos a menos de 8 bloques van hacia el jugador y, si le rozan, le muerden. */
    private static void murcielagos(ServerWorld w, ServerPlayerEntity p, int ahora) {
        List<BatEntity> cerca = w.getEntitiesByClass(BatEntity.class, p.getBoundingBox().expand(8), b -> b.isAlive() && !b.isRoosting());
        if (cerca.isEmpty()) return;
        Vec3d pecho = new Vec3d(p.getX(), p.getBodyY(0.6), p.getZ());
        for (BatEntity bat : cerca) {
            Vec3d hacia = pecho.subtract(bat.getPos());
            if (hacia.lengthSquared() < 1.0E-4) continue;
            Vec3d dir = hacia.normalize();
            if (bat.getBoundingBox().expand(0.25).intersects(p.getBoundingBox())) {
                Integer ultimo = MORDISCOS.get(p.getUuid());
                if (ultimo == null || ahora - ultimo >= 40 || ahora < ultimo) {
                    MORDISCOS.put(p.getUuid(), ahora);
                    p.damage(bat.getDamageSources().mobAttack(bat), 1f);
                    bat.heal(1f);
                    bat.setVelocity(dir.multiply(-0.5));       // se aparta tras el mordisco
                    continue;
                }
            }
            if (bat.getVelocity().dotProduct(dir) < 0.5) bat.setVelocity(bat.getVelocity().add(dir.multiply(0.1)));   // sin pasarse de rápido
        }
    }

    /** Cada segundo: las arañas que te persiguen saltan hacia ti (cada araña, como mucho una vez cada 3 s). */
    private static void aranasSaltan(ServerWorld w, ServerPlayerEntity p) {
        List<SpiderEntity> aranas = w.getEntitiesByClass(SpiderEntity.class, p.getBoundingBox().expand(10),
                s -> (s.getType() == EntityType.SPIDER || s.getType() == EntityType.CAVE_SPIDER) && s.isAlive()
                        && s.getTarget() == p && s.isOnGround() && s.age % 60 < 20);
        for (SpiderEntity arana : aranas) {
            double dx = p.getX() - arana.getX(), dz = p.getZ() - arana.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < 3 || d > 10 || !arana.canSee(p)) continue;
            double vh = Math.min(1.2, (d - 0.8) * 0.123);                            // aterriza más o menos a tus pies
            double vy = 0.5 + Math.max(0, Math.min(3, p.getY() - arana.getY())) * 0.06;
            arana.setVelocity(dx / d * vh, vy, dz / d * vh);
            arana.velocityModified = true;
            w.playSound(null, arana.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.HOSTILE, 0.6f, 1.6f);
        }
    }

    /** Cada segundo: el Zombie Naranja al sol se cura medio corazón. */
    private static void broncear(ServerWorld w, ServerPlayerEntity p, Set<Entity> curados) {
        if (!w.isDay() || w.isRaining()) return;   // en el Nether y el End nunca es "de día"
        List<ZombieNaranjaEntity> zombis = w.getEntitiesByClass(ZombieNaranjaEntity.class, p.getBoundingBox().expand(32),
                zn -> zn.isAlive() && zn.getHealth() < zn.getMaxHealth());
        for (ZombieNaranjaEntity z : zombis) {
            if (!curados.add(z) || !w.isSkyVisible(z.getBlockPos().up())) continue;
            z.heal(1f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, z.getX(), z.getY() + 2.1, z.getZ(), 2, 0.3, 0.2, 0.3, 0);
        }
    }

    /** Cada segundo: Ale lanza un Travensaño si te persigue y estás a 5-15 bloques (cada Ale, una vez cada 10 s). */
    private static void aleLanza(ServerWorld w, ServerPlayerEntity p, EstadoServidor estado) {
        List<AleEntity> ales = w.getEntitiesByClass(AleEntity.class, p.getBoundingBox().expand(16),
                a -> a.isAlive() && a.getTarget() == p && a.age % 200 < 20);
        for (AleEntity ale : ales) {
            double d = ale.distanceTo(p);
            if (d < 5 || d > 15 || !ale.canSee(p) || Reglas.enSpawn(w, ale.getBlockPos(), estado)) continue;
            if (w.getEntitiesByClass(TravensanoEntity.class, ale.getBoundingBox().expand(16), t -> t.isAlive()).size() >= 4) continue;
            lanzarTravensano(w, ale, p);
        }
    }

    private static void lanzarTravensano(ServerWorld w, AleEntity ale, ServerPlayerEntity p) {
        double dx = p.getX() - ale.getX(), dz = p.getZ() - ale.getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 0.01) return;
        double ux = dx / d, uz = dz / d;
        TravensanoEntity t = ModEntidades.TRAVENSANO.create(w);
        if (t == null) return;
        t.refreshPositionAndAngles(ale.getX() + ux * 0.7, ale.getY() + 1.2, ale.getZ() + uz * 0.7, ale.getYaw(), 0f);
        if (!w.isSpaceEmpty(t)) return;                                              // sin hueco delante: esta vez no
        double vh = Math.min(1.6, (d - 1.0) / 8.7);                                  // cae más o menos donde estás
        double vy = 0.6 + Math.max(0, Math.min(4, p.getY() - ale.getY())) * 0.08;
        t.setVelocity(ux * vh, vy, uz * vh);
        t.setTarget(p);
        if (ale.getCommandTags().contains(JefeTeleEntity.MARCA_ESBIRRO)) t.addCommandTag(JefeTeleEntity.MARCA_ESBIRRO);
        w.spawnEntity(t);
        ale.swingHand(Hand.MAIN_HAND);
        w.playSound(null, ale.getBlockPos(), SoundEvents.ENTITY_GOAT_LONG_JUMP, SoundCategory.HOSTILE, 1f, 0.8f);
        w.playSound(null, ale.getBlockPos(), SoundEvents.ENTITY_VILLAGER_YES, SoundCategory.HOSTILE, 1f, 1.5f);
    }

    /** Cada 2 segundos, de noche en el Overworld: los lobos salvajes adultos a menos de 8 bloques van a por el jugador. */
    private static void lobosDeNoche(ServerWorld w, ServerPlayerEntity p) {
        if (w.getRegistryKey() != World.OVERWORLD || w.isDay()) return;
        List<WolfEntity> lobos = w.getEntitiesByClass(WolfEntity.class, p.getBoundingBox().expand(8),
                l -> l.isAlive() && !l.isTamed() && !l.isBaby() && l.getTarget() == null && l.squaredDistanceTo(p) <= 64);
        for (WolfEntity lobo : lobos) {
            lobo.setAngryAt(p.getUuid());
            lobo.setAngerTime(300);
            lobo.setTarget(p);
            w.playSound(null, lobo.getBlockPos(), SoundEvents.ENTITY_WOLF_AMBIENT, SoundCategory.HOSTILE, 1f, 0.6f);
        }
    }
}

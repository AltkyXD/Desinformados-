package com.centrodesinformacion.desinformados;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.block.Blocks;
import org.jetbrains.annotations.Nullable;

/**
 * Máquina tragamonedas de 2 bloques de ancho x 3 de alto (tres partes apiladas).
 * Se coloca desde abajo; si se quita cualquier parte, desaparece entera.
 */
public class TragamonedasBlock extends HorizontalFacingBlock {
    public enum Parte implements StringIdentifiable {
        BAJO("bajo"), MEDIO("medio"), ALTO("alto");
        private final String nombre;
        Parte(String n) { nombre = n; }
        @Override public String asString() { return nombre; }
    }

    public static final EnumProperty<Parte> PARTE = EnumProperty.of("parte", Parte.class);

    private static final VoxelShape FORMA_NS = Block.createCuboidShape(-8, 0, 1, 24, 16, 16);
    private static final VoxelShape FORMA_EO = Block.createCuboidShape(0, 0, -8, 15, 16, 24);

    private final Tragamonedas.Rareza rareza;
    private final MapCodec<TragamonedasBlock> codec;

    public TragamonedasBlock(Settings settings, Tragamonedas.Rareza rareza) {
        super(settings);
        this.rareza = rareza;
        this.codec = createCodec(s -> new TragamonedasBlock(s, rareza));
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PARTE, Parte.BAJO));
    }

    public Tragamonedas.Rareza getRareza() { return rareza; }

    @Override
    protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return codec; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PARTE);
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        BlockPos pos = ctx.getBlockPos();
        World w = ctx.getWorld();
        if (pos.getY() > w.getTopY() - 3) return null;
        if (!w.getBlockState(pos.up()).canReplace(ctx) || !w.getBlockState(pos.up(2)).canReplace(ctx)) return null;
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite()).with(PARTE, Parte.BAJO);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        world.setBlockState(pos.up(), state.with(PARTE, Parte.MEDIO), Block.NOTIFY_ALL);
        world.setBlockState(pos.up(2), state.with(PARTE, Parte.ALTO), Block.NOTIFY_ALL);
    }

    /** Si falta la parte de arriba o de abajo, esta parte también desaparece. */
    @Override
    protected BlockState getStateForNeighborUpdate(BlockState state, Direction dir, BlockState vecino, WorldAccess world, BlockPos pos, BlockPos posVecino) {
        Parte p = state.get(PARTE);
        boolean necesitaArriba = p != Parte.ALTO, necesitaAbajo = p != Parte.BAJO;
        if (dir == Direction.UP && necesitaArriba && !(vecino.isOf(this) && vecino.get(PARTE).ordinal() == p.ordinal() + 1)) return Blocks.AIR.getDefaultState();
        if (dir == Direction.DOWN && necesitaAbajo && !(vecino.isOf(this) && vecino.get(PARTE).ordinal() == p.ordinal() - 1)) return Blocks.AIR.getDefaultState();
        return super.getStateForNeighborUpdate(state, dir, vecino, world, pos, posVecino);
    }

    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        if (state.get(PARTE) == Parte.BAJO) return true;
        BlockState abajo = world.getBlockState(pos.down());
        return abajo.isOf(this) && abajo.get(PARTE).ordinal() == state.get(PARTE).ordinal() - 1;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        Direction f = state.get(FACING);
        return (f == Direction.NORTH || f == Direction.SOUTH) ? FORMA_NS : FORMA_EO;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient() && player instanceof ServerPlayerEntity p) {
            BlockPos base = pos.down(state.get(PARTE).ordinal());
            Tragamonedas.tirar(p, base, rareza, state.get(FACING));
        }
        return ActionResult.SUCCESS;
    }
}

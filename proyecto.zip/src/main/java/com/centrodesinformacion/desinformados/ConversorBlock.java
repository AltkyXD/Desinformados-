package com.centrodesinformacion.desinformados;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

/**
 * Conversor Difamónico (2x1). Clic derecho con una pieza en la mano:
 *  - diamante  + 1 lingote de netherite (del inventario) -> netherite
 *  - netherite + 4 Garatitas (del inventario)            -> Garatita
 * Se conservan encantamientos, nombre y durabilidad.
 */
public class ConversorBlock extends HorizontalFacingBlock {
    public static final MapCodec<ConversorBlock> CODEC = createCodec(ConversorBlock::new);
    public static final BooleanProperty DERECHA = BooleanProperty.of("derecha");
    public static final BooleanProperty ACTIVO = BooleanProperty.of("activo");
    public static final int COSTE_GARATITA = 4;

    public static final Map<Item, Item> A_NETHERITE = Map.ofEntries(
            Map.entry(Items.DIAMOND_HELMET, Items.NETHERITE_HELMET), Map.entry(Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE),
            Map.entry(Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS), Map.entry(Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS),
            Map.entry(Items.DIAMOND_SWORD, Items.NETHERITE_SWORD), Map.entry(Items.DIAMOND_PICKAXE, Items.NETHERITE_PICKAXE),
            Map.entry(Items.DIAMOND_AXE, Items.NETHERITE_AXE), Map.entry(Items.DIAMOND_SHOVEL, Items.NETHERITE_SHOVEL),
            Map.entry(Items.DIAMOND_HOE, Items.NETHERITE_HOE));
    public static final Map<Item, Item> A_GARATITA = Map.ofEntries(
            Map.entry(Items.NETHERITE_HELMET, ModGaratita.CASCO), Map.entry(Items.NETHERITE_CHESTPLATE, ModGaratita.PETO),
            Map.entry(Items.NETHERITE_LEGGINGS, ModGaratita.PANTALONES), Map.entry(Items.NETHERITE_BOOTS, ModGaratita.BOTAS),
            Map.entry(Items.NETHERITE_SWORD, ModGaratita.ESPADA), Map.entry(Items.NETHERITE_PICKAXE, ModGaratita.PICO),
            Map.entry(Items.NETHERITE_AXE, ModGaratita.HACHA), Map.entry(Items.NETHERITE_SHOVEL, ModGaratita.PALA),
            Map.entry(Items.NETHERITE_HOE, ModGaratita.AZADA));

    public ConversorBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(DERECHA, false).with(ACTIVO, false));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, DERECHA, ACTIVO);
    }

    /** Hacia dónde está la mitad derecha (vista de frente). */
    private static Direction derecha(BlockState s) {
        return s.get(FACING).rotateYCounterclockwise();
    }

    private static BlockPos otraMitad(BlockState s, BlockPos pos) {
        return s.get(DERECHA) ? pos.offset(derecha(s).getOpposite()) : pos.offset(derecha(s));
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        BlockState s = getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
        if (!ctx.getWorld().getBlockState(ctx.getBlockPos().offset(derecha(s))).canReplace(ctx)) return null;
        return s;
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        world.setBlockState(pos.offset(derecha(state)), state.with(DERECHA, true), Block.NOTIFY_ALL);
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this)) {
            BlockPos otra = otraMitad(state, pos);
            if (world.getBlockState(otra).isOf(this)) world.removeBlock(otra, false);
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient()) {
            player.sendMessage(Text.literal("El Conversor Difamónico te mira... Tráele una pieza de diamante (+1 lingote de netherite) o de netherite (+"
                    + COSTE_GARATITA + " Garatitas).").formatted(Formatting.LIGHT_PURPLE), true);
        }
        return ActionResult.SUCCESS;
    }

    @Override
    protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        Item resultado;
        Item pago;
        int coste;
        if (A_NETHERITE.containsKey(stack.getItem())) {
            resultado = A_NETHERITE.get(stack.getItem()); pago = Items.NETHERITE_INGOT; coste = 1;
        } else if (A_GARATITA.containsKey(stack.getItem())) {
            resultado = A_GARATITA.get(stack.getItem()); pago = ModItems.GARATITA; coste = COSTE_GARATITA;
        } else {
            return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (world.isClient()) return ItemActionResult.SUCCESS;

        if (!player.isCreative()) {
            if (player.getInventory().count(pago) < coste) {
                player.sendMessage(Text.literal("Te falta: " + coste + "x " + pago.getName().getString()).formatted(Formatting.RED), true);
                world.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 1f, 0.5f);
                return ItemActionResult.CONSUME;
            }
            cobrar(player, pago, coste);
        }
        player.setStackInHand(hand, stack.copyComponentsToNewStack(resultado, 1));

        // ¡Efectos!
        world.playSound(null, pos, SoundEvents.BLOCK_SMITHING_TABLE_USE, SoundCategory.BLOCKS, 1f, 0.8f);
        world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.BLOCKS, 1f, 1.4f);
        if (world instanceof ServerWorld sw) {
            BlockPos centro = state.get(DERECHA) ? pos.offset(derecha(state).getOpposite()) : pos;
            double cx = centro.getX() + 0.5 + derecha(state).getOffsetX() * 0.5;
            double cz = centro.getZ() + 0.5 + derecha(state).getOffsetZ() * 0.5;
            sw.spawnParticles(ParticleTypes.WITCH, cx, pos.getY() + 1.1, cz, 30, 0.6, 0.3, 0.6, 0.05);
            sw.spawnParticles(ParticleTypes.ENCHANT, cx, pos.getY() + 1.0, cz, 40, 0.6, 0.4, 0.6, 0.5);
        }
        activar(world, pos, state);
        if (resultado == ModGaratita.AZADA) {
            player.sendMessage(Text.literal("¿En serio?").formatted(Formatting.GRAY, Formatting.ITALIC), false);
        }
        return ItemActionResult.SUCCESS;
    }

    private static void cobrar(PlayerEntity player, Item item, int n) {
        var inv = player.getInventory();
        for (int i = 0; i < inv.size() && n > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(item)) continue;
            int quita = Math.min(n, s.getCount());
            s.decrement(quita);
            n -= quita;
        }
    }

    /** Los ojos se ponen "en trance" un momento. */
    private void activar(World world, BlockPos pos, BlockState state) {
        BlockPos otra = otraMitad(state, pos);
        world.setBlockState(pos, state.with(ACTIVO, true), Block.NOTIFY_ALL);
        BlockState so = world.getBlockState(otra);
        if (so.isOf(this)) world.setBlockState(otra, so.with(ACTIVO, true), Block.NOTIFY_ALL);
        world.scheduleBlockTick(pos, this, 30);
        world.scheduleBlockTick(otra, this, 30);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (state.get(ACTIVO)) world.setBlockState(pos, state.with(ACTIVO, false), Block.NOTIFY_ALL);
    }

    // ---------- La placa de mejora de netherite ya no existe ----------
    public static void registrar() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (var p : server.getPlayerManager().getPlayerList()) {
                if (p.isCreative()) continue;
                var inv = p.getInventory();
                for (int i = 0; i < inv.size(); i++) {
                    if (inv.getStack(i).isOf(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE)) inv.setStack(i, ItemStack.EMPTY);
                }
            }
        });
    }
}

package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/**
 * "¡Hay más monstruos!" (tele amarilla, a mitad de las teles de mobs de la lista): desde que sale, el límite de monstruos
 * sube un 30 % en todas las dimensiones (SpawnGroupMixin), así que aparecen un 30 % más. Se suma a la Noche de Sangre.
 */
public final class MasMobs {
    private MasMobs() {}

    public static final String ID = "mas_mobs";
    public static final float FACTOR = 1.3f;

    /** Lo lee SpawnGroupMixin. Se actualiza una vez por segundo desde el estado del mundo. */
    public static volatile boolean activo = false;

    static void evento() {
        Eventos.amarillo(ID, "¡Hay más monstruos!",
                "A partir de ahora aparecen un 30% más de monstruos en todas partes: el límite de mobs hostiles del mundo sube un 30%. "
                        + "En las Noches de Sangre se suma (el triple, y encima un 30% más).",
                "El Centro de Desinformación ha abierto una bolsa de empleo para monstruos y se ha apuntado muchísima gente. "
                        + "Como no había presupuesto para entrevistas, los han contratado a todos.",
                server -> {
                    EstadoServidor.get(server).agregarCambio(ID);
                    activo = true;
                });
    }

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 == 0) activo = EstadoServidor.get(server).tieneCambio(ID);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> activo = false);
    }
}

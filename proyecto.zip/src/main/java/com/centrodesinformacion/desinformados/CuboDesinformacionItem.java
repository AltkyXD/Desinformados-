package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Desinformación Pura (antes "Cubo de la Desinformación"). Al usarlo sale flotando donde lo usaste, gira cargándose de estática
 * durante 5 segundos y estalla... rompiendo la Tele Gigante (como /desinfo portal tele romper).
 */
public class CuboDesinformacionItem extends Item {
    private static final int DURACION = 100; // 5 s de animación

    public CuboDesinformacionItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world instanceof ServerWorld sw) {
            Vec3d pos = player.getEyePos().add(player.getRotationVec(1f).multiply(2.0));
            if (activar(sw, player, pos)) stack.decrementUnlessCreative(1, player);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (ctx.getWorld() instanceof ServerWorld sw && ctx.getPlayer() != null) {
            Vec3d pos = Vec3d.ofBottomCenter(ctx.getBlockPos().offset(ctx.getSide())).add(0, 0.6, 0);
            if (activar(sw, ctx.getPlayer(), pos)) ctx.getStack().decrementUnlessCreative(1, ctx.getPlayer());
        }
        return ActionResult.success(ctx.getWorld().isClient());
    }

    private boolean activar(ServerWorld w, PlayerEntity p, Vec3d pos) {
        MinecraftServer server = w.getServer();
        if (EstadoServidor.get(server).getTelesPortal().isEmpty()) {
            p.sendMessage(Text.literal("La Desinformación Pura vibra... pero no hay ninguna Tele Gigante que romper.").formatted(Formatting.DARK_PURPLE), true);
            return false;
        }
        ItemEntity orbe = new ItemEntity(w, pos.x, pos.y, pos.z, new ItemStack(this));
        orbe.setNoGravity(true);
        orbe.setPickupDelayInfinite();
        orbe.setNeverDespawn();
        orbe.setInvulnerable(true);
        orbe.setVelocity(Vec3d.ZERO);
        w.spawnEntity(orbe);
        w.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.5f, 0.6f);
        w.playSound(null, pos.x, pos.y, pos.z, ModSounds.TV_ESTATICA, SoundCategory.PLAYERS, 1.0f, 0.7f);

        for (int t = 1; t < DURACION; t++) {
            final int tick = t;
            Tareas.programar(t, () -> {
                if (orbe.isRemoved()) return;
                float progreso = tick / (float) DURACION;
                // sube despacio y tiembla cada vez más
                double temblor = progreso > 0.6f ? (progreso - 0.6f) * 0.25 : 0;
                orbe.setVelocity((w.getRandom().nextDouble() - 0.5) * temblor, 0.015, (w.getRandom().nextDouble() - 0.5) * temblor);
                orbe.velocityModified = true;
                Vec3d c = orbe.getPos().add(0, 0.25, 0);
                // anillos de estática girando alrededor
                double radio = 1.4 - progreso * 0.9;
                for (int k = 0; k < 3; k++) {
                    double ang = tick * 0.35 + k * (Math.PI * 2 / 3);
                    w.spawnParticles(ParticleTypes.END_ROD, c.x + Math.cos(ang) * radio, c.y + Math.sin(tick * 0.2 + k) * 0.3,
                            c.z + Math.sin(ang) * radio, 1, 0, 0, 0, 0);
                }
                if (tick % 2 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 2 + (int) (progreso * 8), 0.4, 0.4, 0.4, 0.15);
                if (tick % 4 == 0) w.spawnParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 10, 0.6, 0.6, 0.6, 0.6);
                if (tick % 20 == 0) {
                    w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.PLAYERS, 1.5f,
                            MathHelper.lerp(progreso, 0.6f, 2.0f));
                }
                if (tick == DURACION - 20) w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.PLAYERS, 0.8f, 1.6f);
            });
        }
        Tareas.programar(DURACION, () -> {
            Vec3d c = orbe.getPos().add(0, 0.25, 0);
            orbe.discard();
            // ¡estallido épico!
            w.spawnParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 3, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 150, 0.2, 0.2, 0.2, 0.45);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 120, 1.5, 1.5, 1.5, 0.6);
            w.spawnParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 200, 0.5, 0.5, 0.5, 1.2);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 2.0f, 0.7f);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 2.0f, 0.5f);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_WITHER_BREAK_BLOCK, SoundCategory.PLAYERS, 1.0f, 1.2f);
            // ...y la Tele Gigante se rompe
            Dimensiones.romperTeles(server, true);
        });
        return true;
    }
}

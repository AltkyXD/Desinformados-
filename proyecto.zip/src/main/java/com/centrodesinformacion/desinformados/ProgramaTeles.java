package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import com.centrodesinformacion.desinformados.intro.Final;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.command.CommandSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Teles automáticas: lanzan solas, una a una y en orden, las teles amarillas, azules y naranjas
 * (la lista progresiva por actos). Se pueden pausar y reanudar cuando queráis con /desinfo auto.
 * - Se activan SOLAS cuando el primer jugador llega al Centro (al acabar la intro): la primera sale a los 20 minutos.
 * - Después, cada una sale al azar entre 20 y 40 minutos de juego tras la anterior.
 * - DESAFÍOS ROJOS (reloj aparte): la primera 1 h 20 min no sale ninguno; después, uno al azar cada 30-60 minutos.
 *   No se repite ninguno hasta que hayan salido todos.
 * - Solo cuenta el tiempo mientras hay alguien jugando (no espectadores).
 * - Si una tele ya salió (lanzada a mano o activada), se la salta.
 * - Espera si hay un desafío rojo en marcha, si está el jefe final o si está la cinemática final.
 * - Las del Nether esperan a que se abra el Nether, la de la Libreta a que se abra la Libreta, y las últimas al End.
 */
public final class ProgramaTeles {
    public record Paso(String parte, String id) {}

    public static final List<Paso> LISTA = List.of(
            new Paso("1A", "arboles"), new Paso("1A", "furros"), new Paso("1A", "aranas_pequenas"), new Paso("1A", "aldeanos_caros"),
            new Paso("1A", "cubo_blanco"),
            new Paso("1B", "objetos_catapulta"), new Paso("1B", "zombies_falsos"), new Paso("1B", "garabatos"), new Paso("1B", "comida_podrida"),
            new Paso("1B", "furros_manada"),
            new Paso("2A", "creepers_oscuros"), new Paso("2A", "ovejas_sin_lana"), new Paso("2A", "zombie_naranja"), new Paso("2A", "esqueletos_doble_arco"),
            new Paso("2A", "sed_cuevas"), new Paso("2A", "travensanos"), new Paso("2A", "cubo_gigante"),
            new Paso("2B", "interferencia"), new Paso("2B", "fuego_eterno"), new Paso("2B", "garabatos_altos"), new Paso("2B", "camas_rotas"),
            new Paso("2B", "brandon_kevin"), new Paso("2B", "creeper_invisible"),
            new Paso("3A", "ale"), new Paso("3A", "cultivos_lentos"), new Paso("3A", "travensanos_furiosos"), new Paso("3A", "ulises"),
            new Paso("3A", "hornos_glotones"), new Paso("3A", "bebes_rapidos"), new Paso("3A", "altky"),
            new Paso("3B", "leche_cortada"), new Paso("3B", "interferencias_clon"), new Paso("3B", "angel"), new Paso("3B", "antorchas_apagan"),
            new Paso("3B", "ale_poderoso"), new Paso("3B", "brandon_mejorado"),
            // (los mobs del Nether y sus 8 mejoras van aparte, en ColaNether: llegan solos 30 minutos después de pisar el Nether)
            new Paso("4A", "agua_escasa"), new Paso("4A", "esprintar_agota"), new Paso("4A", "armadura_oxidada"),
            new Paso("4B", "mobs_cruzados"), new Paso("4B", "altky_tableta"), new Paso("4B", "creepers_electrificados"),
            new Paso("5", "libreta_mejorada"), new Paso("5", "encantamientos_caros"), new Paso("5", "ulises_rapido"), new Paso("5", "herramientas_fragiles"),
            new Paso("5", "suelos_resbaladizos"), new Paso("5", "caidas_duras"), new Paso("5", "regeneracion_lenta"));

    private static final int ESPERA_REINTENTO = 20 * 60;    // si toca esperar (desafío, jefe...), vuelve a mirar en 1 minuto
    private static final int PRIMERA = 20 * 60 * 20;          // la primera, 20 minutos después de que llegue el primero al Centro
    private static final String ARRANCADO = "sys:auto_arrancado";
    private static final int PRIMER_ROJO = 20 * 60 * 80;      // 1 h 20 min sin desafíos rojos
    private static final int SEPARACION = 20 * 60 * 3;        // nunca dos teles con menos de 3 minutos entre medias
    private static int ultimaTele = -100000;                  // tick del servidor de la última tele automática
    private static final String ROJO_USADO = "sys:rojo_usado:";
    /** Al romperse la tele, los desafíos rojos automáticos se apagan: desde ahí las teles rojas son cosa del jefe. */
    public static final String ROJOS_APAGADOS = "sys:rojos_auto_apagados";

    private static int rojoAlAzar(EstadoServidor e) {
        int min = e.getRojoMinimo() / 20, max = Math.max(min, e.getRojoMaximo() / 20);
        return 20 * (min + AZAR.nextInt(max - min + 1));
    }

    /** Un desafío rojo al azar que no haya salido todavía en esta ronda (cuando salen todos, se empieza otra ronda). */
    private static String rojoSiguiente(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        List<String> libres = new java.util.ArrayList<>();
        for (String id : Desafios.ids()) if (!e.tieneCambio(ROJO_USADO + id)) libres.add(id);
        if (libres.isEmpty()) {
            for (String id : Desafios.ids()) e.quitarCambio(ROJO_USADO + id);
            libres.addAll(Desafios.ids());
        }
        return libres.isEmpty() ? null : libres.get(AZAR.nextInt(libres.size()));
    }

    private static void lanzarRojo(MinecraftServer s, String id) {
        EstadoServidor.get(s).agregarCambio(ROJO_USADO + id);
        var d = Desafios.lanzar(s, id);
        ultimaTele = s.getTicks();
        avisarAdmins(s, Text.literal("Desafío rojo: ").formatted(Formatting.GRAY).append(Text.literal(d.getTitulo()).formatted(Formatting.RED)));
    }

    /** El reloj de los desafíos rojos (va aparte del de las teles de la lista). */
    private static void tickRojos(MinecraftServer s, EstadoServidor e) {
        if (e.tieneCambio(ROJOS_APAGADOS)) return;
        int restante = e.getRojoRestante() - 20;
        if (restante == 20 * 60) avisarAdmins(s, Text.literal("Próximo desafío rojo en 1 minuto.").formatted(Formatting.GRAY));
        if (restante > 0) { e.setRojoRestante(restante); return; }
        if (ocupado(s) != null || s.getTicks() - ultimaTele < SEPARACION) { e.setRojoRestante(ESPERA_REINTENTO); return; }
        String id = rojoSiguiente(s);
        if (id == null) { e.setRojoRestante(rojoAlAzar(e)); return; }
        lanzarRojo(s, id);
        e.setRojoRestante(rojoAlAzar(e));
    }
    private static final java.util.Random AZAR = new java.util.Random();

    /** Ticks hasta la próxima: al azar entre el mínimo y el máximo (en segundos enteros). */
    private static int proximoAlAzar(EstadoServidor e) {
        int min = e.getAutoMinimo() / 20, max = Math.max(min, e.getAutoMaximo() / 20);
        return 20 * (min + AZAR.nextInt(max - min + 1));
    }

    /** El primer jugador ha llegado al Centro: las teles automáticas se ponen en marcha solas (una sola vez en todo el mundo). */
    public static void alLlegarAlCentro(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        if (e.tieneCambio(ARRANCADO)) return;
        e.agregarCambio(ARRANCADO);
        e.setAutoRestante(PRIMERA);
        e.setRojoRestante(PRIMER_ROJO);
        e.setAutoActivo(true);
        avisarAdmins(s, Text.literal("Teles automáticas ACTIVADAS: la primera sale en 20 minutos de juego y el primer desafío rojo en 1 h 20 min. "
                + "Pausa: /desinfo auto pausar").formatted(Formatting.GREEN));
    }
    private static String ultimoBloqueo = null;

    // ------------------------------------------------------------------ estado de cada tele

    private static int numero(Paso p) { return LISTA.indexOf(p) + 1; }

    public static boolean lanzada(MinecraftServer s, String id) {
        return EstadoServidor.get(s).tieneCambio("evento:" + id);
    }

    public static boolean saltada(MinecraftServer s, String id) {
        return EstadoServidor.get(s).tieneCambio("sys:auto_saltada:" + id);
    }

    /** La próxima tele de la lista que aún no ha salido (ni se ha saltado). */
    public static Paso siguiente(MinecraftServer s) {
        for (Paso p : LISTA) if (!lanzada(s, p.id()) && !saltada(s, p.id())) return p;
        return null;
    }

    /** Qué falta para poder lanzar esta tele (null = nada). */
    public static String requisito(MinecraftServer s, Paso p) {
        EstadoServidor e = EstadoServidor.get(s);
        if ((p.parte().startsWith("4")) && !e.tieneCambio("nether_abierto"))
            return "abrir el Nether (/desinfo lanzar nether)";
        if (p.id().equals("libreta_mejorada") && !Eventos.puedeLanzarse(s, p.id()))
            return "abrir la Libreta del Becario";
        if ((p.id().equals("suelos_resbaladizos") || p.id().equals("caidas_duras") || p.id().equals("regeneracion_lenta"))
                && !e.tieneCambio("end_abierto"))
            return "abrir el End (/desinfo lanzar end)";
        return null;
    }

    /** Para otras colas de teles (ColaNether): ¿se puede lanzar una ahora? (null = sí; si no, el motivo) */
    static String puedeSalirOtra(MinecraftServer s) {
        String o = ocupado(s);
        if (o != null) return o;
        return s.getTicks() - ultimaTele < SEPARACION ? "acaba de salir otra tele" : null;
    }

    static void marcarTele(MinecraftServer s) {
        ultimaTele = s.getTicks();
    }

    /** ¿Algo que impide lanzar una tele ahora mismo (sin ser culpa de la lista)? */
    private static String ocupado(MinecraftServer s) {
        if (Desafios.hayEnCurso()) return "hay un desafío rojo en marcha";
        if (Final.enCurso()) return "está la cinemática final";
        for (ServerWorld w : s.getWorlds())
            if (!w.getEntitiesByType(com.centrodesinformacion.desinformados.entidad.ModEntidades.JEFE_TELE, j -> j.isAlive()).isEmpty())
                return "está el jefe final";
        return null;
    }

    private static boolean hayJugando(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) if (!p.isSpectator()) return true;
        return false;
    }

    /** Avisa solo a los admins (para que el público del video no lo vea en el chat de los demás). */
    /**
     * Avisos "[Auto]" para los admins. Están apagados por defecto (para que no salgan en los vídeos);
     * se encienden con /desinfo auto avisos si. El estado siempre se puede consultar con /desinfo auto.
     */
    static void avisarAdmins(MinecraftServer s, Text t) {
        if (!EstadoServidor.get(s).tieneCambio(AVISOS)) return;
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList())
            if (p.hasPermissionLevel(2)) p.sendMessage(Text.literal("[Auto] ").formatted(Formatting.DARK_AQUA).append(t), false);
    }

    private static final String AVISOS = "sys:auto_avisos";

    private static String titulo(String id) {
        Eventos.Evento ev = Eventos.TODOS.get(id);
        return ev != null ? ev.titulo() : id;
    }

    private static Formatting colorDe(String id) {
        Eventos.Evento ev = Eventos.TODOS.get(id);
        if (ev == null) return Formatting.WHITE;
        return switch (ev.color()) {
            case "azul" -> Formatting.BLUE;
            case "naranja" -> Formatting.GOLD;
            default -> Formatting.YELLOW;
        };
    }

    /** Lanza la tele (como /desinfo lanzar). */
    private static boolean lanzar(MinecraftServer s, Paso p) {
        Eventos.Evento ev = Eventos.TODOS.get(p.id());
        if (ev == null) {
            EstadoServidor.get(s).agregarCambio("sys:auto_saltada:" + p.id());
            return false;
        }
        Eventos.lanzar(s, ev);
        avisarAdmins(s, Text.literal("Tele #" + numero(p) + "/" + LISTA.size() + " (" + p.parte() + "): ").formatted(Formatting.GRAY)
                .append(Text.literal(ev.titulo()).formatted(colorDe(p.id()))));
        return true;
    }

    // ------------------------------------------------------------------ reloj

    public static void registrar() {
        // Mundos que arrancaron con la espera vieja de 30 min: si la primera tele aún no ha salido, como mucho 20 min
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            // los ticks del servidor vuelven a 0 en cada arranque: lo de la sesión anterior (LAN, un jugador) no vale
            ultimaTele = -100000;
            ultimoBloqueo = null;
            EstadoServidor e = EstadoServidor.get(s);
            if (e.tieneCambio(ARRANCADO) && siguiente(s) == LISTA.get(0) && e.getAutoRestante() > PRIMERA) e.setAutoRestante(PRIMERA);
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (s.getTicks() % 20 != 0) return;
            EstadoServidor e = EstadoServidor.get(s);
            if (!e.isAutoActivo()) return;
            if (Final.serieTerminada(s)) { e.setAutoActivo(false); return; }
            if (!hayJugando(s)) return;                                                // sin jugadores, el reloj se para
            tickRojos(s, e);
            int restante = e.getAutoRestante() - 20;
            if (restante == 20 * 60) {
                Paso p = siguiente(s);
                if (p != null && requisito(s, p) == null)
                    avisarAdmins(s, Text.literal("Próxima tele en 1 minuto: ").formatted(Formatting.GRAY)
                            .append(Text.literal(titulo(p.id())).formatted(colorDe(p.id()))));
            }
            if (restante > 0) { e.setAutoRestante(restante); return; }

            Paso p = siguiente(s);
            if (p == null) {
                e.setAutoActivo(false);
                avisarAdmins(s, Text.literal("Ya salieron todas las teles de la lista. Teles automáticas apagadas.").formatted(Formatting.GREEN));
                return;
            }
            String falta = requisito(s, p);
            if (falta == null) falta = ocupado(s);
            if (falta == null && s.getTicks() - ultimaTele < SEPARACION) falta = "acaba de salir otra tele";
            if (falta != null) {
                e.setAutoRestante(ESPERA_REINTENTO);
                String clave = p.id() + "|" + falta;
                if (!clave.equals(ultimoBloqueo)) {                                    // avisa una vez por cada motivo
                    ultimoBloqueo = clave;
                    avisarAdmins(s, Text.literal("La próxima tele (" + titulo(p.id()) + ") espera: " + falta + ".").formatted(Formatting.GRAY));
                }
                return;
            }
            ultimoBloqueo = null;
            lanzar(s, p);
            ultimaTele = s.getTicks();
            e.setAutoRestante(proximoAlAzar(e));
        });
        CommandRegistrationCallback.EVENT.register((d, acceso, entorno) -> d.register(literal("desinfo").requires(src -> src.hasPermissionLevel(2))
                .then(literal("auto")
                        .executes(ProgramaTeles::estado)
                        .then(literal("iniciar").executes(c -> {
                            EstadoServidor e = EstadoServidor.get(c.getSource().getServer());
                            if (e.getAutoRestante() <= 0) e.setAutoRestante(proximoAlAzar(e));
                            e.agregarCambio(ARRANCADO);
                            e.setAutoActivo(true);
                            c.getSource().sendFeedback(() -> Text.literal("Teles automáticas ACTIVADAS. ").formatted(Formatting.GREEN)
                                    .append(Text.literal("Próxima en " + tiempo(e.getAutoRestante()) + ".").formatted(Formatting.GRAY)), true);
                            return 1;
                        }))
                        .then(literal("pausar").executes(c -> {
                            EstadoServidor e = EstadoServidor.get(c.getSource().getServer());
                            e.agregarCambio(ARRANCADO);                                    // si se pausa antes de empezar, ya no arranca solo
                            e.setAutoActivo(false);
                            c.getSource().sendFeedback(() -> Text.literal("Teles automáticas en PAUSA (el reloj se queda en " + tiempo(e.getAutoRestante())
                                    + "). Para seguir: /desinfo auto iniciar").formatted(Formatting.YELLOW), true);
                            return 1;
                        }))
                        .then(literal("intervalo").then(argument("minimo", IntegerArgumentType.integer(1, 600))
                                .then(argument("maximo", IntegerArgumentType.integer(1, 600)).executes(c -> {
                                    int min = IntegerArgumentType.getInteger(c, "minimo"), max = Math.max(min, IntegerArgumentType.getInteger(c, "maximo"));
                                    EstadoServidor e = EstadoServidor.get(c.getSource().getServer());
                                    e.setAutoRango(min * 1200, max * 1200);
                                    if (e.getAutoRestante() > max * 1200) e.setAutoRestante(proximoAlAzar(e));
                                    c.getSource().sendFeedback(() -> Text.literal("Ahora sale una tele al azar cada " + min + "-" + max + " minutos de juego.").formatted(Formatting.GREEN), true);
                                    return 1;
                                }))))
                        .then(literal("ahora").executes(c -> {
                            MinecraftServer s = c.getSource().getServer();
                            Paso p = siguiente(s);
                            if (p == null) { c.getSource().sendError(Text.literal("Ya no quedan teles en la lista.")); return 0; }
                            String falta = requisito(s, p);
                            if (falta != null) { c.getSource().sendError(Text.literal("La próxima (" + titulo(p.id()) + ") necesita " + falta + ".")); return 0; }
                            lanzar(s, p);
                            EstadoServidor.get(s).setAutoRestante(proximoAlAzar(EstadoServidor.get(s)));
                            return 1;
                        }))
                        .then(literal("saltar").executes(c -> {
                            MinecraftServer s = c.getSource().getServer();
                            Paso p = siguiente(s);
                            if (p == null) { c.getSource().sendError(Text.literal("Ya no quedan teles en la lista.")); return 0; }
                            EstadoServidor.get(s).agregarCambio("sys:auto_saltada:" + p.id());
                            Paso n = siguiente(s);
                            c.getSource().sendFeedback(() -> Text.literal("Saltada: " + titulo(p.id()) + ". La siguiente es: "
                                    + (n != null ? titulo(n.id()) : "ninguna") + ". (Se puede recuperar con /desinfo auto recuperar " + p.id() + ")")
                                    .formatted(Formatting.YELLOW), true);
                            return 1;
                        }))
                        .then(literal("recuperar").then(argument("id", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(LISTA.stream().map(Paso::id).filter(id -> saltada(c.getSource().getServer(), id)), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarCambio("sys:auto_saltada:" + id);
                                    if (!ok) { c.getSource().sendError(Text.literal("Esa tele no estaba saltada.")); return 0; }
                                    c.getSource().sendFeedback(() -> Text.literal(titulo(id) + " vuelve a la lista.").formatted(Formatting.GREEN), true);
                                    return 1;
                                })))
                        .then(literal("rojo").executes(c -> {
                            MinecraftServer s = c.getSource().getServer();
                            if (Desafios.hayEnCurso()) { c.getSource().sendError(Text.literal("Ya hay un desafío rojo en marcha.")); return 0; }
                            String id = rojoSiguiente(s);
                            if (id == null) return 0;
                            lanzarRojo(s, id);
                            EstadoServidor.get(s).setRojoRestante(rojoAlAzar(EstadoServidor.get(s)));
                            return 1;
                        }))
                        .then(literal("intervalo_rojos").then(argument("minimo", IntegerArgumentType.integer(1, 600))
                                .then(argument("maximo", IntegerArgumentType.integer(1, 600)).executes(c -> {
                                    int min = IntegerArgumentType.getInteger(c, "minimo"), max = Math.max(min, IntegerArgumentType.getInteger(c, "maximo"));
                                    EstadoServidor e = EstadoServidor.get(c.getSource().getServer());
                                    e.setRojoRango(min * 1200, max * 1200);
                                    if (e.getRojoRestante() > max * 1200) e.setRojoRestante(rojoAlAzar(e));
                                    c.getSource().sendFeedback(() -> Text.literal("Ahora sale un desafío rojo al azar cada " + min + "-" + max + " minutos de juego.").formatted(Formatting.RED), true);
                                    return 1;
                                }))))
                        .then(literal("lista").executes(ProgramaTeles::lista))
                        .then(literal("avisos")
                                .then(literal("si").executes(c -> {
                                    EstadoServidor.get(c.getSource().getServer()).agregarCambio(AVISOS);
                                    c.getSource().sendFeedback(() -> Text.literal("Avisos [Auto] encendidos (solo los ven los admins).").formatted(Formatting.GREEN), false);
                                    return 1;
                                }))
                                .then(literal("no").executes(c -> {
                                    EstadoServidor.get(c.getSource().getServer()).quitarCambio(AVISOS);
                                    c.getSource().sendFeedback(() -> Text.literal("Avisos [Auto] apagados.").formatted(Formatting.YELLOW), false);
                                    return 1;
                                }))))));
    }

    // ------------------------------------------------------------------ comandos

    private static String tiempo(int ticks) {
        int s = Math.max(0, ticks / 20);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    private static int estado(CommandContext<ServerCommandSource> c) {
        MinecraftServer s = c.getSource().getServer();
        EstadoServidor e = EstadoServidor.get(s);
        long hechas = LISTA.stream().filter(p -> lanzada(s, p.id()) || saltada(s, p.id())).count();
        Paso p = siguiente(s);
        c.getSource().sendFeedback(() -> Text.literal("━━ Teles automáticas ━━").formatted(Formatting.DARK_AQUA), false);
        c.getSource().sendFeedback(() -> Text.literal("Estado: ").formatted(Formatting.GRAY)
                .append(e.isAutoActivo() ? Text.literal("ACTIVAS").formatted(Formatting.GREEN, Formatting.BOLD)
                        : Text.literal("EN PAUSA").formatted(Formatting.YELLOW, Formatting.BOLD)), false);
        c.getSource().sendFeedback(() -> Text.literal("Una al azar cada " + e.getAutoMinimo() / 1200 + "-" + e.getAutoMaximo() / 1200
                        + " min de juego · Llevamos " + hechas + "/" + LISTA.size())
                .formatted(Formatting.GRAY), false);
        if (p == null) {
            c.getSource().sendFeedback(() -> Text.literal("No quedan teles en la lista.").formatted(Formatting.GREEN), false);
        } else {
            String falta = requisito(s, p);
            c.getSource().sendFeedback(() -> Text.literal("Próxima: #" + numero(p) + " (" + p.parte() + ") ").formatted(Formatting.GRAY)
                    .append(Text.literal(titulo(p.id())).formatted(colorDe(p.id())))
                    .append(Text.literal(falta != null ? "  — espera: " + falta : "  — en " + tiempo(e.getAutoRestante())).formatted(Formatting.GRAY)), false);
        }
        if (e.tieneCambio(ROJOS_APAGADOS))
            c.getSource().sendFeedback(() -> Text.literal("Desafíos rojos automáticos: APAGADOS (la tele está rota; ahora las teles rojas las lanza el jefe)").formatted(Formatting.DARK_RED), false);
        else
            c.getSource().sendFeedback(() -> Text.literal("Próximo desafío rojo (al azar): en " + tiempo(e.getRojoRestante())
                    + " · luego cada " + e.getRojoMinimo() / 1200 + "-" + e.getRojoMaximo() / 1200 + " min").formatted(Formatting.RED), false);
        c.getSource().sendFeedback(() -> Text.literal("/desinfo auto iniciar · pausar · ahora · saltar · rojo · intervalo <min> <max> · intervalo_rojos <min> <max> · lista")
                .formatted(Formatting.DARK_GRAY), false);
        return 1;
    }

    private static int lista(CommandContext<ServerCommandSource> c) {
        MinecraftServer s = c.getSource().getServer();
        Paso sig = siguiente(s);
        String parte = "";
        for (Paso p : LISTA) {
            if (!p.parte().equals(parte)) {
                parte = p.parte();
                String nombre = parte;
                c.getSource().sendFeedback(() -> Text.literal("— Acto " + nombre + " —").formatted(Formatting.DARK_AQUA, Formatting.BOLD), false);
            }
            boolean hecha = lanzada(s, p.id()), salt = saltada(s, p.id());
            String marca = hecha ? "✔ " : salt ? "✘ " : p.equals(sig) ? "▶ " : "· ";
            Formatting fm = hecha || salt ? Formatting.DARK_GRAY : colorDe(p.id());
            MutableText linea = Text.literal(marca + numero(p) + ". ").formatted(Formatting.GRAY)
                    .append(Text.literal(titulo(p.id())).formatted(fm))
                    .append(Text.literal(" (" + p.id() + ")" + (salt ? " saltada" : "")).formatted(Formatting.DARK_GRAY));
            c.getSource().sendFeedback(() -> linea, false);
        }
        return 1;
    }
}

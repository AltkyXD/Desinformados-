package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Desinformados implements ModInitializer {
    public static final String MOD_ID = "desinformados";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static net.minecraft.server.MinecraftServer SERVER;

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.inicializar();
        ModBloques.inicializar();
        com.centrodesinformacion.desinformados.entidad.ModEntidades.inicializar();
        ModItems.inicializar();
        Tareas.registrar();
        Mobs.registrar();
        Modificaciones.registrar();
        Misiones.registrar();
        Tragamonedas.registrar();
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> SERVER = null);
        com.centrodesinformacion.desinformados.desafio.Desafios.registrarEventos();
        PayloadTypeRegistry.playS2C().register(EventoTvPayload.ID, EventoTvPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(AlmasPayload.ID, AlmasPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.ManipuladoPayload.ID, com.centrodesinformacion.desinformados.network.ManipuladoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BancoPayload.ID, com.centrodesinformacion.desinformados.network.BancoPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.BancoAccionPayload.ID, com.centrodesinformacion.desinformados.network.BancoAccionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.MisionesPayload.ID, com.centrodesinformacion.desinformados.network.MisionesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.SustoPayload.ID, com.centrodesinformacion.desinformados.network.SustoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.InvertidoPayload.ID, com.centrodesinformacion.desinformados.network.InvertidoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BlancoPayload.ID, com.centrodesinformacion.desinformados.network.BlancoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.MuertePayload.ID, com.centrodesinformacion.desinformados.network.MuertePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BordePayload.ID, com.centrodesinformacion.desinformados.network.BordePayload.CODEC);
        Banco.registrar(); // después de registrar los paquetes (si no, Fabric falla al arrancar)
        Vida.registrar();
        Reglas.registrar();
        CommandRegistrationCallback.EVENT.register((dispatcher, registros, entorno) -> Comandos.registrar(dispatcher));
        LOGGER.info("Reactor de la Desinformación cargado.");
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Desinformados implements ModInitializer {
    public static final String MOD_ID = "desinformados";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static net.minecraft.server.MinecraftServer SERVER;

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.inicializar();
        ModBloques.inicializar();
        com.centrodesinformacion.desinformados.entidad.ModEntidades.inicializar();
        ModItems.inicializar();
        Tareas.registrar();
        Mobs.registrar();
        Modificaciones.registrar();
        MutacionesNether.registrar();
        MobsCruzados.registrar();
        ProgramaTeles.registrar();
        Eventos.registrar();   // teles que se quedaron a medias al apagar el servidor
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(
                com.centrodesinformacion.desinformados.dimension.TelePortalBlock::asegurarCuerpos);   // las teles viejas reciben su cuerpo de 5x5x5
        Misiones.registrar();
        Endcer.registrar();
        BotinMazmorras.registrar();   // Rumores y algún tótem en los cofres de When Dungeons Arise (si está instalado)
        ColaNether.registrar();
        com.centrodesinformacion.desinformados.dimension.Libreta.registrar();
        com.centrodesinformacion.desinformados.dimension.MutacionesLibreta.registrar();
        Tragamonedas.registrar();
        ModGaratita.inicializar();
        Crafteos.registrar();
        ConversorBlock.registrar();
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> SERVER = null);
        GeneradorCentro.registrar();   // mundo nuevo: el Centro aparece solo en una montaña, decorado y con sus gatos
        com.centrodesinformacion.desinformados.desafio.Desafios.registrarEventos();
        PayloadTypeRegistry.playS2C().register(EventoTvPayload.ID, EventoTvPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.JefePayload.ID, com.centrodesinformacion.desinformados.network.JefePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.ColgadoPayload.ID, com.centrodesinformacion.desinformados.network.ColgadoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(AlmasPayload.ID, AlmasPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.CambiosPayload.ID, com.centrodesinformacion.desinformados.network.CambiosPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.ManipuladoPayload.ID, com.centrodesinformacion.desinformados.network.ManipuladoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BancoPayload.ID, com.centrodesinformacion.desinformados.network.BancoPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.BancoAccionPayload.ID, com.centrodesinformacion.desinformados.network.BancoAccionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.MisionesPayload.ID, com.centrodesinformacion.desinformados.network.MisionesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.NotificacionPayload.ID, com.centrodesinformacion.desinformados.network.NotificacionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.SustoPayload.ID, com.centrodesinformacion.desinformados.network.SustoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.InvertidoPayload.ID, com.centrodesinformacion.desinformados.network.InvertidoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BlancoPayload.ID, com.centrodesinformacion.desinformados.network.BlancoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.ManchaPayload.ID, com.centrodesinformacion.desinformados.network.ManchaPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.MuertePayload.ID, com.centrodesinformacion.desinformados.network.MuertePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.BordePayload.ID, com.centrodesinformacion.desinformados.network.BordePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.TiendaPayload.ID, com.centrodesinformacion.desinformados.network.TiendaPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.TiendaCompraPayload.ID, com.centrodesinformacion.desinformados.network.TiendaCompraPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.DialogoPayload.ID, com.centrodesinformacion.desinformados.network.DialogoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.IntroPayload.ID, com.centrodesinformacion.desinformados.network.IntroPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.IntroFinPayload.ID, com.centrodesinformacion.desinformados.network.IntroFinPayload.CODEC);
        com.centrodesinformacion.desinformados.intro.Intro.registrar();
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.FinalPayload.ID, com.centrodesinformacion.desinformados.network.FinalPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.FinalFinPayload.ID, com.centrodesinformacion.desinformados.network.FinalFinPayload.CODEC);
        com.centrodesinformacion.desinformados.intro.Final.registrar();
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.DjPayload.ID, com.centrodesinformacion.desinformados.network.DjPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.DjPedidoPayload.ID, com.centrodesinformacion.desinformados.network.DjPedidoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.DjSonidoPayload.ID, com.centrodesinformacion.desinformados.network.DjSonidoPayload.CODEC);
        com.centrodesinformacion.desinformados.tienda.Dj.registrar();
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.PasivasPayload.ID, com.centrodesinformacion.desinformados.network.PasivasPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.PasivaTogglePayload.ID, com.centrodesinformacion.desinformados.network.PasivaTogglePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.DobleSaltoPayload.ID, com.centrodesinformacion.desinformados.network.DobleSaltoPayload.CODEC);
        com.centrodesinformacion.desinformados.pasivas.Pasivas.registrar();
        com.centrodesinformacion.desinformados.tienda.Tienda.registrar(); // después de registrar los paquetes
        Banco.registrar(); // después de registrar los paquetes (si no, Fabric falla al arrancar)
        PayloadTypeRegistry.playS2C().register(com.centrodesinformacion.desinformados.network.RuletaPayload.ID, com.centrodesinformacion.desinformados.network.RuletaPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(com.centrodesinformacion.desinformados.network.RuletaApuestaPayload.ID, com.centrodesinformacion.desinformados.network.RuletaApuestaPayload.CODEC);
        Ruleta.registrar();
        Vida.registrar();
        Reglas.registrar();
        CommandRegistrationCallback.EVENT.register((dispatcher, registros, entorno) -> Comandos.registrar(dispatcher));
        LOGGER.info("Reactor de la Desinformación cargado.");
    }
}

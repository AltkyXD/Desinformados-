package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Desinformados implements ModInitializer {
    public static final String MOD_ID = "desinformados";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.inicializar();
        ModSounds.inicializar();
        PayloadTypeRegistry.playS2C().register(EventoTvPayload.ID, EventoTvPayload.CODEC);
        Reglas.registrar();
        CommandRegistrationCallback.EVENT.register((dispatcher, registros, entorno) -> Comandos.registrar(dispatcher));
        LOGGER.info("Reactor de la Desinformación cargado.");
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.RuletaApuestaPayload;
import com.centrodesinformacion.desinformados.network.RuletaPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ruleta del casino (37 casillas: 18 rojas, 18 negras y el 0 verde). Se apuesta con los Rumores del inventario:
 * acertar rojo o negro devuelve lo apostado + 30 %; apostar al verde y que salga paga el doble. Si no, se pierde.
 * El servidor decide el número al apostar; la rueda del cliente gira 5 segundos y se para justo ahí, y entonces se paga.
 */
public class Ruleta {
    public static final int MINIMA = 10, MAXIMA = 1000, PASO = 10;
    /** Ticks hasta pagar (la rueda del cliente tarda 5 segundos en pararse). */
    private static final int GIRO = 106;
    /** Orden de los números en la rueda (ruleta europea). */
    public static final int[] ORDEN = {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20,
            14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26};
    public static final Set<Integer> ROJOS = Set.of(1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36);

    public static String color(int n) {
        return n == 0 ? "verde" : ROJOS.contains(n) ? "rojo" : "negro";
    }

    /** Lo que se cobra (incluido lo apostado) si sale 'numero' apostando 'cantidad' a 'apuesta'. */
    public static int premio(String apuesta, int cantidad, int numero) {
        if (!apuesta.equals(color(numero))) return 0;
        return apuesta.equals("verde") ? cantidad * 2 : cantidad * 13 / 10;
    }

    private record Tirada(UUID jugador, String nombre, BlockPos mesa, String apuesta, int cantidad, int numero, int premio, long fin) {}

    private static final Map<UUID, Tirada> EN_CURSO = new HashMap<>();
    private static final Map<UUID, BlockPos> ABIERTA = new HashMap<>();

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(RuletaApuestaPayload.ID, (paquete, contexto) -> apostar(contexto.player(), paquete));
        ServerTickEvents.END_SERVER_TICK.register(Ruleta::tick);
    }

    public static void abrir(ServerPlayerEntity p, BlockPos pos) {
        ABIERTA.put(p.getUuid(), pos.toImmutable());
        enviar(p, -1, 0, true);
    }

    private static void enviar(ServerPlayerEntity p, int numero, int premio, boolean abrir) {
        if (ServerPlayNetworking.canSend(p, RuletaPayload.ID))
            ServerPlayNetworking.send(p, new RuletaPayload(Tragamonedas.rumores(p), numero, premio, abrir));
    }

    private static boolean cerca(ServerPlayerEntity p) {
        BlockPos pos = ABIERTA.get(p.getUuid());
        return pos != null && p.getBlockPos().isWithinDistance(pos, 8) && p.getWorld().getBlockState(pos).getBlock() instanceof RuletaBlock;
    }

    private static void apostar(ServerPlayerEntity p, RuletaApuestaPayload paquete) {
        if (!cerca(p) || EN_CURSO.containsKey(p.getUuid())) return;
        String apuesta = paquete.color();
        int cantidad = paquete.cantidad();
        if (!apuesta.equals("rojo") && !apuesta.equals("negro") && !apuesta.equals("verde")) return;
        if (cantidad < MINIMA || cantidad > MAXIMA || cantidad % PASO != 0) return;
        if (!Tragamonedas.pagar(p, cantidad)) {
            p.sendMessage(Text.literal("No llevas " + cantidad + " Rumores en el inventario").formatted(Formatting.RED), true);
            enviar(p, -1, 0, false);
            return;
        }
        Misiones.sumar(p, "ruleta", 1);
        int numero = ORDEN[p.getRandom().nextInt(ORDEN.length)];
        int premio = premio(apuesta, cantidad, numero);
        BlockPos mesa = ABIERTA.get(p.getUuid());
        EN_CURSO.put(p.getUuid(), new Tirada(p.getUuid(), p.getGameProfile().getName(), mesa, apuesta, cantidad, numero, premio,
                p.getServer().getTicks() + GIRO));
        enviar(p, numero, premio, false);
        p.getServerWorld().playSound(null, mesa, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.5f, 0.5f);
    }

    private static Formatting formato(int n) {
        return switch (color(n)) { case "rojo" -> Formatting.RED; case "verde" -> Formatting.GREEN; default -> Formatting.DARK_GRAY; };
    }

    private static void tick(MinecraftServer server) {
        if (EN_CURSO.isEmpty()) return;
        Iterator<Tirada> it = EN_CURSO.values().iterator();
        while (it.hasNext()) {
            Tirada t = it.next();
            if (server.getTicks() < t.fin()) continue;
            it.remove();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(t.jugador());
            if (p == null) {                       // se fue a mitad de la tirada: el premio va a su cuenta del Banco
                if (t.premio() > 0) {
                    EstadoServidor e = EstadoServidor.get(server);
                    e.setSaldo(t.jugador(), e.getSaldo(t.jugador()) + t.premio());
                }
                continue;
            }
            ServerWorld w = p.getServerWorld();
            MutableText salio = Text.literal("Ruleta: salió el ").formatted(Formatting.GOLD)
                    .append(Text.literal(t.numero() + " " + color(t.numero()).toUpperCase()).formatted(formato(t.numero()), Formatting.BOLD));
            if (t.premio() > 0) {
                Tragamonedas.darRumores(p, t.premio());
                p.sendMessage(salio.append(Text.literal(". ¡Ganas " + t.premio() + " Rumores!").formatted(Formatting.GREEN)), false);
                w.playSound(null, t.mesa(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.BLOCKS, 0.9f, 1.3f);
                w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, t.mesa().getX() + 0.5, t.mesa().getY() + 1.2, t.mesa().getZ() + 0.5, 15, 0.4, 0.3, 0.4, 0.1);
                if (t.apuesta().equals("verde")) {
                    w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, t.mesa().getX() + 0.5, t.mesa().getY() + 1.5, t.mesa().getZ() + 0.5, 60, 0.6, 0.6, 0.6, 0.35);
                    server.getPlayerManager().broadcast(Text.literal("¡" + t.nombre() + " acertó el VERDE en la ruleta y duplicó " + t.cantidad() + " Rumores!")
                            .formatted(Formatting.GREEN, Formatting.BOLD), false);
                }
            } else {
                p.sendMessage(salio.append(Text.literal(". Pierdes " + t.cantidad() + " Rumores (el Centro te lo agradece).").formatted(Formatting.GRAY)), false);
                w.playSound(null, t.mesa(), SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 0.9f, 0.6f);
            }
            enviar(p, -1, 0, false);
        }
    }
}

package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Mutaciones de los mobs del Nether y del enderman (cambios de dificultad amarillos):
 *  ghasts_triples · blazes_dobles · piglins_ladrones · hoglins_gimnasio · magma_ardiente
 *  wither_veneno · zombificados_rencorosos · enderman_teletransporte
 */
public class MutacionesNether {
    private static final String MARCA = "desinfo_copia";

    private static boolean activo(MinecraftServer s, String id) {
        return EstadoServidor.get(s).tieneCambio(id);
    }

    public static void registrar() {
        // La primera vez que alguien entra al Nether: tele amarilla anunciando a los nuevos vecinos
        net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((jugador, origen, destino) -> {
            if (destino.getRegistryKey() != net.minecraft.world.World.NETHER) return;
            EstadoServidor estado = EstadoServidor.get(destino.getServer());
            if (estado.tieneCambio("sys:nether_poblado")) return;
            estado.agregarCambio("sys:nether_poblado");
            Tareas.programar(60, () -> Eventos.lanzar(destino.getServer(), Eventos.TODOS.get("nether_poblado")));
        });

        // ---- Proyectiles: ghasts disparan 3 bolas de fuego, blazes el doble ----
        ServerEntityEvents.ENTITY_LOAD.register((e, mundo) -> {
            if (e.getCommandTags().contains(MARCA)) return;
            if (e instanceof FireballEntity bola && bola.getOwner() instanceof GhastEntity ghast && activo(mundo.getServer(), "ghasts_triples")) {
                bola.addCommandTag(MARCA);
                Vec3d dir = bola.getVelocity().lengthSquared() > 1e-6 ? bola.getVelocity().normalize() : ghast.getRotationVec(1f);
                for (int lado = -1; lado <= 1; lado += 2) {
                    final int l = lado;
                    Tareas.programar(1, () -> {
                        FireballEntity copia = new FireballEntity(mundo, ghast, dir.rotateY(l * 0.25f), ghast.getFireballStrength());
                        copia.setPosition(bola.getX(), bola.getY(), bola.getZ());
                        copia.addCommandTag(MARCA);
                        mundo.spawnEntity(copia);
                    });
                }
            } else if (e instanceof SmallFireballEntity bola && bola.getOwner() instanceof BlazeEntity blaze && activo(mundo.getServer(), "blazes_dobles")) {
                bola.addCommandTag(MARCA);
                Vec3d dir = bola.getVelocity().lengthSquared() > 1e-6 ? bola.getVelocity().normalize() : blaze.getRotationVec(1f);
                Tareas.programar(3, () -> {
                    SmallFireballEntity copia = new SmallFireballEntity(mundo, blaze, dir.rotateY(0.12f));
                    copia.setPosition(bola.getX(), bola.getY(), bola.getZ());
                    copia.addCommandTag(MARCA);
                    mundo.spawnEntity(copia);
                });
            }
        });

        // ---- Golpes ----
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((victima, fuente, cantidad) -> {
            if (!(victima instanceof ServerPlayerEntity p) || p.getServer() == null) return true;
            MinecraftServer s = p.getServer();
            Entity atacante = fuente.getAttacker();
            if (atacante instanceof PiglinEntity piglin && activo(s, "piglins_ladrones")) robarOro(p, piglin);
            else if (atacante instanceof MagmaCubeEntity && activo(s, "magma_ardiente")) p.setOnFireFor(5f);
            else if (atacante instanceof WitherSkeletonEntity && activo(s, "wither_veneno"))
                Tareas.programar(1, () -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 160, 1)));
            else if (atacante instanceof EndermanEntity && activo(s, "enderman_teletransporte")) Tareas.programar(1, () -> teletransportar(p));
            return true;
        });

        // ---- Atributos y rencor (cada 2 segundos) ----
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 40 != 0) return;
            boolean hoglins = activo(server, "hoglins_gimnasio"), wither = activo(server, "wither_veneno"),
                    zombis = activo(server, "zombificados_rencorosos");
            if (!hoglins && !wither && !zombis) return;
            for (ServerWorld w : server.getWorlds()) {
                for (Entity e : w.iterateEntities()) {
                    if (hoglins && e instanceof HoglinEntity h) {
                        modificador(h, EntityAttributes.GENERIC_MAX_HEALTH, "hoglin_vida", 0.5, true);
                        modificador(h, EntityAttributes.GENERIC_ATTACK_KNOCKBACK, "hoglin_empuje", 1.5, false);
                    } else if (wither && e instanceof WitherSkeletonEntity ws) {
                        modificador(ws, EntityAttributes.GENERIC_MOVEMENT_SPEED, "wither_rapido", 0.25, true);
                    } else if (zombis && e instanceof ZombifiedPiglinEntity z && z.getTarget() == null) {
                        ServerPlayerEntity cerca = (ServerPlayerEntity) w.getClosestPlayer(z, 10);
                        if (cerca != null && !cerca.isCreative() && !cerca.isSpectator()) {
                            z.setAngryAt(cerca.getUuid());
                            z.setAngerTime(400);
                            z.setTarget(cerca);
                        }
                    }
                }
            }
        });
    }

    private static void modificador(LivingEntity e, RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> atributo, String nombre,
                                    double valor, boolean multiplica) {
        EntityAttributeInstance inst = e.getAttributeInstance(atributo);
        Identifier id = Desinformados.id(nombre);
        if (inst == null || inst.hasModifier(id)) return;
        inst.addPersistentModifier(new EntityAttributeModifier(id, valor,
                multiplica ? EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE : EntityAttributeModifier.Operation.ADD_VALUE));
        if (atributo == EntityAttributes.GENERIC_MAX_HEALTH) e.setHealth(e.getMaxHealth());
    }

    /** El piglin te quita hasta 3 objetos de oro del inventario y se los guarda. */
    private static void robarOro(ServerPlayerEntity p, PiglinEntity piglin) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty() || !s.isIn(ItemTags.PIGLIN_LOVED)) continue;
            ItemStack robado = s.split(Math.min(3, s.getCount()));
            ItemStack sobra = piglin.getInventory().addStack(robado);
            if (!sobra.isEmpty()) piglin.dropStack(sobra);
            p.sendMessage(Text.literal("¡Un piglin te ha robado " + robado.getCount() + "x " + robado.getName().getString() + "!")
                    .formatted(Formatting.GOLD), true);
            p.getServerWorld().playSound(null, piglin.getBlockPos(), SoundEvents.ENTITY_PIGLIN_CELEBRATE, SoundCategory.HOSTILE, 1f, 1.2f);
            return;
        }
    }

    /** Como comer una fruta coral: te manda a un sitio cercano al azar. */
    private static void teletransportar(ServerPlayerEntity p) {
        if (!p.isAlive()) return;
        ServerWorld w = p.getServerWorld();
        double x0 = p.getX(), y0 = p.getY(), z0 = p.getZ();
        for (int i = 0; i < 16; i++) {
            double x = x0 + (p.getRandom().nextDouble() - 0.5) * 16;
            double y = Math.max(w.getBottomY(), Math.min(w.getTopY() - 1, y0 + p.getRandom().nextInt(16) - 8));
            double z = z0 + (p.getRandom().nextDouble() - 0.5) * 16;
            if (p.hasVehicle()) p.stopRiding();
            if (p.teleport(x, y, z, true)) {
                w.playSound(null, x0, y0, z0, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1f);
                w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1f);
                p.sendMessage(Text.literal("El enderman te ha mandado a pensar lo que has hecho.").formatted(Formatting.DARK_PURPLE), true);
                return;
            }
        }
    }
}

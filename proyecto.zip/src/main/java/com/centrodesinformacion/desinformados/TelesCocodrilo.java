package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.agua.ModCocodrilo;

import java.util.List;
import java.util.Map;

/** La tele azul del Cocodrilo (lo desbloquea). */
public final class TelesCocodrilo {
    private TelesCocodrilo() {}

    public static final List<String> IDS = List.of("cocodrilo");

    /** Para la Enciclopedia: nombre corto del mob de cada tele. */
    public static final Map<String, String> NOMBRES = Map.ofEntries(
            Map.entry("cocodrilo", "Cocodrilo"));

    /** Crea las teles (lo llama Eventos al cargar). Se vuelven azules solas al estar en GRUPO_MOBS. */
    static void eventos() {
        Eventos.amarillo("cocodrilo", "¡Llega el Cocodrilo!",
                "Aparecerá poco, en el agua de ríos, pantanos y océanos templados o cálidos (como mucho uno cada 64 bloques). "
                        + "Tiene 30 corazones, 4 puntos de armadura y su mordisco quita 3 corazones. Si te muerde mientras estás en el agua, "
                        + "te agarra con la boca y te arrastra hacia el fondo durante 12 segundos, quitándote medio corazón cada 2,5 segundos. "
                        + "Te suelta si le golpeas 3 veces, si muere o si salís los dos del agua. Después tarda 8 segundos en poder agarrar otra vez.",
                "Recursos Humanos pidió un socorrista para los ríos y el becario contrató a un cocodrilo: nadie se atrevió a llevarle la contraria "
                        + "en la entrevista. El Centro de Desinformación defiende el fichaje: es el empleado más comprometido con llegar al fondo "
                        + "de los asuntos. Y de los ríos.",
                server -> Eventos.desbloquearMob(server, ModCocodrilo.COCODRILO));
    }
}

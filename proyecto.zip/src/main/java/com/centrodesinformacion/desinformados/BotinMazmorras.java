package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;

/**
 * Botín extra en las mazmorras de When Dungeons Arise (y su expansión Seven Seas), si está instalado:
 * Rumores en casi todos los cofres y, muy de vez en cuando, un tótem. Sin el mod no hace nada.
 * (Comprobado con DungeonsArise-1.21.1-2.1.68-fabric: id "dungeons_arise", 141 tablas de cofres y barriles en chests/.)
 */
public final class BotinMazmorras {
    /** Probabilidad de que un cofre traiga Rumores, y de que traiga un tótem. */
    private static final float RUMORES = 0.75f, TOTEM = 0.02f;

    private BotinMazmorras() {}

    public static void registrar() {
        LootTableEvents.MODIFY.register((clave, tabla, origen, registros) -> {
            var id = clave.getValue();
            if (!id.getNamespace().startsWith("dungeons_arise")) return;
            // solo cofres y barriles (en el mod están todos en chests/); nada de mobs, vasijas, arqueología ni spawners de desafío
            if (!id.getPath().startsWith("chests/")) return;
            tabla.pool(LootPool.builder()
                    .rolls(UniformLootNumberProvider.create(1, 2))
                    .conditionally(RandomChanceLootCondition.builder(RUMORES))
                    .with(rumor(ModItems.RUMOR_AMARILLO, 40, 3, 10))     // 1 Rumor
                    .with(rumor(ModItems.RUMOR_AZUL, 30, 1, 4))          // 5 Rumores
                    .with(rumor(ModItems.RUMOR_VERDE, 18, 1, 3))         // 10 Rumores
                    .with(rumor(ModItems.RUMOR_ROJO, 9, 1, 2))           // 20 Rumores
                    .with(rumor(ModItems.RUMOR_GRIS, 3, 1, 1)));         // 50 Rumores
            tabla.pool(LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .conditionally(RandomChanceLootCondition.builder(TOTEM))
                    .with(ItemEntry.builder(Items.TOTEM_OF_UNDYING)));
        });
    }

    private static net.minecraft.loot.entry.LeafEntry.Builder<?> rumor(Item moneda, int peso, int min, int max) {
        return ItemEntry.builder(moneda).weight(peso)
                .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(min, max)));
    }
}

package com.centrodesinformacion.desinformados.pasivas;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.network.DobleSaltoPayload;
import com.centrodesinformacion.desinformados.network.PasivaTogglePayload;
import com.centrodesinformacion.desinformados.network.PasivasPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Pasivas: habilidades que se compran al Mago de las Pasivas (como objeto) y se aprenden al usarlo.
 * Con la tecla I se abre el menú para activarlas o desactivarlas.
 */
public class Pasivas {
    public record Pasiva(String id, String nombre, String descripcion, int precio) {}

    public static final List<Pasiva> TODAS = List.of(
            new Pasiva("caida", "Patas de Gato", "No recibes daño de caída. Siempre caes de pie, como los gatos.", 1111),
            new Pasiva("garras", "Guantes de Escala", "Te agarras a las esquinas de los bloques: si caes pegado a un bloque manteniendo ESPACIO, te quedas colgado del borde. Suelta ESPACIO para subirte de un salto.", 1050),
            new Pasiva("doble_salto", "Tendones Reforzados", "Doble salto: suelta y vuelve a pulsar saltar en el aire para dar un segundo salto.", 1134),
            new Pasiva("veneno", "Sistema Inmunológico", "Inmune al veneno. Comida podrida, arañas, pociones... tus defensas se encargan.", 970),
            new Pasiva("aletas", "Aletas", "Nadas un 50% más rápido, en la superficie y bajo el agua.", 924),
            new Pasiva("rock_bottom", "Fondo de Roca", "Tus contenedores de corazón NUNCA bajan: ni al morir, ni por enemigos, ni por sustos, ni por desafíos. Está rota.", 1449),
            new Pasiva("resorte", "Resorte", "Llevas muelles en las botas: saltas 2 bloques de alto en vez de 1.", 1020),
            new Pasiva("cafe", "Café", "Un café bien cargado del Centro: andas y corres un 15% más rápido.", 900));

    public static Pasiva porId(String id) {
        for (Pasiva p : TODAS) if (p.id().equals(id)) return p;
        return null;
    }

    // ------------------------------------------------------------ estado

    public static Set<String> compradas(ServerPlayerEntity p) {
        return separar(EstadoServidor.get(p.getServer()).getPasivas(p.getUuid()));
    }

    public static Set<String> apagadas(ServerPlayerEntity p) {
        return separar(EstadoServidor.get(p.getServer()).getPasivasApagadas(p.getUuid()));
    }

    /** Pasivas apagadas a la fuerza (la tele roja del jefe): jugador -> tick del servidor hasta el que siguen apagadas. */
    private static final java.util.Map<java.util.UUID, Integer> APAGADAS_HASTA = new java.util.HashMap<>();

    /** Apaga TODAS las pasivas de este jugador durante unos ticks (luego vuelven solas). */
    public static void apagarTodas(ServerPlayerEntity p, int ticks) {
        var server = p.getServer();
        if (server == null) return;
        APAGADAS_HASTA.put(p.getUuid(), server.getTicks() + ticks);
        sincronizar(p);
        java.util.UUID id = p.getUuid();
        p.sendMessage(net.minecraft.text.Text.literal("Tus pasivas se han apagado durante " + ticks / 20 + " segundos.").formatted(net.minecraft.util.Formatting.RED), true);
        com.centrodesinformacion.desinformados.Tareas.programar(ticks + 1, () -> {
            ServerPlayerEntity ahora = server.getPlayerManager().getPlayer(id);
            if (ahora != null) {
                sincronizar(ahora);
                ahora.sendMessage(net.minecraft.text.Text.literal("Tus pasivas vuelven a funcionar.").formatted(net.minecraft.util.Formatting.GREEN), true);
            }
        });
    }

    /** En la Libreta del Becario las pasivas no sirven (ninguna, ni Fondo de Roca). */
    public static boolean enLibreta(ServerPlayerEntity p) {
        return p.getServerWorld().getRegistryKey() == com.centrodesinformacion.desinformados.dimension.Dimensiones.LIBRETA;
    }

    private static boolean forzadas(ServerPlayerEntity p) {
        if (enLibreta(p)) return true;
        Integer hasta = APAGADAS_HASTA.get(p.getUuid());
        return hasta != null && p.getServer() != null && p.getServer().getTicks() < hasta;
    }

    /** ¿La tiene comprada y activada? */
    public static boolean tiene(ServerPlayerEntity p, String id) {
        if (p.getServer() == null) return false;
        if (forzadas(p)) return false;
        return compradas(p).contains(id) && !apagadas(p).contains(id);
    }

    /** La aprende (devuelve false si ya la tenía). */
    public static boolean dar(ServerPlayerEntity p, String id) {
        Set<String> c = compradas(p);
        if (!c.add(id)) return false;
        EstadoServidor.get(p.getServer()).setPasivas(p.getUuid(), String.join(",", c));
        sincronizar(p);
        return true;
    }

    /** La olvida (comando de admin). Devuelve false si no la tenía. */
    public static boolean quitar(ServerPlayerEntity p, String id) {
        Set<String> c = compradas(p);
        if (!c.remove(id)) return false;
        EstadoServidor e = EstadoServidor.get(p.getServer());
        e.setPasivas(p.getUuid(), String.join(",", c));
        Set<String> a = apagadas(p);
        if (a.remove(id)) e.setPasivasApagadas(p.getUuid(), String.join(",", a));
        sincronizar(p);
        return true;
    }

    public static void alternar(ServerPlayerEntity p, String id) {
        if (!compradas(p).contains(id)) return;
        Set<String> a = apagadas(p);
        if (!a.remove(id)) a.add(id);
        EstadoServidor.get(p.getServer()).setPasivasApagadas(p.getUuid(), String.join(",", a));
        Pasiva pa = porId(id);
        boolean activa = !a.contains(id);
        if (pa != null) p.sendMessage(Text.literal(pa.nombre() + (activa ? ": activada" : ": desactivada"))
                .formatted(activa ? Formatting.GREEN : Formatting.GRAY), true);
        sincronizar(p);
    }

    public static void sincronizar(ServerPlayerEntity p) {
        if (!ServerPlayNetworking.canSend(p, PasivasPayload.ID)) return;
        Set<String> c = compradas(p), a = apagadas(p);
        Set<String> activas = new LinkedHashSet<>(c);
        activas.removeAll(a);
        if (forzadas(p)) activas.clear();
        ServerPlayNetworking.send(p, new PasivasPayload(String.join(",", c), String.join(",", activas)));
    }

    private static Set<String> separar(String s) {
        Set<String> r = new LinkedHashSet<>();
        if (s == null || s.isEmpty()) return r;
        for (String x : s.split(",")) if (!x.isBlank()) r.add(x.trim());
        return r;
    }

    // ------------------------------------------------------------ efectos

    private static final Identifier MOD_RESORTE = Desinformados.id("pasiva_resorte");
    private static final Identifier MOD_CAFE = Desinformados.id("pasiva_cafe");
    /** Salto normal 0,42 (1,25 bloques); con +0,13 se llega a 2 bloques. */
    private static final double SALTO_RESORTE = 0.13;
    private static final double VELOCIDAD_CAFE = 0.15;

    /** Pone o quita un modificador temporal (no se guarda: se vuelve a poner al entrar si la pasiva sigue activa). */
    private static void modificador(ServerPlayerEntity p, RegistryEntry<EntityAttribute> atributo, Identifier id, double valor,
                                    EntityAttributeModifier.Operation op, boolean activo) {
        EntityAttributeInstance inst = p.getAttributeInstance(atributo);
        if (inst == null) return;
        boolean lleva = inst.hasModifier(id);
        if (activo && !lleva) inst.addTemporaryModifier(new EntityAttributeModifier(id, valor, op));
        else if (!activo && lleva) inst.removeModifier(id);
    }

    public static void registrar() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> server.execute(() -> sincronizar(handler.player)));
        ServerPlayNetworking.registerGlobalReceiver(PasivaTogglePayload.ID, (paquete, ctx) -> ctx.server().execute(() -> alternar(ctx.player(), paquete.id())));
        ServerPlayNetworking.registerGlobalReceiver(DobleSaltoPayload.ID, (paquete, ctx) -> ctx.server().execute(() -> {
            ServerPlayerEntity p = ctx.player();
            if (paquete.nada() != 0) {                            // Guantes de Escala: 1 = se agarra al borde, 2 = se sube, 3 = se suelta
                if (!tiene(p, "garras")) return;
                p.fallDistance = 0;
                var aviso = new com.centrodesinformacion.desinformados.network.ColgadoPayload(p.getId(), paquete.nada() == 1);
                for (ServerPlayerEntity otro : net.fabricmc.fabric.api.networking.v1.PlayerLookup.tracking(p))   // los demás le ven los brazos
                    if (otro != p && ServerPlayNetworking.canSend(otro, aviso.getId())) ServerPlayNetworking.send(otro, aviso);
                if (paquete.nada() == 3) return;
                p.getServerWorld().playSound(null, p.getBlockPos(), paquete.nada() == 1 ? SoundEvents.BLOCK_STONE_HIT : SoundEvents.ENTITY_GOAT_LONG_JUMP,
                        SoundCategory.PLAYERS, 0.6f, paquete.nada() == 1 ? 0.8f : 1.3f);
                return;
            }
            if (!tiene(p, "doble_salto")) return;
            p.fallDistance = 0;                                   // el segundo salto "reinicia" la caída
            p.getServerWorld().spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY(), p.getZ(), 8, 0.3, 0.05, 0.3, 0.02);
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PHANTOM_FLAP, SoundCategory.PLAYERS, 0.5f, 1.6f);
        }));

        // Patas de Gato: sin daño de caída
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof ServerPlayerEntity p && fuente.isIn(DamageTypeTags.IS_FALL) && tiene(p, "caida")));

        // Sistema Inmunológico: el veneno se quita en cuanto llega
        // Resorte y Café: modificadores de salto y velocidad (se ponen y se quitan según estén activas)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            boolean revisar = server.getTicks() % 10 == 0;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.hasStatusEffect(StatusEffects.POISON) && tiene(p, "veneno")) p.removeStatusEffect(StatusEffects.POISON);
                if (revisar) {
                    modificador(p, EntityAttributes.GENERIC_JUMP_STRENGTH, MOD_RESORTE, SALTO_RESORTE,
                            EntityAttributeModifier.Operation.ADD_VALUE, tiene(p, "resorte"));
                    modificador(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, MOD_CAFE, VELOCIDAD_CAFE,
                            EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, tiene(p, "cafe"));
                }
            }
        });

        // Libreta: al entrar se apagan (y se avisa); al salir vuelven
        net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((p, origen, destino) -> {
            sincronizar(p);
            if (compradas(p).isEmpty()) return;
            var libreta = com.centrodesinformacion.desinformados.dimension.Dimensiones.LIBRETA;
            if (destino.getRegistryKey() == libreta)
                p.sendMessage(Text.literal("En la Libreta tus pasivas no sirven de nada.").formatted(Formatting.RED), false);
            else if (origen.getRegistryKey() == libreta)
                p.sendMessage(Text.literal("Tus pasivas vuelven a funcionar.").formatted(Formatting.GREEN), true);
        });
        net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, vivo) -> sincronizar(nuevo));

        // En LAN el mapa estático sobrevive al cerrar el mundo y los ticks vuelven a 0: se olvida al parar el servidor
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(server -> APAGADAS_HASTA.clear());
    }
}

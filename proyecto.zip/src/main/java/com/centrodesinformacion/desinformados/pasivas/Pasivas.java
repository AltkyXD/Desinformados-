package com.centrodesinformacion.desinformados.pasivas;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.network.DobleSaltoPayload;
import com.centrodesinformacion.desinformados.network.PasivaTogglePayload;
import com.centrodesinformacion.desinformados.network.PasivasPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Pasivas: habilidades que se compran al Mago de las Pasivas (como objeto) y se aprenden al usarlo.
 * Con la tecla K se abre el menú para activarlas o desactivarlas.
 */
public class Pasivas {
    public record Pasiva(String id, String nombre, String descripcion, int precio) {}

    public static final List<Pasiva> TODAS = List.of(
            new Pasiva("caida", "Patas de Gato", "No recibes daño de caída. Siempre caes de pie, como los gatos.", 1250),
            new Pasiva("garras", "Garras", "Te agarras a las esquinas de los bloques: si caes pegado a un bloque manteniendo ESPACIO, te quedas colgado del borde. Suelta ESPACIO para subirte de un salto.", 1500),
            new Pasiva("doble_salto", "Doble Salto", "Pulsa saltar otra vez en el aire para dar un segundo salto.", 1800),
            new Pasiva("veneno", "Estómago de Hierro", "Inmune al veneno. Comida podrida, arañas, pociones... nada.", 1100),
            new Pasiva("rock_bottom", "Fondo de Roca", "Tus contenedores de corazón NUNCA bajan: ni al morir, ni por enemigos, ni por sustos, ni por desafíos. Está rota.", 5000));

    public static Pasiva porId(String id) {
        for (Pasiva p : TODAS) if (p.id().equals(id)) return p;
        return null;
    }

    // ------------------------------------------------------------ estado

    public static Set<String> compradas(ServerPlayerEntity p) {
        return separar(EstadoServidor.get(p.getServer()).getPasivas(p.getUuid()));
    }

    public static Set<String> apagadas(ServerPlayerEntity p) {
        return separar(EstadoServidor.get(p.getServer()).getPasivasApagadas(p.getUuid()));
    }

    /** ¿La tiene comprada y activada? */
    public static boolean tiene(ServerPlayerEntity p, String id) {
        if (p.getServer() == null) return false;
        return compradas(p).contains(id) && !apagadas(p).contains(id);
    }

    /** La aprende (devuelve false si ya la tenía). */
    public static boolean dar(ServerPlayerEntity p, String id) {
        Set<String> c = compradas(p);
        if (!c.add(id)) return false;
        EstadoServidor.get(p.getServer()).setPasivas(p.getUuid(), String.join(",", c));
        sincronizar(p);
        return true;
    }

    public static void alternar(ServerPlayerEntity p, String id) {
        if (!compradas(p).contains(id)) return;
        Set<String> a = apagadas(p);
        if (!a.remove(id)) a.add(id);
        EstadoServidor.get(p.getServer()).setPasivasApagadas(p.getUuid(), String.join(",", a));
        Pasiva pa = porId(id);
        boolean activa = !a.contains(id);
        if (pa != null) p.sendMessage(Text.literal(pa.nombre() + (activa ? ": activada" : ": desactivada"))
                .formatted(activa ? Formatting.GREEN : Formatting.GRAY), true);
        sincronizar(p);
    }

    public static void sincronizar(ServerPlayerEntity p) {
        if (!ServerPlayNetworking.canSend(p, PasivasPayload.ID)) return;
        Set<String> c = compradas(p), a = apagadas(p);
        Set<String> activas = new LinkedHashSet<>(c);
        activas.removeAll(a);
        ServerPlayNetworking.send(p, new PasivasPayload(String.join(",", c), String.join(",", activas)));
    }

    private static Set<String> separar(String s) {
        Set<String> r = new LinkedHashSet<>();
        if (s == null || s.isEmpty()) return r;
        for (String x : s.split(",")) if (!x.isBlank()) r.add(x.trim());
        return r;
    }

    // ------------------------------------------------------------ efectos

    public static void registrar() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> server.execute(() -> sincronizar(handler.player)));
        ServerPlayNetworking.registerGlobalReceiver(PasivaTogglePayload.ID, (paquete, ctx) -> ctx.server().execute(() -> alternar(ctx.player(), paquete.id())));
        ServerPlayNetworking.registerGlobalReceiver(DobleSaltoPayload.ID, (paquete, ctx) -> ctx.server().execute(() -> {
            ServerPlayerEntity p = ctx.player();
            if (paquete.nada() != 0) {                            // Garras: 1 = se agarra al borde, 2 = se sube, 3 = se suelta
                if (!tiene(p, "garras")) return;
                p.fallDistance = 0;
                var aviso = new com.centrodesinformacion.desinformados.network.ColgadoPayload(p.getId(), paquete.nada() == 1);
                for (ServerPlayerEntity otro : net.fabricmc.fabric.api.networking.v1.PlayerLookup.tracking(p))   // los demás le ven los brazos
                    if (otro != p && ServerPlayNetworking.canSend(otro, aviso.getId())) ServerPlayNetworking.send(otro, aviso);
                if (paquete.nada() == 3) return;
                p.getServerWorld().playSound(null, p.getBlockPos(), paquete.nada() == 1 ? SoundEvents.BLOCK_STONE_HIT : SoundEvents.ENTITY_GOAT_LONG_JUMP,
                        SoundCategory.PLAYERS, 0.6f, paquete.nada() == 1 ? 0.8f : 1.3f);
                return;
            }
            if (!tiene(p, "doble_salto")) return;
            p.fallDistance = 0;                                   // el segundo salto "reinicia" la caída
            p.getServerWorld().spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY(), p.getZ(), 8, 0.3, 0.05, 0.3, 0.02);
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PHANTOM_FLAP, SoundCategory.PLAYERS, 0.5f, 1.6f);
        }));

        // Patas de Gato: sin daño de caída
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof ServerPlayerEntity p && fuente.isIn(DamageTypeTags.IS_FALL) && tiene(p, "caida")));

        // Estómago de Hierro: el veneno se quita en cuanto llega
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.hasStatusEffect(StatusEffects.POISON) && tiene(p, "veneno")) p.removeStatusEffect(StatusEffects.POISON);
            }
        });
    }
}

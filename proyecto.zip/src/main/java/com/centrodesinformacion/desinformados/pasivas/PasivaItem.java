package com.centrodesinformacion.desinformados.pasivas;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Libro de pasiva: al usarlo aprendes la pasiva para siempre (y se gasta). */
public class PasivaItem extends Item {
    public final String id;

    public PasivaItem(String id, Settings settings) {
        super(settings);
        this.id = id;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient() && user instanceof ServerPlayerEntity p) {
            Pasivas.Pasiva pa = Pasivas.porId(id);
            if (!Pasivas.dar(p, id)) {
                p.sendMessage(Text.literal("Ya tienes esta pasiva.").formatted(Formatting.GRAY), true);
                return TypedActionResult.fail(stack);
            }
            if (!p.isCreative()) stack.decrement(1);
            p.sendMessage(Text.literal("¡Aprendiste " + (pa != null ? pa.nombre() : id) + "! Pulsa K para gestionar tus pasivas.")
                    .formatted(Formatting.LIGHT_PURPLE), false);
            world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.4f);
            world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.PLAYERS, 1f, 1.2f);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        Pasivas.Pasiva pa = Pasivas.porId(id);
        if (pa == null) return;
        tooltip.add(Text.literal("Pasiva").formatted(Formatting.LIGHT_PURPLE));
        tooltip.add(Text.literal(pa.descripcion()).formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Clic derecho para aprenderla").formatted(Formatting.DARK_GRAY, Formatting.ITALIC));
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}

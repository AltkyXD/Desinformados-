package com.centrodesinformacion.desinformados.muebles;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/** Mesa de DJ de 2 x 1: tocadiscos a la izquierda, mezclador y portátil a la derecha. */
public class MesaDjBlock extends MuebleMultiBlock {
    public static final MapCodec<MesaDjBlock> CODEC = createCodec(MesaDjBlock::new);
    public static final IntProperty PARTE = IntProperty.of("parte", 0, 1);
    private static final int[][] PARTES = {{0, 0}, {1, 0}};
    private static final VoxelShape FORMA = Block.createCuboidShape(0, 0, 0, 16, 13, 16);

    public MesaDjBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PARTE, 0));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }
    @Override protected IntProperty parte() { return PARTE; }
    @Override protected int[][] partes() { return PARTES; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PARTE);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return FORMA;
    }
}

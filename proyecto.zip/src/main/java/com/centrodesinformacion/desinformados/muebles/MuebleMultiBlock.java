package com.centrodesinformacion.desinformados.muebles;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Mueble que ocupa varios bloques (recepción en L, mesa de DJ...). Se coloca de una vez,
 * con el frente mirando al jugador; si rompes una parte se va todo y te devuelve el objeto.
 * Las partes se describen como {a la derecha (vista desde delante), hacia atrás}.
 */
public abstract class MuebleMultiBlock extends HorizontalFacingBlock {
    protected MuebleMultiBlock(Settings settings) {
        super(settings);
    }

    protected abstract IntProperty parte();

    protected abstract int[][] partes();

    static Direction derecha(Direction frente) {
        return frente.rotateYCounterclockwise();
    }

    private BlockPos posDe(BlockPos origen, Direction frente, int i) {
        int[] o = partes()[i];
        return origen.offset(derecha(frente), o[0]).offset(frente.getOpposite(), o[1]);
    }

    private BlockPos origen(BlockState s, BlockPos pos) {
        int[] o = partes()[s.get(parte())];
        Direction f = s.get(FACING);
        return pos.offset(derecha(f), -o[0]).offset(f.getOpposite(), -o[1]);
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction frente = ctx.getHorizontalPlayerFacing().getOpposite();
        BlockPos o = ctx.getBlockPos();
        for (int i = 1; i < partes().length; i++) {
            if (!ctx.getWorld().getBlockState(posDe(o, frente, i)).canReplace(ctx)) return null;
        }
        return getDefaultState().with(FACING, frente).with(parte(), 0);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        Direction f = state.get(FACING);
        for (int i = 1; i < partes().length; i++) {
            world.setBlockState(posDe(pos, f, i), state.with(parte(), i), Block.NOTIFY_ALL);
        }
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this)) {
            BlockPos o = origen(state, pos);
            Direction f = state.get(FACING);
            for (int i = 0; i < partes().length; i++) {
                BlockPos q = posDe(o, f, i);
                BlockState b = world.getBlockState(q);
                if (!q.equals(pos) && b.isOf(this) && b.get(parte()) == i && b.get(FACING) == f) {
                    world.setBlockState(q, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
                }
            }
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }

    @Override
    public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (!world.isClient() && !player.isCreative()) dropStack(world, pos, new ItemStack(this));
        return super.onBreak(world, pos, state, player);
    }
}

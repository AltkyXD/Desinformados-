package com.centrodesinformacion.desinformados.muebles;

import com.centrodesinformacion.desinformados.EstadoServidor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Bloques "de obra" para cerrar zonas mientras se construye (Valla de Obra y Andamio de Obra).
 * No se pueden romper en supervivencia. El servidor recuerda dónde están, y con
 * /desinfo obra quitar desaparecen todos de golpe.
 */
public class ObraBlock extends Block {
    public final String tipo;

    public ObraBlock(Settings settings, String tipo) {
        super(settings);
        this.tipo = tipo;
    }

    private static String clave(World world, BlockPos pos) {
        return world.getRegistryKey().getValue() + "|" + pos.asLong();
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState viejo, boolean notify) {
        if (!world.isClient() && world.getServer() != null) EstadoServidor.get(world.getServer()).agregarObra(clave(world, pos));
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this) && !world.isClient() && world.getServer() != null) {
            EstadoServidor.get(world.getServer()).quitarObra(clave(world, pos));
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }

    /** Quita los bloques de obra del tipo dado ("todo" = los dos). Devuelve cuántos quitó. */
    public static int quitarTodos(MinecraftServer server, String tipo) {
        EstadoServidor estado = EstadoServidor.get(server);
        List<String> lista = new ArrayList<>(estado.getObras());
        int n = 0;
        for (String o : lista) {
            String[] partes = o.split("\\|");
            if (partes.length != 2) { estado.quitarObra(o); continue; }
            ServerWorld w = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(partes[0])));
            if (w == null) { estado.quitarObra(o); continue; }
            BlockPos pos = BlockPos.fromLong(Long.parseLong(partes[1]));
            w.getChunk(pos);   // carga el chunk si hace falta
            BlockState b = w.getBlockState(pos);
            if (!(b.getBlock() instanceof ObraBlock obra)) { estado.quitarObra(o); continue; }
            if (!tipo.equals("todo") && !obra.tipo.equals(tipo)) continue;
            w.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            w.spawnParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 6, 0.3, 0.3, 0.3, 0.02);
            if (n % 8 == 0) w.playSound(null, pos, SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.BLOCKS, 0.6f, 0.8f);
            estado.quitarObra(o);
            n++;
        }
        return n;
    }
}

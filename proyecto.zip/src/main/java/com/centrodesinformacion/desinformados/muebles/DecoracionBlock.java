package com.centrodesinformacion.desinformados.muebles;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

import java.util.EnumMap;
import java.util.Map;

/**
 * Decoración pequeña con forma propia (peluche, lámpara, cuadros...). La caja se da mirando al norte
 * (en píxeles 0-16) y se gira sola. Las de pared se pegan a la pared en la que haces clic.
 */
public class DecoracionBlock extends HorizontalFacingBlock {
    private final MapCodec<DecoracionBlock> codec;
    private final Map<Direction, VoxelShape> formas = new EnumMap<>(Direction.class);
    private final boolean pared;

    public DecoracionBlock(Settings settings, double[] caja, boolean pared) {
        super(settings);
        this.pared = pared;
        this.codec = createCodec(s -> new DecoracionBlock(s, caja, pared));
        for (Direction d : Direction.Type.HORIZONTAL) formas.put(d, girar(caja, d));
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
    }

    /** Gira la caja (definida mirando al norte) igual que el modelo del bloque. */
    private static VoxelShape girar(double[] c, Direction d) {
        double x0 = c[0], z0 = c[2], x1 = c[3], z1 = c[5];
        int vueltas = switch (d) { case EAST -> 1; case SOUTH -> 2; case WEST -> 3; default -> 0; };
        for (int i = 0; i < vueltas; i++) {
            double nx0 = 16 - z1, nx1 = 16 - z0, nz0 = x0, nz1 = x1;
            x0 = nx0; x1 = nx1; z0 = nz0; z1 = nz1;
        }
        return Block.createCuboidShape(x0, c[1], z0, x1, c[4], z1);
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return codec; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction lado = ctx.getSide();
        if (pared && lado.getAxis().isHorizontal()) return getDefaultState().with(FACING, lado);
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return formas.get(state.get(FACING));
    }
}

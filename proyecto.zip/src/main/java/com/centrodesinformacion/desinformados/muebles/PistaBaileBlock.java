package com.centrodesinformacion.desinformados.muebles;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Pista de baile: cada medio segundo todas las baldosas cambian a un color al azar (a la vez). */
public class PistaBaileBlock extends Block {
    public static final IntProperty COLOR = IntProperty.of("color", 0, 15);
    public static final int[] COLORES = {
            0xFF3040, 0xFF8A20, 0xFFE030, 0x60F040, 0x20E0A0, 0x30C8FF, 0x3060FF, 0x9040FF,
            0xFF40D0, 0xFF6090, 0xC0FF30, 0x40FFF0, 0xFFFFFF, 0xFFB0F0, 0x80A0FF, 0xFF5000};
    private static final int CADA = 10;

    public PistaBaileBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(COLOR, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(COLOR);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState().with(COLOR, ctx.getWorld().getRandom().nextInt(16));
    }

    /** Siguiente cambio alineado con el reloj del mundo, para que toda la pista cambie al mismo tiempo. */
    private static int espera(World world) {
        return CADA - (int) (world.getTime() % CADA);
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState viejo, boolean notify) {
        if (!world.isClient()) world.scheduleBlockTick(pos, this, espera(world));
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        int nuevo = (state.get(COLOR) + 1 + random.nextInt(15)) % 16;
        world.setBlockState(pos, state.with(COLOR, nuevo), Block.NOTIFY_LISTENERS);
        world.scheduleBlockTick(pos, this, espera(world));
    }
}

package com.centrodesinformacion.desinformados.muebles;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.Direction;

/** Mostrador de recepción en L: 3 bloques de frente y 1 hacia atrás en el extremo derecho. */
public class RecepcionBlock extends MuebleMultiBlock {
    public static final MapCodec<RecepcionBlock> CODEC = createCodec(RecepcionBlock::new);
    public static final IntProperty PARTE = IntProperty.of("parte", 0, 3);
    private static final int[][] PARTES = {{0, 0}, {1, 0}, {2, 0}, {2, 1}};

    public RecepcionBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PARTE, 0));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }
    @Override protected IntProperty parte() { return PARTE; }
    @Override protected int[][] partes() { return PARTES; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PARTE);
    }
}

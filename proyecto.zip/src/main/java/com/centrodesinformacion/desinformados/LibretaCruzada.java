package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.HoglinEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Cambio de dificultad "libreta_cruzada" (otro intercambio cultural, como MobsCruzados): los mobs dibujados de la Libreta
 * aparecen en el Overworld (de noche o a oscuras) y en el Nether, y los del Overworld y del Nether aparecen en la Libreta
 * (y se quedan como son: la Libreta no los convierte en dibujos, ver Libreta.ENTITY_LOAD).
 */
public final class LibretaCruzada {
    private LibretaCruzada() {}

    public static final String ID = "libreta_cruzada";
    /** Los mobs que llegan por este cambio (la Libreta no los convierte en dibujos). */
    public static final String MARCA = "desinfo_cruzado_libreta";
    private static final int CADA = 100;              // cada 5 s se intenta por jugador
    private static final int MAXIMO_POR_JUGADOR = 6;  // de estos mobs vivos cerca de cada jugador

    /** De la Libreta al Overworld y al Nether. */
    private static final EntityType<?>[] DE_LA_LIBRETA = {
            ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ESQUELETO_DIBUJO, ModEntidades.ESQUELETO_DIBUJO,
            ModEntidades.CREEPER_DIBUJO, ModEntidades.ARANA_DIBUJO, ModEntidades.ARANA_DIBUJO, ModEntidades.FURRO_DIBUJO, ModEntidades.TINTERO,
            com.centrodesinformacion.desinformados.entidad.papel.ModPapel.TRAVENSANO_PAPEL,
            com.centrodesinformacion.desinformados.entidad.papel.ModPapel.FANTASMA_PAPEL};
    /** Del Overworld y del Nether a la Libreta. */
    private static final EntityType<?>[] A_LA_LIBRETA = {
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.SPIDER, EntityType.WITCH, EntityType.SLIME,
            EntityType.ZOMBIFIED_PIGLIN, EntityType.MAGMA_CUBE, EntityType.BLAZE, EntityType.WITHER_SKELETON, EntityType.PIGLIN,
            EntityType.HOGLIN};

    static void evento() {
        Eventos.amarillo(ID, "¡Intercambio cultural con la Libreta!",
                "A partir de ahora los mobs dibujados de la Libreta (zombies, esqueletos, creepers, arañas, Furros dibujados, Tinteros, Travensaños y Fantasmas de Papel) aparecen también "
                        + "en el Overworld (de noche y en sitios oscuros) y en el Nether. Y a la Libreta llegan mobs del Overworld y del Nether "
                        + "(zombies, esqueletos, creepers, arañas, brujas, slimes, blazes, piglins, esqueletos wither...) que no se convierten en dibujos.",
                "El programa de intercambio del Centro de Desinformación tuvo tanto éxito con el Nether que lo han ampliado a la Libreta del Becario. "
                        + "Los dibujos quieren conocer el mundo en 3D y los mobs de verdad quieren saber qué se siente siendo plano. Nadie ha preguntado a los jugadores.",
                server -> EstadoServidor.get(server).agregarCambio(ID));
    }

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % CADA != 0) return;
            if (!EstadoServidor.get(server).tieneCambio(ID)) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator() || p.isCreative()) continue;
                ServerWorld w = p.getServerWorld();
                boolean overworld = w.getRegistryKey() == World.OVERWORLD;
                boolean nether = w.getRegistryKey() == World.NETHER;
                boolean libreta = w.getRegistryKey() == Dimensiones.LIBRETA;
                if (!overworld && !nether && !libreta) continue;
                if (w.getRandom().nextFloat() > 0.6f) continue;
                int cerca = w.getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(48), m -> m.getCommandTags().contains(MARCA)).size();
                if (cerca >= MAXIMO_POR_JUGADOR) continue;
                EntityType<?>[] lista = libreta ? A_LA_LIBRETA : DE_LA_LIBRETA;
                intentar(w, p, lista[w.getRandom().nextInt(lista.length)], overworld);
            }
        });
    }

    private static void intentar(ServerWorld w, ServerPlayerEntity p, EntityType<?> tipo, boolean enOverworld) {
        Random r = w.getRandom();
        for (int intento = 0; intento < 12; intento++) {
            double ang = r.nextDouble() * Math.PI * 2, dist = 18 + r.nextDouble() * 22;
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist), z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
            int y0 = p.getBlockY() + r.nextInt(17) - 8;
            for (int dy = 0; dy < 12; dy++) {
                BlockPos pos = new BlockPos(x, y0 - dy, z);
                if (!sitioValido(w, pos, enOverworld)) continue;
                if (!(tipo.create(w) instanceof MobEntity m)) return;
                m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, r.nextFloat() * 360f, 0f);
                if (!w.isSpaceEmpty(m)) { m.discard(); continue; }
                m.initialize(w, w.getLocalDifficulty(pos), SpawnReason.NATURAL, null);
                if (m instanceof AbstractPiglinEntity pig) pig.setImmuneToZombification(true);   // no se convierten fuera del Nether
                if (m instanceof HoglinEntity hog) hog.setImmuneToZombification(true);
                m.addCommandTag(MARCA);
                m.addCommandTag(Mobs.MARCA_EVENTO);
                w.spawnEntity(m);
                return;
            }
        }
    }

    private static boolean sitioValido(ServerWorld w, BlockPos pos, boolean enOverworld) {
        if (!w.getWorldBorder().contains(pos) || !w.isChunkLoaded(pos)) return false;
        if (Reglas.protegido(w, pos, 0)) return false;                                           // nunca dentro de la zona del Centro
        BlockPos abajo = pos.down();
        if (!w.getBlockState(abajo).isSolidBlock(w, abajo)) return false;
        if (!w.getBlockState(pos).getCollisionShape(w, pos).isEmpty() || !w.getFluidState(pos).isEmpty()) return false;
        if (!w.getBlockState(pos.up()).getCollisionShape(w, pos.up()).isEmpty()) return false;
        return !enOverworld || HostileEntity.isSpawnDark(w, pos, w.getRandom());                 // en el Overworld, de noche o a oscuras
    }
}

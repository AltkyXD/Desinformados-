package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.agua.ModAgua;

import java.util.List;
import java.util.Map;

/** Teles azules de los mobs de agua (cada una desbloquea su mob). */
public final class TelesAgua {
    private TelesAgua() {}

    public static final List<String> IDS = List.of("creeper_agua", "pulpo");

    /** Para la Enciclopedia: nombre corto del mob de cada tele. */
    public static final Map<String, String> NOMBRES = Map.ofEntries(
            Map.entry("creeper_agua", "Creeper de Agua"),
            Map.entry("pulpo", "Pulpo"));

    /** Crea las teles (lo llama Eventos al cargar). Se vuelven azules solas al estar en GRUPO_MOBS. */
    static void eventos() {
        Eventos.amarillo("creeper_agua", "¡Llega el Creeper de Agua!",
                "Aparecerá en océanos, ríos y pantanos. Es un pez azul con cara de creeper y 5 corazones. Si te ve a menos de 16 bloques, "
                        + "nadará hacia ti y, a menos de 2,5 bloques, encenderá la mecha: 1,5 segundos después explotará como un creeper normal "
                        + "(si te alejas a más de 7 bloques antes, se apaga). Si estás fuera del agua a menos de 8 bloques, saltará hacia ti "
                        + "con la mecha ya encendida. Fuera del agua no sabe nadar, pero la mecha sigue.",
                "Para ahorrar en socorristas, el Centro de Desinformación encargó al proveedor \"vigilancia acuática con creepers\". "
                        + "Llegaron en una pecera, azules y con branquias. El seguro no cubre explosiones submarinas. Ni las de la orilla.",
                server -> Eventos.desbloquearMob(server, ModAgua.CREEPER_AGUA));

        Eventos.amarillo("pulpo", "¡Llega el Pulpo!",
                "Aparecerá en océanos, ríos y pantanos. Tiene 15 corazones. Si te ve en el agua a menos de 8 bloques, te atrapará: "
                        + "no podrás moverte y perderás 1 corazón cada 2 segundos hasta que lo golpees (basta un golpe, tuyo o de un compañero), "
                        + "muera o te alejes a más de 10 bloques. Después tarda 5 segundos en poder atraparte otra vez. Si vas en barca a menos "
                        + "de 6 bloques, se meterá debajo y a los 3 segundos te la romperá (la barca y lo que lleve el cofre caen al agua).",
                "El Centro de Desinformación contrató a un pulpo como community manager: con ocho brazos contestaba ocho comentarios a la vez. "
                        + "Lo despidieron por abrazar demasiado a la audiencia. No se lo ha tomado bien y ahora abraza gratis.",
                server -> Eventos.desbloquearMob(server, ModAgua.PULPO));
    }
}

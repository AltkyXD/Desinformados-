package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SignBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.block.enums.SlabType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationPropertyHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.noise.NoiseConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * El Centro de Desinformación aparece solo al crear el mundo: busca la montaña más alta cerca del spawn
 * (si no hay, levanta una), aplana la cima, construye el Centro completo y decorado con todos los gatos,
 * talla una escalera en espiral hasta abajo y protege toda la zona (radio del Centro + 20).
 */
public class GeneradorCentro {
    public static final String GENERADO = "sys:centro_generado";
    /** Radio de la meseta de la cima (el Centro mide 20 de radio y la marquesina de la entrada sale hasta 24). */
    static final int RP = 27;
    /** Radio protegido = Centro + 20 bloques. */
    public static final int RADIO_PROTEGIDO = ConstructorCentro.RADIO + 20;
    private static final int BUSQUEDA = 384, PASO_BUSQUEDA = 12;
    private static final int ALTURA_MINIMA = 45;       // si la "montaña" no llega a mar + 45, se levanta hasta ahí
    private static final double PENDIENTE = 1.3;        // laderas de la montaña levantada (más o menos 52 grados)
    private static final int ALCANCE = RP + 75;         // hasta dónde puede tocar el terreno (y bajar la escalera)

    public static void registrar() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            EstadoServidor e = EstadoServidor.get(server);
            if (e.tieneCambio(GENERADO) || e.getCentroProtegido() != null) return;     // ya hay Centro (generado o construido a mano)
            if (server.getOverworld().getTime() > 1200) return;                         // mundo ya empezado: se hace con /desinfo generar centro
            try {
                generar(server);
            } catch (Exception ex) {
                Desinformados.LOGGER.error("No se pudo generar el Centro de Desinformación", ex);
            }
        });
    }

    private record Sitio(int x, int z, int alto, double puntos) {}

    /** Genera todo. Devuelve el punto de aparición del vestíbulo. */
    public static BlockPos generar(MinecraftServer server) {
        long t0 = System.currentTimeMillis();
        ServerWorld w = server.getOverworld();
        BlockPos spawn = w.getSpawnPos();
        int mar = w.getSeaLevel();

        // 1) La montaña: la cima más alta cerca del spawn (cuanto más lejos, menos puntos), en tierra firme
        ChunkGenerator gen = w.getChunkManager().getChunkGenerator();
        NoiseConfig ruidoMundo = w.getChunkManager().getNoiseConfig();
        List<Sitio> sitios = new ArrayList<>();
        for (int dx = -BUSQUEDA; dx <= BUSQUEDA; dx += PASO_BUSQUEDA) {
            for (int dz = -BUSQUEDA; dz <= BUSQUEDA; dz += PASO_BUSQUEDA) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > BUSQUEDA) continue;
                int x = spawn.getX() + dx, z = spawn.getZ() + dz;
                int suelo = gen.getHeight(x, z, Heightmap.Type.OCEAN_FLOOR_WG, w, ruidoMundo);
                int superficie = gen.getHeight(x, z, Heightmap.Type.WORLD_SURFACE_WG, w, ruidoMundo);
                if (superficie > suelo + 1 || suelo < mar) continue;                      // agua encima: no
                sitios.add(new Sitio(x, z, suelo, suelo - dist / 20.0));
            }
        }
        sitios.sort((a, b) -> Double.compare(b.puntos(), a.puntos()));
        Sitio elegido = null;
        int alturaAnillo = 0;
        for (int i = 0; i < Math.min(25, sitios.size()) && elegido == null; i++) {
            Sitio s = sitios.get(i);
            List<Integer> anillo = new ArrayList<>();
            int tierra = 0;
            for (int k = 0; k < 16; k++) {
                double a = Math.PI * 2 * k / 16;
                int x = s.x() + (int) Math.round(Math.cos(a) * RP), z = s.z() + (int) Math.round(Math.sin(a) * RP);
                int suelo = gen.getHeight(x, z, Heightmap.Type.OCEAN_FLOOR_WG, w, ruidoMundo);
                int superficie = gen.getHeight(x, z, Heightmap.Type.WORLD_SURFACE_WG, w, ruidoMundo);
                if (superficie <= suelo + 1) tierra++;
                anillo.add(suelo);
            }
            if (tierra < 10) continue;
            anillo.sort(Integer::compare);
            alturaAnillo = anillo.get(8);
            elegido = s;
        }
        if (elegido == null) {                                  // todo es mar: se levanta una isla-montaña en el spawn
            int suelo = gen.getHeight(spawn.getX(), spawn.getZ(), Heightmap.Type.OCEAN_FLOOR_WG, w, ruidoMundo);
            elegido = new Sitio(spawn.getX(), spawn.getZ(), suelo, 0);
            alturaAnillo = suelo;
        }
        int cx = elegido.x(), cz = elegido.z();
        boolean natural = Math.round(0.5 * elegido.alto() + 0.5 * alturaAnillo) >= mar + ALTURA_MINIMA;
        int baseY = (int) Math.round(0.5 * elegido.alto() + 0.5 * alturaAnillo);   // altura a la que se camina en la cima
        baseY = Math.max(baseY, mar + ALTURA_MINIMA);
        baseY = Math.min(baseY, w.getTopY() - 45);

        // 2) Cargar (generar) los chunks de toda la zona
        for (int x = (cx - ALCANCE) >> 4; x <= (cx + ALCANCE) >> 4; x++)
            for (int z = (cz - ALCANCE) >> 4; z <= (cz + ALCANCE) >> 4; z++) w.getChunk(x, z);

        // 3) La entrada mira hacia el spawn original
        int vx = spawn.getX() - cx, vz = spawn.getZ() - cz;
        Direction haciaSpawn = (vx * vx + vz * vz < 64) ? Direction.NORTH : Direction.getFacing(vx, 0, vz);
        Direction adelante = haciaSpawn.getOpposite();
        BlockPos centroPiso = new BlockPos(cx, baseY - 1, cz);
        ConstructorCentro.Sistema s = new ConstructorCentro.Sistema(centroPiso, adelante);
        long semilla = w.getSeed() ^ 0x5DEECE66DL;

        // 4) Modelar la montaña, construir el Centro, la escalera y decorar
        Materiales mat = materiales(w, cx, cz);
        moldear(w, cx, cz, baseY, semilla, mat);
        BlockPos[] r = ConstructorCentro.construirEn(w, centroPiso, adelante, true);
        List<BlockPos> conectar = new ArrayList<>();
        Map<Long, Columna> camino = escalera(w, s, baseY, semilla, conectar);
        meseta(w, s, baseY, semilla, camino, conectar);
        DisenoCentro.decorar(w, s, conectar);
        for (BlockPos q : conectar) {
            BlockState b = w.getBlockState(q);
            w.setBlockState(q, Block.postProcessState(b, w, q), Block.NOTIFY_LISTENERS);
        }
        DisenoCentro.gatos(w, s);

        // 5) Protección, spawn y llegada después de la cinemática
        EstadoServidor e = EstadoServidor.get(server);
        e.setCentroProtegido(r[0].asLong());
        if (e.getRadioSpawn() < RADIO_PROTEGIDO) e.setRadioSpawn(RADIO_PROTEGIDO);
        float yaw = adelante.asRotation();
        w.setSpawnPos(r[1], yaw);
        server.getGameRules().get(GameRules.SPAWN_RADIUS).set(0, server);
        com.centrodesinformacion.desinformados.intro.Intro.fijarCentro(r[1], yaw, server);
        e.agregarCambio(GENERADO);
        Desinformados.LOGGER.info("Centro de Desinformación generado en {} {} {} ({}), en {} ms", cx, baseY, cz,
                natural ? "montaña natural" : "montaña levantada", System.currentTimeMillis() - t0);
        return r[1];
    }

    // ------------------------------------------------------------------ terreno

    /** Superficie de la montaña: lo que había en la zona (césped, nieve, arena...) y lo que va debajo. */
    record Materiales(BlockState arriba, BlockState debajo, BlockState meseta) {}

    private static Materiales materiales(ServerWorld w, int cx, int cz) {
        Map<Block, Integer> votos = new HashMap<>();
        for (int k = 0; k < 24; k++) {
            double a = Math.PI * 2 * k / 24;
            for (int rr : new int[]{10, 24, 38}) {
                int x = cx + (int) Math.round(Math.cos(a) * rr), z = cz + (int) Math.round(Math.sin(a) * rr);
                Block b = w.getBlockState(new BlockPos(x, suelo(w, x, z), z)).getBlock();
                votos.merge(b, 1, Integer::sum);
            }
        }
        Block mas = Blocks.GRASS_BLOCK;
        int max = -1;
        for (var en : votos.entrySet()) if (en.getValue() > max) { max = en.getValue(); mas = en.getKey(); }
        if (mas == Blocks.SNOW_BLOCK || mas == Blocks.POWDER_SNOW)
            return new Materiales(Blocks.SNOW_BLOCK.getDefaultState(), Blocks.STONE.getDefaultState(), Blocks.SNOW_BLOCK.getDefaultState());
        if (mas == Blocks.SAND) return new Materiales(Blocks.SAND.getDefaultState(), Blocks.SANDSTONE.getDefaultState(), Blocks.SAND.getDefaultState());
        if (mas == Blocks.RED_SAND)
            return new Materiales(Blocks.RED_SAND.getDefaultState(), Blocks.RED_SANDSTONE.getDefaultState(), Blocks.RED_SAND.getDefaultState());
        if (mas == Blocks.PODZOL || mas == Blocks.MYCELIUM || mas == Blocks.COARSE_DIRT)
            return new Materiales(mas.getDefaultState(), Blocks.DIRT.getDefaultState(), Blocks.GRASS_BLOCK.getDefaultState());
        return new Materiales(Blocks.GRASS_BLOCK.getDefaultState(), Blocks.DIRT.getDefaultState(), Blocks.GRASS_BLOCK.getDefaultState());
    }

    /** ¿Este bloque es "terreno de verdad"? (no aire, agua, plantas, troncos ni hojas) */
    private static boolean esTerreno(BlockState b) {
        return !b.isAir() && !b.isReplaceable() && b.getFluidState().isEmpty() && !b.isIn(BlockTags.LOGS) && !b.isIn(BlockTags.LEAVES)
                && !b.isOf(Blocks.BROWN_MUSHROOM_BLOCK) && !b.isOf(Blocks.RED_MUSHROOM_BLOCK) && !b.isOf(Blocks.MUSHROOM_STEM)
                && !b.isOf(Blocks.BAMBOO) && !b.isOf(Blocks.CACTUS) && !b.isOf(Blocks.SUGAR_CANE) && !b.isOf(Blocks.BEE_NEST);
    }

    /** Altura del último bloque de terreno de la columna (ignorando árboles, plantas y agua). */
    static int suelo(ServerWorld w, int x, int z) {
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        BlockPos.Mutable m = new BlockPos.Mutable(x, y, z);
        while (y > w.getBottomY() && !esTerreno(w.getBlockState(m.setY(y)))) y--;
        return y;
    }

    private static void poner(ServerWorld w, BlockPos.Mutable m, int y, BlockState b) {
        m.setY(y);
        if (w.getBlockState(m) != b) w.setBlockState(m, b, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
    }

    /** Ruido suave entre 0 y 1 (para que las laderas no sean un cono perfecto). */
    static double ruido(long semilla, double x, double z) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        double fx = x - x0, fz = z - z0;
        fx = fx * fx * (3 - 2 * fx);
        fz = fz * fz * (3 - 2 * fz);
        double a = azar(semilla, x0, z0), b = azar(semilla, x0 + 1, z0), c = azar(semilla, x0, z0 + 1), d = azar(semilla, x0 + 1, z0 + 1);
        return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fz;
    }

    static double azar(long semilla, int x, int z) {
        long n = semilla ^ (x * 0x9E3779B97F4A7C15L) ^ (z * 0xC2B2AE3D27D4EB4FL);
        n = (n ^ (n >>> 31)) * 0xBF58476D1CE4E5B9L;
        n = (n ^ (n >>> 29)) * 0x94D049BB133111EBL;
        n ^= n >>> 32;
        return (n >>> 11) * 0x1.0p-53;
    }

    /**
     * Aplana la cima en una meseta de radio RP a la altura baseY y, alrededor, rellena una ladera empinada
     * (cono con ruido) donde el terreno quede por debajo; si el terreno sube más que la meseta cerca del borde, lo recorta en rampa.
     */
    private static void moldear(ServerWorld w, int cx, int cz, int baseY, long semilla, Materiales mat) {
        BlockState piedra = Blocks.STONE.getDefaultState(), andesita = Blocks.ANDESITE.getDefaultState(), aire = Blocks.AIR.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        int arribaMax = w.getTopY() - 1;
        for (int dx = -ALCANCE; dx <= ALCANCE; dx++) {
            for (int dz = -ALCANCE; dz <= ALCANCE; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > ALCANCE) continue;
                int x = cx + dx, z = cz + dz;
                int t0 = suelo(w, x, z);
                int nuevo;
                boolean meseta = d <= RP + 0.5;
                if (meseta) {
                    nuevo = baseY - 1;
                } else {
                    double pendiente = PENDIENTE * (0.8 + 0.5 * ruido(semilla, x / 14.0, z / 14.0));
                    double cono = baseY - 1 - (d - RP) * pendiente - ruido(semilla + 7, x / 6.0, z / 6.0) * 2.0;
                    nuevo = t0;
                    if (cono > t0) nuevo = (int) Math.floor(cono);
                    if (d <= RP + 16) {
                        double rampa = baseY - 1 + (d - RP) * 1.1 + ruido(semilla + 3, x / 5.0, z / 5.0) * 2.0;
                        if (nuevo > rampa) nuevo = (int) Math.floor(rampa);
                    }
                    if (nuevo == t0) continue;                                  // aquí no se toca nada
                }
                m.set(x, 0, z);
                // ¿roca o tierra en la superficie? (manchas de roca por la ladera)
                boolean roca = !meseta && ruido(semilla + 11, x / 7.0, z / 7.0) > 0.64;
                BlockState arriba = meseta ? mat.meseta() : roca ? (ruido(semilla + 13, x / 3.0, z / 3.0) > 0.5 ? piedra : andesita) : mat.arriba();
                BlockState debajo = roca ? piedra : (meseta && mat.meseta().isOf(Blocks.GRASS_BLOCK) ? Blocks.DIRT.getDefaultState() : mat.debajo());
                if (nuevo > t0) {
                    for (int y = t0 + 1; y < nuevo - 3; y++) poner(w, m, y, ruido(semilla + 17, x / 9.0 + y / 13.0, z / 9.0) > 0.7 ? andesita : piedra);
                } else {
                    for (int y = nuevo + 1; y <= Math.min(arribaMax, t0); y++) poner(w, m, y, aire);       // se recorta la roca (agua incluida)
                }
                for (int y = Math.max(t0 + 1, nuevo - 3); y < nuevo; y++) poner(w, m, y, debajo);
                if (nuevo <= t0) for (int y = nuevo - 3; y < nuevo; y++) {     // recortado: la capa de debajo vuelve a ser tierra/arena
                    BlockState b = w.getBlockState(m.setY(y));
                    if (b.isOf(Blocks.STONE) || b.isOf(Blocks.DIRT) || b.isOf(Blocks.GRASS_BLOCK) || b.isOf(Blocks.SNOW_BLOCK)) poner(w, m, y, debajo);
                }
                poner(w, m, nuevo, arriba);
                // árboles, plantas y nieve que se quedarían flotando o enterrados: fuera (el agua se queda)
                for (int y = Math.max(nuevo, t0) + 1; y <= Math.min(arribaMax, Math.max(nuevo, t0) + 22); y++) {
                    BlockState b = w.getBlockState(m.setY(y));
                    if (!b.isAir() && b.getFluidState().isEmpty()) w.setBlockState(m, aire, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
                }
            }
        }
    }

    // ------------------------------------------------------------------ escalera en espiral

    /** Una columna del camino: altura en medios bloques de donde se pisa, y a qué distancia del centro del camino está. */
    record Columna(int alto2, double dist, int muestra) {}

    private record Muestra(double x, double z, double alto, double ox, double oz) {}

    /**
     * Talla una escalera en espiral que baja desde el borde de la meseta (delante de la entrada) rodeando la montaña,
     * pegada a la ladera: medio bloque de bajada por bloque (losas), 3 de ancho, barandal donde hay caída y faroles.
     */
    private static Map<Long, Columna> escalera(ServerWorld w, ConstructorCentro.Sistema s, int baseY, long semilla, List<BlockPos> conectar) {
        List<Muestra> muestras = new ArrayList<>();
        double r = RP + 2.5, ang = 0, alto = baseY;
        int mar = w.getSeaLevel();
        for (int i = 0; i < 6000; i++) {
            Vec3d p = s.punto(r * Math.sin(ang), 0, -r * Math.cos(ang));
            Vec3d fuera = s.punto(Math.sin(ang), 0, -Math.cos(ang)).subtract(s.punto(0, 0, 0));
            muestras.add(new Muestra(p.x, p.z, alto, fuera.x, fuera.z));
            // avanzar medio bloque rodeando la montaña y bajar un cuarto de bloque
            ang += 0.5 / r;
            alto -= 0.25;
            Vec3d q = s.punto(r * Math.sin(ang), 0, -r * Math.cos(ang));
            int pisada = suelo(w, (int) Math.floor(q.x), (int) Math.floor(q.z)) + 1;
            double dif = pisada - alto;
            if (dif > 0.5) r += Math.min(0.8, 0.25 + 0.25 * (dif - 0.5));          // se mete en la montaña: hacia fuera
            else if (dif < -1.5) r -= Math.min(0.8, 0.25 + 0.25 * (-dif - 1.5));   // va por el aire: hacia dentro
            r = Math.max(r, RP + 2.5 + ang / (Math.PI * 2) * 6);   // nunca encima de la vuelta anterior
            if (r > ALCANCE - 4) break;
            if (alto <= mar + 1) break;
            if (alto < baseY - 8) {                                  // ¿ya llegó abajo? (el terreno de fuera ya no está más bajo que el camino)
                Vec3d o = s.punto((r + 5) * Math.sin(ang), 0, -(r + 5) * Math.cos(ang));
                int fueraY = suelo(w, (int) Math.floor(o.x), (int) Math.floor(o.z)) + 1;
                if (fueraY >= alto - 0.5) break;
            }
        }

        // columnas: cada bloque toma la altura de la muestra más cercana
        Map<Long, Columna> camino = new HashMap<>(), borde = new HashMap<>();
        for (int i = 0; i < muestras.size(); i++) {
            Muestra mu = muestras.get(i);
            int bx = (int) Math.floor(mu.x()), bz = (int) Math.floor(mu.z());
            for (int ox = -3; ox <= 3; ox++) for (int oz = -3; oz <= 3; oz++) {
                int x = bx + ox, z = bz + oz;
                double d = Math.hypot(x + 0.5 - mu.x(), z + 0.5 - mu.z());
                long k = BlockPos.asLong(x, 0, z);
                Columna c = new Columna((int) Math.round(mu.alto() * 2), d, i);
                if (d <= 1.6) {
                    Columna ya = camino.get(k);
                    if (ya == null || d < ya.dist()) camino.put(k, c);
                } else if (d <= 2.4) {
                    Columna ya = borde.get(k);
                    if (ya == null || d < ya.dist()) borde.put(k, c);
                }
            }
        }

        BlockState aire = Blocks.AIR.getDefaultState();
        BlockState apoyo = Blocks.COBBLESTONE.getDefaultState();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (var en : camino.entrySet()) {
            int x = BlockPos.unpackLongX(en.getKey()), z = BlockPos.unpackLongZ(en.getKey());
            int h2 = en.getValue().alto2(), ys = Math.floorDiv(h2, 2);
            boolean losa = (h2 & 1) == 1;
            double a = azar(semilla, x, z);
            m.set(x, 0, z);
            BlockState ladrillo = a < 0.12 ? Blocks.MOSSY_STONE_BRICKS.getDefaultState() : a < 0.2 ? Blocks.CRACKED_STONE_BRICKS.getDefaultState()
                    : Blocks.STONE_BRICKS.getDefaultState();
            for (int y = ys - 2; y > ys - 60; y--) {                  // relleno de debajo hasta el terreno
                if (esTerreno(w.getBlockState(m.setY(y)))) break;
                poner(w, m, y, apoyo);
            }
            poner(w, m, ys - 1, ladrillo);
            if (losa) poner(w, m, ys, (a < 0.12 ? Blocks.MOSSY_STONE_BRICK_SLAB : Blocks.STONE_BRICK_SLAB).getDefaultState().with(SlabBlock.TYPE, SlabType.BOTTOM));
            for (int y = losa ? ys + 1 : ys; y <= ys + 3; y++) poner(w, m, y, aire);
        }
        // barandal donde hay caída
        BlockState muro = Blocks.STONE_BRICK_WALL.getDefaultState();
        java.util.Set<Long> barandal = new java.util.HashSet<>();
        for (var en : borde.entrySet()) {
            if (camino.containsKey(en.getKey())) continue;
            int x = BlockPos.unpackLongX(en.getKey()), z = BlockPos.unpackLongZ(en.getKey());
            int ys = Math.floorDiv(en.getValue().alto2(), 2);
            int t = suelo(w, x, z);
            if (t + 1 >= ys) continue;                                 // aquí hay montaña al lado: no hace falta
            m.set(x, 0, z);
            for (int y = t + 1; y < ys; y++) poner(w, m, y, Blocks.STONE_BRICKS.getDefaultState());
            poner(w, m, ys, muro);
            conectar.add(new BlockPos(x, ys, z));
            barandal.add(en.getKey());
        }
        // faroles cada 10 bloques: encima del barandal o, si no hay, en un poste del lado de la montaña
        for (int i = 20; i < muestras.size(); i += 20) {
            Muestra mu = muestras.get(i);
            int ys = (int) Math.floor(mu.alto());
            for (int lado : new int[]{2, -2}) {
                int x = (int) Math.floor(mu.x() + mu.ox() * lado), z = (int) Math.floor(mu.z() + mu.oz() * lado);
                long k = BlockPos.asLong(x, 0, z);
                if (camino.containsKey(k)) continue;
                if (barandal.contains(k)) {
                    int yb = Math.floorDiv(borde.get(k).alto2(), 2);
                    w.setBlockState(new BlockPos(x, yb + 1, z), Blocks.LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
                    break;
                }
                int t = suelo(w, x, z);
                if (Math.abs(t + 1 - ys) <= 1) {
                    BlockPos q = new BlockPos(x, t + 1, z);
                    for (int y = 0; y < 4; y++) w.setBlockState(q.up(y), aire, Block.NOTIFY_LISTENERS);
                    w.setBlockState(q, Blocks.COBBLESTONE_WALL.getDefaultState(), Block.NOTIFY_LISTENERS);
                    w.setBlockState(q.up(), Blocks.LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
                    conectar.add(q);
                    break;
                }
            }
        }
        // cartel al pie de la escalera
        if (muestras.size() > 8) {
            Muestra fin = muestras.get(muestras.size() - 1);
            int x = (int) Math.floor(fin.x() + fin.ox() * 2.6), z = (int) Math.floor(fin.z() + fin.oz() * 2.6);
            if (!camino.containsKey(BlockPos.asLong(x, 0, z))) {
                int t = suelo(w, x, z);
                BlockPos q = new BlockPos(x, t + 1, z);
                float yawFuera = (float) Math.toDegrees(Math.atan2(-fin.ox(), fin.oz()));
                w.setBlockState(q, Blocks.SPRUCE_SIGN.getDefaultState().with(SignBlock.ROTATION, RotationPropertyHelper.fromYaw(yawFuera)), Block.NOTIFY_ALL);
                if (w.getBlockEntity(q) instanceof SignBlockEntity cartel) {
                    cartel.setText(new SignText()
                            .withMessage(0, Text.literal("▲ ▲ ▲"))
                            .withMessage(1, Text.literal("Centro de"))
                            .withMessage(2, Text.literal("Desinformación"))
                            .withMessage(3, Text.literal("(sube)")), true);
                }
            }
        }
        return camino;
    }

    // ------------------------------------------------------------------ cima

    /** La explanada de la cima: camino de la entrada a la escalera, muro bajo alrededor con faroles y unas flores. */
    private static void meseta(ServerWorld w, ConstructorCentro.Sistema s, int baseY, long semilla, Map<Long, Columna> camino, List<BlockPos> conectar) {
        BlockState ladrillo = Blocks.STONE_BRICKS.getDefaultState(), aire = Blocks.AIR.getDefaultState();
        int piso = baseY - 1 - s.centro().getY();          // = 0: la explanada está a la altura del suelo del Centro
        // camino de la entrada (dz = -21) hasta la escalera
        for (int dz = -RP - 3; dz <= -ConstructorCentro.RADIO - 1; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                BlockPos q = s.at(dx, piso, dz);
                if (camino.containsKey(BlockPos.asLong(q.getX(), 0, q.getZ()))) continue;
                if (Math.sqrt(dx * dx + dz * dz) <= ConstructorCentro.RADIO + 0.5) continue;
                w.setBlockState(q, ladrillo, Block.NOTIFY_LISTENERS);
                for (int y = 1; y <= 40 && !esTerreno(w.getBlockState(q.down(y))); y++)                 // apoyo hasta la ladera
                    w.setBlockState(q.down(y), Blocks.COBBLESTONE.getDefaultState(), Block.NOTIFY_LISTENERS);
                for (int y = 1; y <= 3; y++) if (!w.getBlockState(q.up(y)).isOf(ModBloques.REJILLA_METAL) && !w.getBlockState(q.up(y)).isOf(ModBloques.VIGA_ACERO))
                    w.setBlockState(q.up(y), aire, Block.NOTIFY_LISTENERS);
            }
        }
        // faroles a los lados del camino, pasada la marquesina
        for (int lado : new int[]{-2, 2}) {
            BlockPos q = s.at(lado, piso + 1, -RP + 1);
            w.setBlockState(q, Blocks.STONE_BRICK_WALL.getDefaultState(), Block.NOTIFY_LISTENERS);
            w.setBlockState(q.up(), Blocks.LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
            conectar.add(q);
        }
        // muro bajo alrededor de la explanada (con hueco para el camino) y un farol en cada tramo
        for (int dx = -RP - 1; dx <= RP + 1; dx++) {
            for (int dz = -RP - 1; dz <= RP + 1; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= RP - 0.5 || d > RP + 0.5) continue;
                if (dz < 0 && Math.abs(dx) <= 2) continue;                                   // hueco hacia la escalera
                BlockPos q = s.at(dx, piso + 1, dz);
                long k = BlockPos.asLong(q.getX(), 0, q.getZ());
                boolean cercaDelCamino = false;
                for (int ox = -1; ox <= 1 && !cercaDelCamino; ox++)
                    for (int oz = -1; oz <= 1 && !cercaDelCamino; oz++) cercaDelCamino = camino.containsKey(BlockPos.asLong(q.getX() + ox, 0, q.getZ() + oz));
                if (cercaDelCamino) continue;
                if (!w.getBlockState(q.down()).isSolidBlock(w, q.down())) continue;
                w.setBlockState(q, Blocks.STONE_BRICK_WALL.getDefaultState(), Block.NOTIFY_LISTENERS);
                conectar.add(q);
                double ang = Math.atan2(dx, -dz);
                if (Math.abs(ang - Math.round(ang / (Math.PI / 8)) * (Math.PI / 8)) * RP < 0.5)
                    w.setBlockState(q.up(), Blocks.LANTERN.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        // flores y hierba en la explanada (alrededor del edificio)
        Block[] flores = {Blocks.SHORT_GRASS, Blocks.SHORT_GRASS, Blocks.SHORT_GRASS, Blocks.POPPY, Blocks.DANDELION, Blocks.CORNFLOWER, Blocks.AZURE_BLUET, Blocks.OXEYE_DAISY};
        for (int dx = -RP; dx <= RP; dx++) {
            for (int dz = -RP; dz <= RP; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < ConstructorCentro.RADIO + 1.5 || d > RP - 1.5) continue;
                if (dz < 0 && Math.abs(dx) <= 5) continue;                                   // la entrada y la marquesina
                BlockPos q = s.at(dx, piso, dz);
                if (!w.getBlockState(q).isOf(Blocks.GRASS_BLOCK) || !w.getBlockState(q.up()).isAir()) continue;
                double a = azar(semilla + 99, q.getX(), q.getZ());
                if (a < 0.14) w.setBlockState(q.up(), flores[(int) (a / 0.14 * flores.length) % flores.length].getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Crafteos;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.CraftingScreenHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Vacía el resultado de la mesa de crafteo (y del 2x2 del inventario) si el objeto está bloqueado. */
@Mixin(CraftingScreenHandler.class)
public abstract class CraftingScreenHandlerMixin {
    @ModifyVariable(method = "updateResult", ordinal = 0,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/CraftingResultInventory;setStack(ILnet/minecraft/item/ItemStack;)V"))
    private static ItemStack desinformados$bloquear(ItemStack resultado) {
        return Crafteos.filtrar(resultado);
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Spawn protegido: no se pueden colocar bloques dentro de la zona del Centro (salvo en creativo).
 * Mira la posición donde quedaría el bloque, y como va después de la interacción del bloque,
 * con un bloque en la mano se siguen pudiendo usar puertas, cofres, tragamonedas, ruleta, banco...
 */
@Mixin(BlockItem.class)
public abstract class ColocarProtegidoMixin {
    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("HEAD"), cancellable = true)
    private void desinformados$noConstruirEnSpawn(ItemPlacementContext contexto, CallbackInfoReturnable<ActionResult> cir) {
        PlayerEntity jugador = contexto.getPlayer();
        if (jugador == null || jugador.isCreative()) return;
        if (Reglas.protegido(contexto.getWorld(), contexto.getBlockPos(), 0)) {
            jugador.sendMessage(Text.literal("No puedes construir en el spawn").formatted(Formatting.RED), true);
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}

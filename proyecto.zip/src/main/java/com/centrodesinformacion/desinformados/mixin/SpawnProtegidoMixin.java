package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Zona del Centro: no aparecen mobs hostiles por sí solos (spawn natural, spawners, refuerzos...). */
@Mixin(SpawnRestriction.class)
public abstract class SpawnProtegidoMixin {
    @Inject(method = "canSpawn", at = @At("HEAD"), cancellable = true)
    private static void desinformados$sinHostiles(EntityType<?> tipo, ServerWorldAccess mundo, SpawnReason razon, BlockPos pos, Random random,
                                                 CallbackInfoReturnable<Boolean> cir) {
        if (tipo.getSpawnGroup() != SpawnGroup.MONSTER) return;
        var w = mundo.toServerWorld();
        if (w == null || w.getServer() == null || !w.getServer().isOnThread()) return;   // generación de chunks en otro hilo: no tocar el estado
        if (Reglas.protegido(w, pos, 0)) cir.setReturnValue(false);
    }
}

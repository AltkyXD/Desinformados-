package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.EstadoServidor;
import net.minecraft.block.EndPortalBlock;
import net.minecraft.block.NetherPortalBlock;
import net.minecraft.block.Portal;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** El Nether y el End están cerrados hasta que se lance su evento morado (/desinfo lanzar nether | end). */
@Mixin(Entity.class)
public abstract class PortalBloqueadoMixin {
    @Inject(method = "tryUsePortal", at = @At("HEAD"), cancellable = true)
    private void desinformados$portalCerrado(Portal portal, BlockPos pos, CallbackInfo ci) {
        Entity yo = (Entity) (Object) this;
        if (yo.getWorld().isClient() || Desinformados.SERVER == null) return;
        EstadoServidor estado = EstadoServidor.get(Desinformados.SERVER);
        String cerrado = null;
        if (portal instanceof NetherPortalBlock && !estado.tieneCambio("nether_abierto")) cerrado = "El Nether";
        else if (portal instanceof EndPortalBlock && !estado.tieneCambio("end_abierto")) cerrado = "El End";
        if (cerrado == null) return;
        ci.cancel();
        if (yo instanceof ServerPlayerEntity p && p.age % 40 == 0) {
            p.sendMessage(Text.literal(cerrado + " todavía no ha sido autorizado por el Centro de Desinformación.")
                    .formatted(Formatting.LIGHT_PURPLE), true);
        }
    }
}

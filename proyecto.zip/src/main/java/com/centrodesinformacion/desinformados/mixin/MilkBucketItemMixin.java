package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.MilkBucketItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Leche cortada: la leche ya no quita los efectos. */
@Mixin(MilkBucketItem.class)
public abstract class MilkBucketItemMixin {
    @Redirect(method = "finishUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;clearStatusEffects()Z"))
    private boolean desinformados$lecheCortada(LivingEntity entidad) {
        if (CambiosActivos.en(entidad.getWorld(), "leche_cortada")) return false;
        return entidad.clearStatusEffects();
    }
}

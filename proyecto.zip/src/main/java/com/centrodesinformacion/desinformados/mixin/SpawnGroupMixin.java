package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.MasMobs;
import com.centrodesinformacion.desinformados.NocheSangre;
import net.minecraft.entity.SpawnGroup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Límite de monstruos:
 * - "¡Hay más monstruos!" (MasMobs): +30 % en todas las dimensiones.
 * - Noche de Sangre: x3 mientras se procesa el Overworld en una Noche de Sangre.
 */
@Mixin(SpawnGroup.class)
public abstract class SpawnGroupMixin {
    @Inject(method = "getCapacity", at = @At("RETURN"), cancellable = true)
    private void desinformados$masMonstruos(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this != SpawnGroup.MONSTER) return;
        int antes = cir.getReturnValueI();
        int limite = antes;
        if (MasMobs.activo) limite = Math.round(limite * MasMobs.FACTOR);
        if (NocheSangre.triplicar) limite *= NocheSangre.MULTIPLICADOR;
        if (limite != antes) cir.setReturnValue(limite);
    }
}

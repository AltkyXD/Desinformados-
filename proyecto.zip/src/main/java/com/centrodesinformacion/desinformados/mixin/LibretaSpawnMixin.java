package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * En la Libreta del Becario los monstruos aparecen en cualquier condición: de día, a pleno sol y junto a antorchas.
 * (Todos los mobs de allí miran la oscuridad con HostileEntity.isSpawnDark: los normales que se convierten en dibujos,
 * los Garabatos, los Tinteros y los de papel.) Fuera de la Libreta no cambia nada.
 */
@Mixin(HostileEntity.class)
public abstract class LibretaSpawnMixin {
    @Inject(method = "isSpawnDark", at = @At("HEAD"), cancellable = true)
    private static void desinformados$libretaSiempre(ServerWorldAccess mundo, BlockPos pos, Random random, CallbackInfoReturnable<Boolean> cir) {
        if (mundo.toServerWorld().getRegistryKey() == Dimensiones.LIBRETA) cir.setReturnValue(true);
    }
}

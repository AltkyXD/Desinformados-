package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.entity.player.HungerManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Regeneración lenta: la vida natural se recupera a la mitad. */
@Mixin(HungerManager.class)
public abstract class HungerManagerMixin {
    @ModifyArg(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;heal(F)V"))
    private float desinformados$regeneracionLenta(float cantidad) {
        return CambiosActivos.servidor("regeneracion_lenta") ? cantidad * 0.5f : cantidad;
    }
}

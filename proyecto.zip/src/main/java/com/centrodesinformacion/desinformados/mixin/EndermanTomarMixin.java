package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.entity.mob.EndermanEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Zona del Centro: los endermen no se llevan bloques (cogen a 2-3 bloques de distancia, por eso el margen). */
@Mixin(targets = "net.minecraft.entity.mob.EndermanEntity$PickUpBlockGoal")
public abstract class EndermanTomarMixin {
    @Shadow @Final private EndermanEntity enderman;

    @Inject(method = "canStart", at = @At("HEAD"), cancellable = true)
    private void desinformados$noTomar(CallbackInfoReturnable<Boolean> cir) {
        if (Reglas.protegido(enderman.getWorld(), enderman.getBlockPos(), 4)) cir.setReturnValue(false);
    }
}

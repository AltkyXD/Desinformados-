package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hornos glotones: el combustible dura la mitad. */
@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceMixin {
    @Inject(method = "getFuelTime", at = @At("RETURN"), cancellable = true)
    private void desinformados$hornosGlotones(ItemStack combustible, CallbackInfoReturnable<Integer> cir) {
        if (CambiosActivos.servidor("hornos_glotones")) cir.setReturnValue(Math.max(1, cir.getReturnValue() / 2));
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Crafteos;
import net.minecraft.block.CrafterBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

/**
 * El Crafter (autocrafteador) tampoco puede fabricar lo bloqueado (equipo de diamante, recetas nuevas del mod).
 * Tanto el crafteo (CrafterBlock.craft) como la vista previa (CrafterScreenHandler.updateResult) piden la receta aquí.
 */
@Mixin(CrafterBlock.class)
public abstract class CrafterBloqueadoMixin {
    @Inject(method = "getCraftingRecipe", at = @At("RETURN"), cancellable = true)
    private static void desinformados$bloquear(World world, CraftingRecipeInput entrada,
                                               CallbackInfoReturnable<Optional<RecipeEntry<CraftingRecipe>>> cir) {
        Optional<RecipeEntry<CraftingRecipe>> receta = cir.getReturnValue();
        if (receta == null || receta.isEmpty() || world.isClient()) return;
        ItemStack resultado = receta.get().value().craft(entrada, world.getRegistryManager());
        if (!resultado.isEmpty() && Crafteos.filtrar(resultado).isEmpty()) cir.setReturnValue(Optional.empty());
    }
}

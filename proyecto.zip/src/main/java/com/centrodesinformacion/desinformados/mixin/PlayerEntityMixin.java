package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    /** Encantamientos caros: la mesa de encantamientos cobra el doble de niveles. */
    @ModifyVariable(method = "applyEnchantmentCosts", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private int desinformados$encantarCaro(int niveles) {
        return CambiosActivos.servidor("encantamientos_caros") ? niveles * 2 : niveles;
    }

    /** Comida podrida: la carne y el pescado crudos tienen un 30% de darte náuseas y hambre. */
    @Inject(method = "eatFood", at = @At("HEAD"))
    private void desinformados$comidaPodrida(World world, ItemStack stack, FoodComponent comida, CallbackInfoReturnable<ItemStack> cir) {
        if (world.isClient() || !CambiosActivos.servidor("comida_podrida")) return;
        if (!(stack.isOf(Items.BEEF) || stack.isOf(Items.PORKCHOP) || stack.isOf(Items.CHICKEN) || stack.isOf(Items.MUTTON)
                || stack.isOf(Items.RABBIT) || stack.isOf(Items.COD) || stack.isOf(Items.SALMON) || stack.isOf(Items.TROPICAL_FISH))) return;
        PlayerEntity p = (PlayerEntity) (Object) this;
        if (p.getRandom().nextFloat() < 0.3f) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 300, 1));
        }
    }
}

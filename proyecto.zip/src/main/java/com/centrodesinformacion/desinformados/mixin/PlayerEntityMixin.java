package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Vida;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Orden del daño: armadura -> corazones dorados (temporales, vanilla) -> corazones de ALMA -> corazones rojos.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @ModifyVariable(method = "applyDamage",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;addExhaustion(F)V"),
            argsOnly = true)
    private float desinformados$escudoDeAlmas(float cantidad) {
        if ((Object) this instanceof ServerPlayerEntity jugador) {
            return Vida.absorberConAlmas(jugador, cantidad);
        }
        return cantidad;
    }
}

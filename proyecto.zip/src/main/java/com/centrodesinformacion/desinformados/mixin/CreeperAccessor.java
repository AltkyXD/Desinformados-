package com.centrodesinformacion.desinformados.mixin;

import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.mob.CreeperEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Acceso al dato "electrificado" del creeper (Minecraft no tiene un método público para ponerlo). */
@Mixin(CreeperEntity.class)
public interface CreeperAccessor {
    @Accessor("CHARGED")
    static TrackedData<Boolean> desinformados$getCharged() {
        throw new AssertionError();
    }
}

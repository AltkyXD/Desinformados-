package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.EstadoServidor;
import net.minecraft.block.BlockState;
import net.minecraft.block.SaplingBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cambio de dificultad "arboles": los brotes nunca crecen (ni con polvo de hueso). */
@Mixin(SaplingBlock.class)
public abstract class SaplingBlockMixin {
    @Inject(method = "generate", at = @At("HEAD"), cancellable = true)
    private void desinformados$arbolesMuertos(ServerWorld world, BlockPos pos, BlockState state, Random random, CallbackInfo ci) {
        if (EstadoServidor.get(world.getServer()).tieneCambio("arboles")) {
            ci.cancel();
        }
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Zona del Centro: las explosiones (creepers, TNT, la lluvia de creepers...) no rompen ni queman nada dentro. En la tele, no rompen la prismarina. */
@Mixin(Explosion.class)
public abstract class ExplosionProtegidaMixin {
    @Shadow @Final private World world;

    @Inject(method = "affectWorld", at = @At("HEAD"))
    private void desinformados$zonaProtegida(boolean particulas, CallbackInfo ci) {
        if (world.isClient() || world.getServer() == null) return;
        if (world.getRegistryKey() == com.centrodesinformacion.desinformados.dimension.Dimensiones.TELE) {   // la prismarina de la tele aguanta
            ((Explosion) (Object) this).getAffectedBlocks().removeIf(pos -> Reglas.prismarinaDeLaTele(world, world.getBlockState(pos)));
            return;
        }
        if (world.getRegistryKey() != World.OVERWORLD) return;
        EstadoServidor estado = EstadoServidor.get(world.getServer());
        ((Explosion) (Object) this).getAffectedBlocks().removeIf(pos -> Reglas.enSpawn(world, pos, estado));
    }
}

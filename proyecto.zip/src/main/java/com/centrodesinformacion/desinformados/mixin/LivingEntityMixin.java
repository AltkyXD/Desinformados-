package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.block.Block;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.entity.damage.DamageSource;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Los esbirros del jefe final no sueltan botín (ni objetos ni experiencia de la tabla), para que la arena no sea una granja. */
    @Inject(method = "dropLoot", at = @At("HEAD"), cancellable = true)
    private void desinformados$sinBotinEsbirros(DamageSource fuente, boolean porJugador, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        if (((LivingEntity) (Object) this).getCommandTags().contains(com.centrodesinformacion.desinformados.entidad.JefeTeleEntity.MARCA_ESBIRRO)) ci.cancel();
    }

    /** Caídas duras: los jugadores reciben un 50% más de daño de caída. */
    @Inject(method = "computeFallDamage", at = @At("RETURN"), cancellable = true)
    private void desinformados$caidasDuras(float distancia, float multiplicador, CallbackInfoReturnable<Integer> cir) {
        LivingEntity yo = (LivingEntity) (Object) this;
        if (yo instanceof PlayerEntity && cir.getReturnValue() > 0 && CambiosActivos.en(yo.getWorld(), "caidas_duras")) {
            cir.setReturnValue((int) Math.ceil(cir.getReturnValue() * 1.5));
        }
    }

    /** Gancho de Danio: los cambios de dificultad pueden subir o bajar el daño recibido (después de armadura y protección). */
    @Inject(method = "modifyAppliedDamage", at = @At("RETURN"), cancellable = true)
    private void desinformados$danio(DamageSource fuente, float cantidad, CallbackInfoReturnable<Float> cir) {
        float antes = cir.getReturnValueF();
        float despues = com.centrodesinformacion.desinformados.Danio.modificar((LivingEntity) (Object) this, fuente, antes);
        if (despues != antes) cir.setReturnValue(despues);
    }

    /** Suelos resbaladizos: en cuevas (sin cielo y por debajo de la capa 50) se resbala como en hielo. */
    @Redirect(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;getSlipperiness()F"))
    private float desinformados$resbaladizo(Block bloque) {
        float normal = bloque.getSlipperiness();
        LivingEntity yo = (LivingEntity) (Object) this;
        if (normal < 0.9f && yo instanceof PlayerEntity && yo.getY() < 50
                && !yo.getWorld().isSkyVisible(yo.getBlockPos()) && CambiosActivos.en(yo.getWorld(), "suelos_resbaladizos")) {
            return 0.98f;
        }
        return normal;
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.block.Block;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** Caídas duras: los jugadores reciben un 50% más de daño de caída. */
    @Inject(method = "computeFallDamage", at = @At("RETURN"), cancellable = true)
    private void desinformados$caidasDuras(float distancia, float multiplicador, CallbackInfoReturnable<Integer> cir) {
        LivingEntity yo = (LivingEntity) (Object) this;
        if (yo instanceof PlayerEntity && cir.getReturnValue() > 0 && CambiosActivos.en(yo.getWorld(), "caidas_duras")) {
            cir.setReturnValue((int) Math.ceil(cir.getReturnValue() * 1.5));
        }
    }

    /** Suelos resbaladizos: en cuevas (sin cielo y por debajo de la capa 50) se resbala como en hielo. */
    @Redirect(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;getSlipperiness()F"))
    private float desinformados$resbaladizo(Block bloque) {
        float normal = bloque.getSlipperiness();
        LivingEntity yo = (LivingEntity) (Object) this;
        if (normal < 0.9f && yo instanceof PlayerEntity && yo.getY() < 50
                && !yo.getWorld().isSkyVisible(yo.getBlockPos()) && CambiosActivos.en(yo.getWorld(), "suelos_resbaladizos")) {
            return 0.98f;
        }
        return normal;
    }
}

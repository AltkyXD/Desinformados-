package com.centrodesinformacion.desinformados.mixin;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.GoalSelector;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Acceso a los objetivos de un mob (para que ataquen al Muñeco de Prueba). */
@Mixin(MobEntity.class)
public interface MobAccessor {
    @Accessor("targetSelector")
    GoalSelector desinformados$getTargetSelector();

    /** Probabilidad de soltar lo que lleva en esa ranura (2.0 = lo recogió de un jugador: siempre lo suelta). */
    @Invoker("getDropChance")
    float desinformados$getDropChance(EquipmentSlot slot);
}

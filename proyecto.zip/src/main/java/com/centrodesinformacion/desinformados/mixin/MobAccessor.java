package com.centrodesinformacion.desinformados.mixin;

import net.minecraft.entity.ai.goal.GoalSelector;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Acceso a los objetivos de un mob (para que ataquen al Muñeco de Prueba). */
@Mixin(MobEntity.class)
public interface MobAccessor {
    @Accessor("targetSelector")
    GoalSelector desinformados$getTargetSelector();
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.block.BlockState;
import net.minecraft.block.FireBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Zona del Centro: el fuego se apaga solo, no se extiende ni quema bloques. */
@Mixin(FireBlock.class)
public abstract class FuegoProtegidoMixin {
    @Inject(method = "scheduledTick", at = @At("HEAD"), cancellable = true)
    private void desinformados$apagar(BlockState state, ServerWorld world, BlockPos pos, Random random, CallbackInfo ci) {
        if (Reglas.protegido(world, pos, 1)) {
            world.removeBlock(pos, false);
            ci.cancel();
        }
    }
}

package com.centrodesinformacion.desinformados.mixin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Cuando un jugador gasta un tótem (el "Gato de la Desinformación"), se avisa a todo el servidor. */
@Mixin(LivingEntity.class)
public abstract class TotemMixin {
    @Inject(method = "tryUseTotem", at = @At("RETURN"))
    private void desinformados$avisarTotem(DamageSource fuente, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() || !((Object) this instanceof ServerPlayerEntity p) || p.getServer() == null) return;
        p.getServer().getPlayerManager().broadcast(Text.literal("🐱 " + p.getGameProfile().getName() + " ha popeado un gato")
                .formatted(Formatting.GOLD, Formatting.BOLD), false);
    }
}

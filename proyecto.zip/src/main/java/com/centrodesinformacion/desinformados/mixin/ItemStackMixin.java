package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.CambiosActivos;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Herramientas frágiles: todo lo que tiene durabilidad se gasta el doble de rápido. */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @ModifyVariable(method = "damage(ILnet/minecraft/server/world/ServerWorld;Lnet/minecraft/server/network/ServerPlayerEntity;Ljava/util/function/Consumer;)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private int desinformados$fragiles(int cantidad) {
        return cantidad > 0 && CambiosActivos.servidor("herramientas_fragiles") ? cantidad * 2 : cantidad;
    }
}

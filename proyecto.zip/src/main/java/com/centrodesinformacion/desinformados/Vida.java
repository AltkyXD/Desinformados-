package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sistema de vida:
 *  - Corazones ROJOS extra: contenedores que se pierden al morir.
 *    Algunos enemigos concretos podrán quitarlos con Vida.cambiarRojos(jugador, -1).
 *  - Corazones de ALMA (azules): escudo propio, separado de los dorados.
 *    Recibe el daño después de los dorados y antes de los rojos, y no se regenera.
 */
public class Vida {
    private static final Map<UUID, Integer> ULTIMO_BLOQUEO = new HashMap<>();
    public static final Identifier MOD_ROJOS = Desinformados.id("corazones_rojos");

    public static final int MAX_ROJOS_EXTRA = 20;   // hasta 30 corazones
    public static final int MIN_ROJOS_EXTRA = -9;   // como mínimo 1 corazón
    public static final int MAX_ALMAS = 3;          // corazones azules (cada uno bloquea 1 golpe)

    public static void registrar() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> aplicarTodo(handler.player));
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(Vida::tickSustos);
        // Va antes que cualquier otra regla de daño: si el alma bloquea, no pasa nada más (ni Creeper Oscuro)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entidad, fuente, cantidad) ->
                !(entidad instanceof ServerPlayerEntity p && intentarBloquear(p, fuente, cantidad)));
        // El estado ya se pone a 0 al morir (ver Reglas); aquí solo se vuelve a aplicar
        ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, seguiaVivo) -> aplicarTodo(nuevo));
    }

    /** Suma (o resta con número negativo) corazones rojos. Devuelve los extra resultantes. */
    public static int cambiarRojos(ServerPlayerEntity p, int cantidad) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        if (cantidad < 0 && com.centrodesinformacion.desinformados.pasivas.Pasivas.tiene(p, "rock_bottom")) {
            p.sendMessage(net.minecraft.text.Text.literal("Fondo de Roca: tus corazones no bajan.").formatted(net.minecraft.util.Formatting.GRAY), true);
            return estado.getRojos(p.getUuid());
        }
        int nuevo = MathHelper.clamp(estado.getRojos(p.getUuid()) + cantidad, MIN_ROJOS_EXTRA, MAX_ROJOS_EXTRA);
        estado.setRojos(p.getUuid(), nuevo);
        aplicarRojos(p, nuevo);
        if (cantidad > 0) p.heal(cantidad * 2f);
        return nuevo;
    }

    /** Suma (o quita) corazones de alma. Devuelve los corazones azules resultantes. */
    public static float cambiarAlmas(ServerPlayerEntity p, int corazones) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        float nuevo = MathHelper.clamp(estado.getAlmas(p.getUuid()) + corazones * 2f, 0f, MAX_ALMAS * 2f);
        estado.setAlmas(p.getUuid(), nuevo);
        sincronizar(p);
        return nuevo / 2f;
    }

    /**
     * Cada corazón de alma bloquea POR COMPLETO un golpe: ni daño ni pérdida de contenedor.
     * Tras bloquear, medio segundo de protección para que un mismo golpe no gaste varios.
     */
    public static boolean intentarBloquear(ServerPlayerEntity p, DamageSource fuente, float danio) {
        if (danio <= 0 || p.isCreative() || p.isSpectator()) return false;
        if (fuente.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false; // /kill, vacío
        if (fuente.getAttacker() instanceof PlayerEntity atacante && atacante != p) return false; // PvP ya está bloqueado
        int ahora = p.getServer().getTicks();
        if (ahora - ULTIMO_BLOQUEO.getOrDefault(p.getUuid(), -100) < 10) return true; // mismo golpe
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        float almas = estado.getAlmas(p.getUuid());
        if (almas < 2f) return false;
        estado.setAlmas(p.getUuid(), almas - 2f);
        ULTIMO_BLOQUEO.put(p.getUuid(), ahora);
        sincronizar(p);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1f, 1f);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, SoundCategory.PLAYERS, 1f, 1.2f);
        p.getServerWorld().spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 20, 0.4, 0.6, 0.4, 0.05);
        int quedan = (int) ((almas - 2f) / 2f);
        p.sendMessage(Text.literal("¡Un corazón de alma ha bloqueado el golpe! (quedan " + quedan + ")").formatted(Formatting.AQUA), true);
        return true;
    }

    // ---------------- Pérdida temporal de corazones (Interferencia) ----------------
    public static final Identifier MOD_SUSTO = Desinformados.id("susto");
    private static final Map<UUID, Integer> SUSTOS = new HashMap<>();

    /** Quita "corazones" contenedores durante "segundos". Si ya estaba asustado, se renueva el tiempo. */
    public static void sustoTemporal(ServerPlayerEntity p, int corazones, int segundos) {
        var vidaMax = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vidaMax == null || com.centrodesinformacion.desinformados.pasivas.Pasivas.tiene(p, "rock_bottom")) return;
        vidaMax.removeModifier(MOD_SUSTO);
        double quitar = Math.min(corazones * 2.0, vidaMax.getValue() - 2.0); // siempre te queda 1 corazón
        if (quitar > 0) vidaMax.addTemporaryModifier(new EntityAttributeModifier(MOD_SUSTO, -quitar, EntityAttributeModifier.Operation.ADD_VALUE));
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
        SUSTOS.put(p.getUuid(), segundos * 20);
    }

    public static void tickSustos(net.minecraft.server.MinecraftServer server) {
        SUSTOS.entrySet().removeIf(e -> {
            int resta = e.getValue() - 1;
            if (resta > 0) { e.setValue(resta); return false; }
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            if (p != null) {
                var vidaMax = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                if (vidaMax != null) vidaMax.removeModifier(MOD_SUSTO);
                p.sendMessage(Text.literal("Ya te has recuperado del susto").formatted(Formatting.GRAY), true);
            }
            return true;
        });
    }

    /** Gasta un corazón de alma (para efectos que no son daño). Devuelve true si tenía uno. */
    public static boolean gastarAlma(ServerPlayerEntity p) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        float almas = estado.getAlmas(p.getUuid());
        if (almas < 2f) return false;
        estado.setAlmas(p.getUuid(), almas - 2f);
        sincronizar(p);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1f, 1f);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, SoundCategory.PLAYERS, 1f, 1.2f);
        return true;
    }

    public static void aplicarTodo(ServerPlayerEntity p) {
        aplicarRojos(p, EstadoServidor.get(p.getServer()).getRojos(p.getUuid()));
        sincronizar(p);
    }

    public static void sincronizar(ServerPlayerEntity p) {
        if (ServerPlayNetworking.canSend(p, AlmasPayload.ID)) {
            ServerPlayNetworking.send(p, new AlmasPayload(EstadoServidor.get(p.getServer()).getAlmas(p.getUuid())));
        }
    }

    private static void aplicarRojos(ServerPlayerEntity p, int extra) {
        EntityAttributeInstance vidaMax = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vidaMax == null) return;
        vidaMax.removeModifier(MOD_ROJOS);
        if (extra != 0) {
            vidaMax.addPersistentModifier(new EntityAttributeModifier(MOD_ROJOS, extra * 2.0, EntityAttributeModifier.Operation.ADD_VALUE));
        }
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Sistema de vida:
 *  - Corazones ROJOS extra: contenedores que se pierden al morir.
 *    Algunos enemigos concretos podrán quitarlos con Vida.cambiarRojos(jugador, -1).
 *  - Corazones de ALMA (azules): escudo propio, separado de los dorados.
 *    Recibe el daño después de los dorados y antes de los rojos, y no se regenera.
 */
public class Vida {
    public static final Identifier MOD_ROJOS = Desinformados.id("corazones_rojos");

    public static final int MAX_ROJOS_EXTRA = 20;   // hasta 30 corazones
    public static final int MIN_ROJOS_EXTRA = -9;   // como mínimo 1 corazón
    public static final int MAX_ALMAS = 10;         // corazones azules

    public static void registrar() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> aplicarTodo(handler.player));
        // El estado ya se pone a 0 al morir (ver Reglas); aquí solo se vuelve a aplicar
        ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, seguiaVivo) -> aplicarTodo(nuevo));
    }

    /** Suma (o resta con número negativo) corazones rojos. Devuelve los extra resultantes. */
    public static int cambiarRojos(ServerPlayerEntity p, int cantidad) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        int nuevo = MathHelper.clamp(estado.getRojos(p.getUuid()) + cantidad, MIN_ROJOS_EXTRA, MAX_ROJOS_EXTRA);
        estado.setRojos(p.getUuid(), nuevo);
        aplicarRojos(p, nuevo);
        if (cantidad > 0) p.heal(cantidad * 2f);
        return nuevo;
    }

    /** Suma (o quita) corazones de alma. Devuelve los corazones azules resultantes. */
    public static float cambiarAlmas(ServerPlayerEntity p, int corazones) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        float nuevo = MathHelper.clamp(estado.getAlmas(p.getUuid()) + corazones * 2f, 0f, MAX_ALMAS * 2f);
        estado.setAlmas(p.getUuid(), nuevo);
        sincronizar(p);
        return nuevo / 2f;
    }

    /** Lo llama el mixin: el escudo de almas se come el daño que pueda. Devuelve el daño que sigue a los rojos. */
    public static float absorberConAlmas(ServerPlayerEntity p, float danio) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        float almas = estado.getAlmas(p.getUuid());
        if (almas <= 0 || danio <= 0) return danio;
        float absorbido = Math.min(almas, danio);
        float restantes = almas - absorbido;
        estado.setAlmas(p.getUuid(), restantes);
        sincronizar(p);
        if (MathHelper.ceil(restantes / 2f) < MathHelper.ceil(almas / 2f)) {
            p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, SoundCategory.PLAYERS, 1f, 1.2f);
        }
        return danio - absorbido;
    }

    public static void aplicarTodo(ServerPlayerEntity p) {
        aplicarRojos(p, EstadoServidor.get(p.getServer()).getRojos(p.getUuid()));
        sincronizar(p);
    }

    public static void sincronizar(ServerPlayerEntity p) {
        if (ServerPlayNetworking.canSend(p, AlmasPayload.ID)) {
            ServerPlayNetworking.send(p, new AlmasPayload(EstadoServidor.get(p.getServer()).getAlmas(p.getUuid())));
        }
    }

    private static void aplicarRojos(ServerPlayerEntity p, int extra) {
        EntityAttributeInstance vidaMax = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vidaMax == null) return;
        vidaMax.removeModifier(MOD_ROJOS);
        if (extra != 0) {
            vidaMax.addPersistentModifier(new EntityAttributeModifier(MOD_ROJOS, extra * 2.0, EntityAttributeModifier.Operation.ADD_VALUE));
        }
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }
}

package com.centrodesinformacion.desinformados;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/** Mesa de Piedra, Papel o Tijera (dos jugadores): al usarla te sientas. Irrompible en supervivencia, como la Ruleta. */
public class PiedraPapelTijeraBlock extends Block {
    public static final MapCodec<PiedraPapelTijeraBlock> CODEC = createCodec(PiedraPapelTijeraBlock::new);
    private static final VoxelShape FORMA = Block.createCuboidShape(0, 0, 0, 16, 12, 16);

    public PiedraPapelTijeraBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return FORMA;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient() && player instanceof ServerPlayerEntity p) {
            PiedraPapelTijera.abrir(p, pos);
            world.playSound(null, pos, SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.BLOCKS, 0.8f, 1.2f);
        }
        return ActionResult.SUCCESS;
    }
}

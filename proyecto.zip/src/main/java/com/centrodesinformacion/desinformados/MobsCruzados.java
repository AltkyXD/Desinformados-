package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.HoglinEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Cambio de dificultad "mobs_cruzados": los mobs del Nether aparecen en el Overworld (de noche y en sitios oscuros)
 * y los del Overworld aparecen en el Nether. Los piglins y hoglins no se zombifican fuera de su dimensión.
 */
public final class MobsCruzados {
    public static final String ID = "mobs_cruzados";
    public static final String MARCA = "desinfo_cruzado";
    private static final int CADA = 100;              // cada 5 s se intenta por jugador
    private static final int MAXIMO_POR_JUGADOR = 6;  // cruzados vivos cerca de cada jugador

    /** Del Nether al Overworld (repetidos = más probables). */
    private static final EntityType<?>[] DEL_NETHER = {
            EntityType.ZOMBIFIED_PIGLIN, EntityType.ZOMBIFIED_PIGLIN, EntityType.MAGMA_CUBE, EntityType.MAGMA_CUBE,
            EntityType.BLAZE, EntityType.BLAZE, EntityType.WITHER_SKELETON, EntityType.WITHER_SKELETON,
            EntityType.PIGLIN, EntityType.PIGLIN, EntityType.HOGLIN, EntityType.PIGLIN_BRUTE, EntityType.GHAST};
    /** Del Overworld al Nether. */
    private static final EntityType<?>[] DEL_OVERWORLD = {
            EntityType.ZOMBIE, EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SKELETON, EntityType.CREEPER,
            EntityType.CREEPER, EntityType.SPIDER, EntityType.SPIDER, EntityType.WITCH, EntityType.ZOMBIE_VILLAGER, EntityType.SLIME};

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % CADA != 0) return;
            if (!EstadoServidor.get(server).tieneCambio(ID)) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator() || p.isCreative()) continue;
                ServerWorld w = p.getServerWorld();
                boolean overworld = w.getRegistryKey() == World.OVERWORLD;
                boolean nether = w.getRegistryKey() == World.NETHER;
                if (!overworld && !nether) continue;
                if (w.getRandom().nextFloat() > 0.6f) continue;
                int cerca = w.getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(48), m -> m.getCommandTags().contains(MARCA)).size();
                if (cerca >= MAXIMO_POR_JUGADOR) continue;
                EntityType<?>[] lista = overworld ? DEL_NETHER : DEL_OVERWORLD;
                intentar(w, p, lista[w.getRandom().nextInt(lista.length)], overworld);
            }
        });
    }

    private static void intentar(ServerWorld w, ServerPlayerEntity p, EntityType<?> tipo, boolean enOverworld) {
        Random r = w.getRandom();
        for (int intento = 0; intento < 12; intento++) {
            double ang = r.nextDouble() * Math.PI * 2, dist = 18 + r.nextDouble() * 22;
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist), z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
            int y0 = p.getBlockY() + r.nextInt(17) - 8;
            for (int dy = 0; dy < 12; dy++) {
                BlockPos pos = new BlockPos(x, y0 - dy, z);
                if (!sitioValido(w, pos, tipo, enOverworld)) continue;
                if (!(tipo.create(w) instanceof MobEntity m)) return;
                m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, r.nextFloat() * 360f, 0f);
                if (!w.isSpaceEmpty(m)) { m.discard(); continue; }
                m.initialize(w, w.getLocalDifficulty(pos), SpawnReason.NATURAL, null);
                if (m instanceof AbstractPiglinEntity pig) pig.setImmuneToZombification(true);   // no se convierten fuera del Nether
                if (m instanceof HoglinEntity hog) hog.setImmuneToZombification(true);
                m.addCommandTag(MARCA);
                w.spawnEntity(m);
                return;
            }
        }
    }

    private static boolean sitioValido(ServerWorld w, BlockPos pos, EntityType<?> tipo, boolean enOverworld) {
        if (!w.getWorldBorder().contains(pos) || !w.isChunkLoaded(pos)) return false;
        if (Reglas.protegido(w, pos, 0)) return false;                                           // nunca dentro de la zona del Centro
        BlockPos abajo = pos.down();
        if (!w.getBlockState(abajo).isSolidBlock(w, abajo)) return false;
        if (!w.getBlockState(pos).getCollisionShape(w, pos).isEmpty() || !w.getFluidState(pos).isEmpty()) return false;
        if (!w.getBlockState(pos.up()).getCollisionShape(w, pos.up()).isEmpty()) return false;
        if (enOverworld) {
            if (!HostileEntity.isSpawnDark(w, pos, w.getRandom())) return false;               // de noche o en sitios oscuros
            if (tipo == EntityType.GHAST) return w.isSkyVisible(pos) && pos.getY() > w.getSeaLevel(); // el ghast, solo al aire libre
        }
        return true;
    }
}

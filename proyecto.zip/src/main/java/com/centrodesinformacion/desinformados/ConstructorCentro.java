package com.centrodesinformacion.desinformados;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Construye el esqueleto del Centro de Desinformación delante del jugador: una torre CIRCULAR
 * de 41 bloques de diámetro, tres pisos de 6 de alto con el techo accesible (caseta con escalera), suelo de madera, paredes de paneles metálicos,
 * 16 vigas de acero alrededor, franja verde entre pisos, ventanales, entrada con marquesina,
 * atrio circular con barandal, escalera al segundo piso y techo plano con pretil. Vacío por dentro.
 */
public class ConstructorCentro {
    public static final int RADIO = 20;      // 41 de diámetro
    private static final int ALTO_PISO = 7;
    private static final int PISOS = 3;
    private static final int TECHO = ALTO_PISO * PISOS;      // 21
    private static final int VIGAS = 16;
    private static final double PASO = Math.PI * 2 / VIGAS;
    private static final int RADIO_ATRIO = 6;

    /** Coordenadas locales con el origen en el centro del círculo, a la altura del suelo. */
    private record Sistema(BlockPos centro, Direction adelante, Direction derecha) {
        BlockPos at(int dx, int y, int dz) {
            return centro.offset(derecha, dx).offset(adelante, dz).up(y);
        }
    }

    /** Ángulo alrededor del centro, 0 = mirando hacia la entrada (hacia el jugador). */
    private static double angulo(int dx, int dz) {
        return Math.atan2(dx, -dz);
    }

    private static boolean esPared(double d) {
        return d > RADIO - 0.5 && d <= RADIO + 0.5;
    }

    /** Las vigas están entre tramos, así la entrada queda justo en medio de un tramo. */
    private static boolean esViga(int dx, int dz) {
        double a = angulo(dx, dz) - PASO / 2;
        double cerca = Math.round(a / PASO) * PASO;
        return Math.abs(a - cerca) * RADIO < 0.6;
    }

    private static boolean esVentana(int dx, int dz, int y) {
        int enPiso = y % ALTO_PISO;
        if (y >= TECHO || enPiso < 2 || enPiso > 4) return false;
        double a = angulo(dx, dz);
        double medio = Math.round(a / PASO) * PASO;
        return Math.abs(a - medio) * RADIO < 1.7;
    }

    /** Devuelve [centro del edificio, punto de aparición dentro del vestíbulo] */
    public static BlockPos[] construir(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Direction adelante = p.getHorizontalFacing();
        Direction derecha = adelante.rotateYClockwise();
        BlockPos centro = p.getBlockPos().down().offset(adelante, RADIO + 5);
        Sistema s = new Sistema(centro, adelante, derecha);

        BlockState panel = ModBloques.PANEL_METAL.getDefaultState();
        BlockState franja = ModBloques.PANEL_METAL_FRANJA.getDefaultState();
        BlockState viga = ModBloques.VIGA_ACERO.getDefaultState().with(PillarBlock.AXIS, Direction.Axis.Y);
        BlockState madera = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState luz = ModBloques.LUZ_INDUSTRIAL.getDefaultState();
        BlockState rejilla = ModBloques.REJILLA_METAL.getDefaultState();
        BlockState cristal = Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState();
        BlockState barandal = Blocks.IRON_BARS.getDefaultState();
        BlockState cimiento = Blocks.STONE_BRICKS.getDefaultState();
        BlockState aire = Blocks.AIR.getDefaultState();
        List<BlockPos> conectar = new ArrayList<>();

        // 1) Despejar el terreno y poner cimientos bajo el círculo
        for (int dx = -RADIO - 4; dx <= RADIO + 4; dx++) {
            for (int dz = -RADIO - 6; dz <= RADIO + 4; dz++) {
                for (int y = 1; y <= TECHO + 6; y++) poner(w, s.at(dx, y, dz), aire);
                if (Math.sqrt(dx * dx + dz * dz) > RADIO + 0.5) continue;
                for (int y = -1; y >= -14; y--) {
                    BlockPos q = s.at(dx, y, dz);
                    BlockState b = w.getBlockState(q);
                    if (!b.isReplaceable() && b.getFluidState().isEmpty()) break;
                    poner(w, q, cimiento);
                }
            }
        }

        // 2) Suelos, techo, luces y la pared circular
        for (int dx = -RADIO; dx <= RADIO; dx++) {
            for (int dz = -RADIO; dz <= RADIO; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > RADIO + 0.5) continue;
                if (esPared(d)) {
                    boolean columna = esViga(dx, dz);
                    poner(w, s.at(dx, 0, dz), columna ? viga : panel);
                    for (int y = 1; y <= TECHO + 1; y++) {
                        BlockState b;
                        if (columna) b = viga;
                        else if (y % ALTO_PISO == 0 || y == TECHO + 1) b = franja;
                        else if (esVentana(dx, dz, y)) { b = cristal; conectar.add(s.at(dx, y, dz)); }
                        else b = panel;
                        poner(w, s.at(dx, y, dz), b);
                    }
                    continue;
                }
                boolean cuadricula = Math.floorMod(dx, 6) == 3 && Math.floorMod(dz, 6) == 3;
                poner(w, s.at(dx, 0, dz), madera);
                for (int piso = 1; piso < PISOS; piso++) poner(w, s.at(dx, piso * ALTO_PISO, dz), cuadricula ? luz : madera);
                poner(w, s.at(dx, TECHO, dz), cuadricula ? luz : panel);
            }
        }

        // 3) Entrada de 5 x 4 en el centro de la fachada, con marquesina de rejilla
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -RADIO - 1; dz <= -RADIO + 2; dz++) {
                if (!esPared(Math.sqrt(dx * dx + dz * dz))) continue;
                for (int y = 1; y <= 4; y++) poner(w, s.at(dx, y, dz), aire);
                poner(w, s.at(dx, 0, dz), madera);
            }
        }
        int frente = -RADIO - 4;
        for (int dz = frente; dz <= -RADIO + 1; dz++) {
            for (int dx = -3; dx <= 3; dx++) {
                if (Math.sqrt(dx * dx + dz * dz) <= RADIO + 0.5) continue;  // solo por fuera de la pared
                poner(w, s.at(dx, 5, dz), rejilla);
            }
            for (int lado = -4; lado <= 4; lado += 8) {
                if (Math.sqrt(lado * lado + dz * dz) <= RADIO + 0.5) continue;
                poner(w, s.at(lado, 5, dz), viga.with(PillarBlock.AXIS, adelante.getAxis()));
            }
        }
        for (int y = 1; y <= 4; y++) {
            poner(w, s.at(-4, y, frente), viga);
            poner(w, s.at(4, y, frente), viga);
        }
        for (int dx = -4; dx <= 4; dx++) poner(w, s.at(dx, 5, frente), viga.with(PillarBlock.AXIS, derecha.getAxis()));

        // 4) Atrio circular que atraviesa los pisos de arriba, con borde de rejilla y barandal
        for (int piso = 1; piso < PISOS; piso++) {
            int y = piso * ALTO_PISO;
            for (int dx = -RADIO_ATRIO - 1; dx <= RADIO_ATRIO + 1; dx++) {
                for (int dz = -RADIO_ATRIO - 1; dz <= RADIO_ATRIO + 1; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= RADIO_ATRIO - 0.5) {
                        poner(w, s.at(dx, y, dz), aire);
                    } else if (d <= RADIO_ATRIO + 0.5) {
                        poner(w, s.at(dx, y, dz), rejilla);
                        poner(w, s.at(dx, y + 1, dz), barandal);
                        conectar.add(s.at(dx, y + 1, dz));
                    }
                }
            }
        }

        // 5) Escaleras: planta baja -> 2º (al fondo), 2º -> 3º (delante), 3º -> techo (al fondo, dentro de una caseta)
        escalera(w, s, conectar, 0, RADIO - 6, -3, 1, false);
        escalera(w, s, conectar, ALTO_PISO, -RADIO + 5, 3, -1, false);
        escalera(w, s, conectar, ALTO_PISO * 2, RADIO - 6, -3, 1, true);
        caseta(w, s, -3, RADIO - 6);

        // 6) Cristales y barandales bien unidos
        for (BlockPos q : conectar) {
            BlockState b = w.getBlockState(q);
            w.setBlockState(q, Block.postProcessState(b, w, q), Block.NOTIFY_LISTENERS);
        }

        return new BlockPos[]{s.at(0, 1, 0), s.at(0, 1, -RADIO + 3)};
    }

    /**
     * Tramo de escalera de madera de 2 de ancho que sube un piso entero.
     * dz1 y dz1+1 son las dos filas; empieza en x0 y avanza en la dirección dir (1 = derecha, -1 = izquierda).
     */
    private static void escalera(ServerWorld w, Sistema s, List<BlockPos> conectar, int y0, int dz1, int x0, int dir, boolean alTecho) {
        BlockState madera = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState barandal = Blocks.IRON_BARS.getDefaultState();
        Direction sube = dir > 0 ? s.derecha() : s.derecha().getOpposite();
        BlockState escalon = Blocks.SPRUCE_STAIRS.getDefaultState().with(StairsBlock.FACING, sube);
        int arriba = y0 + ALTO_PISO;
        for (int dz = dz1; dz <= dz1 + 1; dz++) {
            for (int k = -1; k < ALTO_PISO; k++) poner(w, s.at(x0 + dir * k, arriba, dz), Blocks.AIR.getDefaultState()); // hueco
            for (int i = 0; i < ALTO_PISO; i++) {
                poner(w, s.at(x0 + dir * i, y0 + 1 + i, dz), escalon);
                for (int y = y0 + 1; y < y0 + 1 + i; y++) poner(w, s.at(x0 + dir * i, y, dz), madera);
            }
            poner(w, s.at(x0 + dir * ALTO_PISO, arriba, dz), alTecho ? ModBloques.PANEL_METAL.getDefaultState() : madera);
        }
        if (alTecho) return;   // en el techo la caseta hace de barandal
        for (int k = -2; k < ALTO_PISO; k++) {
            for (int dz : new int[]{dz1 - 1, dz1 + 2}) {
                if (k >= -1) poner(w, s.at(x0 + dir * k, arriba, dz), madera);
                poner(w, s.at(x0 + dir * k, arriba + 1, dz), barandal);
                conectar.add(s.at(x0 + dir * k, arriba + 1, dz));
            }
        }
        for (int dz = dz1; dz <= dz1 + 1; dz++) {
            poner(w, s.at(x0 - dir * 2, arriba, dz), madera);
            poner(w, s.at(x0 - dir * 2, arriba + 1, dz), barandal);
            conectar.add(s.at(x0 - dir * 2, arriba + 1, dz));
        }
    }

    /** Caseta de metal en el techo sobre la última escalera, con puerta hacia el centro del techo. */
    private static void caseta(ServerWorld w, Sistema s, int x0, int dz1) {
        BlockState panel = ModBloques.PANEL_METAL.getDefaultState();
        BlockState franja = ModBloques.PANEL_METAL_FRANJA.getDefaultState();
        int y0 = TECHO;
        int xa = x0 - 2, xb = x0 + ALTO_PISO + 1, za = dz1 - 1, zb = dz1 + 2;
        for (int x = xa; x <= xb; x++) {
            for (int z = za; z <= zb; z++) {
                boolean borde = x == xa || x == xb || z == za || z == zb;
                for (int y = y0 + 1; y <= y0 + 3; y++) {
                    poner(w, s.at(x, y, z), borde ? (y == y0 + 3 ? franja : panel) : Blocks.AIR.getDefaultState());
                }
                poner(w, s.at(x, y0 + 4, z), panel);
            }
        }
        // puerta (2 de ancho, 2 de alto) del lado que da al centro del techo, junto al rellano
        for (int x = xb - 2; x <= xb - 1; x++) {
            for (int y = y0 + 1; y <= y0 + 2; y++) poner(w, s.at(x, y, za), Blocks.AIR.getDefaultState());
        }
        poner(w, s.at(x0 + 3, y0 + 3, dz1), ModBloques.LUZ_INDUSTRIAL.getDefaultState());
    }

    private static void poner(ServerWorld w, BlockPos q, BlockState b) {
        w.setBlockState(q, b, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
    }
}

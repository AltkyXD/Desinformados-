package com.centrodesinformacion.desinformados;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Construye el esqueleto del Centro de Desinformación delante del jugador: una torre CIRCULAR
 * de 41 bloques de diámetro, dos pisos de 6 de alto, suelo de madera, paredes de paneles metálicos,
 * 16 vigas de acero alrededor, franja verde entre pisos, ventanales, entrada con marquesina,
 * atrio circular con barandal, escalera al segundo piso y techo plano con pretil. Vacío por dentro.
 */
public class ConstructorCentro {
    public static final int RADIO = 20;      // 41 de diámetro
    private static final int PISO2 = 7;
    private static final int TECHO = 14;
    private static final int VIGAS = 16;
    private static final double PASO = Math.PI * 2 / VIGAS;
    private static final int RADIO_ATRIO = 6;

    /** Coordenadas locales con el origen en el centro del círculo, a la altura del suelo. */
    private record Sistema(BlockPos centro, Direction adelante, Direction derecha) {
        BlockPos at(int dx, int y, int dz) {
            return centro.offset(derecha, dx).offset(adelante, dz).up(y);
        }
    }

    /** Ángulo alrededor del centro, 0 = mirando hacia la entrada (hacia el jugador). */
    private static double angulo(int dx, int dz) {
        return Math.atan2(dx, -dz);
    }

    private static boolean esPared(double d) {
        return d > RADIO - 0.5 && d <= RADIO + 0.5;
    }

    /** Las vigas están entre tramos, así la entrada queda justo en medio de un tramo. */
    private static boolean esViga(int dx, int dz) {
        double a = angulo(dx, dz) - PASO / 2;
        double cerca = Math.round(a / PASO) * PASO;
        return Math.abs(a - cerca) * RADIO < 0.6;
    }

    private static boolean esVentana(int dx, int dz, int y) {
        boolean pisoBajo = y >= 2 && y <= 4, pisoAlto = y >= PISO2 + 2 && y <= PISO2 + 4;
        if (!pisoBajo && !pisoAlto) return false;
        double a = angulo(dx, dz);
        double medio = Math.round(a / PASO) * PASO;
        return Math.abs(a - medio) * RADIO < 1.7;
    }

    /** Devuelve [centro del edificio, punto de aparición dentro del vestíbulo] */
    public static BlockPos[] construir(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Direction adelante = p.getHorizontalFacing();
        Direction derecha = adelante.rotateYClockwise();
        BlockPos centro = p.getBlockPos().down().offset(adelante, RADIO + 5);
        Sistema s = new Sistema(centro, adelante, derecha);

        BlockState panel = ModBloques.PANEL_METAL.getDefaultState();
        BlockState franja = ModBloques.PANEL_METAL_FRANJA.getDefaultState();
        BlockState viga = ModBloques.VIGA_ACERO.getDefaultState().with(PillarBlock.AXIS, Direction.Axis.Y);
        BlockState madera = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState luz = ModBloques.LUZ_INDUSTRIAL.getDefaultState();
        BlockState rejilla = ModBloques.REJILLA_METAL.getDefaultState();
        BlockState cristal = Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState();
        BlockState barandal = Blocks.IRON_BARS.getDefaultState();
        BlockState cimiento = Blocks.STONE_BRICKS.getDefaultState();
        BlockState aire = Blocks.AIR.getDefaultState();
        List<BlockPos> conectar = new ArrayList<>();

        // 1) Despejar el terreno y poner cimientos bajo el círculo
        for (int dx = -RADIO - 4; dx <= RADIO + 4; dx++) {
            for (int dz = -RADIO - 6; dz <= RADIO + 4; dz++) {
                for (int y = 1; y <= TECHO + 6; y++) poner(w, s.at(dx, y, dz), aire);
                if (Math.sqrt(dx * dx + dz * dz) > RADIO + 0.5) continue;
                for (int y = -1; y >= -14; y--) {
                    BlockPos q = s.at(dx, y, dz);
                    BlockState b = w.getBlockState(q);
                    if (!b.isReplaceable() && b.getFluidState().isEmpty()) break;
                    poner(w, q, cimiento);
                }
            }
        }

        // 2) Suelos, techo, luces y la pared circular
        for (int dx = -RADIO; dx <= RADIO; dx++) {
            for (int dz = -RADIO; dz <= RADIO; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > RADIO + 0.5) continue;
                if (esPared(d)) {
                    boolean columna = esViga(dx, dz);
                    poner(w, s.at(dx, 0, dz), columna ? viga : panel);
                    for (int y = 1; y <= TECHO + 1; y++) {
                        BlockState b;
                        if (columna) b = viga;
                        else if (y == PISO2 || y == TECHO + 1) b = franja;
                        else if (esVentana(dx, dz, y)) { b = cristal; conectar.add(s.at(dx, y, dz)); }
                        else b = panel;
                        poner(w, s.at(dx, y, dz), b);
                    }
                    continue;
                }
                boolean cuadricula = Math.floorMod(dx, 6) == 3 && Math.floorMod(dz, 6) == 3;
                poner(w, s.at(dx, 0, dz), madera);
                poner(w, s.at(dx, PISO2, dz), cuadricula ? luz : madera);
                poner(w, s.at(dx, TECHO, dz), cuadricula ? luz : panel);
            }
        }

        // 3) Entrada de 5 x 4 en el centro de la fachada, con marquesina de rejilla
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -RADIO - 1; dz <= -RADIO + 2; dz++) {
                if (!esPared(Math.sqrt(dx * dx + dz * dz))) continue;
                for (int y = 1; y <= 4; y++) poner(w, s.at(dx, y, dz), aire);
                poner(w, s.at(dx, 0, dz), madera);
            }
        }
        int frente = -RADIO - 4;
        for (int dz = frente; dz <= -RADIO + 1; dz++) {
            for (int dx = -3; dx <= 3; dx++) {
                if (Math.sqrt(dx * dx + dz * dz) <= RADIO + 0.5) continue;  // solo por fuera de la pared
                poner(w, s.at(dx, 5, dz), rejilla);
            }
            for (int lado = -4; lado <= 4; lado += 8) {
                if (Math.sqrt(lado * lado + dz * dz) <= RADIO + 0.5) continue;
                poner(w, s.at(lado, 5, dz), viga.with(PillarBlock.AXIS, adelante.getAxis()));
            }
        }
        for (int y = 1; y <= 4; y++) {
            poner(w, s.at(-4, y, frente), viga);
            poner(w, s.at(4, y, frente), viga);
        }
        for (int dx = -4; dx <= 4; dx++) poner(w, s.at(dx, 5, frente), viga.with(PillarBlock.AXIS, derecha.getAxis()));

        // 4) Atrio circular en el segundo piso, con borde de rejilla y barandal
        for (int dx = -RADIO_ATRIO - 1; dx <= RADIO_ATRIO + 1; dx++) {
            for (int dz = -RADIO_ATRIO - 1; dz <= RADIO_ATRIO + 1; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= RADIO_ATRIO - 0.5) {
                    poner(w, s.at(dx, PISO2, dz), aire);
                } else if (d <= RADIO_ATRIO + 0.5) {
                    poner(w, s.at(dx, PISO2, dz), rejilla);
                    poner(w, s.at(dx, PISO2 + 1, dz), barandal);
                    conectar.add(s.at(dx, PISO2 + 1, dz));
                }
            }
        }

        // 5) Escalera de madera (2 de ancho) al fondo, subiendo hacia la derecha
        BlockState escalon = Blocks.SPRUCE_STAIRS.getDefaultState().with(StairsBlock.FACING, derecha);
        int ex = -3, ez1 = RADIO - 6, ez2 = RADIO - 5;
        for (int dz = ez1; dz <= ez2; dz++) {
            for (int dx = ex - 1; dx < ex + PISO2; dx++) poner(w, s.at(dx, PISO2, dz), aire);   // hueco arriba
            for (int i = 0; i < PISO2; i++) {
                poner(w, s.at(ex + i, 1 + i, dz), escalon);
                for (int y = 1; y < 1 + i; y++) poner(w, s.at(ex + i, y, dz), madera);
            }
            poner(w, s.at(ex + PISO2, PISO2, dz), madera);
        }
        // barandal alrededor del hueco de la escalera
        for (int dx = ex - 2; dx < ex + PISO2; dx++) {
            for (int dz : new int[]{ez1 - 1, ez2 + 1}) {
                poner(w, s.at(dx, PISO2, dz), madera);
                poner(w, s.at(dx, PISO2 + 1, dz), barandal);
                conectar.add(s.at(dx, PISO2 + 1, dz));
            }
        }
        for (int dz = ez1; dz <= ez2; dz++) {
            poner(w, s.at(ex - 2, PISO2, dz), madera);
            poner(w, s.at(ex - 2, PISO2 + 1, dz), barandal);
            conectar.add(s.at(ex - 2, PISO2 + 1, dz));
        }

        // 6) Cristales y barandales bien unidos
        for (BlockPos q : conectar) {
            BlockState b = w.getBlockState(q);
            w.setBlockState(q, Block.postProcessState(b, w, q), Block.NOTIFY_LISTENERS);
        }

        return new BlockPos[]{s.at(0, 1, 0), s.at(0, 1, -RADIO + 3)};
    }

    private static void poner(ServerWorld w, BlockPos q, BlockState b) {
        w.setBlockState(q, b, Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
    }
}

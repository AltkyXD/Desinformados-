package com.centrodesinformacion.desinformados;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Corazón Rojo (+1 contenedor permanente) o Corazón de Alma (+1 corazón azul de escudo). */
public class CorazonItem extends Item {
    private final boolean esAlma;

    public CorazonItem(Settings settings, boolean esAlma) {
        super(settings);
        this.esAlma = esAlma;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient() || !(user instanceof ServerPlayerEntity jugador)) {
            return TypedActionResult.success(stack, true);
        }
        EstadoServidor estado = EstadoServidor.get(jugador.getServer());
        if (esAlma) {
            if (estado.getAlmas(jugador.getUuid()) >= Vida.MAX_ALMAS * 2f) {
                jugador.sendMessage(Text.literal("Ya tienes el máximo de corazones de alma").formatted(Formatting.AQUA), true);
                return TypedActionResult.fail(stack);
            }
            float total = Vida.cambiarAlmas(jugador, 1);
            jugador.sendMessage(Text.literal("+1 corazón de alma (" + total + ")").formatted(Formatting.AQUA), true);
            world.playSound(null, jugador.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1f, 0.8f);
        } else {
            if (estado.getRojos(jugador.getUuid()) >= Vida.MAX_ROJOS_EXTRA) {
                jugador.sendMessage(Text.literal("Ya tienes el máximo de corazones").formatted(Formatting.RED), true);
                return TypedActionResult.fail(stack);
            }
            Vida.cambiarRojos(jugador, 1);
            jugador.sendMessage(Text.literal("+1 corazón permanente").formatted(Formatting.RED), true);
            world.playSound(null, jugador.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1f, 1.2f);
        }
        stack.decrementUnlessCreative(1, jugador);
        return TypedActionResult.success(stack, false);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable(esAlma ? "item.desinformados.corazon_alma.tooltip" : "item.desinformados.corazon_rojo.tooltip")
                .formatted(Formatting.GRAY));
    }
}

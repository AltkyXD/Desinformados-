package com.centrodesinformacion.desinformados.tienda;

import com.centrodesinformacion.desinformados.ModBloques;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import com.centrodesinformacion.desinformados.network.DjPayload;
import com.centrodesinformacion.desinformados.network.DjPedidoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DJ Miaumix: cuando no hace nada pone "Dj espontaneo" en bucle. Por 20 Rumores pone una canción;
 * mientras suena, algunos Gatos Cubo se van a la Pista de Baile a bailar y el DJ salta despacio.
 */
public class Dj {
    public static final int PRECIO = 20;
    public static final String[] NOMBRES = {"Hombre denigrante ante un genero", "Me porto bonito Remix", "Chichabeba"};
    private static final SoundEvent[] SONIDOS = {ModSounds.DJ_HOMBRE_DENIGRANTE, ModSounds.DJ_ME_PORTO_BONITO, ModSounds.DJ_CHICHABEBA};
    /** Duración de cada canción en ticks (20 = 1 s). */
    public static final int[] DURACION = {3158, 3210, 2636};
    public static final int DURACION_ESPONTANEO = 778;
    public static final float VOLUMEN = 1f;            // canciones: se oyen hasta ~16 bloques
    public static final float VOLUMEN_BUCLE = 0.55f;   // "Dj espontaneo" más bajito
    public static final int RADIO_OIDO = 16;
    private static final int CAMBIO_DISCO = 26;        // lo que dura el sonido del disco antes de la canción
    private static final int RADIO_GATOS = 24, RADIO_PISTA = 16;

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(DjPedidoPayload.ID, (paquete, ctx) -> ctx.server().execute(() -> pedir(ctx.player(), paquete)));
    }

    public static void abrir(ServerPlayerEntity p, GatoCuboEntity dj) {
        enviar(p, dj, true);
    }

    private static void enviar(ServerPlayerEntity p, GatoCuboEntity dj, boolean abrir) {
        if (!ServerPlayNetworking.canSend(p, DjPayload.ID)) return;
        int quedan = dj.getCancion() >= 0 ? (int) Math.max(0, (dj.getFinCancion() - dj.getWorld().getTime()) / 20) : 0;
        ServerPlayNetworking.send(p, new DjPayload(dj.getId(), Tienda.dineroTotal(p), dj.getCancion(), quedan, abrir));
    }

    private static void pedir(ServerPlayerEntity p, DjPedidoPayload paquete) {
        Entity e = p.getServerWorld().getEntityById(paquete.entidad());
        if (!(e instanceof GatoCuboEntity dj) || dj.getTipo() != GatoCuboEntity.DJ || p.squaredDistanceTo(dj) > 100) return;
        int i = paquete.indice();
        if (i < 0 || i >= NOMBRES.length) return;
        if (dj.getCancion() >= 0) {
            p.sendMessage(Text.literal("Ya está sonando una canción. Espera a que termine.").formatted(Formatting.YELLOW), true);
        } else if (!Tienda.cobrar(p, PRECIO)) {
            p.sendMessage(Text.literal("No te alcanza. Te faltan " + (PRECIO - Tienda.dineroTotal(p)) + " Rumores.").formatted(Formatting.RED), true);
            p.getServerWorld().playSound(null, dj.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.NEUTRAL, 0.8f, 1f);
        } else {
            poner(dj, i, p);
        }
        enviar(p, dj, false);
    }

    /** Empieza la canción i: corta el bucle del DJ, avisa a todos y manda gatos a la pista. */
    public static void poner(GatoCuboEntity dj, int i, ServerPlayerEntity quien) {
        ServerWorld w = (ServerWorld) dj.getWorld();
        StopSoundS2CPacket parar = new StopSoundS2CPacket(Registries.SOUND_EVENT.getId(ModSounds.DJ_ESPONTANEO), SoundCategory.RECORDS);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(dj) > 48 * 48) continue;
            p.networkHandler.sendPacket(parar);
            p.sendMessage(Text.literal("♪ DJ Miaumix pone: " + NOMBRES[i] + (quien != null ? " (la pidió " + quien.getGameProfile().getName() + ")" : "") + " ♪")
                    .formatted(Formatting.LIGHT_PURPLE), true);
        }
        // primero el disco moviéndose (scratch) y después la canción
        w.playSound(null, dj.getX(), dj.getY(), dj.getZ(), ModSounds.DJ_SCRATCH, SoundCategory.RECORDS, VOLUMEN, 1f);
        com.centrodesinformacion.desinformados.Tareas.programar(CAMBIO_DISCO, () -> {
            if (dj.isAlive() && dj.getCancion() == i) w.playSound(null, dj.getX(), dj.getY(), dj.getZ(), SONIDOS[i], SoundCategory.RECORDS, VOLUMEN, 1f);
        });
        long fin = w.getTime() + CAMBIO_DISCO + DURACION[i];
        dj.empezarCancion(i, fin);
        w.spawnParticles(ParticleTypes.NOTE, dj.getX(), dj.getY() + 1.3, dj.getZ(), 12, 0.6, 0.4, 0.6, 1);
        mandarAPista(w, dj, fin);
    }

    /** Busca baldosas de Pista de Baile cerca del DJ y manda a algunos gatos a bailar en ellas. */
    private static void mandarAPista(ServerWorld w, GatoCuboEntity dj, long fin) {
        List<BlockPos> pista = new ArrayList<>();
        BlockPos c = dj.getBlockPos();
        for (BlockPos q : BlockPos.iterate(c.add(-RADIO_PISTA, -4, -RADIO_PISTA), c.add(RADIO_PISTA, 4, RADIO_PISTA))) {
            if (w.getBlockState(q).isOf(ModBloques.PISTA_BAILE) && w.getBlockState(q.up()).isAir() && w.getBlockState(q.up(2)).isAir()) {
                pista.add(q.toImmutable());
            }
        }
        if (pista.isEmpty()) return;
        Collections.shuffle(pista);
        List<GatoCuboEntity> gatos = w.getEntitiesByClass(GatoCuboEntity.class, new Box(c).expand(RADIO_GATOS),
                g -> g != dj && !g.esVendedor() && g.getTipo() != GatoCuboEntity.DJ);
        Collections.shuffle(gatos);
        int cuantos = gatos.isEmpty() ? 0 : Math.max(1, (int) Math.ceil(gatos.size() * 0.6));
        for (int k = 0; k < cuantos; k++) gatos.get(k).irABailar(pista.get(k % pista.size()), fin);
    }
}

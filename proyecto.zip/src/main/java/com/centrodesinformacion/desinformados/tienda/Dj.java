package com.centrodesinformacion.desinformados.tienda;

import com.centrodesinformacion.desinformados.ConstructorCentro;
import com.centrodesinformacion.desinformados.ModBloques;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import com.centrodesinformacion.desinformados.network.DjPayload;
import com.centrodesinformacion.desinformados.network.DjPedidoPayload;
import com.centrodesinformacion.desinformados.network.DjSonidoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DJ Miaumix: cuando no hace nada va poniendo "Dj espontaneo" y sus dos jingles de helicóptero, al azar. Por 20 Rumores pone una canción;
 * mientras suena, algunos Gatos Cubo se van a la Pista de Baile a bailar y el DJ salta despacio.
 */
public class Dj {
    public static final int PRECIO = 20;
    public static final String[] NOMBRES = {"Hombre denigrante ante un genero", "Me porto bonito Remix", "Chichabeba",
            "Aura", "Para proyectarse", "Konichiwa"};
    private static final SoundEvent[] SONIDOS = {ModSounds.DJ_HOMBRE_DENIGRANTE, ModSounds.DJ_ME_PORTO_BONITO, ModSounds.DJ_CHICHABEBA,
            ModSounds.DJ_AURA, ModSounds.DJ_PARA_PROYECTARSE, ModSounds.DJ_KONICHIWA};
    /** Duración de cada canción en ticks (20 = 1 s). */
    public static final int[] DURACION = {3158, 3210, 2636, 2320, 3610, 4378};
    public static final int DURACION_ESPONTANEO = 778;
    /** Lo que pone cuando nadie le pide nada (se van turnando al azar, sin repetir el último) y cuánto dura cada uno (ticks). */
    public static final SoundEvent[] BUCLES = {ModSounds.DJ_ESPONTANEO, ModSounds.DJ_HELICOPTERO_1, ModSounds.DJ_HELICOPTERO_2};
    public static final int[] DURACION_BUCLES = {DURACION_ESPONTANEO, 946, 655};
    public static final float VOLUMEN = 1f;            // canciones: se oyen hasta ~16 bloques
    public static final float VOLUMEN_BUCLE = 0.55f;   // "Dj espontaneo" más bajito
    public static final int RADIO_OIDO = 32;            // se oye hasta 32 bloques (attenuation_distance de sounds.json): el doble que antes
    /** A quién se le manda el sonido: todo el que esté en el edificio; el cliente solo lo oye si está en el piso del DJ. */
    private static final int RADIO_ENVIO = 80;
    private static final int CAMBIO_DISCO = 26;        // lo que dura el sonido del disco antes de la canción
    private static final int RADIO_GATOS = 24, RADIO_PISTA = 16;

    public static void registrar() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> olvidar());
        ServerPlayNetworking.registerGlobalReceiver(DjPedidoPayload.ID, (paquete, ctx) -> ctx.server().execute(() -> pedir(ctx.player(), paquete)));
    }

    public static void abrir(ServerPlayerEntity p, GatoCuboEntity dj) {
        enviar(p, dj, true);
    }

    private static void enviar(ServerPlayerEntity p, GatoCuboEntity dj, boolean abrir) {
        if (!ServerPlayNetworking.canSend(p, DjPayload.ID)) return;
        int quedan = dj.getCancion() >= 0 ? (int) Math.max(0, (dj.getFinCancion() - dj.getWorld().getTime()) / 20) : 0;
        ServerPlayNetworking.send(p, new DjPayload(dj.getId(), Tienda.dineroTotal(p), dj.getCancion(), quedan, abrir));
    }

    private static void pedir(ServerPlayerEntity p, DjPedidoPayload paquete) {
        Entity e = p.getServerWorld().getEntityById(paquete.entidad());
        if (!(e instanceof GatoCuboEntity dj) || dj.getTipo() != GatoCuboEntity.DJ || p.squaredDistanceTo(dj) > 100) return;
        int i = paquete.indice();
        if (i < 0 || i >= NOMBRES.length) return;
        if (dj.getCancion() >= 0) {
            p.sendMessage(Text.literal("Ya está sonando una canción. Espera a que termine.").formatted(Formatting.YELLOW), true);
        } else if (!Tienda.cobrar(p, PRECIO)) {
            p.sendMessage(Text.literal("No te alcanza. Te faltan " + (PRECIO - Tienda.dineroTotal(p)) + " Rumores.").formatted(Formatting.RED), true);
            p.getServerWorld().playSound(null, dj.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.NEUTRAL, 0.8f, 1f);
        } else {
            poner(dj, i, p);
            com.centrodesinformacion.desinformados.Misiones.sumar(p, "dj", 1);
        }
        enviar(p, dj, false);
    }

    /** Empieza la canción i: corta el bucle del DJ, avisa a todos y manda gatos a la pista. */
    public static void poner(GatoCuboEntity dj, int i, ServerPlayerEntity quien) {
        ServerWorld w = (ServerWorld) dj.getWorld();
        double[] piso = piso(dj);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(dj) > RADIO_ENVIO * RADIO_ENVIO) continue;
            for (SoundEvent b : BUCLES)                                                  // corta lo que estuviera improvisando
                p.networkHandler.sendPacket(new StopSoundS2CPacket(Registries.SOUND_EVENT.getId(b), SoundCategory.RECORDS));
            if (p.getY() >= piso[0] && p.getY() < piso[1] && p.squaredDistanceTo(dj) < 48 * 48)   // el aviso, solo a los que están en la fiesta
                p.sendMessage(Text.literal("♪ DJ Miaumix pone: " + NOMBRES[i] + (quien != null ? " (la pidió " + quien.getGameProfile().getName() + ")" : "") + " ♪")
                        .formatted(Formatting.LIGHT_PURPLE), true);
        }
        // primero el disco moviéndose (scratch) y después la canción
        PISTAS.remove(dj.getUuid());
        sonar(dj, ModSounds.DJ_SCRATCH, VOLUMEN);
        com.centrodesinformacion.desinformados.Tareas.programar(CAMBIO_DISCO, () -> {
            if (dj.isAlive() && dj.getCancion() == i) sonarPista(dj, SONIDOS[i], VOLUMEN, DURACION[i]);
        });
        long fin = w.getTime() + CAMBIO_DISCO + DURACION[i];
        dj.empezarCancion(i, fin);
        w.spawnParticles(ParticleTypes.NOTE, dj.getX(), dj.getY() + 1.3, dj.getZ(), 12, 0.6, 0.4, 0.6, 1);
        mandarAPista(w, dj, fin);
    }

    /**
     * Pone un sonido del DJ solo para su piso: se le manda a todos los de alrededor (también a los de otros pisos,
     * en silencio) y cada cliente lo sube o lo baja según esté o no en el piso del DJ.
     */
    public static void sonar(GatoCuboEntity dj, SoundEvent sonido, float volumen) {
        ServerWorld w = (ServerWorld) dj.getWorld();
        double[] piso = piso(dj);
        DjSonidoPayload paquete = new DjSonidoPayload(sonido.getId(), dj.getX(), dj.getY() + 0.5, dj.getZ(), volumen, piso[0], piso[1], 0);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(dj) > RADIO_ENVIO * RADIO_ENVIO) continue;
            if (ServerPlayNetworking.canSend(p, DjSonidoPayload.ID)) ServerPlayNetworking.send(p, paquete);
        }
    }

    // ---------- Lo que está sonando ahora (canción o bucle): para dárselo a los que lleguen a mitad ----------
    private static final class Pista {
        final SoundEvent sonido; final float volumen; final long inicio, fin;
        final java.util.Set<java.util.UUID> oyentes = new java.util.HashSet<>();
        Pista(SoundEvent sonido, float volumen, long inicio, long fin) { this.sonido = sonido; this.volumen = volumen; this.inicio = inicio; this.fin = fin; }
    }
    private static final java.util.Map<java.util.UUID, Pista> PISTAS = new java.util.HashMap<>();

    /** Pone una pista larga (canción o bucle) y apunta quién la está oyendo. */
    public static void sonarPista(GatoCuboEntity dj, SoundEvent sonido, float volumen, int duracion) {
        ServerWorld w = (ServerWorld) dj.getWorld();
        long ahora = w.getTime();
        Pista pista = new Pista(sonido, volumen, ahora, ahora + duracion);
        PISTAS.put(dj.getUuid(), pista);
        double[] piso = piso(dj);
        DjSonidoPayload paquete = new DjSonidoPayload(sonido.getId(), dj.getX(), dj.getY() + 0.5, dj.getZ(), volumen, piso[0], piso[1], 0);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(dj) > RADIO_ENVIO * RADIO_ENVIO || !ServerPlayNetworking.canSend(p, DjSonidoPayload.ID)) continue;
            ServerPlayNetworking.send(p, paquete);
            pista.oyentes.add(p.getUuid());
        }
    }

    /**
     * Cada segundo (lo llama el DJ): a quien se acerca mientras suena algo (o se conecta, o vuelve de otra dimensión)
     * se le pone por donde va; a quien se aleja se le quita de la lista (si vuelve, se le corta y se le pone de nuevo).
     */
    public static void actualizarOyentes(GatoCuboEntity dj) {
        Pista pista = PISTAS.get(dj.getUuid());
        if (pista == null) return;
        ServerWorld w = (ServerWorld) dj.getWorld();
        long ahora = w.getTime();
        if (ahora >= pista.fin - 20) { PISTAS.remove(dj.getUuid()); return; }
        java.util.Set<java.util.UUID> cerca = new java.util.HashSet<>();
        double[] piso = null;
        for (ServerPlayerEntity p : w.getPlayers()) {
            double d2 = p.squaredDistanceTo(dj);
            if (d2 <= (RADIO_ENVIO + 8) * (RADIO_ENVIO + 8)) cerca.add(p.getUuid());
            if (d2 > RADIO_ENVIO * RADIO_ENVIO || pista.oyentes.contains(p.getUuid()) || !ServerPlayNetworking.canSend(p, DjSonidoPayload.ID)) continue;
            if (piso == null) piso = piso(dj);
            Identifier id = Registries.SOUND_EVENT.getId(pista.sonido);
            if (id == null) id = pista.sonido.getId();
            p.networkHandler.sendPacket(new StopSoundS2CPacket(id, SoundCategory.RECORDS));     // por si aún le sonaba de antes
            ServerPlayNetworking.send(p, new DjSonidoPayload(pista.sonido.getId(), dj.getX(), dj.getY() + 0.5, dj.getZ(), pista.volumen,
                    piso[0], piso[1], (int) (ahora - pista.inicio)));
            pista.oyentes.add(p.getUuid());
        }
        pista.oyentes.retainAll(cerca);
    }

    /** Al parar el servidor (en LAN el mapa estático sobrevive). */
    public static void olvidar() {
        PISTAS.clear();
    }

    /** ¿Está el jugador en el mismo piso que el DJ (y cerca)? */
    public static boolean enSuPiso(GatoCuboEntity dj, ServerPlayerEntity p, int radio) {
        if (p.squaredDistanceTo(dj) > (double) radio * radio) return false;
        double[] piso = piso(dj);
        return p.getY() >= piso[0] && p.getY() < piso[1];
    }

    /**
     * Alturas (de los pies) entre las que un jugador está "en el piso del DJ": desde un bloque por debajo del suelo
     * (los últimos escalones) hasta el techo. El suelo es lo primero sólido bajo el DJ y el techo lo primero sólido
     * encima, como mucho un piso del Centro (7 bloques) más arriba.
     */
    static double[] piso(GatoCuboEntity dj) {
        ServerWorld w = (ServerWorld) dj.getWorld();
        BlockPos pie = BlockPos.ofFloored(dj.getX(), dj.getY() + 0.1, dj.getZ());
        int suelo = pie.getY();
        for (int k = 1; k <= 4; k++) {
            BlockPos q = pie.down(k);
            if (w.getBlockState(q).isSideSolidFullSquare(w, q, Direction.UP)) { suelo = q.getY() + 1; break; }
        }
        int techo = suelo + ConstructorCentro.ALTO_PISO - 1;
        for (int y = suelo + 2; y <= suelo + ConstructorCentro.ALTO_PISO - 1; y++) {
            BlockPos q = new BlockPos(pie.getX(), y, pie.getZ());
            if (w.getBlockState(q).isSideSolidFullSquare(w, q, Direction.DOWN)) { techo = y; break; }
        }
        return new double[]{suelo - 1.0, techo};
    }

    /** Busca baldosas de Pista de Baile cerca del DJ y manda a algunos gatos a bailar en ellas. */
    private static void mandarAPista(ServerWorld w, GatoCuboEntity dj, long fin) {
        List<BlockPos> pista = new ArrayList<>();
        BlockPos c = dj.getBlockPos();
        for (BlockPos q : BlockPos.iterate(c.add(-RADIO_PISTA, -4, -RADIO_PISTA), c.add(RADIO_PISTA, 4, RADIO_PISTA))) {
            if (w.getBlockState(q).isOf(ModBloques.PISTA_BAILE) && w.getBlockState(q.up()).isAir() && w.getBlockState(q.up(2)).isAir()) {
                pista.add(q.toImmutable());
            }
        }
        if (pista.isEmpty()) return;
        Collections.shuffle(pista);
        List<GatoCuboEntity> gatos = w.getEntitiesByClass(GatoCuboEntity.class, new Box(c).expand(RADIO_GATOS),
                g -> g != dj && !g.quieto() && Math.abs(g.getY() - dj.getY()) < 10);   // los que no se mueven de su sitio (y el techo) no bajan a bailar
        Collections.shuffle(gatos);
        int cuantos = gatos.isEmpty() ? 0 : Math.max(1, (int) Math.ceil(gatos.size() * 0.9));   // casi todos se apuntan
        for (int k = 0; k < cuantos; k++) gatos.get(k).irABailar(pista.get(k % pista.size()), fin);
    }
}

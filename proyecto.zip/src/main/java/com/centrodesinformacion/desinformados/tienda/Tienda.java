package com.centrodesinformacion.desinformados.tienda;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.ModItems;
import com.centrodesinformacion.desinformados.RumorItem;
import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import com.centrodesinformacion.desinformados.network.TiendaCompraPayload;
import com.centrodesinformacion.desinformados.network.TiendaPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Tiendas de los Gatos Cubo. Se paga en Rumores: primero del saldo del Banco y, si no llega,
 * con las monedas del inventario (el cambio vuelve al Banco). Precios pensados para ser caros.
 */
public class Tienda {
    public record Oferta(Item item, int cantidad, int precio) {
        public ItemStack stack() { return new ItemStack(item, cantidad); }
    }

    /** Índice = tipo de vendedor - GatoCuboEntity.VEND_PASIVAS */
    public static List<Oferta> ofertas(int tipo) {
        return switch (tipo) {
            case GatoCuboEntity.VEND_PASIVAS -> List.of(
                    new Oferta(ModItems.PASIVA_VENENO, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("veneno").precio()),
                    new Oferta(ModItems.PASIVA_ALETAS, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("aletas").precio()),
                    new Oferta(ModItems.PASIVA_CAIDA, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("caida").precio()),
                    new Oferta(ModItems.PASIVA_GARRAS, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("garras").precio()),
                    new Oferta(ModItems.PASIVA_DOBLE_SALTO, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("doble_salto").precio()),
                    new Oferta(ModItems.PASIVA_ROCK_BOTTOM, 1, com.centrodesinformacion.desinformados.pasivas.Pasivas.porId("rock_bottom").precio()));
            case GatoCuboEntity.VEND_CORAZONES -> List.of(
                    new Oferta(Items.GOLDEN_APPLE, 1, 35),
                    new Oferta(ModItems.CORAZON_ROJO, 1, 90),
                    new Oferta(ModItems.CORAZON_ALMA, 1, 150),
                    new Oferta(Items.TOTEM_OF_UNDYING, 1, 225));
            case GatoCuboEntity.VEND_MINERALES -> List.of(
                    new Oferta(Items.REDSTONE, 32, 16),
                    new Oferta(Items.LAPIS_LAZULI, 32, 18),
                    new Oferta(Items.IRON_INGOT, 16, 24),
                    new Oferta(Items.GOLD_INGOT, 16, 36),
                    new Oferta(Items.EMERALD, 4, 32),
                    new Oferta(Items.DIAMOND, 1, 48),
                    new Oferta(Items.NETHERITE_INGOT, 1, 360));
            default -> List.of(); // pasivas: próximamente
        };
    }

    // ---------- Puesto (estand) ----------
    /** Construye un puesto delante del jugador y pone al vendedor detrás del mostrador. */
    public static GatoCuboEntity construirPuesto(net.minecraft.server.world.ServerWorld w, ServerPlayerEntity p, int tipo) {
        net.minecraft.util.math.Direction f = p.getHorizontalFacing();
        net.minecraft.util.math.Direction der = f.rotateYClockwise();
        net.minecraft.util.math.BlockPos centro = p.getBlockPos().offset(f, 3);
        net.minecraft.block.BlockState lona1, lona2, mostrador;
        switch (tipo) {
            case GatoCuboEntity.VEND_PASIVAS -> { lona1 = net.minecraft.block.Blocks.PURPLE_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.WHITE_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.PURPUR_BLOCK.getDefaultState(); }
            case GatoCuboEntity.VEND_CORAZONES -> { lona1 = net.minecraft.block.Blocks.RED_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.WHITE_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.QUARTZ_BLOCK.getDefaultState(); }
            default -> { lona1 = net.minecraft.block.Blocks.YELLOW_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.BLACK_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.SPRUCE_PLANKS.getDefaultState(); }
        }
        net.minecraft.block.BlockState aire = net.minecraft.block.Blocks.AIR.getDefaultState();
        net.minecraft.block.BlockState poste = net.minecraft.block.Blocks.DARK_OAK_FENCE.getDefaultState();
        for (int i = -2; i <= 2; i++) {
            for (int fila = 0; fila <= 2; fila++) {          // 0 = mostrador, 1 = vendedor, 2 = fondo
                net.minecraft.util.math.BlockPos b = centro.offset(der, i).offset(f, fila);
                for (int y = 0; y <= 2; y++) w.setBlockState(b.up(y), aire);
            }
            w.setBlockState(centro.offset(der, i), mostrador);                         // mostrador
            for (int fila = -1; fila <= 2; fila++)                                      // toldo de rayas
                w.setBlockState(centro.offset(der, i).offset(f, fila).up(3), ((i + 2) % 2 == 0) ? lona1 : lona2);
        }
        for (int lado : new int[]{-2, 2}) for (int fila : new int[]{0, 2}) for (int y = 0; y <= 2; y++) {
            net.minecraft.util.math.BlockPos b = centro.offset(der, lado).offset(f, fila).up(y);
            if (fila == 0 && y == 0) continue; // las esquinas del mostrador se quedan
            w.setBlockState(b, poste);
        }
        w.setBlockState(centro.offset(f, 1).up(2), net.minecraft.block.Blocks.LANTERN.getDefaultState()
                .with(net.minecraft.block.LanternBlock.HANGING, true));
        net.minecraft.util.math.BlockPos casa = centro.offset(f, 1);
        GatoCuboEntity v = com.centrodesinformacion.desinformados.entidad.ModEntidades.GATO_CUBO.create(w);
        if (v == null) return null;
        float yaw = f.getOpposite().asRotation();
        v.refreshPositionAndAngles(casa.getX() + 0.5, casa.getY(), casa.getZ() + 0.5, yaw, 0f);
        v.setHeadYaw(yaw); v.setBodyYaw(yaw);
        v.configurar(tipo, casa);
        w.spawnEntity(v);
        return v;
    }

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(TiendaCompraPayload.ID, (paquete, ctx) -> comprar(ctx.player(), paquete));
    }

    // ---------- Vender (solo en el puesto de minerales) ----------
    /** Al vender te pagan este % de lo que cuesta comprarlo en el puesto. */
    public static final int VENTA_PCT = 40;

    /** ¿Este vendedor también compra? */
    public static boolean compra(int tipo) {
        return tipo == GatoCuboEntity.VEND_MINERALES;
    }

    /** Rumores que te dan por 'cuantos' objetos de esa oferta (redondeando hacia abajo). */
    public static int ganancia(Oferta o, int cuantos) {
        return (int) ((long) cuantos * o.precio() * VENTA_PCT / (100L * o.cantidad()));
    }

    /** Cuántos objetos hacen falta para cobrar 'rumores' (lo que sobra se queda en tu inventario). */
    private static int necesarios(Oferta o, int rumores) {
        long porRumor = 100L * o.cantidad(), porObjeto = (long) o.precio() * VENTA_PCT;
        return (int) ((rumores * porRumor + porObjeto - 1) / porObjeto);
    }

    /** Cuántos lleva el jugador (inventario y mano izquierda; la armadura puesta no cuenta). */
    public static int cuantosLleva(PlayerInventory inv, Item item) {
        int n = 0;
        for (ItemStack s : inv.main) if (s.isOf(item)) n += s.getCount();
        for (ItemStack s : inv.offHand) if (s.isOf(item)) n += s.getCount();
        return n;
    }

    private static void quitar(PlayerInventory inv, Item item, int cuantos) {
        for (java.util.List<ItemStack> lista : java.util.List.of(inv.main, inv.offHand)) {
            for (ItemStack s : lista) {
                if (cuantos <= 0) return;
                if (!s.isOf(item)) continue;
                int q = Math.min(cuantos, s.getCount());
                s.decrement(q);
                cuantos -= q;
            }
        }
    }

    private static void vender(ServerPlayerEntity p, GatoCuboEntity v, int indice) {
        if (!compra(v.getTipo())) return;
        List<Oferta> lista = ofertas(v.getTipo());
        if (indice < 0 || indice >= lista.size()) return;
        Oferta o = lista.get(indice);
        PlayerInventory inv = p.getInventory();
        int lleva = cuantosLleva(inv, o.item());
        int pago = ganancia(o, lleva);
        String nombre = o.item().getName().getString();
        if (pago <= 0) {
            p.sendMessage(Text.literal(lleva == 0 ? "No llevas " + nombre + "."
                    : "Con " + lleva + " no llega ni a 1 Rumor. Necesitas al menos " + necesarios(o, 1) + ".").formatted(Formatting.RED), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.NEUTRAL, 0.6f, 1.2f);
        } else {
            int vendidos = Math.min(lleva, necesarios(o, pago));
            quitar(inv, o.item(), vendidos);
            EstadoServidor estado = EstadoServidor.get(p.getServer());
            estado.setSaldo(p.getUuid(), estado.getSaldo(p.getUuid()) + pago);   // lo cobrado va al Banco
            p.sendMessage(Text.literal("Vendiste " + vendidos + "x " + nombre + " por " + pago + " Rumores (van a tu cuenta del Banco).")
                    .formatted(Formatting.GOLD), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_PURREOW, SoundCategory.NEUTRAL, 1f, 1.1f);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.BLOCK_CHAIN_PLACE, SoundCategory.NEUTRAL, 0.8f, 1.6f);
        }
        enviar(p, v, false);
    }

    public static void abrir(ServerPlayerEntity p, GatoCuboEntity vendedor) {
        enviar(p, vendedor, true);
    }

    private static void enviar(ServerPlayerEntity p, GatoCuboEntity v, boolean abrir) {
        if (ServerPlayNetworking.canSend(p, TiendaPayload.ID))
            ServerPlayNetworking.send(p, new TiendaPayload(v.getId(), v.getTipo(), dineroTotal(p), abrir));
    }

    private static int valorInventario(ServerPlayerEntity p) {
        int total = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++)
            if (inv.getStack(i).getItem() instanceof RumorItem r) total += r.getValor() * inv.getStack(i).getCount();
        return total;
    }

    public static int dineroTotal(ServerPlayerEntity p) {
        return EstadoServidor.get(p.getServer()).getSaldo(p.getUuid()) + valorInventario(p);
    }

    /** Cobra 'precio'. Devuelve false si no alcanza. */
    public static boolean cobrar(ServerPlayerEntity p, int precio) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        int saldo = estado.getSaldo(p.getUuid());
        if (saldo + valorInventario(p) < precio) return false;
        if (saldo >= precio) { estado.setSaldo(p.getUuid(), saldo - precio); return true; }
        int falta = precio - saldo;
        estado.setSaldo(p.getUuid(), 0);
        PlayerInventory inv = p.getInventory();
        int pagado = 0;
        for (int i = 0; i < inv.size() && pagado < falta; i++) {
            ItemStack s = inv.getStack(i);
            if (!(s.getItem() instanceof RumorItem r)) continue;
            while (!s.isEmpty() && pagado < falta) { s.decrement(1); pagado += r.getValor(); }
        }
        if (pagado > falta) estado.setSaldo(p.getUuid(), pagado - falta); // el cambio va al Banco
        return true;
    }

    private static void comprar(ServerPlayerEntity p, TiendaCompraPayload paquete) {
        Entity e = p.getServerWorld().getEntityById(paquete.entidad());
        if (!(e instanceof GatoCuboEntity v) || !v.esVendedor() || p.squaredDistanceTo(v) > 64) return;
        if (paquete.indice() < 0) { vender(p, v, -paquete.indice() - 1); return; }   // índice negativo = vender
        List<Oferta> lista = ofertas(v.getTipo());
        if (paquete.indice() >= lista.size()) return;
        Oferta o = lista.get(paquete.indice());
        if (!cobrar(p, o.precio())) {
            p.sendMessage(Text.literal("No te alcanza. Te faltan " + (o.precio() - dineroTotal(p)) + " Rumores. El casino está por ahí...")
                    .formatted(Formatting.RED), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.NEUTRAL, 0.8f, 1.0f);
        } else {
            ItemStack s = o.stack();
            if (!p.getInventory().insertStack(s)) p.dropItem(s, false);
            p.sendMessage(Text.literal("Compraste " + o.cantidad() + "x " + o.item().getName().getString() + " por " + o.precio() + " Rumores.")
                    .formatted(Formatting.GOLD), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_PURREOW, SoundCategory.NEUTRAL, 1f, 1.1f);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.NEUTRAL, 0.6f, 0.7f);
        }
        enviar(p, v, false);
    }
}

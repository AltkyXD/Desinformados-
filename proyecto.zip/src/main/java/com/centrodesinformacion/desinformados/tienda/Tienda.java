package com.centrodesinformacion.desinformados.tienda;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.ModItems;
import com.centrodesinformacion.desinformados.RumorItem;
import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import com.centrodesinformacion.desinformados.network.TiendaCompraPayload;
import com.centrodesinformacion.desinformados.network.TiendaPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Tiendas de los Gatos Cubo. Se paga en Rumores: primero del saldo del Banco y, si no llega,
 * con las monedas del inventario (el cambio vuelve al Banco). Precios pensados para ser caros.
 */
public class Tienda {
    public record Oferta(Item item, int cantidad, int precio) {
        public ItemStack stack() { return new ItemStack(item, cantidad); }
    }

    /** Índice = tipo de vendedor - GatoCuboEntity.VEND_PASIVAS */
    public static List<Oferta> ofertas(int tipo) {
        return switch (tipo) {
            case GatoCuboEntity.VEND_CORAZONES -> List.of(
                    new Oferta(Items.GOLDEN_APPLE, 1, 70),
                    new Oferta(ModItems.CORAZON_ROJO, 1, 180),
                    new Oferta(ModItems.CORAZON_ALMA, 1, 300),
                    new Oferta(Items.TOTEM_OF_UNDYING, 1, 450));
            case GatoCuboEntity.VEND_MINERALES -> List.of(
                    new Oferta(Items.REDSTONE, 32, 40),
                    new Oferta(Items.LAPIS_LAZULI, 32, 45),
                    new Oferta(Items.IRON_INGOT, 16, 60),
                    new Oferta(Items.GOLD_INGOT, 16, 90),
                    new Oferta(Items.EMERALD, 4, 80),
                    new Oferta(Items.DIAMOND, 1, 120),
                    new Oferta(ModItems.GARATITA, 4, 200),
                    new Oferta(ModItems.FRAGMENTO_ESTATICA, 1, 500),
                    new Oferta(Items.NETHERITE_INGOT, 1, 900));
            default -> List.of(); // pasivas: próximamente
        };
    }

    // ---------- Puesto (estand) ----------
    /** Construye un puesto delante del jugador y pone al vendedor detrás del mostrador. */
    public static GatoCuboEntity construirPuesto(net.minecraft.server.world.ServerWorld w, ServerPlayerEntity p, int tipo) {
        net.minecraft.util.math.Direction f = p.getHorizontalFacing();
        net.minecraft.util.math.Direction der = f.rotateYClockwise();
        net.minecraft.util.math.BlockPos centro = p.getBlockPos().offset(f, 3);
        net.minecraft.block.BlockState lona1, lona2, mostrador;
        switch (tipo) {
            case GatoCuboEntity.VEND_PASIVAS -> { lona1 = net.minecraft.block.Blocks.PURPLE_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.WHITE_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.PURPUR_BLOCK.getDefaultState(); }
            case GatoCuboEntity.VEND_CORAZONES -> { lona1 = net.minecraft.block.Blocks.RED_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.WHITE_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.QUARTZ_BLOCK.getDefaultState(); }
            default -> { lona1 = net.minecraft.block.Blocks.YELLOW_WOOL.getDefaultState(); lona2 = net.minecraft.block.Blocks.BLACK_WOOL.getDefaultState(); mostrador = net.minecraft.block.Blocks.SPRUCE_PLANKS.getDefaultState(); }
        }
        net.minecraft.block.BlockState aire = net.minecraft.block.Blocks.AIR.getDefaultState();
        net.minecraft.block.BlockState poste = net.minecraft.block.Blocks.DARK_OAK_FENCE.getDefaultState();
        for (int i = -2; i <= 2; i++) {
            for (int fila = 0; fila <= 2; fila++) {          // 0 = mostrador, 1 = vendedor, 2 = fondo
                net.minecraft.util.math.BlockPos b = centro.offset(der, i).offset(f, fila);
                for (int y = 0; y <= 2; y++) w.setBlockState(b.up(y), aire);
            }
            w.setBlockState(centro.offset(der, i), mostrador);                         // mostrador
            for (int fila = -1; fila <= 2; fila++)                                      // toldo de rayas
                w.setBlockState(centro.offset(der, i).offset(f, fila).up(3), ((i + 2) % 2 == 0) ? lona1 : lona2);
        }
        for (int lado : new int[]{-2, 2}) for (int fila : new int[]{0, 2}) for (int y = 0; y <= 2; y++) {
            net.minecraft.util.math.BlockPos b = centro.offset(der, lado).offset(f, fila).up(y);
            if (fila == 0 && y == 0) continue; // las esquinas del mostrador se quedan
            w.setBlockState(b, poste);
        }
        w.setBlockState(centro.offset(f, 1).up(2), net.minecraft.block.Blocks.LANTERN.getDefaultState()
                .with(net.minecraft.block.LanternBlock.HANGING, true));
        net.minecraft.util.math.BlockPos casa = centro.offset(f, 1);
        GatoCuboEntity v = com.centrodesinformacion.desinformados.entidad.ModEntidades.GATO_CUBO.create(w);
        if (v == null) return null;
        float yaw = f.getOpposite().asRotation();
        v.refreshPositionAndAngles(casa.getX() + 0.5, casa.getY(), casa.getZ() + 0.5, yaw, 0f);
        v.setHeadYaw(yaw); v.setBodyYaw(yaw);
        v.configurar(tipo, casa);
        w.spawnEntity(v);
        return v;
    }

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(TiendaCompraPayload.ID, (paquete, ctx) -> comprar(ctx.player(), paquete));
    }

    public static void abrir(ServerPlayerEntity p, GatoCuboEntity vendedor) {
        enviar(p, vendedor, true);
    }

    private static void enviar(ServerPlayerEntity p, GatoCuboEntity v, boolean abrir) {
        if (ServerPlayNetworking.canSend(p, TiendaPayload.ID))
            ServerPlayNetworking.send(p, new TiendaPayload(v.getId(), v.getTipo(), dineroTotal(p), abrir));
    }

    private static int valorInventario(ServerPlayerEntity p) {
        int total = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++)
            if (inv.getStack(i).getItem() instanceof RumorItem r) total += r.getValor() * inv.getStack(i).getCount();
        return total;
    }

    public static int dineroTotal(ServerPlayerEntity p) {
        return EstadoServidor.get(p.getServer()).getSaldo(p.getUuid()) + valorInventario(p);
    }

    /** Cobra 'precio'. Devuelve false si no alcanza. */
    public static boolean cobrar(ServerPlayerEntity p, int precio) {
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        int saldo = estado.getSaldo(p.getUuid());
        if (saldo + valorInventario(p) < precio) return false;
        if (saldo >= precio) { estado.setSaldo(p.getUuid(), saldo - precio); return true; }
        int falta = precio - saldo;
        estado.setSaldo(p.getUuid(), 0);
        PlayerInventory inv = p.getInventory();
        int pagado = 0;
        for (int i = 0; i < inv.size() && pagado < falta; i++) {
            ItemStack s = inv.getStack(i);
            if (!(s.getItem() instanceof RumorItem r)) continue;
            while (!s.isEmpty() && pagado < falta) { s.decrement(1); pagado += r.getValor(); }
        }
        if (pagado > falta) estado.setSaldo(p.getUuid(), pagado - falta); // el cambio va al Banco
        return true;
    }

    private static void comprar(ServerPlayerEntity p, TiendaCompraPayload paquete) {
        Entity e = p.getServerWorld().getEntityById(paquete.entidad());
        if (!(e instanceof GatoCuboEntity v) || !v.esVendedor() || p.squaredDistanceTo(v) > 64) return;
        List<Oferta> lista = ofertas(v.getTipo());
        if (paquete.indice() < 0 || paquete.indice() >= lista.size()) return;
        Oferta o = lista.get(paquete.indice());
        if (!cobrar(p, o.precio())) {
            p.sendMessage(Text.literal("No te alcanza. Te faltan " + (o.precio() - dineroTotal(p)) + " Rumores. El casino está por ahí...")
                    .formatted(Formatting.RED), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_HISS, SoundCategory.NEUTRAL, 0.8f, 1.0f);
        } else {
            ItemStack s = o.stack();
            if (!p.getInventory().insertStack(s)) p.dropItem(s, false);
            p.sendMessage(Text.literal("Compraste " + o.cantidad() + "x " + o.item().getName().getString() + " por " + o.precio() + " Rumores.")
                    .formatted(Formatting.GOLD), true);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_CAT_PURREOW, SoundCategory.NEUTRAL, 1f, 1.1f);
            p.getServerWorld().playSound(null, v.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.NEUTRAL, 0.6f, 0.7f);
        }
        enviar(p, v, false);
    }
}

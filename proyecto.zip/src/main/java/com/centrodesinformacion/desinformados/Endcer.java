package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Endcer (la enfermedad del End): al morir el dragón el End se vuelve radiactivo. Quien esté allí sin el efecto
 * "Anti-Endcer" (Pastilla anti-Endcer, 20 minutos) recibe daño que atraviesa la armadura. 5 minutos después de la tele
 * se abre la Libreta del Becario.
 */
public final class Endcer {
    public static final String CAMBIO = "end_radiactivo";
    private static final String GRACIA = "endcer_gracia";             // reloj: margen antes del primer daño
    private static final String LIBRETA = "libreta_tras_dragon";      // reloj: hasta que se abre la Libreta
    private static final float DANO_CADA_3S = 2f;                      // 1 corazón cada 3 segundos

    public static final RegistryEntry<StatusEffect> ANTI_ENDCER =
            Registry.registerReference(Registries.STATUS_EFFECT, Desinformados.id("anti_endcer"), new Proteccion());
    public static final RegistryKey<DamageType> DANO = RegistryKey.of(RegistryKeys.DAMAGE_TYPE, Desinformados.id("endcer"));

    /** El efecto de la pastilla: no hace nada por sí solo, el Endcer mira si lo tienes. */
    static class Proteccion extends StatusEffect {
        Proteccion() {
            super(StatusEffectCategory.BENEFICIAL, 0xB15CFF);
        }
    }

    private Endcer() {}

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (s.getTicks() % 20 == 0) tick(s);
        });
    }

    /** Lo llama la misión del dragón al superarse: tele amarilla, el End se vuelve radiactivo y empieza la cuenta de la Libreta. */
    public static void alMorirElDragon(MinecraftServer s) {
        Eventos.Evento ev = Eventos.TODOS.get(CAMBIO);
        EstadoServidor e = EstadoServidor.get(s);
        if (ev != null) {
            Eventos.mostrarTele(s, ev.color(), ev.titulo(), ev.descripcion(), ev.excusa());
            e.agregarCambio("evento:" + CAMBIO);
        }
        e.agregarCambio(CAMBIO);
        e.setReloj(GRACIA, Eventos.RETRASO_TELE + 20 * 15);           // da tiempo a leer la tele y tomarse la pastilla
        e.setReloj(LIBRETA, Eventos.RETRASO_TELE + 20 * 60 * 5);       // 5 minutos después de la tele
    }

    /** Abre la Libreta del Becario (lo mismo que /desinfo portal libreta abrir). */
    public static void abrirLibreta(MinecraftServer s) {
        Eventos.mostrarTele(s, "morado", "¡La Libreta del Becario está abierta!",
                "El becario se ha dejado la libreta abierta encima del escritorio. Dentro hay un mundo entero dibujado a lápiz... y lo que sea que dibujó cuando se aburría.");
        EstadoServidor e = EstadoServidor.get(s);
        e.agregarCambio(com.centrodesinformacion.desinformados.dimension.LibretaBlock.MARCA_ABIERTA);
        e.agregarCambio("receta_libreta");
        e.agregarCambio("receta_bloque_garatita");
        Crafteos.sincronizarTodos(s);
    }

    private static boolean hayJugando(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) if (!p.isSpectator()) return true;
        return false;
    }

    private static void tick(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        int lib = e.getReloj(LIBRETA);
        if (lib >= 0 && hayJugando(s)) {
            lib -= 20;
            if (lib <= 0) {
                e.quitarReloj(LIBRETA);
                abrirLibreta(s);
            } else {
                e.setReloj(LIBRETA, lib);
            }
        }
        if (!e.tieneCambio(CAMBIO)) return;
        int gracia = e.getReloj(GRACIA);
        if (gracia > 0) {
            gracia -= 20;
            if (gracia <= 0) e.quitarReloj(GRACIA);
            else e.setReloj(GRACIA, gracia);
            return;
        }
        ServerWorld end = s.getWorld(World.END);
        if (end == null) return;
        for (ServerPlayerEntity p : end.getPlayers()) {
            if (p.isSpectator() || p.isCreative()) continue;
            StatusEffectInstance pastilla = p.getStatusEffect(ANTI_ENDCER);
            if (pastilla != null) {
                int seg = pastilla.getDuration() / 20;
                if (seg <= 30 && seg % 5 == 0)
                    p.sendMessage(Text.literal("La Pastilla anti-Endcer se acaba en " + seg + " s").formatted(Formatting.LIGHT_PURPLE), true);
                continue;
            }
            p.sendMessage(Text.literal("☢ ¡ENDCER! Tómate una Pastilla anti-Endcer").formatted(Formatting.DARK_PURPLE, Formatting.BOLD), true);
            end.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 8, 0.3, 0.5, 0.3, 0.02);
            if (s.getTicks() % 60 == 0) p.damage(end.getDamageSources().create(DANO), DANO_CADA_3S);
        }
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class Comandos {
    private static final List<String> COLORES = List.of("verde", "rojo", "amarillo");

    private static final SuggestionProvider<ServerCommandSource> SUGERIR_MUERTOS = (c, b) ->
            CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMuertos().values(), b);

    public static void registrar(CommandDispatcher<ServerCommandSource> d) {
        // Comandos de administrador (operadores)
        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("evento")
                        .then(argument("color", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(COLORES, b))
                                .then(argument("titulo", StringArgumentType.string())
                                        .executes(c -> lanzarEvento(c, ""))
                                        .then(argument("descripcion", StringArgumentType.greedyString())
                                                .executes(c -> lanzarEvento(c, StringArgumentType.getString(c, "descripcion")))))))
                .then(literal("fase")
                        .executes(c -> {
                            int f = EstadoServidor.get(c.getSource().getServer()).getFase();
                            c.getSource().sendFeedback(() -> Text.literal("Fase actual: " + f), false);
                            return f;
                        })
                        .then(argument("numero", IntegerArgumentType.integer(1, Progresion.FASE_MAXIMA))
                                .executes(Comandos::cambiarFase)))
                .then(literal("spawn").then(literal("radio")
                        .then(argument("bloques", IntegerArgumentType.integer(0, 512))
                                .executes(c -> {
                                    int r = IntegerArgumentType.getInteger(c, "bloques");
                                    EstadoServidor.get(c.getSource().getServer()).setRadioSpawn(r);
                                    c.getSource().sendFeedback(() -> Text.literal("Radio del spawn protegido: " + r + " bloques"), true);
                                    return 1;
                                }))))
                .then(literal("muertos").executes(c -> {
                    var muertos = EstadoServidor.get(c.getSource().getServer()).getMuertos();
                    String lista = muertos.isEmpty() ? "nadie" : String.join(", ", muertos.values());
                    c.getSource().sendFeedback(() -> Text.literal("Desinformados (muertos): " + lista), false);
                    return muertos.size();
                }))
                .then(literal("revivir").then(argument("jugador", StringArgumentType.word())
                        .suggests(SUGERIR_MUERTOS)
                        .executes(c -> revivir(c, false))))
                .then(literal("vida").then(argument("objetivo", EntityArgumentType.player())
                        .then(literal("ver").executes(Comandos::verVida))
                        .then(literal("rojos").then(argument("cantidad", IntegerArgumentType.integer(-30, 30))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    int total = Vida.cambiarRojos(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones rojos extra = " + total), true);
                                    return 1;
                                })))
                        .then(literal("almas").then(argument("cantidad", IntegerArgumentType.integer(-10, 10))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    float total = Vida.cambiarAlmas(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones de alma = " + total), true);
                                    return 1;
                                }))))));

        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("lanzar").then(argument("evento", StringArgumentType.word())
                        .suggests((c, b) -> {
                            CommandSource.suggestMatching(Desafios.TODOS.keySet(), b);
                            return CommandSource.suggestMatching(Eventos.TODOS.keySet(), b);
                        })
                        .executes(c -> {
                            String id = StringArgumentType.getString(c, "evento");
                            if (Desafios.existe(id)) {
                                Desafios.lanzar(c.getSource().getServer(), id);
                                c.getSource().sendFeedback(() -> Text.literal("Desafío lanzado: " + id), true);
                                return 1;
                            }
                            Eventos.Evento ev = Eventos.TODOS.get(id);
                            if (ev == null) { c.getSource().sendError(Text.literal("No existe el evento " + id)); return 0; }
                            Eventos.lanzar(c.getSource().getServer(), ev);
                            c.getSource().sendFeedback(() -> Text.literal("Evento lanzado: " + id), true);
                            return 1;
                        })))
                .then(literal("detener").executes(c -> {
                    int n = Desafios.detenerTodos();
                    c.getSource().sendFeedback(() -> Text.literal("Desafíos detenidos: " + n), true);
                    return n;
                }))
                .then(literal("cambios")
                        .executes(c -> {
                            var cambios = EstadoServidor.get(c.getSource().getServer()).getCambios();
                            c.getSource().sendFeedback(() -> Text.literal("Cambios activos: " + (cambios.isEmpty() ? "ninguno" : String.join(", ", cambios))), false);
                            return cambios.size();
                        })
                        .then(literal("quitar").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getCambios(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarCambio(id);
                                    c.getSource().sendFeedback(() -> Text.literal(ok ? "Cambio quitado: " + id : "Ese cambio no estaba activo"), true);
                                    return ok ? 1 : 0;
                                }))))
                .then(literal("mobs")
                        .executes(c -> {
                            var e = EstadoServidor.get(c.getSource().getServer());
                            c.getSource().sendFeedback(() -> Text.literal("Bloqueados: " + String.join(", ", e.getMobsBloqueados())), false);
                            return 1;
                        })
                        .then(literal("bloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestIdentifiers(Registries.ENTITY_TYPE.getIds(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).bloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob bloqueado: " + id), true);
                                    return 1;
                                })))
                        .then(literal("desbloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMobsBloqueados(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).desbloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob desbloqueado: " + id), true);
                                    return 1;
                                })))));

        // Comando para los jugadores: cuesta un periódico
        d.register(literal("revivir").then(argument("jugador", StringArgumentType.word())
                .suggests(SUGERIR_MUERTOS)
                .executes(c -> revivir(c, true))));
    }

    private static int lanzarEvento(CommandContext<ServerCommandSource> c, String descripcion) {
        String color = StringArgumentType.getString(c, "color").toLowerCase(Locale.ROOT);
        if (!COLORES.contains(color)) {
            c.getSource().sendError(Text.literal("Color inválido. Usa: verde, rojo o amarillo"));
            return 0;
        }
        String titulo = StringArgumentType.getString(c, "titulo");
        Eventos.mostrarTele(c.getSource().getServer(), color, titulo, descripcion);
        c.getSource().sendFeedback(() -> Text.literal("Evento " + color + " lanzado: " + titulo), true);
        return 1;
    }

    private static int cambiarFase(CommandContext<ServerCommandSource> c) {
        int n = IntegerArgumentType.getInteger(c, "numero");
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor.get(server).setFase(n);
        server.getPlayerManager().broadcast(Text.literal("¡FASE " + n + "! Minerales desbloqueados: " + Progresion.descripcion(n))
                .formatted(Formatting.GOLD, Formatting.BOLD), false);
        return n;
    }

    private static int revivir(CommandContext<ServerCommandSource> c, boolean cuestaPeriodico) throws CommandSyntaxException {
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor estado = EstadoServidor.get(server);
        UUID uuid = estado.buscarMuerto(StringArgumentType.getString(c, "jugador"));
        if (uuid == null) {
            c.getSource().sendError(Text.literal("Ese jugador no está muerto."));
            return 0;
        }
        String quien = "El Centro de Desinformación";
        if (cuestaPeriodico) {
            ServerPlayerEntity jugador = c.getSource().getPlayerOrThrow();
            if (!gastarPeriodico(jugador)) {
                c.getSource().sendError(Text.literal("Necesitas un Periódico Desinformado para revivir a alguien."));
                return 0;
            }
            quien = jugador.getGameProfile().getName();
        }
        String nombre = estado.quitarMuerto(uuid);
        server.getPlayerManager().broadcast(Text.literal(quien + " ha revivido a " + nombre + ". ¡Ya puede volver al server!")
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
        return 1;
    }

    private static int verVida(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
        EstadoServidor estado = EstadoServidor.get(c.getSource().getServer());
        int rojos = estado.getRojos(p.getUuid());
        float almas = estado.getAlmas(p.getUuid()) / 2f;
        c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": " + (10 + rojos)
                + " corazones rojos, " + almas + " de alma"), false);
        return 1;
    }

    private static boolean gastarPeriodico(ServerPlayerEntity jugador) {
        PlayerInventory inv = jugador.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(ModItems.PERIODICO)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }
}

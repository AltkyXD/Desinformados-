package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class Comandos {
    private static final List<String> COLORES = List.of("verde", "rojo", "amarillo");

    private static final SuggestionProvider<ServerCommandSource> SUGERIR_MUERTOS = (c, b) ->
            CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMuertos().values(), b);

    public static void registrar(CommandDispatcher<ServerCommandSource> d) {
        // Comandos de administrador (operadores)
        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("evento")
                        .then(argument("color", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(COLORES, b))
                                .then(argument("titulo", StringArgumentType.string())
                                        .executes(c -> lanzarEvento(c, ""))
                                        .then(argument("descripcion", StringArgumentType.greedyString())
                                                .executes(c -> lanzarEvento(c, StringArgumentType.getString(c, "descripcion")))))))
                .then(literal("fase")
                        .executes(c -> {
                            int f = EstadoServidor.get(c.getSource().getServer()).getFase();
                            c.getSource().sendFeedback(() -> Text.literal("Fase actual: " + f), false);
                            return f;
                        })
                        .then(argument("numero", IntegerArgumentType.integer(1, Progresion.FASE_MAXIMA))
                                .executes(Comandos::cambiarFase)))
                .then(literal("spawn").then(literal("radio")
                        .then(argument("bloques", IntegerArgumentType.integer(0, 512))
                                .executes(c -> {
                                    int r = IntegerArgumentType.getInteger(c, "bloques");
                                    EstadoServidor.get(c.getSource().getServer()).setRadioSpawn(r);
                                    c.getSource().sendFeedback(() -> Text.literal("Radio del spawn protegido: " + r + " bloques"), true);
                                    return 1;
                                }))))
                .then(literal("muertos").executes(c -> {
                    var muertos = EstadoServidor.get(c.getSource().getServer()).getMuertos();
                    String lista = muertos.isEmpty() ? "nadie" : String.join(", ", muertos.values());
                    c.getSource().sendFeedback(() -> Text.literal("Desinformados (muertos): " + lista), false);
                    return muertos.size();
                }))
                .then(literal("revivir").then(argument("jugador", StringArgumentType.word())
                        .suggests(SUGERIR_MUERTOS)
                        .executes(c -> revivir(c, false))))
                .then(literal("vidas").then(argument("objetivo", EntityArgumentType.player())
                        .then(argument("cantidad", IntegerArgumentType.integer(1, 10)).executes(c -> {
                            ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                            int n = IntegerArgumentType.getInteger(c, "cantidad");
                            EstadoServidor.get(c.getSource().getServer()).setVidas(p.getUuid(), n);
                            c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + " ahora tiene " + n + " vidas"), true);
                            return n;
                        }))))
                .then(literal("vida").then(argument("objetivo", EntityArgumentType.player())
                        .then(literal("ver").executes(Comandos::verVida))
                        .then(literal("rojos").then(argument("cantidad", IntegerArgumentType.integer(-30, 30))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    int total = Vida.cambiarRojos(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones rojos extra = " + total), true);
                                    return 1;
                                })))
                        .then(literal("almas").then(argument("cantidad", IntegerArgumentType.integer(-3, 3))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    float total = Vida.cambiarAlmas(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones de alma = " + total), true);
                                    return 1;
                                }))))));

        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("lanzar").then(argument("evento", StringArgumentType.word())
                        .suggests((c, b) -> {
                            CommandSource.suggestMatching(Desafios.TODOS.keySet(), b);
                            return CommandSource.suggestMatching(Eventos.TODOS.keySet(), b);
                        })
                        .executes(c -> {
                            String id = StringArgumentType.getString(c, "evento");
                            if (Desafios.existe(id)) {
                                Desafios.lanzar(c.getSource().getServer(), id);
                                c.getSource().sendFeedback(() -> Text.literal("Desafío lanzado: " + id), true);
                                return 1;
                            }
                            Eventos.Evento ev = Eventos.TODOS.get(id);
                            if (ev == null) { c.getSource().sendError(Text.literal("No existe el evento " + id)); return 0; }
                            Eventos.lanzar(c.getSource().getServer(), ev);
                            c.getSource().sendFeedback(() -> Text.literal("Evento lanzado: " + id), true);
                            return 1;
                        })))
                .then(literal("mision")
                        .then(literal("diaria").then(argument("id", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(Misiones.ids(), b))
                                .executes(c -> activarMision(c, "diaria"))))
                        .then(literal("secundaria").then(argument("id", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(Misiones.ids(), b))
                                .executes(c -> activarMision(c, "secundaria"))))
                        .then(literal("quitar").then(argument("id", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMisionesActivas().keySet(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarMision(id);
                                    Misiones.sincronizar(c.getSource().getServer());
                                    c.getSource().sendFeedback(() -> Text.literal(ok ? "Misión quitada: " + id : "Esa misión no estaba activa"), true);
                                    return ok ? 1 : 0;
                                })))
                        .then(literal("limpiar").executes(c -> {
                            EstadoServidor.get(c.getSource().getServer()).limpiarMisiones();
                            Misiones.sincronizar(c.getSource().getServer());
                            c.getSource().sendFeedback(() -> Text.literal("Todas las misiones quitadas (nuevo día)"), true);
                            return 1;
                        })))
                .then(literal("activar")
                        .then(literal("mobs").executes(c -> activarGrupo(c, Eventos.GRUPO_MOBS, "mobs nuevos")))
                        .then(literal("mutaciones").executes(c -> activarGrupo(c, Eventos.GRUPO_MUTACIONES, "mutaciones de mobs")))
                        .then(literal("mundo").executes(c -> activarGrupo(c, Eventos.GRUPO_MUNDO, "cambios del mundo"))))
                .then(literal("desactivar").then(literal("todo").executes(c -> {
                    Eventos.desactivarTodo(c.getSource().getServer());
                    c.getSource().sendFeedback(() -> Text.literal("Todos los cambios de dificultad desactivados y mobs del mod bloqueados").formatted(Formatting.YELLOW), true);
                    return 1;
                })))
                .then(literal("portal").then(literal("tele")
                        .then(literal("romper").executes(c -> {
                            int n = com.centrodesinformacion.desinformados.dimension.Dimensiones.romperTeles(c.getSource().getServer(), true);
                            c.getSource().sendFeedback(() -> Text.literal(n == 0 ? "No hay ninguna tele portal colocada" : "Teles rotas: " + n), true);
                            return n;
                        }))
                        .then(literal("reparar").executes(c -> {
                            int n = com.centrodesinformacion.desinformados.dimension.Dimensiones.romperTeles(c.getSource().getServer(), false);
                            c.getSource().sendFeedback(() -> Text.literal("Teles reparadas: " + n), true);
                            return n;
                        }))))
                .then(literal("arena").then(literal("reconstruir").executes(c -> {
                    var tele = c.getSource().getServer().getWorld(com.centrodesinformacion.desinformados.dimension.Dimensiones.TELE);
                    if (tele != null) com.centrodesinformacion.desinformados.dimension.Dimensiones.construirTele(tele, true);
                    c.getSource().sendFeedback(() -> Text.literal("Cuartito, túnel y arena de la Tele reconstruidos"), true);
                    return 1;
                })))
                .then(literal("ir")
                        .then(literal("tele").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.entrarTele(c.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("libreta").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.entrarLibreta(c.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("volver").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.volver(c.getSource().getPlayerOrThrow()); return 1; })))
                .then(literal("detener").executes(c -> {
                    int n = Desafios.detenerTodos();
                    c.getSource().sendFeedback(() -> Text.literal("Desafíos detenidos: " + n), true);
                    return n;
                }))
                .then(literal("cambios")
                        .executes(c -> {
                            var cambios = EstadoServidor.get(c.getSource().getServer()).getCambios();
                            c.getSource().sendFeedback(() -> Text.literal("Cambios activos: " + (cambios.isEmpty() ? "ninguno" : String.join(", ", cambios))), false);
                            return cambios.size();
                        })
                        .then(literal("quitar").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getCambios(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarCambio(id);
                                    Modificaciones.aplicarATodos(c.getSource().getServer());
                                    if (id.equals("agua_escasa")) c.getSource().getServer().getGameRules()
                                            .get(net.minecraft.world.GameRules.WATER_SOURCE_CONVERSION).set(true, c.getSource().getServer());
                                    c.getSource().sendFeedback(() -> Text.literal(ok ? "Cambio quitado: " + id : "Ese cambio no estaba activo"), true);
                                    return ok ? 1 : 0;
                                }))))
                .then(literal("mobs")
                        .executes(c -> {
                            var e = EstadoServidor.get(c.getSource().getServer());
                            c.getSource().sendFeedback(() -> Text.literal("Bloqueados: " + String.join(", ", e.getMobsBloqueados())), false);
                            return 1;
                        })
                        .then(literal("bloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestIdentifiers(Registries.ENTITY_TYPE.getIds(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).bloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob bloqueado: " + id), true);
                                    return 1;
                                })))
                        .then(literal("desbloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMobsBloqueados(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).desbloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob desbloqueado: " + id), true);
                                    return 1;
                                })))));

        // Comando para los jugadores: cuesta un periódico
        d.register(literal("revivir").then(argument("jugador", StringArgumentType.word())
                .suggests(SUGERIR_MUERTOS)
                .executes(c -> revivir(c, true))));
    }

    private static int lanzarEvento(CommandContext<ServerCommandSource> c, String descripcion) {
        String color = StringArgumentType.getString(c, "color").toLowerCase(Locale.ROOT);
        if (!COLORES.contains(color)) {
            c.getSource().sendError(Text.literal("Color inválido. Usa: verde, rojo o amarillo"));
            return 0;
        }
        String titulo = StringArgumentType.getString(c, "titulo");
        Eventos.mostrarTele(c.getSource().getServer(), color, titulo, descripcion);
        c.getSource().sendFeedback(() -> Text.literal("Evento " + color + " lanzado: " + titulo), true);
        return 1;
    }

    private static int cambiarFase(CommandContext<ServerCommandSource> c) {
        int n = IntegerArgumentType.getInteger(c, "numero");
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor.get(server).setFase(n);
        server.getPlayerManager().broadcast(Text.literal("¡FASE " + n + "! Minerales desbloqueados: " + Progresion.descripcion(n))
                .formatted(Formatting.GOLD, Formatting.BOLD), false);
        return n;
    }

    private static int revivir(CommandContext<ServerCommandSource> c, boolean cuestaPeriodico) throws CommandSyntaxException {
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor estado = EstadoServidor.get(server);
        UUID uuid = estado.buscarMuerto(StringArgumentType.getString(c, "jugador"));
        if (uuid == null) {
            c.getSource().sendError(Text.literal("Ese jugador no está muerto."));
            return 0;
        }
        String quien = "El Centro de Desinformación";
        if (cuestaPeriodico) {
            ServerPlayerEntity jugador = c.getSource().getPlayerOrThrow();
            if (!gastarPeriodico(jugador)) {
                c.getSource().sendError(Text.literal("Necesitas un Periódico Desinformado para revivir a alguien."));
                return 0;
            }
            quien = jugador.getGameProfile().getName();
        }
        String nombre = estado.quitarMuerto(uuid);
        estado.setVidas(uuid, 1);
        ServerPlayerEntity enLinea = server.getPlayerManager().getPlayer(uuid);
        if (enLinea != null) Reglas.restaurar(enLinea); // aún no lo habían expulsado
        server.getPlayerManager().broadcast(Text.literal(quien + " ha revivido a " + nombre + ". ¡Ya puede volver al server!")
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
        return 1;
    }

    private static int verVida(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
        EstadoServidor estado = EstadoServidor.get(c.getSource().getServer());
        int rojos = estado.getRojos(p.getUuid());
        float almas = estado.getAlmas(p.getUuid()) / 2f;
        int vidas = estado.getVidas(p.getUuid());
        c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": " + vidas + " vidas, " + (10 + rojos)
                + " corazones rojos, " + almas + " de alma"), false);
        return 1;
    }

    private static int activarMision(CommandContext<ServerCommandSource> c, String tipo) {
        String id = StringArgumentType.getString(c, "id");
        Misiones.Mision m = Misiones.TODAS.get(id);
        if (m == null) { c.getSource().sendError(Text.literal("No existe la misión " + id)); return 0; }
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor.get(server).activarMision(id, tipo);
        Misiones.sincronizar(server);
        boolean diaria = tipo.equals("diaria");
        server.getPlayerManager().broadcast(Text.literal(diaria ? "[NUEVA MISIÓN DIARIA] " : "[NUEVA MISIÓN SECUNDARIA] ")
                .formatted(diaria ? Formatting.GOLD : Formatting.AQUA, Formatting.BOLD)
                .append(Text.literal(m.titulo() + ": ").formatted(Formatting.WHITE))
                .append(Text.literal(m.descripcion() + " (Pulsa L para ver tus misiones)").formatted(Formatting.GRAY)), false);
        return 1;
    }

    private static int activarGrupo(CommandContext<ServerCommandSource> c, java.util.List<String> ids, String nombre) {
        int n = Eventos.activarGrupo(c.getSource().getServer(), ids);
        c.getSource().sendFeedback(() -> Text.literal("Activados " + n + " " + nombre + " (sin teles)").formatted(Formatting.YELLOW), true);
        return n;
    }

    private static boolean gastarPeriodico(ServerPlayerEntity jugador) {
        PlayerInventory inv = jugador.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(ModItems.PERIODICO)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }
}

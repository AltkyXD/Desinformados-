package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.desafio.Desafios;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class Comandos {
    private static final List<String> COLORES = List.of("verde", "rojo", "amarillo", "morado", "azul", "naranja");

    private static final SuggestionProvider<ServerCommandSource> SUGERIR_MUERTOS = (c, b) ->
            CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMuertos().values(), b);

    public static void registrar(CommandDispatcher<ServerCommandSource> d) {
        // Comandos de administrador (operadores)
        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("evento")
                        .then(argument("color", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(COLORES, b))
                                .then(argument("titulo", StringArgumentType.string())
                                        .executes(c -> lanzarEvento(c, ""))
                                        .then(argument("descripcion", StringArgumentType.greedyString())
                                                .executes(c -> lanzarEvento(c, StringArgumentType.getString(c, "descripcion")))))))
                .then(literal("spawn").then(literal("radio")
                        .then(argument("bloques", IntegerArgumentType.integer(0, 512))
                                .executes(c -> {
                                    int r = IntegerArgumentType.getInteger(c, "bloques");
                                    EstadoServidor.get(c.getSource().getServer()).setRadioSpawn(r);
                                    c.getSource().sendFeedback(() -> Text.literal("Radio del spawn protegido: " + r + " bloques"), true);
                                    return 1;
                                })))
                        // Centro de la zona protegida: donde estás parado
                        .then(literal("centro").executes(c -> {
                                    var p = c.getSource().getPlayerOrThrow();
                                    EstadoServidor.get(c.getSource().getServer()).setCentroProtegido(p.getBlockPos().asLong());
                                    int r = EstadoServidor.get(c.getSource().getServer()).getRadioSpawn();
                                    c.getSource().sendFeedback(() -> Text.literal("Zona protegida centrada aquí (" + p.getBlockX() + ", " + p.getBlockZ()
                                            + "), radio " + r + " bloques"), true);
                                    return 1;
                                })
                                .then(literal("mundo").executes(c -> {
                                    EstadoServidor.get(c.getSource().getServer()).setCentroProtegido(null);
                                    c.getSource().sendFeedback(() -> Text.literal("Zona protegida centrada otra vez en el spawn del mundo"), true);
                                    return 1;
                                })))
                        // Dónde aparecen los jugadores: al llegar tras la cinemática, al morir (sin cama) y al revivir
                        .then(literal("aparecer").executes(c -> {
                            var p = c.getSource().getPlayerOrThrow();
                            var server = c.getSource().getServer();
                            server.getOverworld().setSpawnPos(p.getBlockPos(), p.getYaw());
                            server.getGameRules().get(net.minecraft.world.GameRules.SPAWN_RADIUS).set(0, server);
                            com.centrodesinformacion.desinformados.intro.Intro.fijarCentro(p);
                            c.getSource().sendFeedback(() -> Text.literal("Los jugadores aparecerán aquí (" + p.getBlockX() + ", " + p.getBlockY() + ", "
                                    + p.getBlockZ() + "), mirando hacia donde miras"), true);
                            return 1;
                        }))
                        .then(literal("info").executes(c -> {
                            var server = c.getSource().getServer();
                            EstadoServidor e = EstadoServidor.get(server);
                            var sp = server.getOverworld().getSpawnPos();
                            String centro = e.getCentroProtegido() == null ? "el spawn del mundo"
                                    : net.minecraft.util.math.BlockPos.fromLong(e.getCentroProtegido()).toShortString();
                            c.getSource().sendFeedback(() -> Text.literal("Aparecen en: " + sp.toShortString() + "\nZona protegida: centro en "
                                    + centro + ", radio " + e.getRadioSpawn() + " bloques"), false);
                            return 1;
                        })))
                .then(literal("muertos").executes(c -> {
                    var muertos = EstadoServidor.get(c.getSource().getServer()).getMuertos();
                    String lista = muertos.isEmpty() ? "nadie" : String.join(", ", muertos.values());
                    c.getSource().sendFeedback(() -> Text.literal("Desinformados (muertos): " + lista), false);
                    return muertos.size();
                }))
                .then(literal("revivir").then(argument("jugador", StringArgumentType.word())
                        .suggests(SUGERIR_MUERTOS)
                        .executes(c -> revivir(c, false))))
                .then(literal("vidas").then(argument("objetivo", EntityArgumentType.player())
                        .then(argument("cantidad", IntegerArgumentType.integer(1, 10)).executes(c -> {
                            ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                            int n = IntegerArgumentType.getInteger(c, "cantidad");
                            EstadoServidor.get(c.getSource().getServer()).setVidas(p.getUuid(), n);
                            c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + " ahora tiene " + n + " vidas"), true);
                            return n;
                        }))))
                .then(literal("vida").then(argument("objetivo", EntityArgumentType.player())
                        .then(literal("ver").executes(Comandos::verVida))
                        .then(literal("rojos").then(argument("cantidad", IntegerArgumentType.integer(-30, 30))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    int total = Vida.cambiarRojos(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones rojos extra = " + total), true);
                                    return 1;
                                })))
                        .then(literal("almas").then(argument("cantidad", IntegerArgumentType.integer(-3, 3))
                                .executes(c -> {
                                    ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
                                    float total = Vida.cambiarAlmas(p, IntegerArgumentType.getInteger(c, "cantidad"));
                                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": corazones de alma = " + total), true);
                                    return 1;
                                }))))));

        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("lanzar").then(argument("evento", StringArgumentType.word())
                        .suggests((c, b) -> {
                            CommandSource.suggestMatching(Desafios.TODOS.keySet(), b);
                            return CommandSource.suggestMatching(Eventos.TODOS.keySet(), b);
                        })
                        .executes(c -> {
                            String id = StringArgumentType.getString(c, "evento");
                            if (Desafios.existe(id)) {
                                Desafios.lanzar(c.getSource().getServer(), id);
                                c.getSource().sendFeedback(() -> Text.literal("Desafío lanzado: " + id), true);
                                return 1;
                            }
                            Eventos.Evento ev = Eventos.TODOS.get(id);
                            if (ev == null) { c.getSource().sendError(Text.literal("No existe el evento " + id)); return 0; }
                            if (!Eventos.puedeLanzarse(c.getSource().getServer(), id)) {
                                c.getSource().sendError(Text.literal("Ese cambio es de la Libreta: primero abre las libretas con /desinfo portal libreta abrir"));
                                return 0;
                            }
                            Eventos.lanzar(c.getSource().getServer(), ev);
                            c.getSource().sendFeedback(() -> Text.literal("Evento lanzado: " + id), true);
                            return 1;
                        })))
                .then(literal("activar")
                        .then(literal("mobs").executes(c -> activarGrupo(c, Eventos.GRUPO_MOBS, "mobs nuevos")))
                        .then(literal("mutaciones").executes(c -> activarGrupo(c, Eventos.GRUPO_MUTACIONES, "mutaciones de mobs")))
                        .then(literal("mundo").executes(c -> activarGrupo(c, Eventos.GRUPO_MUNDO, "cambios del mundo"))))
                .then(literal("desactivar").then(literal("todo").executes(c -> {
                    Eventos.desactivarTodo(c.getSource().getServer());
                    c.getSource().sendFeedback(() -> Text.literal("Todos los cambios de dificultad desactivados y mobs del mod bloqueados "
                            + "(se mantienen las aperturas, recetas y teles ya salidas; los mobs del Nether siguen allí si ya salió su tele)").formatted(Formatting.YELLOW), true);
                    return 1;
                })))
                .then(literal("portal").then(literal("tele")
                        .then(literal("romper").executes(c -> {
                            int n = com.centrodesinformacion.desinformados.dimension.Dimensiones.romperTeles(c.getSource().getServer(), true);
                            c.getSource().sendFeedback(() -> Text.literal(n == 0 ? "No hay ninguna tele portal colocada" : "Teles rotas: " + n), true);
                            return n;
                        }))
                        .then(literal("reparar").executes(c -> {
                            int n = com.centrodesinformacion.desinformados.dimension.Dimensiones.romperTeles(c.getSource().getServer(), false);
                            c.getSource().sendFeedback(() -> Text.literal("Teles reparadas: " + n), true);
                            return n;
                        })))
                        .then(literal("libreta")
                                .then(literal("abrir").executes(c -> {
                                    var srv = c.getSource().getServer();
                                    Eventos.mostrarTele(srv, "morado", "¡La Libreta del Becario está abierta!",
                                            "El becario se ha dejado la libreta abierta encima del escritorio. Dentro hay un mundo entero dibujado a lápiz... y lo que sea que dibujó cuando se aburría.");
                                    Tareas.programar(Eventos.RETRASO_TELE, () -> {
                                        EstadoServidor.get(srv).agregarCambio(com.centrodesinformacion.desinformados.dimension.LibretaBlock.MARCA_ABIERTA);
                                        EstadoServidor.get(srv).agregarCambio("receta_libreta"); // al abrirse la dimensión se puede craftear la libreta
                                        Crafteos.sincronizarTodos(srv);
                                    });
                                    c.getSource().sendFeedback(() -> Text.literal("Las libretas se abrirán cuando termine la tele morada"), true);
                                    return 1;
                                }))
                                .then(literal("cerrar").executes(c -> {
                                    EstadoServidor.get(c.getSource().getServer()).quitarCambio(com.centrodesinformacion.desinformados.dimension.LibretaBlock.MARCA_ABIERTA);
                                    c.getSource().sendFeedback(() -> Text.literal("Las libretas se cierran"), true);
                                    return 1;
                                }))))
                .then(literal("tienda").then(argument("tipo", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(List.of("pasivas", "corazones", "minerales"), b))
                        .executes(c -> {
                            String t = StringArgumentType.getString(c, "tipo");
                            int tipo = List.of("pasivas", "corazones", "minerales").indexOf(t);
                            if (tipo < 0) { c.getSource().sendError(Text.literal("Usa: pasivas, corazones o minerales")); return 0; }
                            var p = c.getSource().getPlayerOrThrow();
                            com.centrodesinformacion.desinformados.tienda.Tienda.construirPuesto(p.getServerWorld(), p,
                                    com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.VEND_PASIVAS + tipo);
                            c.getSource().sendFeedback(() -> Text.literal("Puesto de " + t + " construido"), true);
                            return 1;
                        })))
                .then(literal("vendedor").then(argument("tipo", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(List.of("pasivas", "corazones", "minerales"), b))
                        .executes(c -> {
                            String t = StringArgumentType.getString(c, "tipo");
                            int tipo = List.of("pasivas", "corazones", "minerales").indexOf(t);
                            if (tipo < 0) { c.getSource().sendError(Text.literal("Usa: pasivas, corazones o minerales")); return 0; }
                            var p = c.getSource().getPlayerOrThrow();
                            var g = com.centrodesinformacion.desinformados.entidad.ModEntidades.GATO_CUBO.create(p.getServerWorld());
                            if (g == null) return 0;
                            float yaw = p.getHorizontalFacing().asRotation();
                            g.refreshPositionAndAngles(p.getBlockPos().getX() + 0.5, p.getY(), p.getBlockPos().getZ() + 0.5, yaw, 0f);
                            g.setHeadYaw(yaw); g.setBodyYaw(yaw);
                            g.configurar(com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.VEND_PASIVAS + tipo, p.getBlockPos());
                            p.getServerWorld().spawnEntity(g);
                            c.getSource().sendFeedback(() -> Text.literal("Vendedor de " + t + " colocado aquí (mirando hacia donde miras)"), true);
                            return 1;
                        })))
                .then(literal("npc").then(argument("tipo", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(List.of("principal", "recepcionista", "periodista", "conserje",
                                "anime", "nerd", "robot", "granjero", "gato", "romantico", "millonario", "elegante", "chef", "detective", "dj", "cientifica", "fujoshi", "madre", "gatito", "fiestera", "perro", "plano", "katem"), b))
                        .executes(c -> {
                            String t = StringArgumentType.getString(c, "tipo");
                            int tipo = java.util.Arrays.asList(com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.IDS).indexOf(t);
                            if (tipo <= 0 || (tipo >= 4 && tipo <= 6)) {
                                c.getSource().sendError(Text.literal(t.equals("becario") ? "El becario está ocupadísimo en su despacho. Ya lo verás. O no."
                                        : "Tipo desconocido (los vendedores van con /desinfo vendedor)"));
                                return 0;
                            }
                            var p = c.getSource().getPlayerOrThrow();
                            var g = com.centrodesinformacion.desinformados.entidad.ModEntidades.GATO_CUBO.create(p.getServerWorld());
                            if (g == null) return 0;
                            g.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw(), 0f);
                            g.configurar(tipo, p.getBlockPos());
                            p.getServerWorld().spawnEntity(g);
                            c.getSource().sendFeedback(() -> Text.literal("Gato " + t + " colocado (camina alrededor de este punto)"), true);
                            return 1;
                        })))
                .then(literal("jefe")
                        .then(literal("invocar").executes(c -> {
                            var p = c.getSource().getPlayerOrThrow();
                            var j = com.centrodesinformacion.desinformados.entidad.ModEntidades.JEFE_TELE.create(p.getServerWorld());
                            if (j == null) return 0;
                            var delante = p.getPos().add(net.minecraft.util.math.Vec3d.fromPolar(0, p.getYaw()).multiply(8));
                            j.refreshPositionAndAngles(delante.x, p.getY(), delante.z, p.getYaw() + 180f, 0f);
                            p.getServerWorld().spawnEntity(j);
                            c.getSource().sendFeedback(() -> Text.literal("La Desinformación (jefe final) aparece delante de ti. Golpéala 3 veces para despertarla."), true);
                            return 1;
                        }))
                        .then(literal("quitar").executes(c -> {
                            int n = 0;
                            for (var w : c.getSource().getServer().getWorlds()) {
                                for (var e : w.getEntitiesByType(com.centrodesinformacion.desinformados.entidad.ModEntidades.JEFE_TELE, x -> true)) { e.discard(); n++; }
                                java.util.List<net.minecraft.entity.Entity> esbirros = new java.util.ArrayList<>();
                                for (var e : w.iterateEntities())
                                    if (e.getCommandTags().contains(com.centrodesinformacion.desinformados.entidad.JefeTeleEntity.MARCA_ESBIRRO)) esbirros.add(e);
                                esbirros.forEach(net.minecraft.entity.Entity::discard);
                            }
                            int quitados = n;
                            c.getSource().sendFeedback(() -> Text.literal("Quitadas " + quitados + " teles (y sus mobs)."), true);
                            return 1;
                        })))
                .then(literal("obra").then(literal("quitar")
                        .executes(c -> quitarObra(c, "todo"))
                        .then(literal("todo").executes(c -> quitarObra(c, "todo")))
                        .then(literal("valla").executes(c -> quitarObra(c, "valla")))
                        .then(literal("andamio").executes(c -> quitarObra(c, "andamio")))))
                .then(literal("generar").then(literal("centro")
                        .executes(c -> generarCentro(c, false))
                        .then(literal("forzar").executes(c -> generarCentro(c, true))))
                        .then(literal("ventanas").executes(c -> {
                            EstadoServidor e = EstadoServidor.get(c.getSource().getServer());
                            if (e.getCentroProtegido() == null) {
                                c.getSource().sendError(Text.literal("No hay Centro todavía."));
                                return 0;
                            }
                            int n = ConstructorCentro.arreglarVentanas(c.getSource().getServer().getOverworld(), BlockPos.fromLong(e.getCentroProtegido()));
                            c.getSource().sendFeedback(() -> Text.literal("Ventanas del Centro: " + n + " paneles cambiados por bloques de cristal."), true);
                            return 1;
                        })))
                .then(literal("construir").then(literal("centro").executes(c -> {
                    var p = c.getSource().getPlayerOrThrow();
                    BlockPos[] r = ConstructorCentro.construir(p);
                    var server = c.getSource().getServer();
                    EstadoServidor e = EstadoServidor.get(server);
                    // El Centro queda protegido y los jugadores aparecen en su vestíbulo
                    e.setCentroProtegido(r[0].asLong());
                    if (e.getRadioSpawn() < GeneradorCentro.RADIO_PROTEGIDO) e.setRadioSpawn(GeneradorCentro.RADIO_PROTEGIDO);
                    float yaw = p.getHorizontalFacing().asRotation();
                    server.getOverworld().setSpawnPos(r[1], yaw);
                    server.getGameRules().get(net.minecraft.world.GameRules.SPAWN_RADIUS).set(0, server);
                    com.centrodesinformacion.desinformados.intro.Intro.fijarCentro(r[1], yaw, server);
                    c.getSource().sendFeedback(() -> Text.literal("Centro de Desinformación construido delante de ti (circular, 41 de diámetro, tres pisos y techo accesible). "
                            + "Queda protegido y los jugadores aparecerán en el vestíbulo."), true);
                    return 1;
                })))
                .then(literal("intro")
                        .then(literal("centro").executes(c -> {
                            var p = c.getSource().getPlayerOrThrow();
                            com.centrodesinformacion.desinformados.intro.Intro.fijarCentro(p);
                            c.getSource().sendFeedback(() -> Text.literal("Al terminar la cinemática aparecerán aquí, mirando hacia donde miras"), true);
                            return 1;
                        }))
                        .then(literal("ver").executes(c -> {
                            com.centrodesinformacion.desinformados.intro.Intro.reiniciar(c.getSource().getPlayerOrThrow());
                            return 1;
                        }))
                        .then(literal("reiniciar").then(argument("jugador", EntityArgumentType.player()).executes(c -> {
                            var p = EntityArgumentType.getPlayer(c, "jugador");
                            com.centrodesinformacion.desinformados.intro.Intro.reiniciar(p);
                            c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + " vuelve al cuarto de la tele"), true);
                            return 1;
                        })))
                        .then(literal("activar").executes(c -> {
                            com.centrodesinformacion.desinformados.intro.Intro.activar(c.getSource().getServer(), true);
                            c.getSource().sendFeedback(() -> Text.literal("Bienvenida activada: los que no la hayan visto irán al cuarto de la tele"), true);
                            return 1;
                        }))
                        .then(literal("desactivar").executes(c -> {
                            com.centrodesinformacion.desinformados.intro.Intro.activar(c.getSource().getServer(), false);
                            c.getSource().sendFeedback(() -> Text.literal("Bienvenida desactivada"), true);
                            return 1;
                        })))
                .then(literal("arena").then(literal("reconstruir").executes(c -> {
                    var tele = c.getSource().getServer().getWorld(com.centrodesinformacion.desinformados.dimension.Dimensiones.TELE);
                    if (tele != null) com.centrodesinformacion.desinformados.dimension.Dimensiones.construirTele(tele, true);
                    c.getSource().sendFeedback(() -> Text.literal("Cuartito, túnel y arena de la Tele reconstruidos"), true);
                    return 1;
                })))
                .then(literal("ir")
                        .then(literal("tele").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.entrarTele(c.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("libreta").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.entrarLibreta(c.getSource().getPlayerOrThrow()); return 1; }))
                        .then(literal("volver").executes(c -> { com.centrodesinformacion.desinformados.dimension.Dimensiones.volver(c.getSource().getPlayerOrThrow()); return 1; })))
                .then(literal("detener").executes(c -> {
                    int n = Desafios.detenerTodos();
                    c.getSource().sendFeedback(() -> Text.literal("Desafíos detenidos: " + n), true);
                    return n;
                }))
                .then(literal("cambios")
                        .executes(c -> {
                            var cambios = EstadoServidor.get(c.getSource().getServer()).getCambios();
                            c.getSource().sendFeedback(() -> Text.literal("Cambios activos: " + (cambios.isEmpty() ? "ninguno" : String.join(", ", cambios))), false);
                            return cambios.size();
                        })
                        .then(literal("quitar").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getCambios(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarCambio(id);
                                    Modificaciones.aplicarATodos(c.getSource().getServer());
                                    if (id.equals("agua_escasa")) c.getSource().getServer().getGameRules()
                                            .get(net.minecraft.world.GameRules.WATER_SOURCE_CONVERSION).set(true, c.getSource().getServer());
                                    c.getSource().sendFeedback(() -> Text.literal(ok ? "Cambio quitado: " + id : "Ese cambio no estaba activo"), true);
                                    return ok ? 1 : 0;
                                }))))
                .then(literal("mobs")
                        .executes(c -> {
                            var e = EstadoServidor.get(c.getSource().getServer());
                            c.getSource().sendFeedback(() -> Text.literal("Bloqueados: " + String.join(", ", e.getMobsBloqueados())), false);
                            return 1;
                        })
                        .then(literal("bloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestIdentifiers(Registries.ENTITY_TYPE.getIds(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).bloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob bloqueado: " + id), true);
                                    return 1;
                                })))
                        .then(literal("desbloquear").then(argument("id", StringArgumentType.greedyString())
                                .suggests((c, b) -> CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMobsBloqueados(), b))
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id").trim();
                                    EstadoServidor.get(c.getSource().getServer()).desbloquearMob(id);
                                    c.getSource().sendFeedback(() -> Text.literal("Mob desbloqueado: " + id), true);
                                    return 1;
                                })))));

        // Comando para los jugadores: cuesta un periódico
        // /primeravez [jugador]: vuelve al cuarto de la tele como si fuera la primera vez (para probar la cinemática)
        d.register(literal("primeravez").requires(s -> s.hasPermissionLevel(2))
                .executes(c -> {
                    var p = c.getSource().getPlayerOrThrow();
                    com.centrodesinformacion.desinformados.intro.Intro.reiniciar(p);
                    c.getSource().sendFeedback(() -> Text.literal("De vuelta al cuarto de la tele. Dale clic derecho cuando quieras."), false);
                    return 1;
                })
                .then(argument("jugador", EntityArgumentType.player()).executes(c -> {
                    var p = EntityArgumentType.getPlayer(c, "jugador");
                    com.centrodesinformacion.desinformados.intro.Intro.reiniciar(p);
                    c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + " vuelve al cuarto de la tele"), true);
                    return 1;
                })));
        d.register(literal("revivir").then(argument("jugador", StringArgumentType.word())
                .suggests(SUGERIR_MUERTOS)
                .executes(c -> revivir(c, true))));
    }

    private static int lanzarEvento(CommandContext<ServerCommandSource> c, String descripcion) {
        String color = StringArgumentType.getString(c, "color").toLowerCase(Locale.ROOT);
        if (!COLORES.contains(color)) {
            c.getSource().sendError(Text.literal("Color inválido. Usa: verde, rojo, amarillo, morado, azul o naranja"));
            return 0;
        }
        String titulo = StringArgumentType.getString(c, "titulo");
        Eventos.mostrarTele(c.getSource().getServer(), color, titulo, descripcion);
        c.getSource().sendFeedback(() -> Text.literal("Evento " + color + " lanzado: " + titulo), true);
        return 1;
    }

    private static int revivir(CommandContext<ServerCommandSource> c, boolean cuestaPeriodico) throws CommandSyntaxException {
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor estado = EstadoServidor.get(server);
        UUID uuid = estado.buscarMuerto(StringArgumentType.getString(c, "jugador"));
        if (uuid == null) {
            c.getSource().sendError(Text.literal("Ese jugador no está muerto."));
            return 0;
        }
        String quien = "El Centro de Desinformación";
        if (cuestaPeriodico) {
            ServerPlayerEntity jugador = c.getSource().getPlayerOrThrow();
            if (!gastarPeriodico(jugador)) {
                c.getSource().sendError(Text.literal("Necesitas un Periódico Desinformado para revivir a alguien."));
                return 0;
            }
            quien = jugador.getGameProfile().getName();
        }
        String nombre = estado.quitarMuerto(uuid);
        estado.setVidas(uuid, 1);
        ServerPlayerEntity enLinea = server.getPlayerManager().getPlayer(uuid);
        if (enLinea != null) Reglas.restaurar(enLinea); // aún no lo habían expulsado
        server.getPlayerManager().broadcast(Text.literal(quien + " ha revivido a " + nombre + ". ¡Ya puede volver al server!")
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
        return 1;
    }

    private static int verVida(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        ServerPlayerEntity p = EntityArgumentType.getPlayer(c, "objetivo");
        EstadoServidor estado = EstadoServidor.get(c.getSource().getServer());
        int rojos = estado.getRojos(p.getUuid());
        float almas = estado.getAlmas(p.getUuid()) / 2f;
        int vidas = estado.getVidas(p.getUuid());
        c.getSource().sendFeedback(() -> Text.literal(p.getGameProfile().getName() + ": " + vidas + " vidas, " + (10 + rojos)
                + " corazones rojos, " + almas + " de alma"), false);
        return 1;
    }

    private static int activarGrupo(CommandContext<ServerCommandSource> c, java.util.List<String> ids, String nombre) {
        int n = Eventos.activarGrupo(c.getSource().getServer(), ids);
        c.getSource().sendFeedback(() -> Text.literal("Activados " + n + " " + nombre + " (sin teles)").formatted(Formatting.YELLOW), true);
        return n;
    }

    private static boolean gastarPeriodico(ServerPlayerEntity jugador) {
        PlayerInventory inv = jugador.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(ModItems.PERIODICO)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }

    private static int quitarObra(CommandContext<ServerCommandSource> c, String tipo) {
        int n = com.centrodesinformacion.desinformados.muebles.ObraBlock.quitarTodos(c.getSource().getServer(), tipo);
        String que = switch (tipo) { case "valla" -> "vallas"; case "andamio" -> "andamios"; default -> "bloques de obra"; };
        c.getSource().sendFeedback(() -> Text.literal("¡Obra terminada! Se quitaron " + n + " " + que + "."), true);
        return n;
    }

    /** Lo mismo que pasa solo al crear un mundo nuevo: montaña, Centro decorado, gatos, escalera y protección. */
    private static int generarCentro(CommandContext<ServerCommandSource> c, boolean forzar) {
        var server = c.getSource().getServer();
        EstadoServidor e = EstadoServidor.get(server);
        if (e.tieneCambio(GeneradorCentro.GENERADO) && !forzar) {
            c.getSource().sendError(Text.literal("El Centro ya se generó en este mundo. Si quieres otro, usa /desinfo generar centro forzar "
                    + "(los gatos del Centro anterior se quitan)."));
            return 0;
        }
        if (forzar && e.getCentroProtegido() != null) {        // fuera los gatos del Centro anterior, para no duplicarlos
            BlockPos viejo = BlockPos.fromLong(e.getCentroProtegido());
            var caja = new net.minecraft.util.math.Box(viejo).expand(30, 40, 30);
            server.getOverworld().getEntitiesByClass(com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.class, caja, g -> true)
                    .forEach(net.minecraft.entity.Entity::discard);
        }
        c.getSource().sendFeedback(() -> Text.literal("Generando el Centro de Desinformación (puede tardar unos segundos)...").formatted(Formatting.GRAY), false);
        BlockPos llegada = GeneradorCentro.generar(server);
        c.getSource().sendFeedback(() -> Text.literal("Centro generado en " + llegada.getX() + " " + llegada.getY() + " " + llegada.getZ()
                + ": decorado, con sus gatos, escalera en espiral y la zona protegida (radio " + GeneradorCentro.RADIO_PROTEGIDO + ").")
                .formatted(Formatting.GREEN), true);
        return 1;
    }
}

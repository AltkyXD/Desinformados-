package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class Comandos {
    private static final List<String> COLORES = List.of("verde", "rojo", "amarillo");

    private static final SuggestionProvider<ServerCommandSource> SUGERIR_MUERTOS = (c, b) ->
            CommandSource.suggestMatching(EstadoServidor.get(c.getSource().getServer()).getMuertos().values(), b);

    public static void registrar(CommandDispatcher<ServerCommandSource> d) {
        // Comandos de administrador (operadores)
        d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("evento")
                        .then(argument("color", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(COLORES, b))
                                .then(argument("titulo", StringArgumentType.string())
                                        .executes(c -> lanzarEvento(c, ""))
                                        .then(argument("descripcion", StringArgumentType.greedyString())
                                                .executes(c -> lanzarEvento(c, StringArgumentType.getString(c, "descripcion")))))))
                .then(literal("fase")
                        .executes(c -> {
                            int f = EstadoServidor.get(c.getSource().getServer()).getFase();
                            c.getSource().sendFeedback(() -> Text.literal("Fase actual: " + f), false);
                            return f;
                        })
                        .then(argument("numero", IntegerArgumentType.integer(1, Progresion.FASE_MAXIMA))
                                .executes(Comandos::cambiarFase)))
                .then(literal("spawn").then(literal("radio")
                        .then(argument("bloques", IntegerArgumentType.integer(0, 512))
                                .executes(c -> {
                                    int r = IntegerArgumentType.getInteger(c, "bloques");
                                    EstadoServidor.get(c.getSource().getServer()).setRadioSpawn(r);
                                    c.getSource().sendFeedback(() -> Text.literal("Radio del spawn protegido: " + r + " bloques"), true);
                                    return 1;
                                }))))
                .then(literal("muertos").executes(c -> {
                    var muertos = EstadoServidor.get(c.getSource().getServer()).getMuertos();
                    String lista = muertos.isEmpty() ? "nadie" : String.join(", ", muertos.values());
                    c.getSource().sendFeedback(() -> Text.literal("Desinformados (muertos): " + lista), false);
                    return muertos.size();
                }))
                .then(literal("revivir").then(argument("jugador", StringArgumentType.word())
                        .suggests(SUGERIR_MUERTOS)
                        .executes(c -> revivir(c, false)))));

        // Comando para los jugadores: cuesta un periódico
        d.register(literal("revivir").then(argument("jugador", StringArgumentType.word())
                .suggests(SUGERIR_MUERTOS)
                .executes(c -> revivir(c, true))));
    }

    private static int lanzarEvento(CommandContext<ServerCommandSource> c, String descripcion) {
        String color = StringArgumentType.getString(c, "color").toLowerCase(Locale.ROOT);
        if (!COLORES.contains(color)) {
            c.getSource().sendError(Text.literal("Color inválido. Usa: verde, rojo o amarillo"));
            return 0;
        }
        String titulo = StringArgumentType.getString(c, "titulo");
        EventoTvPayload paquete = new EventoTvPayload(color, titulo, descripcion);
        for (ServerPlayerEntity p : c.getSource().getServer().getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, paquete);
        }
        c.getSource().sendFeedback(() -> Text.literal("Evento " + color + " lanzado: " + titulo), true);
        return 1;
    }

    private static int cambiarFase(CommandContext<ServerCommandSource> c) {
        int n = IntegerArgumentType.getInteger(c, "numero");
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor.get(server).setFase(n);
        server.getPlayerManager().broadcast(Text.literal("¡FASE " + n + "! Minerales desbloqueados: " + Progresion.descripcion(n))
                .formatted(Formatting.GOLD, Formatting.BOLD), false);
        return n;
    }

    private static int revivir(CommandContext<ServerCommandSource> c, boolean cuestaPeriodico) throws CommandSyntaxException {
        MinecraftServer server = c.getSource().getServer();
        EstadoServidor estado = EstadoServidor.get(server);
        UUID uuid = estado.buscarMuerto(StringArgumentType.getString(c, "jugador"));
        if (uuid == null) {
            c.getSource().sendError(Text.literal("Ese jugador no está muerto."));
            return 0;
        }
        String quien = "El Centro de Desinformación";
        if (cuestaPeriodico) {
            ServerPlayerEntity jugador = c.getSource().getPlayerOrThrow();
            if (!gastarPeriodico(jugador)) {
                c.getSource().sendError(Text.literal("Necesitas un Periódico Desinformado para revivir a alguien."));
                return 0;
            }
            quien = jugador.getGameProfile().getName();
        }
        String nombre = estado.quitarMuerto(uuid);
        server.getPlayerManager().broadcast(Text.literal(quien + " ha revivido a " + nombre + ". ¡Ya puede volver al server!")
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
        return 1;
    }

    private static boolean gastarPeriodico(ServerPlayerEntity jugador) {
        PlayerInventory inv = jugador.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(ModItems.PERIODICO)) {
                stack.decrement(1);
                return true;
            }
        }
        return false;
    }
}

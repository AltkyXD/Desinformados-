package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Creeper de Fuego (Nether): al explotar te prende fuego y deja llamas alrededor. Qué sorpresa. */
public class CreeperFuegoEntity extends CreeperEntity {
    public CreeperFuegoEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() && age % 3 == 0)
            getWorld().addParticle(ParticleTypes.FLAME, getParticleX(0.5), getRandomBodyY(), getParticleZ(0.5), 0, 0.02, 0);
    }

    /** El creeper "explota" llamando a discard() con dead = true y aún con vida: ahí soltamos el fuego. */
    @Override
    public void remove(RemovalReason reason) {
        if (!getWorld().isClient() && reason == RemovalReason.DISCARDED && dead && getHealth() > 0
                && getWorld() instanceof ServerWorld w) {
            double radio = shouldRenderOverlay() ? 7 : 5;
            for (PlayerEntity p : w.getPlayers()) {
                if (p.squaredDistanceTo(this) < radio * radio && !p.isCreative() && !p.isSpectator()) p.setOnFireFor(8f);
            }
            BlockPos c = getBlockPos();
            for (int i = 0; i < 14; i++) {
                BlockPos q = c.add(random.nextInt(7) - 3, random.nextInt(3) - 1, random.nextInt(7) - 3);
                if (w.getBlockState(q).isAir() && w.getBlockState(q.down()).isSolidBlock(w, q.down()))
                    w.setBlockState(q, Blocks.FIRE.getDefaultState());
            }
            w.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 1, getZ(), 80, 1.5, 1, 1.5, 0.08);
            w.spawnParticles(ParticleTypes.LAVA, getX(), getY() + 1, getZ(), 20, 1, 0.5, 1, 0.1);
        }
        super.remove(reason);
    }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.RumorItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.NoPenaltyTargeting;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/**
 * Zombie Ladrón: si te pega con las manos vacías, te roba UN montón de Rumores (el que más vale de tu inventario).
 * Lo lleva en la mano y lo suelta siempre al morir. Después huye 8 segundos con Velocidad II e Invisibilidad.
 * Nunca roba otra cosa y no desaparece mientras lleve el botín.
 */
public class ZombieLadronEntity extends ZombieEntity {
    private static final int HUIDA = 8 * 20;

    private int huida = 0;
    @Nullable private Vec3d huirDe;

    public ZombieLadronEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        Variantes.zombieSinExtras(this);
        setCanPickUpLoot(false);   // no recoge nada del suelo: solo roba Rumores
        return r;
    }

    /** Sale con las manos vacías (sin armas ni armadura): tiene que poder robar. */
    @Override
    protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
    }

    /** Siempre adulto (la textura es de adulto). */
    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    /** Mientras huye no persigue a nadie. */
    @Override
    public void setTarget(@Nullable LivingEntity objetivo) {
        if (huida > 0 && objetivo != null) return;
        super.setTarget(objetivo);
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && !getWorld().isClient() && getMainHandStack().isEmpty()
                && objetivo instanceof ServerPlayerEntity p && Variantes.valido(p)) {
            robar(p);
        }
        return golpe;
    }

    private void robar(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        int mejor = -1;
        int valorMejor = 0;
        for (int i = 0; i < inv.main.size(); i++) {
            ItemStack s = inv.main.get(i);
            if (s.isEmpty() || !(s.getItem() instanceof RumorItem rumor)) continue;
            int valor = rumor.getValor() * s.getCount();
            if (valor > valorMejor) {
                valorMejor = valor;
                mejor = i;
            }
        }
        if (mejor < 0) return;
        ItemStack botin = inv.main.get(mejor).copy();
        inv.main.set(mejor, ItemStack.EMPTY);
        inv.markDirty();

        equipStack(EquipmentSlot.MAINHAND, botin);
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 2.0f);   // > 1: lo suelta seguro al morir, lo mate quien lo mate
        setCanPickUpLoot(false);
        setPersistent();                                         // no desaparece con tus Rumores encima
        addCommandTag(Mobs.MARCA_EVENTO);                        // ni aunque se vuelva a bloquear su tipo (se perderían)
        addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, HUIDA, 1));
        addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, HUIDA, 0));
        huida = HUIDA;
        huirDe = p.getPos();
        super.setTarget(null);
        getNavigation().stop();

        getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.HOSTILE, 1f, 0.6f);
        p.sendMessage(Text.literal("¡Te han robado " + valorMejor + (valorMejor == 1 ? " Rumor!" : " Rumores!"))
                .formatted(Formatting.RED, Formatting.BOLD), true);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || huida <= 0) return;
        huida--;
        if (huirDe != null && huida % 10 == 0) {
            Vec3d lejos = NoPenaltyTargeting.findFrom(this, 16, 7, huirDe);
            if (lejos != null) getNavigation().startMovingTo(lejos.x, lejos.y, lejos.z, 1.2);
        }
        if (huida == 0) huirDe = null;
    }

    /** En el agua no se convierte en ahogado normal. */
    @Override
    protected boolean canConvertInWater() {
        return false;
    }
}

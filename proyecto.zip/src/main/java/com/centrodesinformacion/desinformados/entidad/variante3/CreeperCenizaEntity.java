package com.centrodesinformacion.desinformados.entidad.variante3;

import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.entidad.CreeperFuegoEntity;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * Creeper de Ceniza (Nether): explota como un Creeper de Fuego (te prende fuego y deja llamas) y además deja
 * una nube de humo y ceniza de 10 segundos. La nube es solo visual (sin efectos propios, para no dar efectos infinitos
 * ni afectar a creativos): cada medio segundo, los jugadores válidos que están dentro reciben Ceguera 4 s y Debilidad 8 s.
 * El bloqueo de aparición ya lo hace CreeperFuegoEntity.canSpawn con getType() (su propio desbloqueo).
 */
public class CreeperCenizaEntity extends CreeperFuegoEntity {
    private static final float RADIO = 3.5f;
    private static final int DURACION = 200;       // 10 segundos
    private static final int CEGUERA = 80;         // 4 segundos
    private static final int DEBILIDAD = 160;      // 8 segundos
    private static final int PULSO = 10;           // cada medio segundo

    public CreeperCenizaEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() && age % 4 == 0)
            getWorld().addParticle(ParticleTypes.SMOKE, getParticleX(0.5), getRandomBodyY(), getParticleZ(0.5), 0, 0.03, 0);
    }

    /** Igual que CreeperFuegoEntity: "explota" con discard(), dead = true y aún con vida. Ahí deja la nube. */
    @Override
    public void remove(RemovalReason reason) {
        if (!getWorld().isClient() && reason == RemovalReason.DISCARDED && dead && getHealth() > 0
                && getWorld() instanceof ServerWorld w) {
            nube(w);
        }
        super.remove(reason);   // el fuego del Creeper de Fuego
    }

    private void nube(ServerWorld w) {
        AreaEffectCloudEntity nube = new AreaEffectCloudEntity(w, getX(), getY(), getZ());
        nube.setRadius(RADIO);
        nube.setDuration(DURACION);
        nube.setWaitTime(0);
        nube.setRadiusGrowth(-(RADIO - 1.5f) / DURACION);   // se va encogiendo hasta 1,5 bloques
        nube.setParticleType(ParticleTypes.LARGE_SMOKE);
        w.spawnEntity(nube);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 40, 1.5, 0.8, 1.5, 0.02);
        w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 1, getZ(), 80, 2, 1, 2, 0.05);
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.HOSTILE, 1.2f, 0.6f);
        Tareas.programar(1, () -> pulso(w, nube));
    }

    /** Mientras la nube exista: Ceguera y Debilidad a los jugadores que están dentro (sin creativos ni espectadores). */
    private static void pulso(ServerWorld w, AreaEffectCloudEntity nube) {
        if (nube.isRemoved()) return;
        double r = nube.getRadius();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;
            double dx = p.getX() - nube.getX(), dz = p.getZ() - nube.getZ();
            if (dx * dx + dz * dz > r * r || Math.abs(p.getY() - nube.getY()) > 2.5) continue;
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, CEGUERA, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, DEBILIDAD, 0));
        }
        Tareas.programar(PULSO, () -> pulso(w, nube));
    }
}

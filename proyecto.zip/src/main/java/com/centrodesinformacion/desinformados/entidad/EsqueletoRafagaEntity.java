package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Tareas;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Esqueleto Ráfaga (Nether, verde): dispara 5 flechas seguidas y luego recarga 5 segundos. */
public class EsqueletoRafagaEntity extends SkeletonEntity {
    private int recarga = 0;

    public EsqueletoRafagaEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (recarga > 0) recarga--;
    }

    @Override
    public void shootAt(LivingEntity objetivo, float tension) {
        if (recarga > 0) return;
        recarga = 100 + 5 * 4; // 5 s después de terminar la ráfaga
        for (int i = 0; i < 5; i++) {
            Tareas.programar(i * 4, () -> {
                if (isAlive() && objetivo.isAlive()) EsqueletoRafagaEntity.super.shootAt(objetivo, tension);
            });
        }
    }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.network.InvertidoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Travensaño: especie del lore. Te persigue y se te sienta en el cuello:
 * medio corazón cada 3 segundos, controles y cámara invertidos mientras esté ahí.
 * Se queda hasta que lo mates o hasta 15 segundos; luego salta y descansa 5 segundos.
 */
public class TravensanoEntity extends PathAwareEntity {
    private static final int MAX_ENCIMA = 300;
    private static final int DESCANSO = 100;
    private static final TrackedData<Boolean> SENTADO = DataTracker.registerData(TravensanoEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(SENTADO, false);
    }

    /** Para el modelo: dibujarlo sentado sobre los hombros. */
    public boolean isSentado() {
        return dataTracker.get(SENTADO);
    }

    @Nullable private UUID montado;
    private int ticksEncima;
    private int descanso;

    public TravensanoEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Solo aparece de forma natural después de su tele amarilla ("travensanos"). */
    @Override
    public boolean canSpawn(net.minecraft.world.WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(world)) return super.canSpawn(world, reason);
        // En el Nether solo aparecen solos después de la tele "nether_poblado"
        if (reason == SpawnReason.NATURAL && world instanceof net.minecraft.world.ServerWorldAccess sw
                && sw.toServerWorld().getRegistryKey() == net.minecraft.world.World.NETHER)
            return world.getServer() != null
                    && com.centrodesinformacion.desinformados.EstadoServidor.get(world.getServer()).tieneCambio("evento:nether_poblado")
                    && super.canSpawn(world, reason);
        if (reason == SpawnReason.NATURAL && (world.getServer() == null
                || !com.centrodesinformacion.desinformados.EstadoServidor.get(world.getServer()).tieneCambio("travensanos"))) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        if (reason != SpawnReason.NATURAL) setPersistent(); // los que aparecen solos sí pueden desaparecer
        return super.initialize(world, difficulty, reason, data);
    }

    /** "Atacar" = subirse a tu cabeza. */
    @Override
    public boolean tryAttack(Entity objetivo) {
        if (montado != null || descanso > 0 || !(objetivo instanceof ServerPlayerEntity p)
                || p.isCreative() || p.isSpectator() || cabezaOcupada(p)) return false;
        montado = p.getUuid();
        ticksEncima = 0;
        setNoGravity(true);
        dataTracker.set(SENTADO, true);
        getNavigation().stop();
        p.sendMessage(Text.literal("¡Un Travensaño se te ha subido al cuello! Pégale para quitártelo").formatted(Formatting.LIGHT_PURPLE), true);
        getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_VILLAGER_YES, SoundCategory.HOSTILE, 1f, 1.3f);
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        if (descanso > 0) descanso--;
        if (montado == null) return;

        ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(montado);
        if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator() || p.getWorld() != getWorld() || ticksEncima >= MAX_ENCIMA) {
            bajarse(p);
            return;
        }
        ticksEncima++;
        // Sentado a horcajadas sobre el cuello: cadera a la altura de los hombros, un poco hacia atrás
        float rad = p.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double atras = 0.22;
        setPosition(p.getX() + MathHelper.sin(rad) * atras, p.getY() + 0.8, p.getZ() - MathHelper.cos(rad) * atras);
        setVelocity(Vec3d.ZERO);
        fallDistance = 0;
        setYaw(p.getYaw());
        setBodyYaw(p.getYaw());
        setHeadYaw(p.getHeadYaw());
        // Normal: medio corazón cada 3 s.
        // Con "travensanos_furiosos": 1,5 corazones CADA SEGUNDO y atravesando la armadura.
        boolean furioso = com.centrodesinformacion.desinformados.EstadoServidor.get(getServer()).tieneCambio("travensanos_furiosos");
        if (furioso) {
            if (ticksEncima % 20 == 0) p.damage(getDamageSources().indirectMagic(this, this), 3f);
        } else if (ticksEncima % 60 == 0) {
            p.damage(getDamageSources().mobAttack(this), 1f);
        }
        if (ticksEncima % 20 == 1 && ServerPlayNetworking.canSend(p, InvertidoPayload.ID)) {
            ServerPlayNetworking.send(p, new InvertidoPayload(30)); // se renueva cada segundo mientras siga encima
        }
        if (ticksEncima % 40 == 0) getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_VILLAGER_AMBIENT, SoundCategory.HOSTILE, 0.8f, 1.4f);
    }

    /** ¿Ya lleva otro Travensaño en el cuello? (se busca en el mundo: nada de listas estáticas que se queden colgadas) */
    private boolean cabezaOcupada(ServerPlayerEntity p) {
        return !p.getWorld().getEntitiesByClass(TravensanoEntity.class, p.getBoundingBox().expand(2),
                t -> t != this && p.getUuid().equals(t.montado)).isEmpty();
    }

    /** Al descargarse (chunk, cambio de dimensión) no se llama a remove(): ahí también se baja. */
    public static void registrar() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_UNLOAD.register((entidad, mundo) -> {
            if (entidad instanceof TravensanoEntity t && t.montado != null)
                t.bajarse(mundo.getServer().getPlayerManager().getPlayer(t.montado));
        });
    }

    private void bajarse(@Nullable ServerPlayerEntity p) {
        montado = null;
        descanso = DESCANSO;
        setNoGravity(false);
        dataTracker.set(SENTADO, false);
        if (p != null) {
            setVelocity((random.nextDouble() - 0.5) * 0.6, 0.35, (random.nextDouble() - 0.5) * 0.6);
            if (ServerPlayNetworking.canSend(p, InvertidoPayload.ID)) ServerPlayNetworking.send(p, new InvertidoPayload(0));
        }
    }

    @Override
    public void remove(RemovalReason razon) {
        if (!getWorld().isClient() && montado != null) {
            ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(montado);
            bajarse(p);
        }
        super.remove(razon);
    }

    /** Si se guardó sentado en un cuello, se guardó sin gravedad: al cargar ya no está montado. */
    @Override
    public void readCustomDataFromNbt(net.minecraft.nbt.NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (montado == null) setNoGravity(false);
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        if (montado != null && (fuente.isOf(DamageTypes.IN_WALL) || fuente.isOf(DamageTypes.FALL))) return false;
        return super.damage(fuente, cantidad);
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_VILLAGER_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_VILLAGER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_VILLAGER_DEATH; }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.entity.mob.WitchEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Bruja Influencer: cada 20 segundos, si tiene a un jugador como objetivo a menos de 16 bloques
 * y hay menos de 6 "Seguidores" a menos de 16 bloques, invoca a 2 Seguidores (lepismas) a su lado.
 */
public class BrujaInfluencerEntity extends WitchEntity {
    /** Etiqueta de los lepismas invocados (para contarlos). */
    public static final String SEGUIDOR = "desinfo_seguidor";
    private static final int CADA = 20 * 20;
    private static final double RADIO = 16;
    private static final int MAX_SEGUIDORES = 6;

    private int espera = CADA;

    public BrujaInfluencerEntity(EntityType<? extends WitchEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw) || !isAlive()) return;
        if (espera > 0) {
            espera--;
            return;
        }
        LivingEntity objetivo = getTarget();
        if (!(objetivo instanceof PlayerEntity p) || !Variantes.valido(p) || squaredDistanceTo(p) > RADIO * RADIO) return;
        espera = CADA;
        int seguidores = sw.getEntitiesByClass(SilverfishEntity.class, getBoundingBox().expand(RADIO),
                e -> e.isAlive() && e.getCommandTags().contains(SEGUIDOR)).size();
        if (seguidores >= MAX_SEGUIDORES) return;
        int invocados = 0;
        for (int i = 0; i < 2 && seguidores + invocados < MAX_SEGUIDORES; i++) {
            SilverfishEntity s = EntityType.SILVERFISH.create(sw);
            if (s == null) continue;
            double x = getX() + (random.nextDouble() - 0.5) * 2.0;
            double z = getZ() + (random.nextDouble() - 0.5) * 2.0;
            BlockPos bp = BlockPos.ofFloored(x, getY(), z);
            if (!sw.getBlockState(bp).getCollisionShape(sw, bp).isEmpty()) {
                x = getX();
                z = getZ();
            }
            s.refreshPositionAndAngles(x, getY(), z, random.nextFloat() * 360f, 0f);
            s.initialize(sw, sw.getLocalDifficulty(getBlockPos()), SpawnReason.MOB_SUMMONED, null);
            s.addCommandTag(Mobs.MARCA_EVENTO);   // existe aunque alguien haya bloqueado los lepismas
            s.addCommandTag(SEGUIDOR);
            s.setCustomName(Text.literal("Seguidor").formatted(Formatting.LIGHT_PURPLE));
            s.setTarget(p);
            sw.spawnEntity(s);
            sw.spawnParticles(ParticleTypes.WITCH, s.getX(), s.getY() + 0.3, s.getZ(), 8, 0.3, 0.2, 0.3, 0.02);
            invocados++;
        }
        if (invocados > 0) {
            sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_WITCH_CELEBRATE, SoundCategory.HOSTILE, 1f, 1.3f);
            p.sendMessage(Text.literal("La Bruja Influencer llama a sus seguidores...").formatted(Formatting.LIGHT_PURPLE), true);
        }
    }
}

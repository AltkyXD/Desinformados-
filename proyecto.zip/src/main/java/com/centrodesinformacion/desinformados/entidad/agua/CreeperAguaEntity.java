package com.centrodesinformacion.desinformados.entidad.agua;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.SwimAroundGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.FishEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

/**
 * Creeper de Agua: un pez (modelo del bacalao x2) con piel de creeper azul. 5 corazones.
 * - Si ve a un jugador a menos de 16 bloques, nada hacia él (más rápido que un pez normal).
 * - A menos de 2,5 bloques enciende la mecha: 1,5 s después explota como un creeper normal (potencia 3) y desaparece.
 *   Si te alejas a más de 7 bloques antes (o deja de verte), la mecha se apaga, como la de un creeper.
 * - Si estás FUERA del agua a menos de 8 bloques y él está cerca de la superficie, salta hacia ti con la mecha ya
 *   encendida (esa ya no se apaga): cae a tu lado y explota.
 * - Fuera del agua es un pez varado (da coletazos y no puede nadar), pero la mecha sigue.
 */
public class CreeperAguaEntity extends FishEntity implements Monster {
    /** Duración de la mecha: 1,5 s. */
    public static final int MECHA = 30;
    private static final float POTENCIA = 3.0f;
    private static final double VISTA = 16;
    private static final double CERCA = 2.5;
    private static final double SALTO = 8;
    private static final double APAGAR = 7;
    private static final int ESPERA = 40;   // 2 s sin volver a encenderse tras apagarse

    /** Ticks de mecha (0 = apagada), para que el cliente lo dibuje hinchándose y parpadeando. */
    private static final TrackedData<Integer> FUSE = DataTracker.registerData(CreeperAguaEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private int mecha = 0;
    private boolean saltado = false;   // encendida al saltar: ya no se apaga
    private int espera = 0;

    public CreeperAguaEntity(EntityType<? extends FishEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return FishEntity.createFishAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FUSE, 0);
    }

    /** Sin los objetivos del pez normal (no huye de los jugadores): persigue y, si no, nada al azar. */
    @Override
    protected void initGoals() {
        goalSelector.add(1, new PerseguirGoal(this));
        goalSelector.add(4, new SwimAroundGoal(this, 1.0, 40));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Es un monstruo: en pacífico desaparece. */
    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    @Override
    protected int getXpToDrop() {
        return 5;
    }

    /** No se puede meter en un cubo. */
    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        return ActionResult.PASS;
    }

    /** Obligatorio por ser un pez (nunca se usa: no se puede coger con cubo). */
    @Override
    public ItemStack getBucketItem() {
        return new ItemStack(Items.WATER_BUCKET);
    }

    @Override
    protected SoundEvent getFlopSound() {
        return SoundEvents.ENTITY_COD_FLOP;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_CREEPER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CREEPER_DEATH;
    }

    /** Para el renderer: 0 = apagada, 1 = a punto de explotar. */
    public float progresoMecha(float tickDelta) {
        int m = dataTracker.get(FUSE);
        if (m <= 0) return 0f;
        return Math.min(1f, (m - 1 + tickDelta) / (float) MECHA);
    }

    /** Cuando persigue a alguien nada el doble de rápido que un pez normal. */
    @Override
    public void travel(Vec3d movimiento) {
        if (getTarget() != null && isLogicalSideForUpdatingMovement() && isTouchingWater()) {
            updateVelocity(0.018f, movimiento);
            move(MovementType.SELF, getVelocity());
            setVelocity(getVelocity().multiply(0.9));
            return;
        }
        super.travel(movimiento);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw) || !isAlive() || isRemoved()) return;
        if (espera > 0) espera--;
        if (age % 10 == 0 && electrificado())                                         // cargado: echa chispas
            sw.spawnParticles(net.minecraft.particle.ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.4, getZ(), 3, 0.4, 0.3, 0.4, 0.05);
        if (mecha > 0) {
            tickMecha(sw);
            return;
        }
        if (espera > 0 || age % 4 != 0) return;
        if (jugadorVisible(CERCA, false) != null) {
            encender(sw, false);
        } else if (isTouchingWater() && cercaDeLaSuperficie()) {
            PlayerEntity fuera = jugadorVisible(SALTO, true);
            if (fuera != null) saltar(sw, fuera);
        }
    }

    private void tickMecha(ServerWorld sw) {
        // Como un creeper: si te alejas (o deja de verte) se apaga. La del salto ya no se apaga.
        if (!saltado && age % 5 == 0 && jugadorVisible(APAGAR, false) == null) {
            mecha = 0;
            dataTracker.set(FUSE, 0);
            espera = ESPERA;
            return;
        }
        mecha++;
        dataTracker.set(FUSE, mecha);
        if (mecha % 3 == 0) {
            sw.spawnParticles(isTouchingWater() ? ParticleTypes.BUBBLE : ParticleTypes.SMOKE, getX(), getY() + 0.5, getZ(), 2, 0.15, 0.1, 0.15, 0.01);
        }
        if (mecha >= MECHA) explotar(sw);
    }

    private void encender(ServerWorld sw, boolean salto) {
        mecha = 1;
        saltado = salto;
        dataTracker.set(FUSE, 1);
        getNavigation().stop();
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_CREEPER_PRIMED, SoundCategory.HOSTILE, 1f, 0.5f);
    }

    /** Explota como un creeper normal (potencia 3, rompe bloques si mobGriefing está activo) y desaparece. */
    /** ¿Está activo «¡Creepers electrificados!»? (su tele sale después de la del Creeper de Agua) */
    public boolean electrificado() {
        return getServer() != null && com.centrodesinformacion.desinformados.EstadoServidor.get(getServer()).tieneCambio("creepers_electrificados");
    }

    private void explotar(ServerWorld sw) {
        // con «¡Creepers electrificados!» también está cargado: explosión doble, como los creepers normales
        sw.createExplosion(this, getX(), getY(), getZ(), electrificado() ? POTENCIA * 2 : POTENCIA, World.ExplosionSourceType.MOB);
        discard();
    }

    /** ¿Tiene la superficie justo encima? (si no, primero tiene que subir para poder saltar) */
    private boolean cercaDeLaSuperficie() {
        BlockPos arriba = BlockPos.ofFloored(getX(), getY() + 1.6, getZ());
        return !getWorld().getFluidState(arriba).isIn(FluidTags.WATER);
    }

    /**
     * Salta fuera del agua hacia el jugador con la mecha encendida. La velocidad se calcula para caer a ~0,8 bloques
     * de él (en el aire: gravedad 0,08 y rozamiento 0,98 en vertical y 0,91 en horizontal).
     */
    private void saltar(ServerWorld sw, PlayerEntity p) {
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        double dy = MathHelper.clamp(p.getY() - getY(), -2.0, 4.0);
        double vy = 0.55 + 0.09 * Math.max(0.0, dy);
        double altura = 0;
        double v = vy;
        int t = 0;
        while (t < 60) {
            altura += v;
            v = (v - 0.08) * 0.98;
            t++;
            if (v < 0 && altura <= dy) break;
        }
        double recorrido = Math.max(0.0, dist - 0.8);
        double vh = Math.min(1.1, recorrido * 0.09 / (1.0 - Math.pow(0.91, t)));
        double nx = dist > 1.0E-4 ? dx / dist : 0.0;
        double nz = dist > 1.0E-4 ? dz / dist : 0.0;
        getNavigation().stop();
        setTarget(null);
        setYaw((float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f);
        bodyYaw = getYaw();
        setVelocity(nx * vh, vy, nz * vh);
        velocityModified = true;
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.HOSTILE, 1f, 1.2f);
        sw.spawnParticles(ParticleTypes.SPLASH, getX(), getY() + 0.5, getZ(), 12, 0.4, 0.2, 0.4, 0.1);
        encender(sw, true);
    }

    /** El jugador válido más cercano que puede ver a menos de "radio" bloques (si fueraDelAgua, solo los que están fuera). */
    @Nullable
    PlayerEntity jugadorVisible(double radio, boolean fueraDelAgua) {
        PlayerEntity mejor = null;
        double mejorD = radio * radio;
        for (PlayerEntity p : getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radio), UtilAgua::valido)) {
            if (fueraDelAgua && p.isTouchingWater()) continue;
            double d = squaredDistanceTo(p);
            if (d <= mejorD && canSee(p)) {
                mejor = p;
                mejorD = d;
            }
        }
        return mejor;
    }

    /** Nada hacia el jugador más cercano que vea (a menos de 16 bloques) mientras no tenga la mecha encendida. */
    static class PerseguirGoal extends Goal {
        private final CreeperAguaEntity creeper;
        @Nullable private PlayerEntity objetivo;
        private int recalcular = 0;

        PerseguirGoal(CreeperAguaEntity creeper) {
            this.creeper = creeper;
            setControls(EnumSet.of(Control.MOVE));
        }

        @Override
        public boolean canStart() {
            if (creeper.age % 10 != 0 || creeper.mecha > 0 || !creeper.isTouchingWater()) return false;
            objetivo = creeper.jugadorVisible(VISTA, false);
            return objetivo != null;
        }

        @Override
        public boolean shouldContinue() {
            return creeper.mecha == 0 && creeper.isTouchingWater() && UtilAgua.valido(objetivo)
                    && creeper.squaredDistanceTo(objetivo) < (VISTA + 4) * (VISTA + 4);
        }

        @Override
        public void start() {
            recalcular = 0;
            creeper.setTarget(objetivo);
        }

        @Override
        public void stop() {
            objetivo = null;
            creeper.setTarget(null);
            creeper.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (objetivo == null) return;
            if (--recalcular <= 0) {
                recalcular = 10;
                creeper.getNavigation().startMovingTo(objetivo, 1.6);
            }
        }
    }
}

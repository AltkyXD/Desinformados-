package com.centrodesinformacion.desinformados.entidad.variante;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Utilidades compartidas por las 15 variantes de mobs. */
final class Variantes {
    private Variantes() {}

    /** Jugador al que se le puede hacer algo: vivo, ni creativo ni espectador. */
    static boolean valido(PlayerEntity p) {
        return p != null && p.isAlive() && !p.isCreative() && !p.isSpectator();
    }

    /** Variantes de zombi: sin refuerzos de zombis normales y sin montar en pollos (por si salió de jinete). */
    static void zombieSinExtras(ZombieEntity z) {
        EntityAttributeInstance refuerzos = z.getAttributeInstance(EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS);
        if (refuerzos != null) {
            refuerzos.clearModifiers();
            refuerzos.setBaseValue(0);
        }
        if (z.getVehicle() instanceof ChickenEntity) z.stopRiding();
    }
}

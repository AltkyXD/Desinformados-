package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Cubo Rojo (Nether): como el Cubo Blanco (te ciega y te frena)... y además te quema. */
public class CuboRojoEntity extends CuboBlancoEntity {
    public CuboRojoEntity(EntityType<? extends SlimeEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void alTocar(ServerPlayerEntity p) {
        p.setOnFireFor(5f);
        p.sendMessage(Text.literal("El Cubo Rojo te ha tocado... y quema.").formatted(Formatting.RED, Formatting.ITALIC), true);
    }

    @Override
    protected ParticleEffect getParticles() {
        return ParticleTypes.FLAME;
    }
}

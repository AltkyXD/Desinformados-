package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.network.BlancoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/**
 * Cubo Blanco: un cubo lento que da saltitos hacia ti. Si te toca te flashea:
 * pantalla en blanco unos segundos y Lentitud I.
 * No se divide al morir.
 */
public class CuboBlancoEntity extends SlimeEntity {
    private static final int TAMANO = 2;
    private static final int TICKS_BLANCO = 80;   // 4 segundos de pantalla blanca
    private static final int TICKS_ATURDIDO = 60; // 3 segundos aturdido
    private static final int ESPERA = 120;        // 6 segundos antes de poder volver a aturdirte

    private int espera = 0;

    public CuboBlancoEntity(EntityType<? extends SlimeEntity> type, World world) {
        super(type, world);
    }

    @Override
    public void setSize(int size, boolean heal) {
        super.setSize(TAMANO, heal);
        var vel = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (vel != null) vel.setBaseValue(0.18); // lento
        var vida = getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (vida != null) vida.setBaseValue(20.0);
        if (heal) setHealth(getMaxHealth());
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        setSize(TAMANO, true);
        return r;
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    private boolean gigante() {
        return getServer() != null && com.centrodesinformacion.desinformados.EstadoServidor.get(getServer()).tieneCambio("cubo_gigante");
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient() && age % 20 == 0) {
            var escala = getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_SCALE);
            if (escala != null) escala.setBaseValue(gigante() ? 2.0 : 1.0);
        }
        if (espera > 0) espera--;
    }

    /** Al tocarte: aturdimiento + pantalla blanca. No hace daño. */
    @Override
    public void onPlayerCollision(PlayerEntity jugador) {
        if (getWorld().isClient() || espera > 0 || !(jugador instanceof ServerPlayerEntity p)
                || p.isCreative() || p.isSpectator() || !canSee(p)) return;
        espera = ESPERA;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, TICKS_ATURDIDO, 0, false, false)); // Lentitud I
        if (ServerPlayNetworking.canSend(p, BlancoPayload.ID)) ServerPlayNetworking.send(p, new BlancoPayload(gigante() ? TICKS_BLANCO * 2 : TICKS_BLANCO));
        getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 1f, 2f);
        p.sendMessage(Text.literal("El Cubo Blanco te ha tocado...").formatted(Formatting.WHITE, Formatting.ITALIC), true);
    }

    @Override
    protected ParticleEffect getParticles() {
        return ParticleTypes.WHITE_ASH;
    }

    /** Antes de morir se reduce a tamaño 1 para que no se divida como un slime. */
    @Override
    public void remove(RemovalReason reason) {
        if (!getWorld().isClient() && isDead()) super.setSize(1, false);
        super.remove(reason);
    }
}

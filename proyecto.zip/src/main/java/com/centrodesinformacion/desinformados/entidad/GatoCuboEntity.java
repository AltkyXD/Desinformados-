package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.tienda.Tienda;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Gato Cubo: los NPC del Centro de Desinformación. Un cubo con la cara del gato del canal.
 * Cada tipo camina con su propio patrón alrededor de su "casa" y dice cosas sarcásticas.
 * Los vendedores se quedan en su puesto y abren la tienda.
 */
public class GatoCuboEntity extends PathAwareEntity {
    public static final int BECARIO = 0, RECEPCIONISTA = 1, PERIODISTA = 2, CONSERJE = 3,
            VEND_PASIVAS = 4, VEND_CORAZONES = 5, VEND_MINERALES = 6,
            PRINCIPAL = 7, ANIME = 8, NERD = 9, ROBOT = 10, GRANJERO = 11, GATO_GATO = 12, ROMANTICO = 13,
            MILLONARIO = 14, ELEGANTE = 15, CHEF = 16, DETECTIVE = 17, DJ = 18;
    public static final int MAX_TIPO = 18;
    public static final String[] IDS = {"becario", "recepcionista", "periodista", "conserje", "pasivas", "corazones", "minerales",
            "principal", "anime", "nerd", "robot", "granjero", "gato", "romantico", "millonario", "elegante", "chef", "detective", "dj"};
    public static final String[] NOMBRES = {"Michi el Becario", "Recepcionista Cubo", "Periodista Cubo", "Conserje Cubo",
            "Mago de las Pasivas", "Enfermero de Corazones", "Minero Cubo",
            "El Gato", "Gata Kawaii", "Gato Nerd", "GATO-BOT 3000", "Gato Granjero", "Gato Gato", "Gato Romántico",
            "Gato Millonario", "Gato Elegante", "Chef Michelin", "Detective Bigotes", "DJ Miaumix"};

    /** Para los que no venden: una conversación de 3 frases seguidas (avanza cada vez que le hablas). Vendedores: frases sueltas. */
    private static final String[][] CONVERSACION = {
            {"...", "...", "..."}, // becario: no existe
            {"Bienvenido al Centro de Desinformación. ¿Tiene cita? No. Nadie tiene cita.",
                    "Por favor, tome un número. Todos son el 7. Llevamos así desde 2019.",
                    "Si viene a quejarse del reactor, la ventanilla de quejas está dentro de la tele. Suerte."},
            {"¡Exclusiva! Fuentes que me acabo de inventar confirman que todo va genial.",
                    "Estoy escribiendo un artículo sobre ti. Aún no sé qué has hecho, pero será un escándalo.",
                    "Mi sueño es aprender a imprimir los periódicos que reviven a la gente. Si descubres cómo se hacen, ¡la exclusiva es mía!"},
            {"Alguien ha vuelto a dejar el suelo lleno de tierra. Adivina quién lo barre.",
                    "Barro en zigzag. Es más eficiente. No lo es, pero queda bonito.",
                    "Si ves tinta en el suelo, no fui yo. Fue el becario: lo vi pasar con la libreta goteando."},
            {"Pasivas mágicas recién horneadas... bueno, todavía están en el horno. Vuelve luego.",
                    "Mi mercancía sigue en desarrollo. Como el reactor. Como todo aquí.",
                    "No toques el sombrero. Es mágico. Bueno, es un cono morado, pero me hace sentir mágico."},
            {"Corazones de segunda mano, apenas usados. Uno late un poco raro, pero seguro que se le pasa.",
                    "Precios justos. Justos para mí, quiero decir.",
                    "¿Un tótem? Tiene cara de gato. Aquí todos los tótems tienen cara de gato. No preguntes."},
            {"Minerales recién picados. Bueno, picados hace bastante. Pero picados.",
                    "El diamante no se puede craftear todavía... pero venderlo sí. Qué casualidad.",
                    "¿Te parece caro? Ahí tienes una mina. Y un casino. Tú verás."},
            {"Ah, hola. Bienvenido al Centro de Desinformación. Yo soy el gato que dirige esto. Bueno, que lo intenta.",
                    "La tele es la que suelta las desinformaciones exageradas y cambia el mundo. Yo no la controlo... solo puedo mandaros señales verdes.",
                    "Alguien dañó el Reactor de la Desinformación. Reparadlo antes de que la tele se vuelva más loca. Cuando salga verde, ese soy yo ayudando."},
            {"¡Kyaaa~! ¡Un humano! ¿Sabías que en este centro todos somos cubos? Es súper kawaii, nya~",
                    "Hoy el becario-senpai me saludó desde el pasillo. ¡Kyaaa! Estoy segura de que me notó, nya~",
                    "Si derrotas al jefe final te dibujaré en mi libreta con ojos brillantes. ¡Es una promesa! (no lo es)"},
            {"Técnicamente, un cubo tiene 6 caras. Yo solo uso una. Eficiencia energética del 16,6%.",
                    "Calculé las probabilidades de la tragaperras: el casino gana siempre. Igual voy a jugar ahora.",
                    "La Garatita no es un mineral real. Lo sé porque lo busqué en la Wikipedia. No aparece. Fascinante."},
            {"BIP. BUP. SALUDOS, HUMANO. SOY EL GATO-BOT 3000. MODELO SIN GARANTÍA.",
                    "ANALIZANDO... NIVEL DE DESINFORMACIÓN EN TU CEREBRO: 87%. EXCELENTE. CONTINÚE.",
                    "ERROR 404: EMOCIONES NO ENCONTRADAS. INTENTE APAGARME Y ENCENDERME. NO, ESPERE. NO LO HAGA."},
            {"Buenas, forastero. Antes plantaba árboles, pero se declararon en huelga. Ahora planto quejas.",
                    "Las ovejas de por aquí ya no tienen lana. Las esquilé yo. Fue un accidente. Uno muy largo.",
                    "Si ves un zombie con mis pantalones, no me los robó. Se los presté. Somos amigos."},
            {"Miau.", "Miau miau.", "...miau."},
            {"¿Lo sientes? Es el amor... o el reactor perdiendo radiación. Uno de los dos.",
                    "Le escribí un poema a la Gata Kawaii. Dice: 'Eres un cubo y yo también'. Es muy profundo.",
                    "Si alguna vez te sientes solo, recuerda: los Furros siempre quieren abrazarte. Demasiado."},
            {"¿Ves estos billetes? Son de verdad. Bueno, los imprimí yo. Pero con mucho cariño.",
                    "Hice mi fortuna vendiendo rumores. Literalmente. Son la moneda de aquí.",
                    "Te doy 1.000 billetes si me traes un café. Ya, ya sé que no valen nada. Pero son muchos."},
            {"Buenas tardes. Disculpe mi sombrero de copa: es que tengo clase. Y un cubo como cuerpo.",
                    "En este centro hay que mantener la compostura. Aunque el reactor explote. Sobre todo si explota.",
                    "Una dama nunca revela su edad. Un caballero nunca revela que es un cubo. Ups."},
            {"¡Bienvenido a mi cocina! Hoy preparo comida podrida al horno. Es la especialidad desde el último cambio.",
                    "El ingrediente secreto es la leche cortada. No te la recomiendo. Pero es secreto.",
                    "Si la comida no te mata, te hace más fuerte. Si te mata, no me pongas reseña."},
            {"Elemental, querido jugador. Alguien dañó el reactor... y no fui yo. Eso ya es una pista.",
                    "Interrogué al becario esta mañana. Sudaba tinta y no paraba de mirar la libreta. Muy sospechoso.",
                    "Mi principal sospechoso es la tele. Tiene antenas. Las antenas son sospechosas."},
            {"¡Yooo! DJ Miaumix en la casa. ¿Quieres una canción? Son 20 Rumores y la pongo ya.",
                    "Cuando suena la música, los gatos se vienen a la pista. Hasta el conserje. Sobre todo el conserje.",
                    "El becario me pidió 'Chichabeba' doce veces ayer. Le cobré las doce."}
    };

    /** Cuando ya te contó todo. */
    private static final String[] MOLESTO = {
            "¿No tienes algo mejor que hacer?",
            "¿Otra vez tú? El reactor no se va a reparar solo, ¿eh?",
            "Ya te lo conté todo. Ve a picar algo. Lo que sea.",
            "Si me sigues hablando te voy a cobrar en Rumores.",
            "Me estás gastando la batería social. Y soy un cubo, tengo poca.",
            "Hay zombies ahí fuera esperándote. Me caen mejor que tú ahora mismo."};
    private static final String[] MOLESTO_PROPIO = {
            null, "Tome otro número. Sigue siendo el 7.", "Esto lo voy a poner en portada: 'Jugador sin vida social'.",
            "Si no vas a barrer, quítate de en medio.", null, null, null,
            "¿No tienes un reactor que reparar? Yo estoy muy ocupado siendo un cubo.",
            "B-basta, me pones nerviosa...", "Según mis cálculos, llevas un 300% más de tiempo hablando conmigo que picando.",
            "BIP. INTERACCIÓN REPETIDA DETECTADA. INICIANDO PROTOCOLO DE IGNORAR.", "Si tienes tanto tiempo libre, ayúdame a arar.",
            "MIAU.", "Lo siento, mi corazón ya pertenece a otro cubo.", "Toma un billete y vete. Bueno, no te lo doy, pero imagínalo.",
            "Le ruego que se retire. Con elegancia, a poder ser.", "¡Fuera de mi cocina! ¡Aquí solo entra gente con gorro!",
            "Tu insistencia me resulta... sospechosa. Te estoy vigilando.",
            "No pido canciones. Ni aunque me pagues en Rumores. Bueno... depende de cuántos."};

    private static final TrackedData<Integer> TIPO = DataTracker.registerData(GatoCuboEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private BlockPos casa = null;
    private int paso = 0;
    private int espera = 40;

    public GatoCuboEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        setPersistent();
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(TIPO, RECEPCIONISTA);
    }

    public int getTipo() { return dataTracker.get(TIPO); }
    public boolean esVendedor() { int t = getTipo(); return t >= VEND_PASIVAS && t <= VEND_MINERALES; }

    public void configurar(int tipo, BlockPos casa) {
        if (tipo == BECARIO) tipo = RECEPCIONISTA; // el becario es anónimo: nadie lo ha visto nunca
        dataTracker.set(TIPO, tipo);
        this.casa = casa.toImmutable();
        setCustomName(Text.literal(NOMBRES[tipo]).formatted(colorNombre()));
        setCustomNameVisible(true);
    }

    public Formatting colorNombre() {
        int t = getTipo();
        if (esVendedor()) return Formatting.GOLD;
        if (t == PRINCIPAL) return Formatting.LIGHT_PURPLE;
        if (t == DJ) return Formatting.GREEN;
        return t <= CONSERJE ? Formatting.AQUA : Formatting.WHITE;
    }

    @Override
    protected void initGoals() {
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        goalSelector.add(6, new LookAroundGoal(this));
    }

    // ---------- Patrones de caminata ----------
    private double[] siguientePunto() {
        return switch (getTipo()) {
            case RECEPCIONISTA -> linea(4);
            case ELEGANTE -> linea(3);
            case NERD, CHEF -> linea(2);
            case PERIODISTA -> circulo(4);
            case ANIME -> circulo(3);
            case ROMANTICO -> circulo(2);
            case CONSERJE -> zigzag(4);
            case GRANJERO -> zigzag(6);
            case ROBOT -> cuadrado(4);
            case MILLONARIO -> cuadrado(2);
            case PRINCIPAL -> paseo(3);
            case DETECTIVE -> paseo(5);
            case GATO_GATO -> paseo(7);
            default -> null; // los vendedores se quedan en su puesto
        };
    }
    // ---------- Suelo permitido: madera y lana ----------
    private static boolean esSuelo(net.minecraft.block.BlockState b) {
        return b.isIn(net.minecraft.registry.tag.BlockTags.PLANKS) || b.isIn(net.minecraft.registry.tag.BlockTags.LOGS)
                || b.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_SLABS) || b.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_STAIRS)
                || b.isIn(net.minecraft.registry.tag.BlockTags.WOOL) || b.isIn(net.minecraft.registry.tag.BlockTags.WOOL_CARPETS);
    }

    /** ¿Se puede estar de pie en esta posición? (el bloque de los pies, por si es alfombra/losa, o el de debajo) */
    private boolean sueloValido(BlockPos pies) {
        return esSuelo(getWorld().getBlockState(pies)) || esSuelo(getWorld().getBlockState(pies.down()));
    }

    /** El punto del patrón si es suelo válido; si no, el suelo válido más cercano a él (o null). */
    private BlockPos destinoValido(double x, double y, double z) {
        BlockPos p = BlockPos.ofFloored(x, y, z);
        for (int r = 0; r <= 3; r++)
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = -1; dy <= 1; dy++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                BlockPos q = p.add(dx, dy, dz);
                if (sueloValido(q) && getWorld().getBlockState(q).getCollisionShape(getWorld(), q).isEmpty()
                        || getWorld().getBlockState(q).isIn(net.minecraft.registry.tag.BlockTags.WOOL_CARPETS)) return q;
            }
        return null;
    }

    /** Si se sale de la madera o la lana, vuelve al bloque válido más cercano. */
    private void volverAlSuelo() {
        BlockPos aqui = getBlockPos();
        BlockPos mejor = null;
        double dist = Double.MAX_VALUE;
        for (int dx = -8; dx <= 8; dx++) for (int dz = -8; dz <= 8; dz++) for (int dy = -2; dy <= 2; dy++) {
            BlockPos q = aqui.add(dx, dy, dz);
            if (!sueloValido(q) || !getWorld().getBlockState(q).getCollisionShape(getWorld(), q).isEmpty()
                    && !getWorld().getBlockState(q).isIn(net.minecraft.registry.tag.BlockTags.WOOL_CARPETS)) continue;
            double d = q.getSquaredDistance(aqui);
            if (d < dist) { dist = d; mejor = q; }
        }
        if (mejor != null) getNavigation().startMovingTo(mejor.getX() + 0.5, mejor.getY(), mejor.getZ() + 0.5, 0.9);
    }

    private double[] linea(double r) { return (paso++ % 2 == 0) ? new double[]{r, 0} : new double[]{-r, 0}; }
    private double[] circulo(double r) { double a = (paso++ % 8) * Math.PI / 4; return new double[]{Math.cos(a) * r, Math.sin(a) * r}; }
    private double[] cuadrado(double r) { double[][] c = {{r, r}, {r, -r}, {-r, -r}, {-r, r}}; return c[paso++ % 4]; }
    private double[] zigzag(double r) {
        double[][] z = {{-r, -r / 2}, {-r / 2, r / 2}, {0, -r / 2}, {r / 2, r / 2}, {r, -r / 2}, {r / 2, r / 2}, {0, -r / 2}, {-r / 2, r / 2}};
        return z[paso++ % 8];
    }
    private double[] paseo(double r) { return new double[]{(random.nextDouble() * 2 - 1) * r, (random.nextDouble() * 2 - 1) * r}; }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        if (casa == null) casa = getBlockPos();
        if (getTipo() == DJ) tickDj();
        if (bailando()) {
            tickBaile();
            return;
        }
        if (esVendedor() || getTipo() == DJ) {
            // los vendedores (y el enfermero) se quedan quietos detrás de su puesto; el DJ, en su cabina
            getNavigation().stop();
            setVelocity(0, getVelocity().y, 0);
        } else {
            // Solo caminan sobre madera (tablones, troncos, losas y escaleras de madera) o lana / alfombras
            if (isOnGround() && !sueloValido(getBlockPos())) {
                if (age % 10 == 0) volverAlSuelo();
            } else {
                var camino = getNavigation().getCurrentPath();
                if (camino != null && !camino.isFinished() && !sueloValido(camino.getCurrentNodePos())) getNavigation().stop();
                if (getNavigation().isIdle() && --espera <= 0) {
                    double[] p = siguientePunto();
                    if (p != null) {
                        BlockPos destino = destinoValido(casa.getX() + p[0], casa.getY(), casa.getZ() + p[1]);
                        if (destino != null) getNavigation().startMovingTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5, 0.8);
                    }
                    espera = 30 + random.nextInt(40);
                }
            }
        }
    }

    // ---------- DJ: bucle de "Dj espontaneo", canciones y saltitos ----------
    private int cancion = -1;
    private long finCancion = 0, proximoBucle = 0;

    public int getCancion() { return cancion; }
    public long getFinCancion() { return finCancion; }

    public void empezarCancion(int i, long fin) {
        cancion = i;
        finCancion = fin;
    }

    private void tickDj() {
        var w = (net.minecraft.server.world.ServerWorld) getWorld();
        long ahora = w.getTime();
        if (cancion >= 0) {
            if (ahora >= finCancion) {
                cancion = -1;
                proximoBucle = ahora + 60;     // un respiro antes de volver a improvisar
                return;
            }
            // salta despacio para animar al público
            if (age % 30 == 0 && isOnGround()) {
                setVelocity(0, 0.36, 0);
                velocityModified = true;
            }
            if (age % 10 == 0) w.spawnParticles(net.minecraft.particle.ParticleTypes.NOTE, getX(), getY() + 1.2, getZ(), 1, 0.4, 0.2, 0.4, 1);
        } else if (ahora >= proximoBucle) {
            boolean alguien = !w.getPlayers(p -> p.squaredDistanceTo(this) < 40 * 40).isEmpty();
            if (alguien) {
                w.playSound(null, getX(), getY(), getZ(), com.centrodesinformacion.desinformados.ModSounds.DJ_ESPONTANEO,
                        net.minecraft.sound.SoundCategory.RECORDS, com.centrodesinformacion.desinformados.tienda.Dj.VOLUMEN, 1f);
                proximoBucle = ahora + com.centrodesinformacion.desinformados.tienda.Dj.DURACION_ESPONTANEO + 10;
            } else {
                proximoBucle = ahora + 40;
            }
        }
    }

    // ---------- Baile: ir a una baldosa de la pista y bailar mientras suene la canción ----------
    private BlockPos pista = null;
    private long bailarHasta = 0;

    public void irABailar(BlockPos baldosa, long hasta) {
        pista = baldosa;
        bailarHasta = hasta;
        getNavigation().stop();
    }

    private boolean bailando() {
        if (pista == null) return false;
        if (getWorld().getTime() >= bailarHasta) {
            pista = null;
            getNavigation().stop();
            return false;
        }
        return true;
    }

    private void tickBaile() {
        double dx = getX() - (pista.getX() + 0.5), dz = getZ() - (pista.getZ() + 0.5);
        if (dx * dx + dz * dz > 0.6 * 0.6 || Math.abs(getY() - (pista.getY() + 1)) > 1.1) {
            if (age % 20 == 0 || getNavigation().isIdle()) {
                getNavigation().startMovingTo(pista.getX() + 0.5, pista.getY() + 1, pista.getZ() + 0.5, 1.0);
            }
            return;
        }
        // ¡a bailar! giros, saltitos y notas
        getNavigation().stop();
        setVelocity(0, getVelocity().y, 0);
        float giro = getYaw() + (((age / 40) % 2 == 0) ? 12f : -12f);
        setYaw(giro);
        setBodyYaw(giro);
        setHeadYaw(giro);
        if ((age + getId()) % 12 == 0 && isOnGround()) {
            setVelocity(0, 0.3, 0);
            velocityModified = true;
        }
        if ((age + getId()) % 25 == 0) {
            ((net.minecraft.server.world.ServerWorld) getWorld()).spawnParticles(net.minecraft.particle.ParticleTypes.NOTE,
                    getX(), getY() + 1.1, getZ(), 1, 0.2, 0.1, 0.2, 1);
        }
    }

    private final java.util.Map<java.util.UUID, Integer> charla = new java.util.HashMap<>();
    private final java.util.Map<java.util.UUID, Long> ultimaFrase = new java.util.HashMap<>();
    public static final int ESPERA_DIALOGO = 140; // 7 segundos entre frase y frase
    /** Solo en el cliente: cuándo le diste clic por última vez (para esconder la burbuja durante la espera). */
    public int ultimoClicCliente = -10000;

    private boolean puedeHablar(PlayerEntity p) {
        long ahora = getWorld().getTime();
        Long antes = ultimaFrase.get(p.getUuid());
        if (antes != null && ahora - antes < ESPERA_DIALOGO) return false;
        ultimaFrase.put(p.getUuid(), ahora);
        return true;
    }

    private void hablar(PlayerEntity a, String linea) {
        int c = colorNombre().getColorValue() != null ? colorNombre().getColorValue() : 0xFFFFFF;
        var paquete = new com.centrodesinformacion.desinformados.network.DialogoPayload(NOMBRES[getTipo()], c, linea);
        for (PlayerEntity p : getWorld().getPlayers()) {
            if ((a != null ? p == a : p.squaredDistanceTo(this) < 100) && p instanceof ServerPlayerEntity sp
                    && net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(sp, com.centrodesinformacion.desinformados.network.DialogoPayload.ID))
                net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(sp, paquete);
        }
        voz();
    }

    /** Tono de voz de cada uno (1 = normal). */
    private static final float[] TONO = {1f, 1.05f, 1f, 0.9f, 0.85f, 1.05f, 0.88f, 0.95f, 1.3f, 1.12f, 0.8f, 0.92f, 1.2f, 0.97f, 0.9f, 0.93f, 1.0f, 0.9f, 0.95f};

    private void voz() {
        int t = getTipo();
        if (t == ANIME) {   // voz propia
            playSound(com.centrodesinformacion.desinformados.ModSounds.KAWAII_VOZ, 1f, 0.97f + random.nextFloat() * 0.06f);
            return;
        }
        if (t == ROBOT) {   // voz propia
            playSound(com.centrodesinformacion.desinformados.ModSounds.ROBOT_VOZ, 1f, 0.97f + random.nextFloat() * 0.06f);
            return;
        }
        playSound(com.centrodesinformacion.desinformados.ModSounds.GATO_VOZ, 1f, TONO[t] * (0.95f + random.nextFloat() * 0.1f));
    }

    /** Frase al azar (la oyen todos los de cerca si 'a' es null). */
    public void decir(ServerPlayerEntity a) {
        String[] l = CONVERSACION[getTipo()];
        hablar(a, l[random.nextInt(l.length)]);
    }

    /** Conversación: 3 frases seguidas y luego "¿no tienes algo mejor que hacer?". */
    private void conversar(ServerPlayerEntity p) {
        int i = charla.getOrDefault(p.getUuid(), 0);
        String[] l = CONVERSACION[getTipo()];
        if (i < l.length) {
            hablar(p, l[i]);
            charla.put(p.getUuid(), i + 1);
        } else {
            if (getTipo() == ANIME) {
                String[] nervios = {"B-basta, me pones nerviosa...", "N-no me mires tanto... b-baka...", "¡Kyaa! ¡Ya te lo conté todo, nya!"};
                hablar(p, nervios[random.nextInt(nervios.length)]);
                return;
            }
            String propio = MOLESTO_PROPIO[getTipo()];
            hablar(p, propio != null && random.nextBoolean() ? propio : MOLESTO[random.nextInt(MOLESTO.length)]);
        }
    }

    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (getWorld().isClient() && age - ultimoClicCliente >= ESPERA_DIALOGO) ultimoClicCliente = age;
        if (!getWorld().isClient() && player instanceof ServerPlayerEntity p) {
            boolean habla = puedeHablar(p);
            if (esVendedor()) {
                if (habla) decir(p);
                if (getTipo() == VEND_CORAZONES) curar(p);
                Tienda.abrir(p, this);
            } else if (getTipo() == DJ) {
                if (habla) conversar(p);
                com.centrodesinformacion.desinformados.tienda.Dj.abrir(p, this);
            } else if (habla) conversar(p);
        }
        return ActionResult.success(getWorld().isClient());
    }

    // ---------- El enfermero cura al hablar con él (cada 2 minutos por jugador) ----------
    private final java.util.Map<java.util.UUID, Long> ultimaCura = new java.util.HashMap<>();
    private static final long ESPERA_CURA = 2400;

    private void curar(ServerPlayerEntity p) {
        long ahora = getWorld().getTime();
        Long antes = ultimaCura.get(p.getUuid());
        if (antes != null && ahora - antes < ESPERA_CURA) {
            long seg = (ESPERA_CURA - (ahora - antes)) / 20;
            p.sendMessage(Text.literal("El enfermero está fumando en la puerta... vuelve en " + seg + " s.").formatted(Formatting.GRAY), true);
            return;
        }
        if (p.getHealth() >= p.getMaxHealth()) {
            p.sendMessage(Text.literal("\"Estás perfectamente. Bueno, perfectamente para estar aquí.\"").formatted(Formatting.GRAY), true);
            return;
        }
        ultimaCura.put(p.getUuid(), ahora);
        p.setHealth(p.getMaxHealth());
        p.sendMessage(Text.literal("¡El Enfermero de Corazones te ha curado! (gratis, por esta vez)").formatted(Formatting.RED), true);
        if (getWorld() instanceof net.minecraft.server.world.ServerWorld sw)
            sw.spawnParticles(net.minecraft.particle.ParticleTypes.HEART, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.4, 0.4, 0.4, 0.05);
        playSound(net.minecraft.sound.SoundEvents.ENTITY_CAT_PURR, 1f, 1f);
    }

    // ---------- Inmortales (solo un admin en creativo los puede quitar de un golpe) ----------
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.OUT_OF_WORLD) || source.isOf(DamageTypes.GENERIC_KILL)) return super.damage(source, amount);
        if (source.getAttacker() instanceof PlayerEntity p && p.isCreative()) { discard(); return true; }
        return false;
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean canImmediatelyDespawn(double d) { return false; }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Tipo", getTipo());
        if (casa != null) nbt.putLong("Casa", casa.asLong());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(TIPO, Math.max(RECEPCIONISTA, Math.min(MAX_TIPO, nbt.getInt("Tipo"))));
        if (nbt.contains("Casa")) casa = BlockPos.fromLong(nbt.getLong("Casa"));
    }
}

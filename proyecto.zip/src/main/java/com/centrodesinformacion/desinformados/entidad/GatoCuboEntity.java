package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.tienda.Tienda;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Gato Cubo: los NPC del Centro de Desinformación. Un cubo con la cara del gato del canal.
 * Cada tipo camina con su propio patrón alrededor de su "casa" y dice cosas sarcásticas.
 * Los vendedores se quedan en su puesto y abren la tienda.
 */
public class GatoCuboEntity extends PathAwareEntity {
    public static final int BECARIO = 0, RECEPCIONISTA = 1, PERIODISTA = 2, CONSERJE = 3,
            VEND_PASIVAS = 4, VEND_CORAZONES = 5, VEND_MINERALES = 6,
            PRINCIPAL = 7, ANIME = 8, NERD = 9, ROBOT = 10, GRANJERO = 11, GATO_GATO = 12, ROMANTICO = 13,
            MILLONARIO = 14, ELEGANTE = 15, CHEF = 16, DETECTIVE = 17, DJ = 18,
            CIENTIFICA = 19, FUJOSHI = 20, MADRE = 21, GATITO = 22, FIESTERA = 23, PERRO = 24, PLANO = 25, KATEM = 26;
    public static final int MAX_TIPO = 26;
    public static final String[] IDS = {"becario", "recepcionista", "periodista", "conserje", "pasivas", "corazones", "minerales",
            "principal", "anime", "nerd", "robot", "granjero", "gato", "romantico", "millonario", "elegante", "chef", "detective", "dj",
            "cientifica", "fujoshi", "madre", "gatito", "fiestera", "perro", "plano", "katem"};
    public static final String[] NOMBRES = {"Michi el Becario", "Recepcionista", "Periodista", "Conserje",
            "Mago de las Pasivas", "Enfermero de Corazones", "Minero",
            "El Gato", "Gata Kawaii", "Gato Nerd", "GATO-BOT 3000", "Gato Granjero", "Gato Gato", "Gato Romántico",
            "Gato Millonario", "Gato Elegante", "Chef Michelin", "Detective Bigotes", "DJ Miaumix",
            "Gata Científica", "Gata Fujoshi", "Gata Mamá", "Gatito", "Gata Fiestera", "Gato Perro", "Gato 2D", "Gata Katemcita"};

    /** Para los que no venden: una conversación de 3 frases seguidas (avanza cada vez que le hablas). Vendedores: frases sueltas. */
    private static final String[][] CONVERSACION = {
            {"...", "...", "..."}, // becario: no existe
            {"Bienvenido al Centro de Desinformación. ¿Tiene cita? No. Nadie tiene cita.",
                    "Por favor, tome un número. Todos son el 7. Llevamos así desde 2019.",
                    "Si viene a quejarse del reactor, la ventanilla de quejas está dentro de la tele. Suerte."},
            {"¡Exclusiva! Fuentes que me acabo de inventar confirman que todo va genial.",
                    "Estoy escribiendo un artículo sobre ti. Aún no sé qué has hecho, pero será un escándalo.",
                    "Mi sueño es aprender a imprimir los periódicos que reviven a la gente. Si descubres cómo se hacen, ¡la exclusiva es mía!"},
            {"Alguien ha vuelto a dejar el suelo lleno de tierra. Adivina quién lo barre.",
                    "Barro en zigzag. Es más eficiente. No lo es, pero queda bonito.",
                    "Si ves tinta en el suelo, no fui yo. Fue el becario: lo vi pasar con la libreta goteando."},
            {"¡Pasivas mágicas recién horneadas! Léete el libro y aprendes la habilidad para siempre. Sin devoluciones.",
                    "¿El Fondo de Roca? Carísimo. Es que está roto. Lo encontré en el sótano de un tal Isaac.",
                    "No toques el sombrero. Es mágico. Bueno, es un cono morado, pero me hace sentir mágico."},
            {"Corazones de segunda mano, apenas usados. Uno late un poco raro, pero seguro que se le pasa.",
                    "Precios justos. Justos para mí, quiero decir.",
                    "¿Un tótem? Tiene cara de gato. Aquí todos los tótems tienen cara de gato. No preguntes."},
            {"Minerales recién picados. Bueno, picados hace bastante. Pero picados.",
                    "El diamante no se puede craftear todavía... pero venderlo sí. Qué casualidad.",
                    "¿Te parece caro? Ahí tienes una mina. Y un casino. Tú verás."},
            {"Ah, hola. Bienvenido al Centro de Desinformación. Yo soy el gato que dirige esto. Bueno, que lo intenta.",
                    "La tele es la que suelta las desinformaciones exageradas y cambia el mundo. Yo no la controlo... solo puedo mandaros señales verdes.",
                    "Alguien dañó el Reactor de la Desinformación. Reparadlo antes de que la tele se vuelva más loca. Cuando salga verde, ese soy yo ayudando."},
            {"¡Kyaaa~! ¡Un humano! ¿Sabías que en este centro todos somos gatos? ¡Hasta el Gato Perro! Bueno, él no está seguro, nya~",
                    "Hoy el becario-senpai me saludó desde el pasillo. ¡Kyaaa! Estoy segura de que me notó, nya~",
                    "Si derrotas al jefe final te dibujaré en mi libreta con ojos brillantes. ¡Es una promesa! (no lo es)"},
            {"La Gata Científica dice que somos colegas. Yo digo que es mi ayudante. Lo estamos discutiendo con gráficas.",
                    "Calculé las probabilidades de la tragaperras: el casino gana siempre. Igual voy a jugar ahora.",
                    "Llevo 3 semanas intentando entender la tele. Mi conclusión científica: no me cae bien."},
            {"BIP. BUP. SALUDOS, HUMANO. SOY EL GATO-BOT 3000. MODELO SIN GARANTÍA.",
                    "ANALIZANDO... NIVEL DE DESINFORMACIÓN EN TU CEREBRO: 87%. EXCELENTE. CONTINÚE.",
                    "ERROR 404: EMOCIONES NO ENCONTRADAS. INTENTE APAGARME Y ENCENDERME. NO, ESPERE. NO LO HAGA."},
            {"Buenas, forastero. Antes plantaba árboles, pero se declararon en huelga. Ahora planto quejas.",
                    "Las ovejas de por aquí ya no tienen lana. Las esquilé yo. Fue un accidente. Uno muy largo.",
                    "Si ves un zombie con mis pantalones, no me los robó. Se los presté. Somos amigos."},
            {"Miau.", "Miau miau.", "...miau."},
            {"¿Lo sientes? Es el amor... o el reactor perdiendo radiación. Uno de los dos.",
                    "Le escribí un poema a la Gata Kawaii: 'Tus bigotes son mi wifi, siempre conecto contigo'. Es muy profundo.",
                    "Si alguna vez te sientes solo, recuerda: los Furros siempre quieren abrazarte. Demasiado."},
            {"¿Ves estos billetes? Son de verdad. Bueno, los imprimí yo. Pero con mucho cariño.",
                    "Hice mi fortuna vendiendo rumores. Literalmente. Son la moneda de aquí.",
                    "Te doy 1.000 billetes si me traes un café. Ya, ya sé que no valen nada. Pero son muchos."},
            {"Buenas tardes. Disculpe mi sombrero de copa: es que tengo clase. Y unos bigotes de primera.",
                    "En este centro hay que mantener la compostura. Aunque el reactor explote. Sobre todo si explota.",
                    "La Gata Fujoshi no deja de mirarnos al Gato Romántico y a mí mientras escribe. Me pregunto qué será. Mejor no pregunto."},
            {"¡Bienvenido a mi cocina! Hoy preparo comida podrida al horno. Es la especialidad desde el último cambio.",
                    "El ingrediente secreto es la leche cortada. No te la recomiendo. Pero es secreto.",
                    "Si la comida no te mata, te hace más fuerte. Si te mata, no me pongas reseña."},
            {"Elemental, querido jugador. Alguien dañó el reactor... y no fui yo. Eso ya es una pista.",
                    "Interrogué al becario esta mañana. Sudaba tinta y no paraba de mirar la libreta. Muy sospechoso.",
                    "Mi principal sospechoso es la tele. Tiene antenas. Las antenas son sospechosas."},
            {"¡Yooo! DJ Miaumix en la casa. ¿Quieres una canción? Son 20 Rumores y la pongo ya.",
                    "Cuando suena la música, los gatos se vienen a la pista. Hasta el conserje. Sobre todo el conserje.",
                    "El becario me pidió 'Chichabeba' doce veces ayer. Le cobré las doce."},
            {"Estoy estudiando la estática de la tele. De momento sé que pica, que hace ruido y que no le caigo bien.",
                    "El Gato Nerd dice que es mi colega. Es mi ayudante. Le dejo sujetar los tubos de ensayo vacíos.",
                    "Experimento de hoy: ¿qué pasa si el Gato Perro come comida podrida? Resultado: ladra más fuerte. Fascinante."},
            {"¡Hola! ¿Te gusta el BL? Yo vivo por él. Llevo tres libretas llenas de ships del Centro y voy por la cuarta.",
                    "El Gato Romántico y el Gato Elegante son MI ship. Las miradas, el sombrero, la tensión... *suspira* Ya voy por el capítulo 14.",
                    "El DJ y el Conserje se miraron tres segundos en la pista de baile. TRES. Nadie me va a convencer de que ahí no hay algo."},
            {"¿Has visto a mi hijo? Pequeñito, con bigotes... ah, está detrás de mí. Siempre está detrás de mí.",
                    "Le digo que no se acerque a la tele, pero la Gata Fiestera le enseñó a bailar con la estática.",
                    "¿Has comido? Te veo muy delgado. Toma... no, espera, la comida está podrida desde el último cambio. Mejor no."},
            {"¡Hola! ¡Mi mamá dice que no hable con extraños! ...¿Tú eres un extraño?",
                    "El Gato Perro es mi mejor amigo. Dice guau. ¡Yo también sé decir guau! ¡GUAU!",
                    "De mayor quiero ser como El Gato. O como el DJ. ¡O como la tele! La tele es genial, hace cosas."},
            {"¡Uuuh! ¿Oyes la música? ¿No? Yo tampoco, pero hay que estar lista por si empieza.",
                    "DJ Miaumix es mi ídolo. Cuando pone música. Cuando no, es solo un gato con gafas de sol.",
                    "Llevo bailando desde que llegué al Centro. No sé cuándo fue eso. ¿Qué día es hoy?"},
            {"Guau.", "Guau guau.", "¡Guau! *mueve la cola*"},
            {"Hola. Sí, soy plano. No, no me pasó nada. Nací así. En una servilleta.",
                    "Alguien me dibujó y cobré vida. No voy a decir quién. (Fue el becario.)",
                    "Si me miras de lado, desaparezco. Es mi único truco. Mira... ¿Ves? No ves nada. Ese es el truco."},
            {"¡Hola! Soy Katemcita. ¿Te gusta cómo quedó el Centro? Lo decoré yo: los cuadros, la pista de baile, los gatitos de adorno... Todo. La tele no. La tele apareció sola y me arruinó la paleta de colores.",
                    "También hago las miniaturas del canal. Si ves una cara de sorpresa enorme y una flecha roja señalando algo, fui yo. La flecha siempre es necesaria.",
                    "Oye... ¿quieres una comisión? Te dibujo lo que sea por 67 dólares. Precio de amigo. Bueno, de conocido. Bueno, es el precio normal."}
    };

    /** Cuando ya te contó todo. */
    private static final String[] MOLESTO = {
            "¿No tienes algo mejor que hacer?",
            "¿Otra vez tú? El reactor no se va a reparar solo, ¿eh?",
            "Ya te lo conté todo. Ve a picar algo. Lo que sea.",
            "Si me sigues hablando te voy a cobrar en Rumores.",
            "Me estás gastando la batería social. Y soy un gato: necesito 16 horas de siesta para recargarla.",
            "Hay zombies ahí fuera esperándote. Me caen mejor que tú ahora mismo."};
    private static final String[] MOLESTO_PROPIO = {
            null, "Tome otro número. Sigue siendo el 7.", "Esto lo voy a poner en portada: 'Jugador sin vida social'.",
            "Si no vas a barrer, quítate de en medio.", null, null, null,
            "¿No tienes un reactor que reparar? Yo estoy muy ocupado mandando señales verdes.",
            "B-basta, me pones nerviosa...", "Según mis cálculos, llevas un 300% más de tiempo hablando conmigo que picando.",
            "BIP. INTERACCIÓN REPETIDA DETECTADA. INICIANDO PROTOCOLO DE IGNORAR.", "Si tienes tanto tiempo libre, ayúdame a arar.",
            "MIAU.", "Lo siento, mi corazón ya pertenece a otro gato.", "Toma un billete y vete. Bueno, no te lo doy, pero imagínalo.",
            "Le ruego que se retire. Con elegancia, a poder ser.", "¡Fuera de mi cocina! ¡Aquí solo entra gente con gorro!",
            "Tu insistencia me resulta... sospechosa. Te estoy vigilando.",
            "No pido canciones. Ni aunque me pagues en Rumores. Bueno... depende de cuántos.",
            "Interrumpir a una científica en pleno experimento es un delito. Lo dice la ciencia.",
            "¿Sigues aquí? Perfecto, ¿tú qué opinas del Gato Nerd con el GATO-BOT? Yo creo que tienen química. Literal.",
            "Jovencito, ¿no tienes un reactor que arreglar? Ve, y abrígate.",
            "¡MAMÁÁÁ! ¡Este me sigue hablando!",
            "¡Si no vas a bailar, no tapes la pista!",
            "Guau.",
            "Me estás aplastando con tanta conversación. Y ya estoy bastante aplastado.",
            "Si no me vas a encargar nada, no me muevas la mesa que se me tuerce la línea."};

    private static final TrackedData<Integer> TIPO = DataTracker.registerData(GatoCuboEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private BlockPos casa = null;
    private int espera = 40;

    public GatoCuboEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        setPersistent();
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, ALCANCE_CAMINO);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(TIPO, RECEPCIONISTA);
    }

    public int getTipo() { return dataTracker.get(TIPO); }
    public boolean esVendedor() { int t = getTipo(); return t >= VEND_PASIVAS && t <= VEND_MINERALES; }

    public void configurar(int tipo, BlockPos casa) {
        if (tipo == BECARIO) tipo = RECEPCIONISTA; // el becario es anónimo: nadie lo ha visto nunca
        dataTracker.set(TIPO, tipo);
        this.casa = casa.toImmutable();
        setCustomName(Text.literal(NOMBRES[tipo]).formatted(colorNombre()));
        setCustomNameVisible(true);
    }

    public Formatting colorNombre() {
        int t = getTipo();
        if (esVendedor()) return Formatting.GOLD;
        if (t == PRINCIPAL) return Formatting.LIGHT_PURPLE;
        if (t == DJ) return Formatting.GREEN;
        return t <= CONSERJE ? Formatting.AQUA : Formatting.WHITE;
    }

    @Override
    protected void initGoals() {
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        goalSelector.add(6, new LookAroundGoal(this));
    }

    // ---------- Suelo permitido: madera y lana (y las luces del suelo de los pisos de arriba) ----------
    private static boolean esSuelo(net.minecraft.block.BlockState b) {
        return b.isOf(com.centrodesinformacion.desinformados.ModBloques.LUZ_INDUSTRIAL) || b.isOf(com.centrodesinformacion.desinformados.ModBloques.PISTA_BAILE)
                || b.isIn(net.minecraft.registry.tag.BlockTags.PLANKS) || b.isIn(net.minecraft.registry.tag.BlockTags.LOGS)
                || b.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_SLABS) || b.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_STAIRS)
                || b.isIn(net.minecraft.registry.tag.BlockTags.WOOL) || b.isIn(net.minecraft.registry.tag.BlockTags.WOOL_CARPETS);
    }

    /** ¿Se puede estar de pie en esta posición? (el bloque de los pies, por si es alfombra/losa, o el de debajo) */
    private boolean sueloValido(BlockPos pies) {
        return esSuelo(getWorld().getBlockState(pies)) || esSuelo(getWorld().getBlockState(pies.down()));
    }

    /** ¿Cabe de pie aquí? (aire o alfombra en los pies y aire en la cabeza) */
    private boolean cabe(BlockPos q) {
        var w = getWorld();
        boolean pies = w.getBlockState(q).getCollisionShape(w, q).isEmpty() || w.getBlockState(q).isIn(net.minecraft.registry.tag.BlockTags.WOOL_CARPETS);
        return pies && w.getBlockState(q.up()).getCollisionShape(w, q.up()).isEmpty();
    }

    /** Sitio donde se puede estar de pie (suelo válido y hueco) cerca de q, ajustando la altura un bloque arriba o abajo. */
    private BlockPos sitioDePie(BlockPos q) {
        for (int dy : new int[]{0, 1, -1}) {
            BlockPos p = q.up(dy);
            if (sueloValido(p) && cabe(p)) return p.toImmutable();
        }
        return null;
    }

    /** El sitio válido más cercano (para rescatar a un gato que ha acabado encima de algo que no puede pisar). */
    private BlockPos sueloMasCercano(int radio) {
        BlockPos aqui = getBlockPos();
        BlockPos mejor = null;
        double dist = Double.MAX_VALUE;
        for (int dx = -radio; dx <= radio; dx++) for (int dz = -radio; dz <= radio; dz++) for (int dy = -2; dy <= 2; dy++) {
            BlockPos q = aqui.add(dx, dy, dz);
            if (!sueloValido(q) || !cabe(q)) continue;
            double d = q.getSquaredDistance(aqui);
            if (d < dist) { dist = d; mejor = q.toImmutable(); }
        }
        return mejor;
    }

    /** Calcula el camino y SOLO lo acepta si todo él va por suelo válido (madera, lana, pista, escaleras...). */
    private boolean caminarA(BlockPos destino, double vel) {
        net.minecraft.entity.ai.pathing.Path camino = getNavigation().findPathTo(destino, 0);
        if (camino == null || !camino.reachesTarget()) return false;
        for (int i = 1; i < camino.getLength(); i++) {
            if (!sueloValido(camino.getNode(i).getBlockPos())) return false;
        }
        return getNavigation().startMovingAlong(camino, vel);
    }

    // ---------- Paseo libre por todo su piso ----------
    private void pasear() {
        BlockPos base = getBlockPos();
        if (casa != null && (Math.abs(base.getY() - casa.getY()) > 2 || base.getSquaredDistance(casa) > 26 * 26)) base = casa;   // muy lejos: vuelve hacia su zona
        for (int i = 0; i < 5; i++) {
            BlockPos q = sitioDePie(base.add(random.nextInt(25) - 12, 0, random.nextInt(25) - 12));
            if (q != null && q.getSquaredDistance(getBlockPos()) > 4 && caminarA(q, 0.8)) return;
        }
    }

    // ---------- Si se atasca o acaba encima de un bloque que no puede pisar, se redirige ----------
    private int rescate = 0;
    private BlockPos objetivoRescate = null;
    private net.minecraft.util.math.Vec3d ultimaPos = null;

    private void rescatar() {
        rescate++;
        if (rescate % 20 == 1) {
            objetivoRescate = sueloMasCercano(10);
            if (objetivoRescate != null)
                getNavigation().startMovingTo(objetivoRescate.getX() + 0.5, objetivoRescate.getY(), objetivoRescate.getZ() + 0.5, 1.0);
        }
        // si andando no sale (encima de un mueble, en un hueco...), da saltitos hacia el suelo bueno
        if (rescate > 40 && objetivoRescate != null && isOnGround() && rescate % 15 == 0) {
            double dx = objetivoRescate.getX() + 0.5 - getX(), dz = objetivoRescate.getZ() + 0.5 - getZ();
            double l = Math.max(0.01, Math.sqrt(dx * dx + dz * dz));
            setVelocity(dx / l * 0.3, 0.42, dz / l * 0.3);
            velocityModified = true;
        }
    }

    /** Lleva un rato andando sin moverse del sitio: cambia de destino. */
    private void comprobarAtasco() {
        if (getNavigation().isIdle()) { ultimaPos = null; return; }
        if (age % 40 != 0) return;
        if (ultimaPos != null && getPos().squaredDistanceTo(ultimaPos) < 0.25 * 0.25) {
            getNavigation().stop();
            espera = 5;
        }
        ultimaPos = getPos();
    }


    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        if (casa == null) casa = getBlockPos();
        if (getTipo() == DJ) tickDj();
        if (getTipo() == FIESTERA && pista == null && age % 60 == 0) buscarPista();
        if (bailando()) {
            tickBaile();
            return;
        }
        if (getTipo() == GATITO && seguirAMama()) { volviendoHasta = 0; return; }
        if (tickVolver()) return;
        if (!esVendedor() && getTipo() != DJ) tickPisos();
        if (tickRuta()) return;                                  // va por las escaleras a otro piso
        if (esVendedor() || getTipo() == DJ) {
            // los vendedores (y el enfermero) se quedan quietos detrás de su puesto; el DJ, en su cabina
            getNavigation().stop();
            setVelocity(0, getVelocity().y, 0);
        } else {
            // Pasean libremente por su piso, pero solo por madera, lana/alfombras, la pista y escaleras de madera
            if (isOnGround() && !sueloValido(getBlockPos())) {
                rescatar();                                       // está encima de algo que no puede pisar
            } else {
                rescate = 0;
                comprobarAtasco();
                if (getNavigation().isIdle() && --espera <= 0) {
                    pasear();
                    espera = 30 + random.nextInt(60);
                }
            }
        }
    }

    // ---------- Cambiar de piso: los gatos van y vienen entre el piso 1 y el 2 por las escaleras ----------
    // (los pisos del Centro están a 7 bloques; el 3 es el casino y en el techo está la tele: ahí no suben)
    public static final double ALCANCE_CAMINO = 48;
    private static final int ALTO_PISO = 7;
    private int proximoPiso = 0;
    private long viajeHasta = 0;
    private BlockPos casaAntes = null;

    private boolean cambiaDePiso() {
        int t = getTipo();
        return t != GATITO && t != FIESTERA && t != DJ && !esVendedor();   // el gatito ya sigue a su mamá; la fiestera vive en la pista
    }

    private void tickPisos() {
        if (!cambiaDePiso() || casa == null) return;
        if (viajeHasta > 0) {
            if (Math.abs(getY() - casa.getY()) < 1.5) { viajeHasta = 0; return; }        // ¡llegó al otro piso!
            if (getWorld().getTime() > viajeHasta || ruta.isEmpty()) {                     // no encontró el camino: se queda donde está
                ruta.clear();
                casa = casaAntes != null && Math.abs(getY() - casaAntes.getY()) < 1.5 ? casaAntes : getBlockPos();
                viajeHasta = 0;
            }
            return;
        }
        if (proximoPiso <= 0) proximoPiso = 600 + random.nextInt(2400);
        if (--proximoPiso > 0 || !isOnGround()) return;
        proximoPiso = 1200 + random.nextInt(2400);                                          // cada 1-3 minutos
        BlockPos aqui = getBlockPos();
        int dy;
        if (hayPiso(aqui, -ALTO_PISO)) dy = -ALTO_PISO;        // hay un piso debajo: estoy en el 2º -> bajo al 1º
        else if (hayPiso(aqui, ALTO_PISO)) dy = ALTO_PISO;     // no hay nada debajo pero sí arriba: estoy en el 1º -> subo al 2º
        else return;                                            // no está en el Centro (o no hay otro piso)
        BlockPos destino = buscarSitio(aqui.up(dy));
        if (destino == null) return;
        var alcance = getAttributeInstance(EntityAttributes.GENERIC_FOLLOW_RANGE);
        if (alcance != null && alcance.getBaseValue() < ALCANCE_CAMINO) alcance.setBaseValue(ALCANCE_CAMINO);
        casaAntes = casa;
        casa = destino;
        viajeHasta = getWorld().getTime() + 1600;              // 80 segundos para llegar
        espera = 20;
        if (!planificar(destino, 0.8)) { casa = casaAntes; viajeHasta = 0; }   // sin escaleras cerca: no viaja
    }

    // ---------- Rutas entre pisos: SIEMPRE por las escaleras ----------
    private final java.util.ArrayDeque<BlockPos> ruta = new java.util.ArrayDeque<>();
    private double velRuta = 0.8;
    private int intentosRuta = 0;

    /**
     * Prepara el camino hasta 'destino'. Si está en otro piso, pasa por las escaleras: entrada del tramo, salida del tramo y destino.
     * Devuelve false si está en otro piso y no hay escaleras cerca (entonces no se mueve).
     */
    private boolean planificar(BlockPos destino, double vel) {
        ruta.clear();
        intentosRuta = 0;
        velRuta = vel;
        int yYo = getBlockPos().getY(), yDest = destino.getY();
        if (Math.abs(yDest - yYo) <= 3) {
            ruta.add(destino.toImmutable());
        } else {
            boolean sube = yDest > yYo;
            BlockPos[] esc = buscarEscalera(sube ? yYo : yDest, getBlockPos());
            if (esc == null) return false;
            if (sube) { ruta.add(esc[0]); ruta.add(esc[1]); }
            else { ruta.add(esc[1]); ruta.add(esc[0]); }
            ruta.add(destino.toImmutable());
        }
        irAlPunto(ruta.peek());
        return true;
    }

    private void irAlPunto(BlockPos q) {
        getNavigation().startMovingTo(q.getX() + 0.5, q.getY(), q.getZ() + 0.5, velRuta);
    }

    /** Sigue la ruta punto a punto. true mientras siga en camino. */
    private boolean tickRuta() {
        if (ruta.isEmpty()) return false;
        BlockPos q = ruta.peek();
        double dx = getX() - (q.getX() + 0.5), dz = getZ() - (q.getZ() + 0.5);
        if (dx * dx + dz * dz < 1.1 * 1.1 && Math.abs(getY() - q.getY()) < 1.2) {     // llegó a este punto
            ruta.poll();
            intentosRuta = 0;
            if (ruta.isEmpty()) { getNavigation().stop(); return false; }
            irAlPunto(ruta.peek());
            return true;
        }
        if (getNavigation().isIdle() && age % 10 == 0) {
            if (++intentosRuta > 30) { ruta.clear(); getNavigation().stop(); return false; }   // imposible: se rinde
            irAlPunto(q);
        } else if (age % 60 == 0) {
            irAlPunto(q);
        }
        return true;
    }

    /**
     * Busca un tramo de escaleras de madera que suba un piso entero empezando a la altura 'yBajo' (donde se está de pie abajo).
     * Devuelve {donde ponerse abajo, delante del primer escalón; donde se sale arriba, en el rellano} o null.
     */
    private BlockPos[] buscarEscalera(int yBajo, BlockPos cerca) {
        BlockPos[] mejor = null;
        double dist = Double.MAX_VALUE;
        BlockPos.Mutable q = new BlockPos.Mutable();
        for (int dx = -26; dx <= 26; dx++) for (int dz = -26; dz <= 26; dz++) {
            q.set(cerca.getX() + dx, yBajo, cerca.getZ() + dz);
            net.minecraft.block.BlockState b = getWorld().getBlockState(q);
            if (!(b.getBlock() instanceof net.minecraft.block.StairsBlock)
                    || b.get(net.minecraft.block.StairsBlock.HALF) != net.minecraft.block.enums.BlockHalf.BOTTOM) continue;
            net.minecraft.util.math.Direction f = b.get(net.minecraft.block.StairsBlock.FACING);
            BlockPos cima = q.toImmutable();
            for (int n = 0; n < ALTO_PISO + 2; n++) {                       // sube escalón a escalón
                BlockPos sig = cima.offset(f).up();
                net.minecraft.block.BlockState sb = getWorld().getBlockState(sig);
                if (!(sb.getBlock() instanceof net.minecraft.block.StairsBlock) || sb.get(net.minecraft.block.StairsBlock.FACING) != f) break;
                cima = sig;
            }
            BlockPos abajo = q.offset(f.getOpposite()).toImmutable(), arriba = cima.offset(f).up();
            int sube = arriba.getY() - yBajo;
            if (sube < ALTO_PISO - 1 || sube > ALTO_PISO + 1 || !libre(abajo) || !libre(arriba)) continue;
            double d = q.getSquaredDistance(cerca);
            if (d < dist) { dist = d; mejor = new BlockPos[]{abajo, arriba}; }
        }
        return mejor;
    }

    /** ¿Hay suelo de madera transitable a 'dy' bloques (alrededor de esta posición)? */
    private boolean hayPiso(BlockPos aqui, int dy) {
        int buenos = 0;
        for (int dx = -3; dx <= 3; dx += 3) for (int dz = -3; dz <= 3; dz += 3) {
            BlockPos q = aqui.add(dx, dy, dz);
            if (esSuelo(getWorld().getBlockState(q.down())) && libre(q)) buenos++;
        }
        return buenos >= 3;
    }

    private boolean libre(BlockPos q) {
        return getWorld().getBlockState(q).getCollisionShape(getWorld(), q).isEmpty()
                && getWorld().getBlockState(q.up()).getCollisionShape(getWorld(), q.up()).isEmpty();
    }

    /** Un sitio al azar del otro piso donde quedarse (suelo de madera, con techo encima: dentro del edificio). */
    private BlockPos buscarSitio(BlockPos base) {
        for (int i = 0; i < 40; i++) {
            BlockPos q = base.add(random.nextInt(25) - 12, 0, random.nextInt(25) - 12);
            if (!esSuelo(getWorld().getBlockState(q.down())) || !libre(q)) continue;
            boolean techo = false;
            for (int y = 2; y <= ALTO_PISO + 1 && !techo; y++) techo = !getWorld().getBlockState(q.up(y)).isAir();
            if (techo) return q.toImmutable();
        }
        return null;
    }

    // ---------- DJ: bucle de "Dj espontaneo", canciones y saltitos ----------
    private int cancion = -1;
    private long finCancion = 0, proximoBucle = 0;

    public int getCancion() { return cancion; }
    public long getFinCancion() { return finCancion; }

    public void empezarCancion(int i, long fin) {
        cancion = i;
        finCancion = fin;
    }

    private void tickDj() {
        var w = (net.minecraft.server.world.ServerWorld) getWorld();
        long ahora = w.getTime();
        if (cancion >= 0) {
            if (ahora >= finCancion) {
                cancion = -1;
                proximoBucle = ahora + 60;     // un respiro antes de volver a improvisar
                return;
            }
            // salta despacio para animar al público
            if (age % 30 == 0 && isOnGround()) {
                setVelocity(0, 0.36, 0);
                velocityModified = true;
            }
            if (age % 10 == 0) w.spawnParticles(net.minecraft.particle.ParticleTypes.NOTE, getX(), getY() + 1.2, getZ(), 1, 0.4, 0.2, 0.4, 1);
        } else if (ahora >= proximoBucle) {
            int r = com.centrodesinformacion.desinformados.tienda.Dj.RADIO_OIDO;
            boolean alguien = !w.getPlayers(p -> p.squaredDistanceTo(this) < r * r).isEmpty();
            if (alguien) {
                w.playSound(null, getX(), getY(), getZ(), com.centrodesinformacion.desinformados.ModSounds.DJ_ESPONTANEO,
                        net.minecraft.sound.SoundCategory.RECORDS, com.centrodesinformacion.desinformados.tienda.Dj.VOLUMEN_BUCLE, 1f);
                proximoBucle = ahora + com.centrodesinformacion.desinformados.tienda.Dj.DURACION_ESPONTANEO + 10;
            } else {
                proximoBucle = ahora + 40;
            }
        }
    }

    // ---------- Baile: ir a una baldosa de la pista y bailar mientras suene la canción ----------
    private BlockPos pista = null;
    private long bailarHasta = 0;

    public void irABailar(BlockPos baldosa, long hasta) {
        if (pista == null && volviendoHasta == 0) {            // apunta dónde estaba para volver cuando acabe la canción
            antesDeBailar = getBlockPos().toImmutable();
            yawAntes = getYaw();
        }
        volviendoHasta = 0;
        ruta.clear();
        pista = baldosa;
        bailarHasta = hasta;
        getNavigation().stop();
    }

    private boolean bailando() {
        if (pista == null) return false;
        if (getWorld().getTime() >= bailarHasta || !getWorld().getBlockState(pista).isOf(com.centrodesinformacion.desinformados.ModBloques.PISTA_BAILE)) {
            pista = null;
            ruta.clear();
            getNavigation().stop();
            if (antesDeBailar != null && getTipo() != FIESTERA) volviendoHasta = getWorld().getTime() + 1600;   // de vuelta a su sitio
            else antesDeBailar = null;
            return false;
        }
        return true;
    }

    // ---------- Al acabar de bailar: volver justo a donde estaba antes ----------
    private BlockPos antesDeBailar = null;
    private float yawAntes = 0;
    private long volviendoHasta = 0;

    /** true mientras va de vuelta (y entonces no hace nada más). */
    private boolean tickVolver() {
        if (volviendoHasta == 0 || antesDeBailar == null) return false;
        double x = antesDeBailar.getX() + 0.5, y = antesDeBailar.getY(), z = antesDeBailar.getZ() + 0.5;
        double d = squaredDistanceTo(x, y, z);
        boolean llego = d < 0.6 * 0.6;
        if (llego || getWorld().getTime() > volviendoHasta) {
            getNavigation().stop();
            ruta.clear();
            if (llego) { setYaw(yawAntes); setBodyYaw(yawAntes); setHeadYaw(yawAntes); }
            else casa = getBlockPos();                          // no pudo volver: se queda en este piso
            antesDeBailar = null;
            volviendoHasta = 0;
            espera = 60;
            return false;
        }
        if (!ruta.isEmpty() || Math.abs(getY() - y) > 3) {      // estaba en otro piso: por las escaleras
            if (ruta.isEmpty() && age % 40 == 0) planificar(antesDeBailar, 0.9);
            tickRuta();
            return true;
        }
        if (getNavigation().isIdle() || age % 40 == 0) getNavigation().startMovingTo(x, y, z, 0.9);
        return true;
    }

    /** La Gata Fiestera se va a la pista de baile más cercana y se queda ahí bailando, haya música o no. */
    private void buscarPista() {
        BlockPos c = casa != null ? casa : getBlockPos();
        BlockPos mejor = null;
        double d = Double.MAX_VALUE;
        for (BlockPos q : BlockPos.iterate(c.add(-16, -4, -16), c.add(16, 4, 16))) {
            if (getWorld().getBlockState(q).isOf(com.centrodesinformacion.desinformados.ModBloques.PISTA_BAILE)
                    && getWorld().getBlockState(q.up()).isAir() && getWorld().getBlockState(q.up(2)).isAir()) {
                double dd = q.getSquaredDistance(c) + random.nextDouble() * 6;
                if (dd < d) { d = dd; mejor = q.toImmutable(); }
            }
        }
        if (mejor != null) irABailar(mejor, getWorld().getTime() + 20L * 60 * 60 * 24);
    }

    /** El Gatito sigue a su mamá (la Gata Mamá más cercana) a todas partes. */
    private java.util.UUID mama = null;

    private boolean seguirAMama() {
        var w = (net.minecraft.server.world.ServerWorld) getWorld();
        GatoCuboEntity m = mama != null && w.getEntity(mama) instanceof GatoCuboEntity g && g.isAlive() ? g : null;
        if (m == null && age % 40 == 0) {
            var cerca = w.getEntitiesByClass(GatoCuboEntity.class, getBoundingBox().expand(24), g -> g.getTipo() == MADRE);
            cerca.sort(java.util.Comparator.comparingDouble(this::squaredDistanceTo));
            if (!cerca.isEmpty()) { m = cerca.get(0); mama = m.getUuid(); }
        }
        if (m == null) return false;
        double d = squaredDistanceTo(m);
        if (d > 48 * 48) { refreshPositionAndAngles(m.getX(), m.getY(), m.getZ(), getYaw(), 0f); return true; }   // se perdió del todo
        if (!ruta.isEmpty() || Math.abs(getY() - m.getY()) > 3) {   // mamá está en otro piso: por las escaleras
            if (ruta.isEmpty() && age % 40 == 0) planificar(m.getBlockPos(), 1.15);
            tickRuta();
            if (!ruta.isEmpty() || Math.abs(getY() - m.getY()) > 3) return true;
        }
        if (d > 2.2 * 2.2) {
            if (age % 10 == 0 || getNavigation().isIdle()) getNavigation().startMovingTo(m, 1.15);
        } else {
            getNavigation().stop();
            getLookControl().lookAt(m, 30f, 30f);
        }
        return true;
    }

    private void tickBaile() {
        double dx = getX() - (pista.getX() + 0.5), dz = getZ() - (pista.getZ() + 0.5);
        if (dx * dx + dz * dz > 0.6 * 0.6 || Math.abs(getY() - (pista.getY() + 1)) > 1.1) {
            if (!ruta.isEmpty() || Math.abs(getY() - (pista.getY() + 1)) > 3) {   // la pista está en otro piso: escaleras
                if (ruta.isEmpty() && age % 40 == 0) planificar(pista.up(), 1.0);
                if (tickRuta() || Math.abs(getY() - (pista.getY() + 1)) > 3) return;
            }
            if (age % 20 == 0 || getNavigation().isIdle()) {
                getNavigation().startMovingTo(pista.getX() + 0.5, pista.getY() + 1, pista.getZ() + 0.5, 1.0);
            }
            return;
        }
        // ¡a bailar! giros, saltitos y notas
        getNavigation().stop();
        setVelocity(0, getVelocity().y, 0);
        float giro = getYaw() + (((age / 40) % 2 == 0) ? 12f : -12f);
        setYaw(giro);
        setBodyYaw(giro);
        setHeadYaw(giro);
        if ((age + getId()) % 12 == 0 && isOnGround()) {
            setVelocity(0, 0.3, 0);
            velocityModified = true;
        }
        if ((age + getId()) % 25 == 0) {
            ((net.minecraft.server.world.ServerWorld) getWorld()).spawnParticles(net.minecraft.particle.ParticleTypes.NOTE,
                    getX(), getY() + 1.1, getZ(), 1, 0.2, 0.1, 0.2, 1);
        }
    }

    private final java.util.Map<java.util.UUID, Integer> charla = new java.util.HashMap<>();
    private final java.util.Map<java.util.UUID, Long> ultimaFrase = new java.util.HashMap<>();
    public static final int ESPERA_DIALOGO = 140; // 7 segundos entre frase y frase
    /** Solo en el cliente: cuándo le diste clic por última vez (para esconder la burbuja durante la espera). */
    public int ultimoClicCliente = -10000;

    private boolean puedeHablar(PlayerEntity p) {
        long ahora = getWorld().getTime();
        Long antes = ultimaFrase.get(p.getUuid());
        if (antes != null && ahora - antes < ESPERA_DIALOGO) return false;
        ultimaFrase.put(p.getUuid(), ahora);
        return true;
    }

    private void hablar(PlayerEntity a, String linea) {
        int c = colorNombre().getColorValue() != null ? colorNombre().getColorValue() : 0xFFFFFF;
        var paquete = new com.centrodesinformacion.desinformados.network.DialogoPayload(NOMBRES[getTipo()], c, linea);
        for (PlayerEntity p : getWorld().getPlayers()) {
            if ((a != null ? p == a : p.squaredDistanceTo(this) < 100) && p instanceof ServerPlayerEntity sp
                    && net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(sp, com.centrodesinformacion.desinformados.network.DialogoPayload.ID))
                net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(sp, paquete);
        }
        voz();
    }

    /** Tono de voz de cada uno (1 = normal). */
    private static final float[] TONO = {1f, 1.05f, 1f, 0.9f, 0.85f, 1.05f, 0.88f, 0.95f, 1.3f, 1.12f, 0.8f, 0.92f, 1.2f, 0.97f, 0.9f, 0.93f, 1.0f, 0.9f, 0.95f, 1.1f, 1.25f, 1.0f, 1.6f, 1.2f, 1.0f, 1.05f, 1.15f};

    private void voz() {
        int t = getTipo();
        if (t == ANIME) {   // voz propia
            playSound(com.centrodesinformacion.desinformados.ModSounds.KAWAII_VOZ, 1f, 0.97f + random.nextFloat() * 0.06f);
            return;
        }
        if (t == ROBOT) {   // voz propia
            playSound(com.centrodesinformacion.desinformados.ModSounds.ROBOT_VOZ, 1f, 0.97f + random.nextFloat() * 0.06f);
            return;
        }
        if (t == PERRO) {   // ladra
            playSound(net.minecraft.sound.SoundEvents.ENTITY_WOLF_AMBIENT, 1f, 0.95f + random.nextFloat() * 0.1f);
            return;
        }
        playSound(com.centrodesinformacion.desinformados.ModSounds.GATO_VOZ, 1f, TONO[t] * (0.95f + random.nextFloat() * 0.1f));
    }

    /** Frase al azar (la oyen todos los de cerca si 'a' es null). */
    public void decir(ServerPlayerEntity a) {
        String[] l = CONVERSACION[getTipo()];
        hablar(a, l[random.nextInt(l.length)]);
    }

    /** Conversación: 3 frases seguidas y luego "¿no tienes algo mejor que hacer?". */
    private void conversar(ServerPlayerEntity p) {
        int i = charla.getOrDefault(p.getUuid(), 0);
        String[] l = CONVERSACION[getTipo()];
        if (i < l.length) {
            hablar(p, l[i]);
            charla.put(p.getUuid(), i + 1);
        } else {
            if (getTipo() == ANIME) {
                String[] nervios = {"B-basta, me pones nerviosa...", "N-no me mires tanto... b-baka...", "¡Kyaa! ¡Ya te lo conté todo, nya!"};
                hablar(p, nervios[random.nextInt(nervios.length)]);
                return;
            }
            String propio = MOLESTO_PROPIO[getTipo()];
            boolean siempre = getTipo() == GATO_GATO || getTipo() == PERRO || getTipo() == GATITO;   // solo saben decir lo suyo
            if (getTipo() == GATO_GATO) propio = new String[]{"Miau.", "Miau miau.", "...miau.", "MIAU."}[random.nextInt(4)];
            if (getTipo() == PERRO) propio = new String[]{"Guau.", "Guau guau.", "¡Guau!", "...guau."}[random.nextInt(4)];
            hablar(p, propio != null && (siempre || random.nextBoolean()) ? propio : MOLESTO[random.nextInt(MOLESTO.length)]);
        }
    }

    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (getWorld().isClient() && age - ultimoClicCliente >= ESPERA_DIALOGO) ultimoClicCliente = age;
        if (!getWorld().isClient() && player instanceof ServerPlayerEntity p) {
            boolean habla = puedeHablar(p);
            if (esVendedor()) {
                if (habla) decir(p);
                if (getTipo() == VEND_CORAZONES) curar(p);
                Tienda.abrir(p, this);
            } else if (getTipo() == DJ) {
                if (habla) conversar(p);
                com.centrodesinformacion.desinformados.tienda.Dj.abrir(p, this);
            } else if (habla) conversar(p);
        }
        return ActionResult.success(getWorld().isClient());
    }

    // ---------- El enfermero cura al hablar con él (cada 2 minutos por jugador) ----------
    private final java.util.Map<java.util.UUID, Long> ultimaCura = new java.util.HashMap<>();
    private static final long ESPERA_CURA = 2400;

    private void curar(ServerPlayerEntity p) {
        long ahora = getWorld().getTime();
        Long antes = ultimaCura.get(p.getUuid());
        if (antes != null && ahora - antes < ESPERA_CURA) {
            long seg = (ESPERA_CURA - (ahora - antes)) / 20;
            p.sendMessage(Text.literal("El enfermero está fumando en la puerta... vuelve en " + seg + " s.").formatted(Formatting.GRAY), true);
            return;
        }
        if (p.getHealth() >= p.getMaxHealth()) {
            p.sendMessage(Text.literal("\"Estás perfectamente. Bueno, perfectamente para estar aquí.\"").formatted(Formatting.GRAY), true);
            return;
        }
        ultimaCura.put(p.getUuid(), ahora);
        p.setHealth(p.getMaxHealth());
        p.sendMessage(Text.literal("¡El Enfermero de Corazones te ha curado! (gratis, por esta vez)").formatted(Formatting.RED), true);
        if (getWorld() instanceof net.minecraft.server.world.ServerWorld sw)
            sw.spawnParticles(net.minecraft.particle.ParticleTypes.HEART, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.4, 0.4, 0.4, 0.05);
        playSound(net.minecraft.sound.SoundEvents.ENTITY_CAT_PURR, 1f, 1f);
    }

    // ---------- Inmortales (solo un admin en creativo los puede quitar de un golpe) ----------
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.OUT_OF_WORLD) || source.isOf(DamageTypes.GENERIC_KILL)) return super.damage(source, amount);
        if (source.getAttacker() instanceof PlayerEntity p && p.isCreative()) { discard(); return true; }
        return false;
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean canImmediatelyDespawn(double d) { return false; }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Tipo", getTipo());
        if (casa != null) nbt.putLong("Casa", casa.asLong());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        var alcance = getAttributeInstance(EntityAttributes.GENERIC_FOLLOW_RANGE);   // los gatos viejos guardaban 16
        if (alcance != null && alcance.getBaseValue() < ALCANCE_CAMINO) alcance.setBaseValue(ALCANCE_CAMINO);
        dataTracker.set(TIPO, Math.max(RECEPCIONISTA, Math.min(MAX_TIPO, nbt.getInt("Tipo"))));
        setCustomName(Text.literal(NOMBRES[getTipo()]).formatted(colorNombre()));   // nombres actualizados
        if (nbt.contains("Casa")) casa = BlockPos.fromLong(nbt.getLong("Casa"));
        if (casa != null && Math.abs(getY() - casa.getY()) > 3) casa = getBlockPos();   // se guardó a medio cambiar de piso
    }
}

package com.centrodesinformacion.desinformados.entidad.papel;

import com.centrodesinformacion.desinformados.entidad.TravensanoEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Travensaño de Papel: un Travensaño dibujado (mal) en la Libreta. Hace lo mismo que el de verdad
 * (se te sube al cuello e invierte los controles), pero es de papel: menos vida y más rápido.
 * Los Travensaños normales que entran en la Libreta se convierten en este.
 */
public class TravensanoPapelEntity extends TravensanoEntity {
    public TravensanoPapelEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return TravensanoEntity.atributos()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 6.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36);
    }

    /** Solo aparece solo en la Libreta (sus biomas); fuera, únicamente por eventos o huevos. */
    @Override
    protected boolean desbloqueadoSolo(WorldAccess world) {
        return false;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ITEM_BOOK_PUT; }
}

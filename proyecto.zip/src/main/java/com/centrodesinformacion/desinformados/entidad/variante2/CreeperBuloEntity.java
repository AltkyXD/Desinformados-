package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.CreeperOscuroEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Creeper Bulo: un Creeper Oscuro que, al crearse, decide en secreto (50 %) si su explosión es un bulo.
 * - Bulo: sisea y "explota" (ruido y mucho humo) con radio 0: ni daño ni bloques rotos. Luego desaparece.
 * - De verdad: es un Creeper Oscuro normal (Reglas le quita un contenedor de corazón a quien alcance, por instanceof).
 * Por fuera son idénticos. El radio sale del NBT "ExplosionRadius" que lee CreeperEntity (el campo es privado).
 */
public class CreeperBuloEntity extends CreeperOscuroEntity {
    private static final String CLAVE = "BuloFalso";

    /** ¿Su explosión es un bulo? Se decide al crearse y se guarda con el mob. */
    private boolean falso;
    /** El radio ya está puesto (al cargar del NBT o en su primer tick). Solo importa en el servidor. */
    private boolean radioListo;

    public CreeperBuloEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
        falso = random.nextBoolean();
    }

    public boolean esBulo() {
        return falso;
    }

    @Override
    public void tick() {
        // Primer tick en el servidor de un creeper recién creado (no cargado de disco): si es bulo, radio 0
        if (!getWorld().isClient() && !radioListo) {
            radioListo = true;
            if (falso) {
                NbtCompound datos = new NbtCompound();
                writeCustomDataToNbt(datos);
                readCustomDataFromNbt(datos);   // se vuelve a leer igual, pero con ExplosionRadius = 0
            }
        }
        super.tick();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean(CLAVE, falso);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        if (nbt.contains(CLAVE)) falso = nbt.getBoolean(CLAVE);
        if (falso) nbt.putByte("ExplosionRadius", (byte) 0);   // radio 0: ni daño ni bloques rotos
        super.readCustomDataFromNbt(nbt);
        radioListo = true;
    }

    /** El creeper "explota" llamando a discard() con dead = true y aún con vida: si era un bulo, solo humo. */
    @Override
    public void remove(RemovalReason reason) {
        if (falso && !getWorld().isClient() && reason == RemovalReason.DISCARDED && dead && getHealth() > 0
                && getWorld() instanceof ServerWorld w) {
            w.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 90, 1.6, 1.0, 1.6, 0.03);
            w.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 40, 1.2, 0.8, 1.2, 0.05);
            w.spawnParticles(ParticleTypes.POOF, getX(), getY() + 0.5, getZ(), 30, 0.8, 0.5, 0.8, 0.05);
            w.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.HOSTILE, 1.5f, 0.7f);
            for (ServerPlayerEntity p : w.getEntitiesByClass(ServerPlayerEntity.class, getBoundingBox().expand(16),
                    j -> j.isAlive() && !j.isSpectator())) {
                p.sendMessage(Text.literal("¡Era un bulo! Mucho ruido y ninguna explosión.").formatted(Formatting.GRAY, Formatting.ITALIC), true);
            }
        }
        super.remove(reason);
    }
}

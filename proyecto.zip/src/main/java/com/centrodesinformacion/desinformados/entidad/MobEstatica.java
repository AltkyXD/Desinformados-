package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

/**
 * Marca para las versiones de estática de los mobs normales (solo viven en el Interior de la Tele).
 * Las mutaciones de los cambios de dificultad no les afectan.
 */
public interface MobEstatica {
    float PROBABILIDAD_SALTO = 0.4f;

    /** Al recibir un golpe, probabilidad de teletransportarse a unos 3 bloques. */
    static void alRecibirGolpe(LivingEntity e) {
        if (!(e.getWorld() instanceof ServerWorld w) || !e.isAlive() || e.getRandom().nextFloat() >= PROBABILIDAD_SALTO) return;
        double ox = e.getX(), oy = e.getY(), oz = e.getZ();
        for (int i = 0; i < 12; i++) {
            double ang = e.getRandom().nextDouble() * Math.PI * 2;
            double x = ox + Math.cos(ang) * 3, z = oz + Math.sin(ang) * 3;
            double y = oy + e.getRandom().nextInt(3) - 1;
            if (e.teleport(x, y, z, false)) {
                w.spawnParticles(ParticleTypes.WHITE_ASH, ox, oy + 1, oz, 30, 0.3, 0.6, 0.3, 0.05);
                w.spawnParticles(ParticleTypes.WHITE_ASH, e.getX(), e.getY() + 1, e.getZ(), 30, 0.3, 0.6, 0.3, 0.05);
                w.playSound(null, e.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 0.7f, 1.8f);
                return;
            }
        }
    }
}

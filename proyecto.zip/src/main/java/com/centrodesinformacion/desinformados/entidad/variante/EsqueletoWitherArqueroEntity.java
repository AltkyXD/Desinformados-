package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/**
 * Esqueleto Wither Arquero: un esqueleto wither con arco. Dispara como un esqueleto; sus flechas salen ardiendo
 * (lo hace el esqueleto wither vanilla) y dan Wither II 5 s al acertar (modificador en ModVariantes).
 */
public class EsqueletoWitherArqueroEntity extends WitherSkeletonEntity {
    public EsqueletoWitherArqueroEntity(EntityType<? extends WitherSkeletonEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Arco en vez de espada de piedra (con el arco en la mano, updateAttackType elige el ataque a distancia). */
    @Override
    protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        setCanPickUpLoot(false);   // que no cambie el arco por una espada del suelo
        // (equipStack de los esqueletos ya recalcula el tipo de ataque)
        if (!getMainHandStack().isOf(Items.BOW)) equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        return r;
    }
}

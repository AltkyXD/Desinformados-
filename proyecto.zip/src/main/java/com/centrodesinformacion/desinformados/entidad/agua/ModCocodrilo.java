package com.centrodesinformacion.desinformados.entidad.agua;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.Difficulty;
import net.minecraft.world.Heightmap;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.biome.BiomeKeys;

/** El Cocodrilo: tipo, atributos, aparición (rara, en el agua de ríos, pantanos y océanos templados/cálidos) y huevo. */
public final class ModCocodrilo {
    private ModCocodrilo() {}

    /** 1,3 x 0,7: caja baja y ancha (el modelo mide ~3,4 bloques de largo, la cola sobresale). */
    public static final EntityType<CocodriloEntity> COCODRILO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("cocodrilo"),
            EntityType.Builder.<CocodriloEntity>create(CocodriloEntity::new, SpawnGroup.MONSTER)
                    .dimensions(1.3f, 0.7f).eyeHeight(0.45f).maxTrackingRange(10).build("cocodrilo"));

    public static final Item HUEVO_COCODRILO = Registry.register(Registries.ITEM, Desinformados.id("cocodrilo_spawn_egg"),
            new SpawnEggItem(COCODRILO, 0x4E6230, 0xD2C68A, new Item.Settings()));

    /** Copia de ModEntidades.pocos (allí es privada del paquete): como mucho {@code max} de este tipo a menos de 64 bloques. */
    private static boolean pocos(ServerWorldAccess mundo, EntityType<?> tipo, BlockPos pos, SpawnReason razon, int max) {
        if (razon != SpawnReason.NATURAL || com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(mundo)) return true;
        return mundo.getEntitiesByClass(Entity.class, new Box(pos).expand(64, 32, 64), e -> e.getType() == tipo).size() < max;
    }

    /** Lo llama Desinformados.onInitialize. */
    public static void inicializar() {
        FabricDefaultAttributeRegistry.register(COCODRILO, CocodriloEntity.atributos());

        // Dentro del agua (con agua también debajo), cerca de la superficie (no en acuíferos de cuevas),
        // 1 de cada 6 intentos y como mucho uno a menos de 64 bloques. Bloqueado hasta su tele azul (CocodriloEntity.canSpawn).
        SpawnRestriction.register(COCODRILO, SpawnLocationTypes.IN_WATER, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && mundo.getFluidState(pos).isIn(FluidTags.WATER) && mundo.getFluidState(pos.down()).isIn(FluidTags.WATER)
                        && pos.getY() >= mundo.getSeaLevel() - 14
                        && random.nextInt(6) == 0
                        && pocos(mundo, tipo, pos, razon, 1));
        // Ríos, pantanos y océanos templados o cálidos (ni fríos ni helados): peso 3, de uno en uno
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.RIVER, BiomeKeys.SWAMP, BiomeKeys.MANGROVE_SWAMP,
                        BiomeKeys.OCEAN, BiomeKeys.DEEP_OCEAN, BiomeKeys.LUKEWARM_OCEAN, BiomeKeys.DEEP_LUKEWARM_OCEAN, BiomeKeys.WARM_OCEAN),
                SpawnGroup.MONSTER, COCODRILO, 3, 1, 1);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(HUEVO_COCODRILO));
    }
}

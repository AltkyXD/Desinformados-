package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/**
 * Altky: cuando te ve se pone a dibujar y de su hoja sale un mob dibujado (mal hecho).
 * Los Furros dibujados son sus favoritos (50 %); el resto, mobs de la Libreta.
 * Tarda 10 segundos entre un dibujo y el siguiente.
 * Con la mutación "altky_tableta" se compra una tableta de dibujo y saca mobs normales (también los del mod).
 */
public class AltkyEntity extends HostileEntity {
    private static final TrackedData<Boolean> DIBUJANDO = DataTracker.registerData(AltkyEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    public static final String TABLETA = "altky_tableta";
    private static final int TIEMPO_DIBUJO = 30;    // 1,5 s dibujando
    private static final int COOLDOWN = 200;        // 10 s antes de soltar otro
    private static final int MAX_VIVOS = 6;

    private final List<UUID> dibujos = new ArrayList<>();

    public AltkyEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 12;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(DIBUJANDO, false);
    }

    public boolean isDibujando() {
        return dataTracker.get(DIBUJANDO);
    }

    private boolean tableta() {
        return getWorld().getServer() != null && EstadoServidor.get(getWorld().getServer()).tieneCambio(TABLETA);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new DibujarGoal());
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true)); // solo si te VE
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || age % 20 != 0) return;
        // Lápiz (pluma) normalmente; con la mutación, su tableta nueva
        ItemStack quiere = new ItemStack(tableta() ? Items.BLACK_STAINED_GLASS_PANE : Items.FEATHER);
        if (!getMainHandStack().isOf(quiere.getItem())) {
            equipStack(EquipmentSlot.MAINHAND, quiere);
            setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
        }
    }

    private int vivos(ServerWorld sw) {
        dibujos.removeIf(u -> !(sw.getEntity(u) instanceof LivingEntity e) || !e.isAlive());
        return dibujos.size();
    }

    /** Se queda a distancia, dibuja y suelta el dibujo. */
    private class DibujarGoal extends Goal {
        private int espera = 30;
        private int dibujando = 0;

        DibujarGoal() { setControls(EnumSet.of(Control.MOVE, Control.LOOK)); }

        @Override
        public boolean canStart() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean shouldContinue() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive() && !(t instanceof PlayerEntity p && (p.isCreative() || p.isSpectator()));
        }

        @Override
        public void stop() {
            dibujando = 0;
            dataTracker.set(DIBUJANDO, false);
        }

        @Override
        public boolean shouldRunEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity t = getTarget();
            if (t == null || !(getWorld() instanceof ServerWorld sw)) return;
            getLookControl().lookAt(t, 30f, 30f);
            boolean ve = getVisibilityCache().canSee(t);
            double dist = distanceTo(t);

            if (dibujando > 0) {
                getNavigation().stop();
                dibujando--;
                Vec3d hoja = getPos().add(getRotationVector().multiply(0.7)).add(0, 1.1, 0);
                if (dibujando % 4 == 0) {
                    if (tableta()) {
                        sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, hoja.x, hoja.y, hoja.z, 3, 0.15, 0.1, 0.15, 0.02);
                        sw.spawnParticles(ParticleTypes.END_ROD, hoja.x, hoja.y, hoja.z, 1, 0.1, 0.1, 0.1, 0.01);
                    } else {
                        sw.spawnParticles(ParticleTypes.SQUID_INK, hoja.x, hoja.y, hoja.z, 2, 0.12, 0.05, 0.12, 0.005);
                    }
                }
                if (dibujando % 10 == 0) {
                    sw.playSound(null, getBlockPos(), tableta() ? SoundEvents.BLOCK_STONE_BUTTON_CLICK_ON : SoundEvents.ITEM_BOOK_PAGE_TURN,
                            SoundCategory.HOSTILE, 0.8f, 0.8f + random.nextFloat() * 0.6f);
                }
                if (dibujando == 0) {
                    soltarDibujo(sw, t);
                    dataTracker.set(DIBUJANDO, false);
                    espera = COOLDOWN;
                }
                return;
            }
            // Mantiene la distancia mientras te mira
            if (dist > 14 || !ve) {
                getNavigation().startMovingTo(t, 1.0);
            } else if (dist < 6) {
                Vec3d lejos = getPos().subtract(t.getPos()).multiply(1, 0, 1);
                lejos = lejos.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : lejos.normalize();
                Vec3d destino = getPos().add(lejos.multiply(5));
                getNavigation().startMovingTo(destino.x, destino.y, destino.z, 1.15);
            } else {
                getNavigation().stop();
            }
            if (espera > 0) espera--;
            if (espera == 0 && ve && dist <= 20 && vivos(sw) < MAX_VIVOS) {
                dibujando = TIEMPO_DIBUJO;
                dataTracker.set(DIBUJANDO, true);
            }
        }
    }

    // ------------------------------------------------------------ qué dibuja

    private static final List<EntityType<? extends MobEntity>> LIBRETA = List.of(
            ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ESQUELETO_DIBUJO, ModEntidades.CREEPER_DIBUJO,
            ModEntidades.ARANA_DIBUJO, ModEntidades.GARABATO);

    private static final List<EntityType<? extends MobEntity>> NORMALES = List.of(
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.SPIDER,
            ModEntidades.ZOMBIE_NARANJA, ModEntidades.CUBO_BLANCO, ModEntidades.CREEPER_OSCURO, ModEntidades.TRAVENSANO,
            ModEntidades.CREEPER_FUEGO, ModEntidades.CUBO_ROJO, ModEntidades.ESQUELETO_RAFAGA, ModEntidades.GARABATO);

    private EntityType<? extends MobEntity> elegir() {
        boolean tab = tableta();
        if (random.nextFloat() < 0.5f) return tab ? ModEntidades.FURRO : ModEntidades.FURRO_DIBUJO; // sus favoritos
        List<EntityType<? extends MobEntity>> lista = tab ? NORMALES : LIBRETA;
        return lista.get(random.nextInt(lista.size()));
    }

    private void soltarDibujo(ServerWorld sw, LivingEntity objetivo) {
        MobEntity mob = elegir().create(sw);
        if (mob == null) return;
        Vec3d frente = getRotationVector().multiply(1, 0, 1);
        frente = frente.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : frente.normalize();
        Vec3d pos = getPos().add(frente.multiply(1.6));
        BlockPos bp = BlockPos.ofFloored(pos);
        if (!sw.getBlockState(bp).getCollisionShape(sw, bp).isEmpty() || !sw.getBlockState(bp.up()).getCollisionShape(sw, bp.up()).isEmpty()) {
            pos = getPos();
        }
        mob.refreshPositionAndAngles(pos.x, getY(), pos.z, getYaw(), 0f);
        mob.initialize(sw, sw.getLocalDifficulty(BlockPos.ofFloored(pos)), SpawnReason.MOB_SUMMONED, null);
        mob.addCommandTag(Mobs.MARCA_EVENTO);   // existe aunque su tipo esté bloqueado
        mob.setTarget(objetivo);
        sw.spawnEntity(mob);
        dibujos.add(mob.getUuid());

        if (tableta()) {
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, mob.getX(), mob.getBodyY(0.5), mob.getZ(), 25, 0.3, 0.6, 0.3, 0.1);
            sw.playSound(null, mob.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.HOSTILE, 1f, 0.7f);
        } else {
            sw.spawnParticles(ParticleTypes.POOF, mob.getX(), mob.getBodyY(0.5), mob.getZ(), 15, 0.3, 0.6, 0.3, 0.02);
            sw.spawnParticles(ParticleTypes.SQUID_INK, mob.getX(), mob.getBodyY(0.5), mob.getZ(), 10, 0.3, 0.6, 0.3, 0.02);
            sw.playSound(null, mob.getBlockPos(), SoundEvents.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, SoundCategory.HOSTILE, 1f, 1f);
        }
    }
}

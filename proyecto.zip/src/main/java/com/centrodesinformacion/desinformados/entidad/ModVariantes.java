package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Danio;
import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.variante.AbejaAsesinaEntity;
import com.centrodesinformacion.desinformados.entidad.variante.AhogadoPescadorEntity;
import com.centrodesinformacion.desinformados.entidad.variante.AranaTejedoraEntity;
import com.centrodesinformacion.desinformados.entidad.variante.BlazeHeladoEntity;
import com.centrodesinformacion.desinformados.entidad.variante.BrujaInfluencerEntity;
import com.centrodesinformacion.desinformados.entidad.variante.CreeperSaltarinEntity;
import com.centrodesinformacion.desinformados.entidad.variante.EndermanBromistaEntity;
import com.centrodesinformacion.desinformados.entidad.variante.EsqueletoFrancotiradorEntity;
import com.centrodesinformacion.desinformados.entidad.variante.EsqueletoWitherArqueroEntity;
import com.centrodesinformacion.desinformados.entidad.variante.PolloBombaEntity;
import com.centrodesinformacion.desinformados.entidad.variante.SlimeViralEntity;
import com.centrodesinformacion.desinformados.entidad.variante.VacaLocaEntity;
import com.centrodesinformacion.desinformados.entidad.variante.ZombieLadronEntity;
import com.centrodesinformacion.desinformados.entidad.variante.ZombiePeriodistaEntity;
import com.centrodesinformacion.desinformados.entidad.variante.ZombieTanqueEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.BlazeEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.WitchEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.world.Difficulty;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;

import java.util.List;

/** Las 15 variantes de mobs: tipos, atributos, aparición natural y huevos. */
public final class ModVariantes {
    private ModVariantes() {}

    // =============================== Tipos ===============================

    public static final EntityType<ZombiePeriodistaEntity> ZOMBIE_PERIODISTA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_periodista"),
            EntityType.Builder.<ZombiePeriodistaEntity>create(ZombiePeriodistaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_periodista"));

    public static final EntityType<EsqueletoFrancotiradorEntity> ESQUELETO_FRANCOTIRADOR = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_francotirador"),
            EntityType.Builder.<EsqueletoFrancotiradorEntity>create(EsqueletoFrancotiradorEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.99f).eyeHeight(1.74f).maxTrackingRange(8).build("esqueleto_francotirador"));

    public static final EntityType<AranaTejedoraEntity> ARANA_TEJEDORA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("arana_tejedora"),
            EntityType.Builder.<AranaTejedoraEntity>create(AranaTejedoraEntity::new, SpawnGroup.MONSTER)
                    .dimensions(1.4f, 0.9f).eyeHeight(0.65f).maxTrackingRange(8).build("arana_tejedora"));

    public static final EntityType<CreeperSaltarinEntity> CREEPER_SALTARIN = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_saltarin"),
            EntityType.Builder.<CreeperSaltarinEntity>create(CreeperSaltarinEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_saltarin"));

    public static final EntityType<ZombieLadronEntity> ZOMBIE_LADRON = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_ladron"),
            EntityType.Builder.<ZombieLadronEntity>create(ZombieLadronEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_ladron"));

    public static final EntityType<BrujaInfluencerEntity> BRUJA_INFLUENCER = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("bruja_influencer"),
            EntityType.Builder.<BrujaInfluencerEntity>create(BrujaInfluencerEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.62f).maxTrackingRange(8).build("bruja_influencer"));

    public static final EntityType<SlimeViralEntity> SLIME_VIRAL = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("slime_viral"),
            EntityType.Builder.<SlimeViralEntity>create(SlimeViralEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.52f, 0.52f).eyeHeight(0.325f).maxTrackingRange(8).build("slime_viral"));

    public static final EntityType<VacaLocaEntity> VACA_LOCA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("vaca_loca"),
            EntityType.Builder.<VacaLocaEntity>create(VacaLocaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.9f, 1.4f).eyeHeight(1.3f).maxTrackingRange(8).build("vaca_loca"));

    public static final EntityType<PolloBombaEntity> POLLO_BOMBA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("pollo_bomba"),
            EntityType.Builder.<PolloBombaEntity>create(PolloBombaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.4f, 0.7f).eyeHeight(0.644f).maxTrackingRange(8).build("pollo_bomba"));

    /** x1,4 del zombie normal (el renderer también lo escala x1,4). */
    public static final EntityType<ZombieTanqueEntity> ZOMBIE_TANQUE = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_tanque"),
            EntityType.Builder.<ZombieTanqueEntity>create(ZombieTanqueEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.84f, 2.7f).eyeHeight(2.4f).maxTrackingRange(8).build("zombie_tanque"));

    public static final EntityType<EndermanBromistaEntity> ENDERMAN_BROMISTA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("enderman_bromista"),
            EntityType.Builder.<EndermanBromistaEntity>create(EndermanBromistaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 2.9f).eyeHeight(2.55f).maxTrackingRange(8).build("enderman_bromista"));

    public static final EntityType<AbejaAsesinaEntity> ABEJA_ASESINA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("abeja_asesina"),
            EntityType.Builder.<AbejaAsesinaEntity>create(AbejaAsesinaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.7f, 0.6f).eyeHeight(0.3f).maxTrackingRange(8).build("abeja_asesina"));

    /** Sin makeFireImmune a propósito: es de hielo, el fuego le hace daño. */
    public static final EntityType<BlazeHeladoEntity> BLAZE_HELADO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("blaze_helado"),
            EntityType.Builder.<BlazeHeladoEntity>create(BlazeHeladoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).maxTrackingRange(8).build("blaze_helado"));

    public static final EntityType<EsqueletoWitherArqueroEntity> ESQUELETO_WITHER_ARQUERO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_wither_arquero"),
            EntityType.Builder.<EsqueletoWitherArqueroEntity>create(EsqueletoWitherArqueroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.7f, 2.4f).eyeHeight(2.1f).makeFireImmune().maxTrackingRange(8).build("esqueleto_wither_arquero"));

    public static final EntityType<AhogadoPescadorEntity> AHOGADO_PESCADOR = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("ahogado_pescador"),
            EntityType.Builder.<AhogadoPescadorEntity>create(AhogadoPescadorEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("ahogado_pescador"));

    // =============================== Huevos ===============================

    private static Item huevo(String id, EntityType<? extends MobEntity> tipo, int base, int manchas) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, base, manchas, new Item.Settings()));
    }

    public static final Item HUEVO_ZOMBIE_PERIODISTA = huevo("zombie_periodista", ZOMBIE_PERIODISTA, 0xC8B48A, 0x5E7A5A);
    public static final Item HUEVO_ESQUELETO_FRANCOTIRADOR = huevo("esqueleto_francotirador", ESQUELETO_FRANCOTIRADOR, 0xD8D4C4, 0x4E5A2E);
    public static final Item HUEVO_ARANA_TEJEDORA = huevo("arana_tejedora", ARANA_TEJEDORA, 0xDADDE2, 0xF07AB4);
    public static final Item HUEVO_CREEPER_SALTARIN = huevo("creeper_saltarin", CREEPER_SALTARIN, 0xC6E03A, 0x5C7A12);
    public static final Item HUEVO_ZOMBIE_LADRON = huevo("zombie_ladron", ZOMBIE_LADRON, 0x1E1E1E, 0xF2F2F2);
    public static final Item HUEVO_BRUJA_INFLUENCER = huevo("bruja_influencer", BRUJA_INFLUENCER, 0xE0399A, 0x6A2C91);
    public static final Item HUEVO_SLIME_VIRAL = huevo("slime_viral", SLIME_VIRAL, 0x3EF2D0, 0xF5F5F5);
    public static final Item HUEVO_VACA_LOCA = huevo("vaca_loca", VACA_LOCA, 0x7A3FA8, 0xD02020);
    public static final Item HUEVO_POLLO_BOMBA = huevo("pollo_bomba", POLLO_BOMBA, 0x333333, 0xF28C1C);
    public static final Item HUEVO_ZOMBIE_TANQUE = huevo("zombie_tanque", ZOMBIE_TANQUE, 0x55595E, 0x3F7A3A);
    public static final Item HUEVO_ENDERMAN_BROMISTA = huevo("enderman_bromista", ENDERMAN_BROMISTA, 0x2A1238, 0x4CE04C);
    public static final Item HUEVO_ABEJA_ASESINA = huevo("abeja_asesina", ABEJA_ASESINA, 0x151515, 0xD81E1E);
    public static final Item HUEVO_BLAZE_HELADO = huevo("blaze_helado", BLAZE_HELADO, 0xA8E4F5, 0xFFFFFF);
    public static final Item HUEVO_ESQUELETO_WITHER_ARQUERO = huevo("esqueleto_wither_arquero", ESQUELETO_WITHER_ARQUERO, 0x1C1C1C, 0x9B3BD6);
    public static final Item HUEVO_AHOGADO_PESCADOR = huevo("ahogado_pescador", AHOGADO_PESCADOR, 0x3C8C8C, 0xF2CC1D);

    private static final List<Item> HUEVOS = List.of(HUEVO_ZOMBIE_PERIODISTA, HUEVO_ESQUELETO_FRANCOTIRADOR, HUEVO_ARANA_TEJEDORA,
            HUEVO_CREEPER_SALTARIN, HUEVO_ZOMBIE_LADRON, HUEVO_BRUJA_INFLUENCER, HUEVO_SLIME_VIRAL, HUEVO_VACA_LOCA, HUEVO_POLLO_BOMBA,
            HUEVO_ZOMBIE_TANQUE, HUEVO_ENDERMAN_BROMISTA, HUEVO_ABEJA_ASESINA, HUEVO_BLAZE_HELADO, HUEVO_ESQUELETO_WITHER_ARQUERO,
            HUEVO_AHOGADO_PESCADOR);

    // =============================== Aparición ===============================

    /** Abeja Asesina: solo en bosques, llanuras, praderas y cerezos. */
    private static boolean biomaDeAbejas(RegistryEntry<Biome> b) {
        return b.isIn(BiomeTags.IS_FOREST) || b.matchesKey(BiomeKeys.PLAINS) || b.matchesKey(BiomeKeys.SUNFLOWER_PLAINS)
                || b.matchesKey(BiomeKeys.FLOWER_FOREST) || b.matchesKey(BiomeKeys.MEADOW) || b.matchesKey(BiomeKeys.CHERRY_GROVE);
    }

    /** Lo llama Desinformados.onInitialize, justo después de ModEntidades.inicializar(). */
    public static void inicializar() {
        // ---------- Atributos ----------
        FabricDefaultAttributeRegistry.register(ZOMBIE_PERIODISTA, ZombiePeriodistaEntity.atributos());
        FabricDefaultAttributeRegistry.register(ESQUELETO_FRANCOTIRADOR, EsqueletoFrancotiradorEntity.atributos());
        FabricDefaultAttributeRegistry.register(ARANA_TEJEDORA, SpiderEntity.createSpiderAttributes());
        FabricDefaultAttributeRegistry.register(CREEPER_SALTARIN, CreeperEntity.createCreeperAttributes());
        FabricDefaultAttributeRegistry.register(ZOMBIE_LADRON, net.minecraft.entity.mob.ZombieEntity.createZombieAttributes());
        FabricDefaultAttributeRegistry.register(BRUJA_INFLUENCER, WitchEntity.createWitchAttributes());
        FabricDefaultAttributeRegistry.register(SLIME_VIRAL, HostileEntity.createHostileAttributes());
        FabricDefaultAttributeRegistry.register(VACA_LOCA, VacaLocaEntity.atributos());
        FabricDefaultAttributeRegistry.register(POLLO_BOMBA, ChickenEntity.createChickenAttributes());
        FabricDefaultAttributeRegistry.register(ZOMBIE_TANQUE, ZombieTanqueEntity.atributos());
        FabricDefaultAttributeRegistry.register(ENDERMAN_BROMISTA, EndermanEntity.createEndermanAttributes());
        FabricDefaultAttributeRegistry.register(ABEJA_ASESINA, AbejaAsesinaEntity.atributos());
        FabricDefaultAttributeRegistry.register(BLAZE_HELADO, BlazeEntity.createBlazeAttributes());
        FabricDefaultAttributeRegistry.register(ESQUELETO_WITHER_ARQUERO, AbstractSkeletonEntity.createAbstractSkeletonAttributes());
        FabricDefaultAttributeRegistry.register(AHOGADO_PESCADOR, DrownedEntity.createDrownedAttributes());

        // ---------- Reglas de aparición (todas bloqueadas hasta su tele azul: ver canSpawn de cada clase) ----------
        var overworld = BiomeSelectors.foundInOverworld();
        var nether = BiomeSelectors.foundInTheNether();

        // Lugares oscuros (superficie de noche o cuevas)
        SpawnRestriction.register(ZOMBIE_PERIODISTA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ZOMBIE_PERIODISTA, 12, 1, 2);

        SpawnRestriction.register(ESQUELETO_FRANCOTIRADOR, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ESQUELETO_FRANCOTIRADOR, 10, 1, 2);

        // Araña Tejedora: solo en cuevas (sin cielo a la vista)
        SpawnRestriction.register(ARANA_TEJEDORA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> !m.isSkyVisible(p) && HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ARANA_TEJEDORA, 12, 1, 2);

        SpawnRestriction.register(CREEPER_SALTARIN, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, CREEPER_SALTARIN, 12, 1, 2);

        SpawnRestriction.register(ZOMBIE_LADRON, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ZOMBIE_LADRON, 8, 1, 1);

        SpawnRestriction.register(BRUJA_INFLUENCER, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, BRUJA_INFLUENCER, 6, 1, 1);

        // Slime Viral: en la superficie y de noche (con cualquier luz); no usa la regla de los chunks de slimes
        SpawnRestriction.register(SLIME_VIRAL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos) && mundo.toServerWorld().isNight()
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, SLIME_VIRAL, 10, 1, 2);

        // Vaca Loca: sobre hierba, en la superficie, a cualquier hora (de día menos), pocas
        SpawnRestriction.register(VACA_LOCA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos) && mundo.getBlockState(pos.down()).isOf(Blocks.GRASS_BLOCK)
                        && ModEntidades.aVeces(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, VACA_LOCA, 6, 1, 1);

        // Pollo Bomba: en la superficie, a cualquier hora (de día menos)
        SpawnRestriction.register(POLLO_BOMBA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos) && ModEntidades.aVeces(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, POLLO_BOMBA, 8, 1, 2);

        SpawnRestriction.register(ZOMBIE_TANQUE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ZOMBIE_TANQUE, 6, 1, 1);

        // Enderman Bromista: lugares oscuros del Overworld y el End
        SpawnRestriction.register(ENDERMAN_BROMISTA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ENDERMAN_BROMISTA, 6, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInTheEnd(), SpawnGroup.MONSTER, ENDERMAN_BROMISTA, 8, 1, 2);

        // Abeja Asesina: de día, en la superficie de bosques, llanuras y praderas (y no todas las veces)
        SpawnRestriction.register(ABEJA_ASESINA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && mundo.isSkyVisible(pos) && mundo.toServerWorld().isDay() && random.nextFloat() < 0.3f
                        && biomaDeAbejas(mundo.getBiome(pos))
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 3));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ABEJA_ASESINA, 8, 1, 2);

        // Nether: cualquier bioma (las fortalezas tienen su propia lista y ahí no se puede añadir)
        SpawnRestriction.register(BLAZE_HELADO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnIgnoreLightLevel(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, BLAZE_HELADO, 10, 1, 2);

        SpawnRestriction.register(ESQUELETO_WITHER_ARQUERO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 3));
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, ESQUELETO_WITHER_ARQUERO, 10, 1, 1);

        // Ahogado Pescador: dentro del agua y a oscuras, como los ahogados (1 de cada 8 intentos)
        SpawnRestriction.register(AHOGADO_PESCADOR, SpawnLocationTypes.IN_WATER, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && mundo.getFluidState(pos).isIn(FluidTags.WATER) && mundo.getFluidState(pos.down()).isIn(FluidTags.WATER)
                        && HostileEntity.isSpawnDark(mundo, pos, random) && random.nextInt(8) == 0
                        && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, AHOGADO_PESCADOR, 10, 1, 1);

        // ---------- Huevos en la pestaña de herramientas ----------
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item h : HUEVOS) e.add(h);
        });

        // ---------- Daño de las habilidades ----------
        Danio.agregar((vivo, fuente, cantidad) -> {
            if (!fuente.isIn(DamageTypeTags.IS_PROJECTILE)) return cantidad;
            if (fuente.getAttacker() instanceof EsqueletoFrancotiradorEntity) return cantidad * 1.5f;   // +50 % por flecha
            if (fuente.getAttacker() instanceof EsqueletoWitherArqueroEntity arquero) {
                vivo.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 5 * 20, 1), arquero);   // Wither II 5 s
            }
            return cantidad;
        });
    }
}

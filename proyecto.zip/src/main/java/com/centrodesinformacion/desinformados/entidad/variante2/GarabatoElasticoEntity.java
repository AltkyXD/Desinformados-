package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.GarabatoEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Garabato Elástico: si te toca no te sube 10 bloques: te lanza lejos de él en horizontal
 * (velocidad 4,8 en horizontal + 0,5 hacia arriba = unos 35 bloques, el triple que antes). Una vez cada 3 segundos.
 * Con el desafío "Garabatos furiosos" hace lo mismo que todos los Garabatos (te manda al cielo).
 */
public class GarabatoElasticoEntity extends GarabatoEntity {
    private static final int ESPERA = 60;           // 3 segundos entre lanzamientos (como el Garabato)
    private static final double FUERZA = 4.8;       // horizontal: ~35 bloques con 0,5 de subida (antes 1,6: el triple)
    private static final double SUBIDA = 0.5;

    private int esperaLanzar = 0;

    public GarabatoElasticoEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    @Override
    public void tick() {
        super.tick();
        if (esperaLanzar > 0) esperaLanzar--;
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        if (modoCielo) return super.tryAttack(objetivo);
        if (esperaLanzar > 0 || !(objetivo instanceof ServerPlayerEntity p) || p.isCreative() || p.isSpectator()) return false;
        Vec3d fuera = new Vec3d(p.getX() - getX(), 0, p.getZ() - getZ());
        if (fuera.lengthSquared() < 1.0E-4) fuera = new Vec3d(-Math.sin(Math.toRadians(getYaw())), 0, Math.cos(Math.toRadians(getYaw())));
        fuera = fuera.normalize();
        if (p.hasVehicle()) p.stopRiding();
        p.setVelocity(fuera.x * FUERZA, SUBIDA, fuera.z * FUERZA);
        p.velocityModified = true;
        esperaLanzar = ESPERA;
        ServerWorld mundo = p.getServerWorld();
        mundo.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 12, 0.3, 0.6, 0.3, 0.02);
        mundo.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.6f);
        mundo.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.HOSTILE, 1f, 1.4f);
        p.sendMessage(Text.literal("¡Un Garabato Elástico te ha mandado a la otra punta de la hoja!").formatted(Formatting.RED, Formatting.ITALIC), true);
        return true;
    }
}

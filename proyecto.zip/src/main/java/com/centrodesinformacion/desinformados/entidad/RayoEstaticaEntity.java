package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Rayo de estática que dispara Desinformación (el jefe final): una bola de estática que va en línea recta.
 * No persigue: si corres hacia un lado, la esquivas.
 */
public class RayoEstaticaEntity extends ProjectileEntity {
    private static final int VIDA = 110;
    private float dano = 6f;

    public RayoEstaticaEntity(EntityType<? extends RayoEstaticaEntity> tipo, World mundo) {
        super(tipo, mundo);
        setNoGravity(true);
    }

    /** Dispara un rayo desde 'desde' hacia 'hacia' a 'velocidad' bloques por tick. */
    public static void disparar(ServerWorld w, LivingEntity dueno, Vec3d desde, Vec3d hacia, double velocidad, float dano) {
        RayoEstaticaEntity r = ModEntidades.RAYO_ESTATICA.create(w);
        if (r == null) return;
        r.setOwner(dueno);
        r.dano = dano;
        r.refreshPositionAndAngles(desde.x, desde.y, desde.z, 0f, 0f);
        r.setVelocity(hacia.subtract(desde).normalize().multiply(velocidad));
        w.spawnEntity(r);
        w.playSound(null, desde.x, desde.y, desde.z, com.centrodesinformacion.desinformados.ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 1.2f, 1.6f);
        w.playSound(null, desde.x, desde.y, desde.z, SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 0.8f, 1.8f);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
    }

    @Override
    public void tick() {
        super.tick();
        Vec3d v = getVelocity();
        if (!getWorld().isClient()) {
            HitResult choque = ProjectileUtil.getCollision(this, this::canHit);
            if (choque.getType() != HitResult.Type.MISS) {
                onCollision(choque);
                if (isRemoved()) return;
            }
            if (age > VIDA) { discard(); return; }
        } else {
            // estela de estática
            for (int i = 0; i < 2; i++) {
                getWorld().addParticle(i == 0 ? ParticleTypes.WHITE_ASH : ParticleTypes.ELECTRIC_SPARK,
                        getX() + (random.nextDouble() - 0.5) * 0.4, getY() + 0.25 + (random.nextDouble() - 0.5) * 0.4,
                        getZ() + (random.nextDouble() - 0.5) * 0.4, -v.x * 0.1, -v.y * 0.1, -v.z * 0.1);
            }
        }
        setPosition(getX() + v.x, getY() + v.y, getZ() + v.z);
    }

    @Override
    protected boolean canHit(Entity e) {
        return super.canHit(e) && !(e instanceof JefeTeleEntity) && !e.getCommandTags().contains(JefeTeleEntity.MARCA_ESBIRRO);
    }

    @Override
    protected void onEntityHit(EntityHitResult r) {
        super.onEntityHit(r);
        Entity e = r.getEntity();
        LivingEntity dueno = getOwner() instanceof LivingEntity l ? l : null;
        if (e.damage(getDamageSources().mobProjectile(this, dueno), dano) && e instanceof LivingEntity vivo) {
            vivo.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 1, false, false, true));
        }
    }

    @Override
    protected void onCollision(HitResult r) {
        super.onCollision(r);
        if (getWorld() instanceof ServerWorld w) {
            w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.25, getZ(), 25, 0.4, 0.4, 0.4, 0.05);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.25, getZ(), 10, 0.3, 0.3, 0.3, 0.2);
            w.playSound(null, getX(), getY(), getZ(), com.centrodesinformacion.desinformados.ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 0.8f, 2f);
            discard();
        }
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putFloat("Dano", dano);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("Dano")) dano = nbt.getFloat("Dano");
    }
}

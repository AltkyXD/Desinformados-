package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Kevin: el tanque de Brandon. 20 corazones y el daño de un zombie normal.
 * Siempre se pone delante de Brandon (entre él y tú) y te pega si te acercas.
 * Si Brandon muere, Kevin va a por ti como un zombie cualquiera.
 */
public class KevinEntity extends HostileEntity {
    private UUID brandon;

    public KevinEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 10;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0)      // como un zombie
                .add(EntityAttributes.GENERIC_ARMOR, 2.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.6)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    public void setBrandon(UUID u) { brandon = u; }

    /** Con la mejora de Brandon, Kevin tiene el doble de vida (40 corazones). */
    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || age % 20 != 0) return;
        var vida = getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH);
        double quiere = BrandonEntity.mejorado(getWorld()) ? 80.0 : 40.0;
        if (vida != null && vida.getBaseValue() != quiere) {
            float proporcion = getHealth() / getMaxHealth();
            vida.setBaseValue(quiere);
            setHealth((float) (quiere * proporcion));
        }
    }

    BrandonEntity brandon() {
        if (brandon == null || !(getWorld() instanceof ServerWorld sw)) return null;
        return sw.getEntity(brandon) instanceof BrandonEntity b && b.isAlive() ? b : null;
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new EscudoGoal());
        goalSelector.add(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this, BrandonEntity.class));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Se coloca entre Brandon y su objetivo, a unos pasos delante de él. */
    private class EscudoGoal extends Goal {
        private int golpe = 0;

        EscudoGoal() { setControls(EnumSet.of(Control.MOVE, Control.LOOK)); }

        private LivingEntity objetivo(BrandonEntity b) {
            LivingEntity t = b.getTarget();
            return t != null && t.isAlive() ? t : getTarget();
        }

        @Override
        public boolean canStart() {
            BrandonEntity b = brandon();
            return b != null && objetivo(b) != null;
        }

        @Override
        public boolean shouldContinue() { return canStart(); }

        @Override
        public boolean shouldRunEveryTick() { return true; }

        @Override
        public void tick() {
            BrandonEntity b = brandon();
            if (b == null) return;
            LivingEntity t = objetivo(b);
            if (t == null) return;
            if (getTarget() != t) setTarget(t);
            getLookControl().lookAt(t, 30f, 30f);

            Vec3d hacia = t.getPos().subtract(b.getPos()).multiply(1, 0, 1);
            double separacion = hacia.length();
            hacia = separacion < 0.01 ? new Vec3d(1, 0, 0) : hacia.normalize();
            Vec3d puesto = b.getPos().add(hacia.multiply(Math.min(2.5, separacion * 0.5)));
            if (squaredDistanceTo(puesto) > 0.8) {
                getNavigation().startMovingTo(puesto.x, puesto.y, puesto.z, 1.35);
            } else {
                getNavigation().stop();
            }
            // Si te pones a su alcance, te pega
            if (golpe > 0) golpe--;
            if (golpe == 0 && squaredDistanceTo(t) < 2.6 * 2.6 && getVisibilityCache().canSee(t)) {
                swingHand(Hand.MAIN_HAND);
                tryAttack(t);
                golpe = 20;
            }
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (brandon != null) nbt.putUuid("Brandon", brandon);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("Brandon")) brandon = nbt.getUuid("Brandon");
    }
}

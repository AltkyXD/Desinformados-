package com.centrodesinformacion.desinformados.entidad.papel;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/**
 * Avión de Papel (Libreta). Se comporta como un phantom: vuela en círculos por encima de su objetivo
 * (así sabes que te tiene fichado), baja en picado, te da un golpe flojo (1 corazón) y vuelve a subir.
 * Salen en grupos de 4, tienen poquita vida (2 corazones) y no se queman con el sol.
 */
public class AvionPapelEntity extends PhantomEntity {
    public static final float DANIO = 2f;

    public AvionPapelEntity(EntityType<? extends PhantomEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 4.0);
    }

    /** Es de papel: el sol no lo quema. */
    @Override
    protected boolean isAffectedByDaylight() {
        return false;
    }

    /** Golpe flojo, sea cual sea su tamaño de phantom (el phantom normal pega 6 + tamaño). */
    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = objetivo.damage(getDamageSources().mobAttack(this), DANIO);
        if (golpe) {
            onAttacking(objetivo);
            if (getWorld() instanceof ServerWorld mundo) {
                mundo.spawnParticles(net.minecraft.particle.ParticleTypes.POOF, objetivo.getX(), objetivo.getEyeY() - 0.3, objetivo.getZ(),
                        4, 0.2, 0.2, 0.2, 0.01);
            }
        }
        return golpe;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ITEM_BOOK_PUT; }
}

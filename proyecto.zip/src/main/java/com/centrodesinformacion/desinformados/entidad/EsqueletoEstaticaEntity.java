package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;

/** Esqueleto de estática. */
public class EsqueletoEstaticaEntity extends SkeletonEntity implements MobEstatica {
    public EsqueletoEstaticaEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient()) MobEstatica.alRecibirGolpe(this);
        return r;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.Vida;
import com.centrodesinformacion.desinformados.network.SustoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Interferencia: si te toca, screamer a pantalla completa 5 segundos, pierdes 5 contenedores
 * de corazón durante 60 segundos y él desaparece. 4 corazones, velocidad normal.
 */
public class InterferenciaEntity extends HostileEntity {
    private static final int CORAZONES = 5;
    private static final int SEGUNDOS = 60;

    public InterferenciaEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 8.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.23)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && world.getServer() != null && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        if (!(objetivo instanceof ServerPlayerEntity p) || p.isCreative() || p.isSpectator() || isRemoved()) return false;
        if (ServerPlayNetworking.canSend(p, SustoPayload.ID)) ServerPlayNetworking.send(p, new SustoPayload(100));
        p.getServerWorld().playSound(null, p.getBlockPos(), ModSounds.SUSTO, SoundCategory.HOSTILE, 0.6f, 1f); // lo oyen los de cerca
        Vida.sustoTemporal(p, CORAZONES, SEGUNDOS);
        p.sendMessage(Text.literal("La Interferencia te ha robado 5 corazones durante 1 minuto").formatted(Formatting.DARK_PURPLE), false);
        if (getWorld() instanceof ServerWorld mundo) {
            mundo.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 25, 0.3, 0.7, 0.3, 0.02);
        }
        discard(); // desaparece tras el susto
        return true;
    }
}

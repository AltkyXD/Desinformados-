package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.Vida;
import com.centrodesinformacion.desinformados.network.SustoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Interferencia: si te toca, screamer de 2 segundos, pierdes 5 contenedores de corazón durante
 * 60 segundos y desaparece. Un corazón de alma evita perder los corazones (el susto se ve igual). 4 corazones, rápida. Solo en oscuridad total.
 */
public class InterferenciaEntity extends HostileEntity {
    private static final int CORAZONES = 5;
    private static final int SEGUNDOS = 60;

    public InterferenciaEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 8.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32) // más rápido que un zombie (0.23)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MiedoALaLuzGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && world.getServer() != null && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    // ---------------- Miedo a las antorchas ----------------
    private static final int LUZ_QUE_ASUSTA = 4;
    private static final double DISTANCIA_ANTORCHA = 7;

    /** Le da miedo estar en un sitio iluminado o que alguien cerca lleve una antorcha en la mano. */
    boolean tieneMiedo() {
        if (getWorld().getLightLevel(net.minecraft.world.LightType.BLOCK, getBlockPos()) >= LUZ_QUE_ASUSTA) return true;
        return antorchaCercana() != null;
    }

    @org.jetbrains.annotations.Nullable
    PlayerEntity antorchaCercana() {
        for (PlayerEntity p : getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(DISTANCIA_ANTORCHA), pl -> !pl.isSpectator())) {
            if (llevaAntorcha(p)) return p;
        }
        return null;
    }

    private static boolean llevaAntorcha(PlayerEntity p) {
        for (net.minecraft.item.ItemStack s : new net.minecraft.item.ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (s.isOf(net.minecraft.item.Items.TORCH) || s.isOf(net.minecraft.item.Items.SOUL_TORCH)
                    || s.isOf(net.minecraft.item.Items.LANTERN) || s.isOf(net.minecraft.item.Items.SOUL_LANTERN)) return true;
        }
        return false;
    }

    /** Huye hacia la oscuridad (o lejos de quien lleva la antorcha) mientras tenga miedo. */
    static class MiedoALaLuzGoal extends Goal {
        private final InterferenciaEntity mob;
        private int recalcular = 0;

        MiedoALaLuzGoal(InterferenciaEntity mob) {
            this.mob = mob;
            setControls(java.util.EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override public boolean canStart() { return mob.tieneMiedo(); }
        @Override public boolean shouldContinue() { return mob.tieneMiedo() || !mob.getNavigation().isIdle(); }

        @Override
        public void start() {
            recalcular = 0;
            mob.getWorld().playSound(null, mob.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_ENDERMAN_SCREAM,
                    SoundCategory.HOSTILE, 0.5f, 0.6f);
        }

        @Override
        public void tick() {
            if (--recalcular > 0) return;
            recalcular = 10;
            net.minecraft.util.math.Vec3d destino = null;
            PlayerEntity antorcha = mob.antorchaCercana();
            if (antorcha != null) {
                destino = net.minecraft.entity.ai.NoPenaltyTargeting.findFrom(mob, 14, 6, antorcha.getPos());
            } else {
                int menosLuz = 99;
                for (int i = 0; i < 10; i++) {
                    net.minecraft.util.math.Vec3d v = net.minecraft.entity.ai.FuzzyTargeting.find(mob, 12, 6);
                    if (v == null) continue;
                    int luz = mob.getWorld().getLightLevel(net.minecraft.world.LightType.BLOCK, net.minecraft.util.math.BlockPos.ofFloored(v));
                    if (luz < menosLuz) { menosLuz = luz; destino = v; }
                }
            }
            if (destino != null) mob.getNavigation().startMovingTo(destino.x, destino.y, destino.z, 1.5);
        }
    }

    /** Con "interferencias_clon": 15% de que al recibir daño aparezca otra detrás de quien le pegó. */
    @Override
    public boolean damage(net.minecraft.entity.damage.DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient() && fuente.getAttacker() instanceof ServerPlayerEntity p && getServer() != null
                && com.centrodesinformacion.desinformados.EstadoServidor.get(getServer()).tieneCambio("interferencias_clon") && random.nextFloat() < 0.15f) {
            InterferenciaEntity clon = ModEntidades.INTERFERENCIA.create(getWorld());
            if (clon != null) {
                net.minecraft.util.math.Vec3d atras = p.getRotationVector().multiply(-2.5);
                clon.addCommandTag(Mobs.MARCA_EVENTO);
                clon.refreshPositionAndAngles(p.getX() + atras.x, p.getY(), p.getZ() + atras.z, p.getYaw(), 0f);
                clon.setTarget(p);
                getWorld().spawnEntity(clon);
                getWorld().playSound(null, clon.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 0.8f, 0.5f);
            }
        }
        return r;
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        if (tieneMiedo()) return false; // con luz no se atreve a tocarte
        if (!(objetivo instanceof ServerPlayerEntity p) || p.isCreative() || p.isSpectator() || isRemoved()) return false;
        if (ServerPlayNetworking.canSend(p, SustoPayload.ID)) ServerPlayNetworking.send(p, new SustoPayload(40));
        p.getServerWorld().playSound(null, p.getBlockPos(), ModSounds.SUSTO, SoundCategory.HOSTILE, 0.6f, 1f); // lo oyen los de cerca
        // El susto siempre se ve; un corazón de alma solo evita perder los corazones rojos
        if (Vida.gastarAlma(p)) {
            p.sendMessage(Text.literal("Un corazón de alma ha protegido tus corazones de la Interferencia").formatted(Formatting.AQUA), false);
        } else {
            Vida.sustoTemporal(p, CORAZONES, SEGUNDOS);
            p.sendMessage(Text.literal("La Interferencia te ha robado 5 corazones durante 1 minuto").formatted(Formatting.DARK_PURPLE), false);
        }
        if (getWorld() instanceof ServerWorld mundo) {
            mundo.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 25, 0.3, 0.7, 0.3, 0.02);
        }
        discard(); // desaparece tras el susto
        return true;
    }
}

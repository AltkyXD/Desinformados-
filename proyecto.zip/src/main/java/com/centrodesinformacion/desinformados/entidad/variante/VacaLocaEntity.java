package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Vaca Loca: una vaca hostil. Te persigue en cuanto te ve y embiste (2,5 corazones y mucho empuje).
 * 8 corazones, rápida. No se puede criar (sí ordeñar). No existe en pacífico.
 */
public class VacaLocaEntity extends CowEntity {
    public VacaLocaEntity(EntityType<? extends CowEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return CowEntity.createCowAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_ATTACK_KNOCKBACK, 2.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0);
    }

    /** Sin pánico, sin tentarla con trigo y sin cruzarse: solo embestir. */
    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.25, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    /** Es un monstruo: en pacífico desaparece. */
    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    /** Como los monstruos: puede desaparecer lejos de los jugadores. */
    @Override
    public boolean canImmediatelyDespawn(double distanciaCuadrada) {
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        // Humo por la nariz de vez en cuando (solo partículas)
        if (getTarget() != null && age % 15 == 0 && getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.CLOUD, getX(), getEyeY(), getZ(), 2, 0.2, 0.05, 0.2, 0.01);
        }
    }
}

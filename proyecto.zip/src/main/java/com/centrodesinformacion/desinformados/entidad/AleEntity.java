package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Ale: vida de jugador (10 corazones), te persigue y te pega. Al morir suelta 2 Travensaños (4 con "ale_poderoso"). */
public class AleEntity extends HostileEntity {
    public AleEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.1, true));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.9));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Solo aparece de forma natural después de su tele amarilla ("ale"). */
    @Override
    public boolean canSpawn(net.minecraft.world.WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && (world.getServer() == null
                || !com.centrodesinformacion.desinformados.EstadoServidor.get(world.getServer()).tieneCambio("ale"))) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        setCustomName(Text.literal("Ale"));
        setCustomNameVisible(true);
        if (reason != SpawnReason.NATURAL) setPersistent(); // los que aparecen solos sí pueden desaparecer
        return super.initialize(world, difficulty, reason, data);
    }

    @Override
    public void onDeath(DamageSource fuente) {
        super.onDeath(fuente);
        if (!(getWorld() instanceof ServerWorld mundo)) return;
        int cantidad = com.centrodesinformacion.desinformados.EstadoServidor.get(mundo.getServer()).tieneCambio("ale_poderoso") ? 4 : 2;
        for (int i = 0; i < cantidad; i++) {
            TravensanoEntity t = ModEntidades.TRAVENSANO.create(mundo);
            if (t == null) continue;
            double ang = Math.PI * 2 * i / cantidad;
            t.refreshPositionAndAngles(getX() + Math.cos(ang) * 0.4, getY(), getZ() + Math.sin(ang) * 0.4, random.nextFloat() * 360f, 0f);
            t.setVelocity(Math.cos(ang) * 0.25, 0.3, Math.sin(ang) * 0.25);
            t.initialize(mundo, mundo.getLocalDifficulty(getBlockPos()), SpawnReason.EVENT, null);
            mundo.spawnEntity(t);
        }
        mundo.spawnParticles(ParticleTypes.POOF, getX(), getY() + 1, getZ(), 15, 0.3, 0.5, 0.3, 0.05);
    }

    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_PLAYER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PLAYER_DEATH; }
}

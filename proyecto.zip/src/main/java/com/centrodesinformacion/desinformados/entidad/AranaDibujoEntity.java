package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.world.World;

/** Araña a lápiz. Versión "dibujada" que vive en la Libreta del Becario. */
public class AranaDibujoEntity extends SpiderEntity {
    public AranaDibujoEntity(EntityType<? extends SpiderEntity> type, World world) {
        super(type, world);
    }

    /** Las arañas dibujadas atacan también de día (no se calman con la luz). */
    @Override public float getBrightnessAtEyes() { return 0.0f; }
}

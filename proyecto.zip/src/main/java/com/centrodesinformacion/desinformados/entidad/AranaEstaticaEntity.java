package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;

/** Araña de estática. */
public class AranaEstaticaEntity extends SpiderEntity implements MobEstatica {
    public AranaEstaticaEntity(EntityType<? extends SpiderEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient()) MobEstatica.alRecibirGolpe(this);
        return r;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Furro: perro antropomórfico. Si te ve, te persigue y te abraza.
 * Mientras te abraza: Lentitud IV y medio corazón cada 2 segundos. Puedes pegarle para matarlo.
 * El abrazo dura como máximo 10 segundos; luego descansa 5 segundos antes de volver a por ti.
 */
public class FurroEntity extends ZombieEntity {
    private static final int ABRAZO_MAX = 200;
    private static final int DESCANSO = 100;

    @Nullable private UUID abrazado;
    private int ticksAbrazo;
    private int descanso;

    public FurroEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.9));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true)); // solo si te VE
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && world.getServer() != null && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        // Con "furros_manada", cada furro que aparece solo trae a dos amigos
        if (reason == SpawnReason.NATURAL && world.toServerWorld().getServer() != null
                && com.centrodesinformacion.desinformados.EstadoServidor.get(world.toServerWorld().getServer()).tieneCambio("furros_manada")) {
            for (int i = 0; i < 2; i++) {
                FurroEntity amigo = ModEntidades.FURRO.create(world.toServerWorld());
                if (amigo == null) continue;
                amigo.refreshPositionAndAngles(getX() + random.nextInt(3) - 1, getY(), getZ() + random.nextInt(3) - 1, random.nextFloat() * 360f, 0f);
                amigo.initialize(world, difficulty, SpawnReason.EVENT, null);
                world.spawnEntity(amigo);
            }
        }
        setBaby(false);
        setCanPickUpLoot(false);
        for (EquipmentSlot slot : EquipmentSlot.values()) equipStack(slot, ItemStack.EMPTY);
        return r;
    }

    // ---------------- El abrazo ----------------

    @Override
    public boolean tryAttack(Entity objetivo) {
        if (abrazado == null && descanso <= 0 && objetivo instanceof ServerPlayerEntity p && !p.isCreative() && !p.isSpectator()) {
            abrazado = p.getUuid();
            ticksAbrazo = 0;
            p.sendMessage(Text.literal("¡Un furro te está abrazando! Pégale para librarte").formatted(Formatting.LIGHT_PURPLE), true);
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_WOLF_WHINE, SoundCategory.HOSTILE, 1f, 1.3f);
            return true;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        if (descanso > 0) descanso--;
        if (abrazado == null) return;

        ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(abrazado);
        if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator() || p.getWorld() != getWorld()
                || squaredDistanceTo(p) > 16 || ticksAbrazo >= ABRAZO_MAX) {
            soltar();
            return;
        }
        ticksAbrazo++;

        // Pegado delante del jugador, mirándole, con los brazos estirados
        Vec3d mirada = p.getRotationVector();
        Vec3d horizontal = new Vec3d(mirada.x, 0, mirada.z);
        if (horizontal.lengthSquared() < 1.0E-4) horizontal = new Vec3d(0, 0, 1);
        horizontal = horizontal.normalize().multiply(0.55);
        setPosition(p.getX() + horizontal.x, p.getY(), p.getZ() + horizontal.z);
        setVelocity(Vec3d.ZERO);
        float yaw = (float) (MathHelper.atan2(p.getZ() - getZ(), p.getX() - getX()) * (180 / Math.PI)) - 90f;
        setYaw(yaw);
        setHeadYaw(yaw);
        setBodyYaw(yaw);
        getNavigation().stop();
        setAttacking(true);

        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3, false, true));
        if (ticksAbrazo % 40 == 0) p.damage(getDamageSources().mobAttack(this), 1f); // medio corazón
        if (ticksAbrazo % 10 == 0 && getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.HEART, getX(), getY() + 2.1, getZ(), 1, 0.3, 0.1, 0.3, 0);
        }
        if (ticksAbrazo % 30 == 0) {
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_WOLF_PANT, SoundCategory.HOSTILE, 0.8f, 1.2f);
        }
    }

    private void soltar() {
        abrazado = null;
        descanso = DESCANSO;
        setAttacking(false);
    }

    // ---------------- Que no se comporte como un zombi ----------------

    @Override protected boolean burnsInDaylight() { return false; }
    @Override protected boolean canConvertInWater() { return false; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WOLF_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_WOLF_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_WOLF_DEATH; }
    @Override protected SoundEvent getStepSound() { return SoundEvents.ENTITY_WOLF_STEP; }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.variante3.CreeperCenizaEntity;
import com.centrodesinformacion.desinformados.entidad.variante3.EsqueletoFuegoEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

import java.util.List;

/**
 * Variantes de los mobs del mod (parte 2 de 2): tipos, atributos, aparición natural y huevos.
 * Creeper de Ceniza y Esqueleto de Fuego (Nether). Todas bloqueadas hasta su tele azul.
 */
public final class ModVariantes3 {
    private ModVariantes3() {}

    // =============================== Tipos (mismas medidas que su original) ===============================

    public static final EntityType<CreeperCenizaEntity> CREEPER_CENIZA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_ceniza"),
            EntityType.Builder.<CreeperCenizaEntity>create(CreeperCenizaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).makeFireImmune().maxTrackingRange(8).build("creeper_ceniza"));

    public static final EntityType<EsqueletoFuegoEntity> ESQUELETO_FUEGO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_fuego"),
            EntityType.Builder.<EsqueletoFuegoEntity>create(EsqueletoFuegoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.99f).makeFireImmune().maxTrackingRange(8).build("esqueleto_fuego"));

    // =============================== Huevos ===============================

    private static Item huevo(String id, EntityType<? extends MobEntity> tipo, int base, int manchas) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, base, manchas, new Item.Settings()));
    }

    public static final Item HUEVO_CREEPER_CENIZA = huevo("creeper_ceniza", CREEPER_CENIZA, 0x6B6B6B, 0xFF7A1A);
    public static final Item HUEVO_ESQUELETO_FUEGO = huevo("esqueleto_fuego", ESQUELETO_FUEGO, 0x2A1208, 0xFF8A1E);

    private static final List<Item> HUEVOS = List.of(HUEVO_CREEPER_CENIZA, HUEVO_ESQUELETO_FUEGO);

    /** Lo llama Desinformados.onInitialize, después de ModVariantes.inicializar(). */
    public static void inicializar() {
        // ---------- Atributos (los de su original) ----------
        FabricDefaultAttributeRegistry.register(CREEPER_CENIZA, CreeperEntity.createCreeperAttributes());
        FabricDefaultAttributeRegistry.register(ESQUELETO_FUEGO, AbstractSkeletonEntity.createAbstractSkeletonAttributes());

        // ---------- Aparición: pocas y de una en una (bloqueadas hasta su tele azul: ver canSpawn de cada clase) ----------
        var overworld = BiomeSelectors.foundInOverworld();
        var nether = BiomeSelectors.foundInTheNether();

        // Lugares oscuros del Overworld (superficie de noche o cuevas), como sus originales



        // Nether: cualquier bioma, a oscuras (como el Creeper de Fuego y el Esqueleto Ráfaga)
        SpawnRestriction.register(CREEPER_CENIZA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, CREEPER_CENIZA, 6, 1, 1);

        SpawnRestriction.register(ESQUELETO_FUEGO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, ESQUELETO_FUEGO, 6, 1, 1);

        // ---------- Huevos en la pestaña de herramientas ----------
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item h : HUEVOS) e.add(h);
        });
    }
}

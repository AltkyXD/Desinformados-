package com.centrodesinformacion.desinformados.entidad.agua;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.ServerWorldAccess;
import org.jetbrains.annotations.Nullable;

/** Utilidades compartidas por el Creeper de Agua y el Pulpo. */
final class UtilAgua {
    private UtilAgua() {}

    /** Jugador al que se le puede hacer algo: vivo, ni creativo ni espectador. */
    static boolean valido(@Nullable PlayerEntity p) {
        return p != null && p.isAlive() && !p.isCreative() && !p.isSpectator();
    }

    /** Copia de ModEntidades.pocos (allí es privada del paquete): como mucho "max" de ese tipo en 64 bloques. */
    static boolean pocos(ServerWorldAccess mundo, EntityType<?> tipo, BlockPos pos, SpawnReason razon, int max) {
        if (razon != SpawnReason.NATURAL || com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(mundo)) return true;
        return mundo.getEntitiesByClass(Entity.class, new Box(pos).expand(64, 32, 64), e -> e.getType() == tipo).size() < max;
    }

    /**
     * Aparición natural en el agua: no en pacífico, con agua en el sitio y debajo (2 bloques de hondo), entre el nivel del mar
     * y 40 bloques por debajo (nada de lagos de cuevas profundas), a oscuras siempre y con luz solo 1 de cada 4 intentos.
     */
    static boolean puedeAparecer(EntityType<?> tipo, ServerWorldAccess mundo, SpawnReason razon, BlockPos pos, Random random, int max) {
        if (mundo.getDifficulty() == Difficulty.PEACEFUL) return false;
        if (!mundo.getFluidState(pos).isIn(FluidTags.WATER) || !mundo.getFluidState(pos.down()).isIn(FluidTags.WATER)) return false;
        int mar = mundo.getSeaLevel();
        if (pos.getY() > mar || pos.getY() < mar - 40) return false;
        if (!HostileEntity.isSpawnDark(mundo, pos, random) && random.nextFloat() >= 0.25f) return false;
        return pocos(mundo, tipo, pos, razon, max);
    }
}

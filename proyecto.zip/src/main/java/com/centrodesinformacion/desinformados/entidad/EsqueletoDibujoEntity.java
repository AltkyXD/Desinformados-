package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.world.World;

/** Esqueleto a lápiz. Versión "dibujada" que vive en la Libreta del Becario. */
public class EsqueletoDibujoEntity extends SkeletonEntity {
    public EsqueletoDibujoEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    /** En la Libreta el sol es de papel: no quema. */
    @Override protected boolean isAffectedByDaylight() { return false; }
}

package com.centrodesinformacion.desinformados.entidad.agua;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.SquidEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Pulpo (modelo del calamar). 15 corazones.
 * - Si ve a un jugador EN EL AGUA a menos de 4 bloques, lo atrapa: lo deja quieto donde estaba y le quita 1 corazón
 *   cada 2 s mientras se pega a él. Lo suelta si un jugador lo golpea (basta un golpe), si muere, si el jugador sale del
 *   agua o se aleja a más de 7 bloques (y, para no dejarlo atrapado para siempre, si lo pierde de vista 3 s o no consigue
 *   acercarse en 10 s). Después tarda 5 s en poder volver a atrapar a ese jugador.
 * - Si un jugador va en barca (o barca con cofre) a menos de 6 bloques, se mete debajo y a los 3 s la rompe (suelta la
 *   barca y lo que lleve el cofre, como cuando la rompe un jugador); luego lo atrapa en el agua como siempre.
 */
public class PulpoEntity extends SquidEntity implements Monster {
    private static final double VISTA = 4;
    private static final double SUELTA = 7;
    private static final double RADIO_BARCA = 6;
    private static final int CADA_DANIO = 40;      // 2 s
    private static final float DANIO = 2.0f;      // 1 corazón
    private static final int ESPERA = 100;         // 5 s antes de volver a atrapar al mismo
    private static final int TIEMPO_BARCA = 60;    // 3 s debajo de la barca
    private static final float NADO = 0.6f;

    @Nullable private PlayerEntity atrapado;
    @Nullable private Vec3d ancla;
    private int agarre = 0;
    private int sinVer = 0;
    private int lejos = 0;

    @Nullable private BoatEntity barca;
    @Nullable private PlayerEntity remero;
    private int bajoBarca = 0;

    /** uuid del jugador -> edad (age) del pulpo a partir de la cual puede volver a atraparlo. */
    private final Map<UUID, Integer> esperas = new HashMap<>();

    public PulpoEntity(EntityType<? extends SquidEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return SquidEntity.createSquidAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0);
    }

    /** Sin los objetivos del calamar (nadar al azar y huir): todo lo hace en tick(). */
    @Override
    protected void initGoals() {
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Es un monstruo: en pacífico desaparece. */
    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    @Override
    protected int getXpToDrop() {
        return 5;
    }

    /** Un golpe de cualquier jugador (también de un compañero o con flecha) le hace soltar a quien tenga atrapado. */
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!getWorld().isClient() && atrapado != null && source.getAttacker() instanceof PlayerEntity) soltar(true);
        return super.damage(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw) || !isAlive() || isRemoved()) return;
        if (age % 100 == 0 && !esperas.isEmpty()) esperas.values().removeIf(hasta -> hasta <= age);
        if (atrapado != null) {
            sujetar(sw);
            return;
        }
        if (barca != null) {
            atacarBarca(sw);
            return;
        }
        if (age % 5 == 0 && isTouchingWater()) buscar(sw);
        if (atrapado == null && barca == null) pasear();
    }

    /** Como el calamar normal: cambia de dirección de vez en cuando. */
    private void pasear() {
        if (!isTouchingWater()) return;
        if (getRandom().nextInt(50) == 0 || !hasSwimmingVector()) {
            float a = getRandom().nextFloat() * MathHelper.TAU;
            setSwimmingVector(MathHelper.cos(a) * 0.2f, -0.1f + getRandom().nextFloat() * 0.2f, MathHelper.sin(a) * 0.2f);
        }
    }

    private void nadarHacia(Vec3d destino, double parada) {
        Vec3d hacia = destino.subtract(getPos());
        double d = hacia.length();
        if (d > parada) {
            Vec3d v = hacia.multiply(NADO / d);
            setSwimmingVector((float) v.x, (float) v.y, (float) v.z);
        } else {
            setSwimmingVector(0f, 0f, 0f);
        }
    }

    private boolean enEspera(PlayerEntity p) {
        Integer hasta = esperas.get(p.getUuid());
        return hasta != null && age < hasta;
    }

    /** Busca (cada 5 ticks) a un jugador en el agua al que atrapar o a uno en barca. */
    private void buscar(ServerWorld sw) {
        PlayerEntity mejor = null;
        double mejorD = VISTA * VISTA;
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(VISTA), UtilAgua::valido)) {
            double d = squaredDistanceTo(p);
            if (p.getVehicle() instanceof BoatEntity b) {
                if (barca == null && d <= RADIO_BARCA * RADIO_BARCA && canSee(p)) {
                    barca = b;
                    remero = p;
                    bajoBarca = 0;
                }
                continue;
            }
            if (p.hasVehicle() || !p.isTouchingWater() || d > mejorD || enEspera(p) || !canSee(p)) continue;
            mejor = p;
            mejorD = d;
        }
        if (mejor != null) {
            barca = null;
            remero = null;
            agarrar(sw, mejor);
        }
    }

    private void agarrar(ServerWorld sw, PlayerEntity p) {
        atrapado = p;
        ancla = p.getPos();
        agarre = 0;
        sinVer = 0;
        lejos = 0;
        p.setVelocity(Vec3d.ZERO);
        p.velocityModified = true;
        sw.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.6f);
        sw.spawnParticles(ParticleTypes.SQUID_INK, p.getX(), p.getY() + 0.5, p.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
        aviso(p);
    }

    private static void aviso(PlayerEntity p) {
        p.sendMessage(Text.literal("¡Un pulpo te tiene atrapado! Golpéalo para soltarte").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), true);
    }

    /** Cada tick mientras lo tiene atrapado: lo deja quieto, le hace daño cada 2 s y se le acerca. */
    private void sujetar(ServerWorld sw) {
        PlayerEntity p = atrapado;
        Vec3d punto = ancla;
        if (p == null || punto == null || !UtilAgua.valido(p) || p.isRemoved() || p.getWorld() != getWorld() || p.hasVehicle()
                || !p.isTouchingWater() || squaredDistanceTo(p) > SUELTA * SUELTA) {
            soltar(false);
            return;
        }
        sinVer = canSee(p) ? 0 : sinVer + 1;
        double distancia = Math.sqrt(squaredDistanceTo(p));
        lejos = distancia > 4 ? lejos + 1 : 0;
        if (sinVer > 60 || lejos > 200) {   // lo ha perdido de vista 3 s o no consigue llegar hasta él en 10 s
            soltar(false);
            return;
        }
        agarre++;
        // Quieto donde lo atrapó: si se ha ido más de 1 bloque, de vuelta al sitio; si no, tirón suave hacia el punto
        Vec3d desvio = punto.subtract(p.getPos());
        if (desvio.lengthSquared() > 1.0) {
            p.requestTeleport(punto.x, punto.y, punto.z);
            p.setVelocity(Vec3d.ZERO);
        } else {
            p.setVelocity(desvio.multiply(0.5));
        }
        p.velocityModified = true;
        if (agarre % CADA_DANIO == 0) p.damage(getDamageSources().mobAttack(this), DANIO);
        if (agarre % 20 == 0) aviso(p);
        // Se pega a él (para que pueda golpearlo)
        nadarHacia(p.getPos().add(0, 0.4, 0), 1.6);
    }

    private void soltar(boolean golpeado) {
        PlayerEntity p = atrapado;
        atrapado = null;
        ancla = null;
        agarre = 0;
        sinVer = 0;
        lejos = 0;
        setSwimmingVector(0f, 0f, 0f);
        if (p == null) return;
        esperas.put(p.getUuid(), age + ESPERA);
        if (golpeado && p.isAlive()) p.sendMessage(Text.literal("¡Te has soltado del pulpo!").formatted(Formatting.GREEN), true);
    }

    /** Se mete debajo de la barca y, a los 3 s, la rompe. */
    private void atacarBarca(ServerWorld sw) {
        BoatEntity b = barca;
        PlayerEntity p = remero;
        if (b == null || p == null || b.isRemoved() || !UtilAgua.valido(p) || p.getVehicle() != b || !isTouchingWater()
                || squaredDistanceTo(b) > (RADIO_BARCA + 4) * (RADIO_BARCA + 4)) {
            barca = null;
            remero = null;
            bajoBarca = 0;
            return;
        }
        Vec3d debajo = b.getPos().add(0, -1.4, 0);
        nadarHacia(debajo, 0.5);
        if (debajo.squaredDistanceTo(getPos()) > 2.5 * 2.5) return;
        bajoBarca++;
        if (bajoBarca % 20 == 0 && bajoBarca < TIEMPO_BARCA) {   // golpes desde abajo: la barca se tambalea
            b.setDamageWobbleTicks(10);
            b.setDamageWobbleSide(-b.getDamageWobbleSide());
            sw.playSound(null, b.getBlockPos(), SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, SoundCategory.HOSTILE, 0.6f, 1.3f);
        }
        if (bajoBarca >= TIEMPO_BARCA) romperBarca(sw, b, p);
    }

    private void romperBarca(ServerWorld sw, BoatEntity b, PlayerEntity p) {
        barca = null;
        remero = null;
        bajoBarca = 0;
        double x = b.getX(), y = b.getY(), z = b.getZ();
        // Mucho daño de golpe: se rompe y suelta la barca (y el contenido del cofre) como cuando la rompe un jugador
        b.damage(getDamageSources().mobAttack(this), 100f);
        sw.playSound(null, b.getBlockPos(), SoundEvents.BLOCK_WOOD_BREAK, SoundCategory.HOSTILE, 1.2f, 0.8f);
        sw.spawnParticles(ParticleTypes.SQUID_INK, x, y, z, 15, 0.5, 0.2, 0.5, 0.05);
        p.sendMessage(Text.literal("¡El pulpo ha roto tu barca!").formatted(Formatting.RED, Formatting.BOLD), true);
    }
}

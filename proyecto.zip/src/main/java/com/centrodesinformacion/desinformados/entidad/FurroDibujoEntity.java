package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;

/** Furro dibujado (mal) por Altky: abraza igual que un Furro, pero es de papel: menos vida, más rápido y no se quema. */
public class FurroDibujoEntity extends FurroEntity {
    public FurroDibujoEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return FurroEntity.atributos()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34);
    }

    @Override protected boolean canConvertInWater() { return false; }
    @Override protected boolean isAffectedByDaylight() { return false; }
    @Override protected boolean burnsInDaylight() { return false; }
}

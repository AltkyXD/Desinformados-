package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.BlazeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Blaze Helado: aura de frío. Cada segundo, a los jugadores a menos de 5 bloques: Lentitud II 3 s y escarcha
 * (+60 ticks de congelación, máximo 200; el hielo se derrite solo a 40 por segundo, así que quedarse cerca acumula
 * y a partir de 140 hace daño por congelación). Sus bolas de fuego son las normales. No es inmune al fuego (es de hielo).
 */
public class BlazeHeladoEntity extends BlazeEntity {
    private static final double RADIO = 5;
    private static final int ESCARCHA = 60;
    private static final int MAX_ESCARCHA = 200;

    public BlazeHeladoEntity(EntityType<? extends BlazeEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (age % 20 != 0 || !(getWorld() instanceof ServerWorld sw) || !isAlive()) return;
        sw.spawnParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 6, 0.8, 0.8, 0.8, 0.02);
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(RADIO),
                j -> Variantes.valido(j) && j.squaredDistanceTo(this) <= RADIO * RADIO)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), this);
            p.setFrozenTicks(Math.min(p.getFrozenTicks() + ESCARCHA, MAX_ESCARCHA));
        }
    }
}

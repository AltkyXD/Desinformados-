package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.BlazeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Blaze Helado: aura de frío. Cada segundo, a los jugadores a menos de 5 bloques: Lentitud II 3 s y escarcha
 * (+60 ticks de congelación, máximo 200; el hielo se derrite solo a 40 por segundo, así que quedarse cerca acumula
 * y a partir de 140 hace daño por congelación). No es inmune al fuego (es de hielo).
 * No lanza bolas de fuego: lanza ráfagas de 3 bolas de nieve heladas (1 corazón, mucha escarcha y Lentitud II 3 s),
 * y no se enciende al cargar el ataque (nada de llamas).
 */
public class BlazeHeladoEntity extends BlazeEntity {
    private static final double RADIO = 5;
    private static final int ESCARCHA = 60;
    private static final int MAX_ESCARCHA = 200;

    public BlazeHeladoEntity(EntityType<? extends BlazeEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Los objetivos del blaze, pero con las bolas de nieve en vez de las de fuego. */
    @Override
    protected void initGoals() {
        goalSelector.add(4, new BolasNieveGoal(this));
        goalSelector.add(5, new GoToWalkTargetGoal(this, 1.0));
        goalSelector.add(7, new WanderAroundFarGoal(this, 1.0, 0.0f));
        goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this).setGroupRevenge());
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Sin el "fuego" del blaze al cargar (ni llamas encima ni humo). */
    @Override
    public boolean isOnFire() {
        return false;
    }

    /** Lanza una bola de nieve helada hacia el objetivo. */
    void lanzarBola(LivingEntity t) {
        if (!(getWorld() instanceof ServerWorld sw)) return;
        SnowballEntity bola = new SnowballEntity(sw, this) {
            @Override
            protected void onEntityHit(EntityHitResult hit) {
                super.onEntityHit(hit);
                Entity e = hit.getEntity();
                if (e instanceof LivingEntity v && !(e instanceof BlazeHeladoEntity)) {
                    v.damage(getDamageSources().thrown(this, getOwner()), 2f);
                    v.setFrozenTicks(Math.min(v.getFrozenTicks() + 100, 240));
                    v.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
                    if (getWorld() instanceof ServerWorld w)
                        w.spawnParticles(ParticleTypes.SNOWFLAKE, v.getX(), v.getEyeY() - 0.3, v.getZ(), 12, 0.3, 0.3, 0.3, 0.05);
                }
            }
        };
        bola.setPosition(getX(), getBodyY(0.5) + 0.5, getZ());
        double dx = t.getX() - getX(), dy = t.getBodyY(0.5) - bola.getY(), dz = t.getZ() - getZ();
        double h = Math.sqrt(dx * dx + dz * dz);
        bola.setVelocity(dx, dy + h * 0.12, dz, 1.4f, 3.0f);
        sw.spawnEntity(bola);
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.HOSTILE, 1f, 0.6f);
        sw.spawnParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1.2, getZ(), 6, 0.3, 0.3, 0.3, 0.05);
    }

    /** Como el ataque del blaze: ráfagas de 3 disparos (uno cada 6 ticks) y 3 s de recarga; si te acercas, te pega. */
    static class BolasNieveGoal extends Goal {
        private final BlazeHeladoEntity blaze;
        private int disparos, espera, sinVer;

        BolasNieveGoal(BlazeHeladoEntity blaze) {
            this.blaze = blaze;
            setControls(java.util.EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            LivingEntity t = blaze.getTarget();
            return t != null && t.isAlive() && blaze.canTarget(t);
        }

        @Override
        public void start() { disparos = 0; espera = 20; }

        @Override
        public boolean shouldRunEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity t = blaze.getTarget();
            if (t == null) return;
            if (--espera > 0 && disparos == 0) { acercarse(t); return; }
            boolean ve = blaze.getVisibilityCache().canSee(t);
            sinVer = ve ? 0 : sinVer + 1;
            double d = blaze.squaredDistanceTo(t);
            if (d < 4.0) {                                                          // muy cerca: golpe
                if (espera <= 0) { blaze.tryAttack(t); espera = 20; }
                blaze.getMoveControl().moveTo(t.getX(), t.getY(), t.getZ(), 1.0);
                return;
            }
            if (d < 16 * 16 && ve) {
                blaze.getLookControl().lookAt(t, 10f, 10f);
                if (espera <= 0) {
                    disparos++;
                    if (disparos <= 3) { blaze.lanzarBola(t); espera = 6; }
                    else { disparos = 0; espera = 60; }
                }
            } else if (sinVer < 5) {
                acercarse(t);
            }
        }

        private void acercarse(LivingEntity t) {
            blaze.getMoveControl().moveTo(t.getX(), t.getY(), t.getZ(), 1.0);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (age % 20 != 0 || !(getWorld() instanceof ServerWorld sw) || !isAlive()) return;
        sw.spawnParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 6, 0.8, 0.8, 0.8, 0.02);
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(RADIO),
                j -> Variantes.valido(j) && j.squaredDistanceTo(this) <= RADIO * RADIO)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), this);
            p.setFrozenTicks(Math.min(p.getFrozenTicks() + ESCARCHA, MAX_ESCARCHA));
        }
    }
}

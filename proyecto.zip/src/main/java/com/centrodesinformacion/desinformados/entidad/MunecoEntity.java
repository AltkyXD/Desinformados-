package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.mixin.MobAccessor;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Muñeco de Prueba: un "jugador" falso que los mobs hostiles atacan, para ver cómo se comportan.
 * Se queda quieto, tiene 100 de vida, se cura solo y muestra su vida en el nombre.
 */
public class MunecoEntity extends PathAwareEntity {
    public MunecoEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        setPersistent();
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.5);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(8, new LookAroundGoal(this));
    }

    /** Todos los mobs hostiles (y los del mod) también eligen al muñeco como objetivo. */
    public static void registrar() {
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (!(entidad instanceof MobEntity mob) || entidad instanceof MunecoEntity || entidad instanceof GatoCuboEntity) return;
            boolean delMod = Registries.ENTITY_TYPE.getId(entidad.getType()).getNamespace().equals(Desinformados.MOD_ID);
            if (!(entidad instanceof Monster) && !delMod) return;
            ((MobAccessor) mob).desinformados$getTargetSelector().add(2, new ActiveTargetGoal<>(mob, MunecoEntity.class, true));
        });
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        if (age % 40 == 0 && getHealth() < getMaxHealth()) heal(2f);       // se cura 1 corazón cada 2 s
        if (age % 5 == 0) {
            setCustomName(Text.literal("Muñeco de Prueba ").formatted(Formatting.GRAY)
                    .append(Text.literal("❤ " + Math.round(getHealth()) + "/" + Math.round(getMaxHealth())).formatted(Formatting.RED)));
            setCustomNameVisible(true);
        }
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient() && fuente.getAttacker() != null) {
            String quien = fuente.getAttacker().getName().getString();
            getWorld().getPlayers().forEach(p -> {
                if (p.squaredDistanceTo(this) < 32 * 32) p.sendMessage(Text.literal("Muñeco: -" + String.format("%.1f", cantidad)
                        + " (" + quien + ")").formatted(Formatting.YELLOW), true);
            });
        }
        return r;
    }

    @Override
    public boolean cannotDespawn() { return true; }
}

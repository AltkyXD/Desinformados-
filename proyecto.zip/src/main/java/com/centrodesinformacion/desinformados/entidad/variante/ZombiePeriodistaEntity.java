package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/** Zombie Periodista: más rápido que un zombie normal. Si te pega, te hace brillar 15 segundos (¡EXCLUSIVA!). */
public class ZombiePeriodistaEntity extends ZombieEntity {
    private static final int BRILLO = 15 * 20;

    public ZombiePeriodistaEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27);   // zombie normal: 0.23
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        Variantes.zombieSinExtras(this);
        return r;
    }

    /** Siempre adulto (la textura es de adulto). */
    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && !getWorld().isClient() && objetivo instanceof ServerPlayerEntity p && Variantes.valido(p)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, BRILLO, 0), this);
            p.sendMessage(Text.literal("¡EXCLUSIVA!").formatted(Formatting.YELLOW, Formatting.BOLD), true);
            getWorld().playSound(null, p.getBlockPos(), SoundEvents.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, SoundCategory.HOSTILE, 1f, 1.4f);
        }
        return golpe;
    }

    /** En el agua no se convierte en ahogado normal. */
    @Override
    protected boolean canConvertInWater() {
        return false;
    }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.entidad.ModVariantes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/**
 * Slime Viral: cada vez que un jugador le hace daño, 25 % de que salga una copia pequeña (tamaño 1) a su lado,
 * como mucho 8 Slimes Virales a menos de 16 bloques. Aparece como mucho de tamaño 2.
 */
public class SlimeViralEntity extends SlimeEntity {
    private static final float PROBABILIDAD = 0.25f;
    private static final int MAX_CERCA = 8;
    private static final double RADIO = 16;

    public SlimeViralEntity(EntityType<? extends SlimeEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        if (getSize() > 2) setSize(2, true);   // nada de slimes gigantes: ya se multiplica solo
        return r;
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean herido = super.damage(fuente, cantidad);
        if (herido && getWorld() instanceof ServerWorld sw && fuente.getAttacker() instanceof PlayerEntity
                && random.nextFloat() < PROBABILIDAD) {
            copiar(sw);
        }
        return herido;
    }

    private void copiar(ServerWorld sw) {
        int cerca = sw.getEntitiesByClass(SlimeViralEntity.class, getBoundingBox().expand(RADIO), Entity::isAlive).size();
        if (cerca >= MAX_CERCA) return;
        SlimeViralEntity copia = ModVariantes.SLIME_VIRAL.create(sw);
        if (copia == null) return;
        copia.setSize(1, true);
        copia.refreshPositionAndAngles(getX() + (random.nextDouble() - 0.5), getY() + 0.1, getZ() + (random.nextDouble() - 0.5),
                random.nextFloat() * 360f, 0f);
        copia.addCommandTag(Mobs.MARCA_EVENTO);   // la copia existe aunque el tipo siga bloqueado (p. ej. con huevo)
        if (getTarget() != null) copia.setTarget(getTarget());
        sw.spawnEntity(copia);
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 1.6f);
    }
}

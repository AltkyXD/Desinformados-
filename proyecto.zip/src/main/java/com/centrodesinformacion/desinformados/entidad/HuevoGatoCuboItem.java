package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;

/** Huevo de un Gato Cubo concreto (cada variante tiene el suyo). Los vendedores salen mirando hacia ti. */
public class HuevoGatoCuboItem extends SpawnEggItem {
    private final int tipo;

    public HuevoGatoCuboItem(int tipo, int base, int detalle, Settings settings) {
        super(ModEntidades.GATO_CUBO, base, detalle, settings);
        this.tipo = tipo;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (!(ctx.getWorld() instanceof ServerWorld w)) return ActionResult.SUCCESS;
        BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
        GatoCuboEntity g = ModEntidades.GATO_CUBO.create(w);
        if (g == null) return ActionResult.FAIL;
        float yaw = ctx.getPlayer() != null ? ctx.getPlayer().getHorizontalFacing().getOpposite().asRotation() : 0f;
        g.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yaw, 0f);
        g.setHeadYaw(yaw);
        g.setBodyYaw(yaw);
        g.configurar(tipo, pos);
        w.spawnEntity(g);
        ItemStack s = ctx.getStack();
        if (ctx.getPlayer() != null) s.decrementUnlessCreative(1, ctx.getPlayer());
        return ActionResult.CONSUME;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;

/** Creeper de estática. */
public class CreeperEstaticaEntity extends CreeperEntity implements MobEstatica {
    public CreeperEstaticaEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient()) MobEstatica.alRecibirGolpe(this);
        return r;
    }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

/**
 * Pollo Bomba: va a por el jugador más cercano a menos de 12 bloques. A menos de 2,5 bloques enciende la mecha:
 * 1,5 segundos después explota (potencia 2, no rompe bloques) y desaparece. No pone huevos. No existe en pacífico.
 */
public class PolloBombaEntity extends ChickenEntity {
    private static final double VISTA = 12;
    private static final double CERCA = 2.5;
    private static final int MECHA = 30;          // 1,5 s
    private static final float POTENCIA = 2.0f;

    private int mecha = 0;

    public PolloBombaEntity(EntityType<? extends ChickenEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new IrAPorJugador(this));
        goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 6f));
        goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        setBreedingAge(0);   // siempre adulto
        return r;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    /** No pone huevos (el pollo normal los suelta con dropItem). */
    @Override
    public @Nullable ItemEntity dropItem(ItemConvertible item) {
        if (item.asItem() == Items.EGG) return null;
        return super.dropItem(item);
    }

    /** Es un monstruo: en pacífico desaparece. */
    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    /** Como los monstruos: puede desaparecer lejos de los jugadores (el pollo normal no). */
    @Override
    public boolean canImmediatelyDespawn(double distanciaCuadrada) {
        return true;
    }

    @Nullable
    PlayerEntity jugadorCerca(double radio) {
        PlayerEntity p = getWorld().getClosestPlayer(getX(), getY(), getZ(), radio, true);
        return Variantes.valido(p) ? p : null;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw) || !isAlive()) return;
        if (mecha > 0) {
            mecha++;
            if (mecha % 2 == 0) sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 0.8, getZ(), 2, 0.1, 0.1, 0.1, 0.01);
            if (mecha >= MECHA) explotar(sw);
            return;
        }
        if (age % 5 == 0 && jugadorCerca(CERCA) != null) {
            mecha = 1;
            getNavigation().stop();
            sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_CREEPER_PRIMED, SoundCategory.HOSTILE, 1f, 1.6f);
        }
    }

    private void explotar(ServerWorld sw) {
        sw.createExplosion(this, getX(), getY(), getZ(), POTENCIA, World.ExplosionSourceType.NONE);
        discard();
    }

    /** Va directo al jugador más cercano (a menos de 12 bloques). */
    static class IrAPorJugador extends Goal {
        private final PolloBombaEntity pollo;
        @Nullable private PlayerEntity objetivo;
        private int recalcular = 0;

        IrAPorJugador(PolloBombaEntity pollo) {
            this.pollo = pollo;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            if (pollo.age % 10 != 0) return false;
            objetivo = pollo.jugadorCerca(VISTA);
            return objetivo != null;
        }

        @Override
        public boolean shouldContinue() {
            return Variantes.valido(objetivo) && pollo.squaredDistanceTo(objetivo) < (VISTA + 4) * (VISTA + 4);
        }

        @Override
        public void start() {
            recalcular = 0;
        }

        @Override
        public void stop() {
            objetivo = null;
            pollo.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (objetivo == null) return;
            pollo.getLookControl().lookAt(objetivo, 30f, 30f);
            if (--recalcular <= 0) {
                recalcular = 10;
                pollo.getNavigation().startMovingTo(objetivo, 1.4);
            }
        }
    }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Araña Tejedora: cuando te muerde, teje una telaraña a tus pies (una vez cada 10 segundos por araña). */
public class AranaTejedoraEntity extends SpiderEntity {
    private static final int ESPERA = 10 * 20;

    private int espera = 0;

    public AranaTejedoraEntity(EntityType<? extends SpiderEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (espera > 0) espera--;
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && espera <= 0 && !getWorld().isClient() && getServer() != null
                && objetivo instanceof ServerPlayerEntity p && Variantes.valido(p)) {
            World mundo = getWorld();
            BlockPos pies = p.getBlockPos();
            // Solo en aire (nunca sustituye bloques) y nunca dentro de la zona protegida del Centro
            if (mundo.isAir(pies) && !Reglas.enSpawn(mundo, pies, EstadoServidor.get(getServer()))) {
                mundo.setBlockState(pies, Blocks.COBWEB.getDefaultState());
                espera = ESPERA;
                mundo.playSound(null, pies, SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.HOSTILE, 1f, 0.6f);
                p.sendMessage(Text.literal("¡La Araña Tejedora te ha atrapado en su tela!").formatted(Formatting.GRAY), true);
            }
        }
        return golpe;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Zombie de estática. */
public class ZombieEstaticaEntity extends ZombieEntity implements MobEstatica {
    public ZombieEstaticaEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && !getWorld().isClient()) MobEstatica.alRecibirGolpe(this);
        return r;
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        // Sin refuerzos de zombi al recibir golpes (como el Zombie Naranja)
        EntityAttributeInstance refuerzos = getAttributeInstance(EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS);
        if (refuerzos != null) {
            refuerzos.clearModifiers();
            refuerzos.setBaseValue(0);
        }
        return r;
    }

    @Override protected boolean burnsInDaylight() { return false; }
    @Override protected boolean canConvertInWater() { return false; }
}

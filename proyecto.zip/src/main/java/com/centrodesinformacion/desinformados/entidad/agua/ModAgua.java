package com.centrodesinformacion.desinformados.entidad.agua;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.BiomeKeys;

/** Mobs de agua: tipos, atributos, aparición y huevos. */
public final class ModAgua {
    private ModAgua() {}

    // =============================== Tipos ===============================

    /** El modelo del bacalao x2 (el renderer también lo escala x2). */
    public static final EntityType<CreeperAguaEntity> CREEPER_AGUA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_agua"),
            EntityType.Builder.<CreeperAguaEntity>create(CreeperAguaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(1.0f, 0.6f).eyeHeight(0.39f).maxTrackingRange(8).build("creeper_agua"));

    /** Mismo tamaño que el calamar. */
    public static final EntityType<PulpoEntity> PULPO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("pulpo"),
            EntityType.Builder.<PulpoEntity>create(PulpoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.8f, 0.8f).eyeHeight(0.4f).maxTrackingRange(8).build("pulpo"));

    // =============================== Huevos ===============================

    private static Item huevo(String id, EntityType<? extends MobEntity> tipo, int base, int manchas) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, base, manchas, new Item.Settings()));
    }

    public static final Item HUEVO_CREEPER_AGUA = huevo("creeper_agua", CREEPER_AGUA, 0x2F6FD6, 0x0E1B3D);
    public static final Item HUEVO_PULPO = huevo("pulpo", PULPO, 0x9A2E63, 0xF1C1CF);

    // =============================== Registro ===============================

    /** Lo llama Desinformados.onInitialize. */
    public static void inicializar() {
        // ---------- Atributos ----------
        FabricDefaultAttributeRegistry.register(CREEPER_AGUA, CreeperAguaEntity.atributos());   // 5 corazones
        FabricDefaultAttributeRegistry.register(PULPO, PulpoEntity.atributos());                // 15 corazones

        // ---------- Aparición (bloqueados hasta su tele azul: ver canSpawn de cada clase) ----------
        // En océanos, ríos y pantanos; dentro del agua (2 bloques de hondo), por debajo del nivel del mar,
        // a oscuras siempre y con luz 1 de cada 4 intentos (UtilAgua.puedeAparecer).
        var agua = BiomeSelectors.tag(BiomeTags.IS_OCEAN).or(BiomeSelectors.tag(BiomeTags.IS_RIVER))
                .or(BiomeSelectors.includeByKey(BiomeKeys.SWAMP, BiomeKeys.MANGROVE_SWAMP));

        SpawnRestriction.register(CREEPER_AGUA, SpawnLocationTypes.IN_WATER, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> UtilAgua.puedeAparecer(tipo, mundo, razon, pos, random, 3));
        BiomeModifications.addSpawn(agua, SpawnGroup.MONSTER, CREEPER_AGUA, 15, 1, 2);

        SpawnRestriction.register(PULPO, SpawnLocationTypes.IN_WATER, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> UtilAgua.puedeAparecer(tipo, mundo, razon, pos, random, 2));
        BiomeModifications.addSpawn(agua, SpawnGroup.MONSTER, PULPO, 10, 1, 1);

        // ---------- Huevos en la pestaña de herramientas ----------
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(HUEVO_CREEPER_AGUA);
            e.add(HUEVO_PULPO);
        });
    }
}

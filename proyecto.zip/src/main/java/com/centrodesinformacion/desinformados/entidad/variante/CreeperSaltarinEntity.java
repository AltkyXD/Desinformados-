package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Creeper Saltarín: como mucho cada 3 segundos, si su objetivo está a entre 3 y 9 bloques
 * y él está en el suelo, pega un salto hacia él. Explota como un creeper normal.
 */
public class CreeperSaltarinEntity extends CreeperEntity {
    private static final int ESPERA = 3 * 20;
    private static final double MIN = 3, MAX = 9;

    private int espera = ESPERA;

    public CreeperSaltarinEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || !isAlive()) return;
        if (espera > 0) {
            espera--;
            return;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo == null || !objetivo.isAlive() || !isOnGround()) return;
        double d2 = squaredDistanceTo(objetivo);
        if (d2 < MIN * MIN || d2 > MAX * MAX) return;
        Vec3d hacia = new Vec3d(objetivo.getX() - getX(), 0, objetivo.getZ() - getZ());
        if (hacia.lengthSquared() < 1.0E-4) return;
        hacia = hacia.normalize();
        setVelocity(hacia.x * 0.9, 0.55, hacia.z * 0.9);
        velocityModified = true;
        espera = ESPERA;
        getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_GOAT_LONG_JUMP, SoundCategory.HOSTILE, 1f, 1.3f);
    }
}

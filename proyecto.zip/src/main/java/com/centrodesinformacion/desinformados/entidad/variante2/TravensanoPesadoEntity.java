package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.entidad.TravensanoEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Travensaño Pesado: se te sienta en el cuello como un Travensaño (mismo daño y misma duración), pero NO invierte los controles:
 * mientras esté encima no puedes saltar (fuerza de salto x0, modificador temporal) y, si estás en el agua, te hunde.
 * El modificador se quita al bajarse (también al morir él, al descargarse o si cambias de dimensión);
 * al ser temporal no se guarda con el jugador (salir del mundo lo quita) y al morir el jugador reaparece sin él.
 */
public class TravensanoPesadoEntity extends TravensanoEntity {
    private static final Identifier SIN_SALTO = Desinformados.id("travensano_pesado");
    private static final double HUNDIR = 0.2;   // tirón hacia abajo cada 5 ticks en el agua

    public TravensanoPesadoEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    /** Aparece solo con su propio desbloqueo (su tele azul), no con la tele de los Travensaños. */
    @Override
    protected boolean desbloqueadoSolo(WorldAccess world) {
        return !Mobs.bloqueadoEn(world, getType());
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean r = super.tryAttack(objetivo);
        if (r && objetivo instanceof ServerPlayerEntity p) {
            p.sendMessage(Text.literal("¡Un Travensaño Pesado se te ha subido al cuello! No puedes saltar").formatted(Formatting.DARK_AQUA), true);
        }
        return r;
    }

    @Override
    protected void efectoEncima(ServerPlayerEntity p, int ticks) {
        EntityAttributeInstance salto = p.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH);
        if (salto != null && !salto.hasModifier(SIN_SALTO)) {
            salto.addTemporaryModifier(new EntityAttributeModifier(SIN_SALTO, -1.0, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        if (ticks % 5 == 0 && p.isTouchingWater()) {
            p.addVelocity(0, -HUNDIR, 0);
            p.velocityModified = true;
        }
    }

    @Override
    protected void quitarEfecto(ServerPlayerEntity p) {
        EntityAttributeInstance salto = p.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH);
        if (salto != null) salto.removeModifier(SIN_SALTO);
    }
}

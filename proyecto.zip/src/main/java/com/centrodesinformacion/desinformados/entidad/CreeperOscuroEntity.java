package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Creeper Oscuro: si su explosión te alcanza, pierdes un contenedor de corazón (ver Reglas). */
public class CreeperOscuroEntity extends CreeperEntity {
    private static final net.minecraft.entity.data.TrackedData<Boolean> OCULTO =
            net.minecraft.entity.data.DataTracker.registerData(CreeperOscuroEntity.class, net.minecraft.entity.data.TrackedDataHandlerRegistry.BOOLEAN);

    @Override
    protected void initDataTracker(net.minecraft.entity.data.DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(OCULTO, false);
    }

    /** Con "creeper_invisible" solo se ve a menos de 5 bloques (lo usa el renderer). */
    public boolean isOculto() {
        return dataTracker.get(OCULTO);
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient() && age % 20 == 0 && getServer() != null) {
            dataTracker.set(OCULTO, com.centrodesinformacion.desinformados.EstadoServidor.get(getServer()).tieneCambio("creeper_invisible"));
        }
    }

    public CreeperOscuroEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        // Solo aparece de forma natural cuando un cambio de dificultad lo desbloquea
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) {
            return false;
        }
        // Solo en cuevas: sin cielo visible y por debajo de la capa 50
        if (reason == SpawnReason.NATURAL) {
            BlockPos pos = getBlockPos();
            if (pos.getY() > 50 || world.isSkyVisible(pos)) return false;
        }
        return super.canSpawn(world, reason);
    }
}

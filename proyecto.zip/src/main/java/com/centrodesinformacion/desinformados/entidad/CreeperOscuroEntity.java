package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Creeper Oscuro: si su explosión te alcanza, pierdes un contenedor de corazón (ver Reglas). */
public class CreeperOscuroEntity extends CreeperEntity {
    public CreeperOscuroEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        // Solo aparece de forma natural cuando un cambio de dificultad lo desbloquea
        if (reason == SpawnReason.NATURAL && world.getServer() != null
                && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Garabato: un monigote de palo dibujado en una hoja, del tamaño de un jugador.
 * Si te ve se acerca y, si te toca, te teletransporta 10 bloques hacia arriba (el daño es la caída).
 */
public class GarabatoEntity extends HostileEntity {
    private static final int ALTURA = 10;
    private static final int ESPERA = 60; // 3 segundos entre teletransportes
    private int espera = 0;

    /** Lo activa el desafío "Garabatos furiosos": te mandan a la capa máxima aunque haya techo. */
    public static boolean modoCielo = false;

    public GarabatoEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true)); // solo si te ve
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && world.getServer() != null && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (espera > 0) espera--;
    }

    /** "Atacar" = mandarte 10 bloques hacia arriba (o lo más alto que quepas si hay techo). */
    @Override
    public boolean tryAttack(Entity objetivo) {
        if (espera > 0 || !(objetivo instanceof ServerPlayerEntity p) || p.isCreative() || p.isSpectator()) return false;
        ServerWorld mundo = p.getServerWorld();
        double ox = p.getX(), oy = p.getY(), oz = p.getZ();
        if (modoCielo) {
            if (p.hasVehicle()) p.stopRiding();
            double cima = mundo.getTopY() - 2;
            p.requestTeleport(ox, cima, oz);
            p.setVelocity(0, 0, 0);
            p.velocityModified = true;
            espera = ESPERA;
            mundo.spawnParticles(ParticleTypes.CLOUD, ox, oy + 1, oz, 20, 0.3, 0.6, 0.3, 0.02);
            mundo.playSound(null, ox, oy, oz, SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT, SoundCategory.HOSTILE, 1f, 0.8f);
            p.sendMessage(Text.literal("¡Un Garabato furioso te ha dibujado en el cielo!").formatted(Formatting.RED, Formatting.BOLD), true);
            return true;
        }
        int subida = 0;
        for (int dy = ALTURA; dy >= 2; dy--) {
            if (mundo.isSpaceEmpty(p, p.getBoundingBox().offset(0, dy, 0))) { subida = dy; break; }
        }
        if (subida == 0) return false; // sin hueco encima (techo bajo)
        if (p.hasVehicle()) p.stopRiding();
        p.requestTeleport(ox, oy + subida, oz);
        p.setVelocity(0, 0, 0);
        p.velocityModified = true;
        espera = ESPERA;
        mundo.spawnParticles(ParticleTypes.CLOUD, ox, oy + 1, oz, 12, 0.3, 0.6, 0.3, 0.02);
        mundo.playSound(null, ox, oy, oz, SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT, SoundCategory.HOSTILE, 1f, 1.4f);
        mundo.playSound(null, ox, oy + subida, oz, SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.HOSTILE, 1f, 1f);
        p.sendMessage(Text.literal("Un Garabato te ha borrado... y te ha dibujado más arriba").formatted(Formatting.GRAY, Formatting.ITALIC), true);
        return true;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.UI_CARTOGRAPHY_TABLE_TAKE_RESULT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ITEM_BOOK_PUT; }
}

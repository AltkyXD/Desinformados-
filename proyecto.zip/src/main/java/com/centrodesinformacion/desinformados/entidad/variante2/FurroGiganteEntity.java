package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.FurroEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

/**
 * Furro Gigante: x1,5 (caja en ModVariantes2 y escala en el renderer), 16 corazones y más lento.
 * Su abrazo atrapa a la vez a TODOS los jugadores a menos de 2 bloques: al principal lo abraza como un Furro normal;
 * a los demás les da lo mismo (Lentitud IV y medio corazón cada 2 s) y no les deja alejarse mientras dure el abrazo.
 */
public class FurroGiganteEntity extends FurroEntity {
    private static final double RADIO_ABRAZO = 2.0;
    private static final double SOLTAR = 6.0;        // si alguno acaba a más de 6 bloques (teletransporte...), se suelta

    /** Los abrazados "de más" (el principal lo lleva FurroEntity). Solo dura lo que dura un abrazo: no se guarda. */
    private final Set<UUID> extras = new HashSet<>();

    public FurroGiganteEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return FurroEntity.atributos()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 32.0)       // el doble que un Furro (16)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.24);  // Furro: 0,3
    }

    /** Es más ancho: se pone un poco más lejos para no empujar al abrazado. */
    @Override
    protected double distanciaAbrazo() {
        return 0.8;
    }

    @Override
    protected void alAbrazar(ServerPlayerEntity principal) {
        extras.clear();
        for (ServerPlayerEntity p : getWorld().getEntitiesByClass(ServerPlayerEntity.class, getBoundingBox().expand(RADIO_ABRAZO),
                j -> j != principal && j.isAlive() && !j.isCreative() && !j.isSpectator()
                        && j.squaredDistanceTo(this) <= (RADIO_ABRAZO + 0.5) * (RADIO_ABRAZO + 0.5))) {
            extras.add(p.getUuid());
            p.sendMessage(Text.literal("¡El Furro Gigante os está abrazando a todos!").formatted(Formatting.LIGHT_PURPLE), true);
        }
        if (!extras.isEmpty()) {
            principal.sendMessage(Text.literal("¡El Furro Gigante os está abrazando a todos!").formatted(Formatting.LIGHT_PURPLE), true);
        }
    }

    @Override
    protected void abrazando(ServerPlayerEntity principal, int ticks) {
        if (extras.isEmpty() || getServer() == null) return;
        Iterator<UUID> it = extras.iterator();
        while (it.hasNext()) {
            ServerPlayerEntity p = getServer().getPlayerManager().getPlayer(it.next());
            if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator() || p.getWorld() != getWorld()
                    || p.squaredDistanceTo(this) > SOLTAR * SOLTAR) {
                it.remove();
                continue;
            }
            // Lo mismo que el abrazo normal: Lentitud IV renovada y medio corazón cada 2 segundos
            if (ticks % 10 == 1) p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3, false, true));
            if (ticks % 40 == 0) p.damage(getDamageSources().mobAttack(this), 1f);
            if (ticks % 10 == 0 && getWorld() instanceof ServerWorld sw) {
                sw.spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 2.1, p.getZ(), 1, 0.3, 0.1, 0.3, 0);
            }
            // No te deja alejarte: si te separas más de 1,5 bloques, tira de ti hacia él
            if (ticks % 5 == 0) {
                Vec3d hacia = new Vec3d(getX() - p.getX(), 0, getZ() - p.getZ());
                if (hacia.lengthSquared() > 1.5 * 1.5) {
                    Vec3d tiron = hacia.normalize().multiply(0.25);
                    p.addVelocity(tiron.x, 0, tiron.z);
                    p.velocityModified = true;
                }
            }
        }
    }

    @Override
    protected void alSoltar() {
        extras.clear();
    }
}

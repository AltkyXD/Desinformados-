package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.CuboRojoEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Cubo Púrpura (Nether): te flashea como el Cubo Rojo (pantalla en blanco y Lentitud I), pero en vez de quemarte te hace levitar 3 s. */
public class CuboPurpuraEntity extends CuboRojoEntity {
    private static final int TICKS_LEVITACION = 3 * 20;

    public CuboPurpuraEntity(EntityType<? extends SlimeEntity> type, World world) {
        super(type, world);
    }

    /** Sustituye al del Cubo Rojo (no quema). */
    @Override
    protected void alTocar(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, TICKS_LEVITACION, 0, false, true), this);
        p.sendMessage(Text.literal("El Cubo Púrpura te ha tocado... y flotas.").formatted(Formatting.LIGHT_PURPLE, Formatting.ITALIC), true);
    }

    @Override
    protected ParticleEffect getParticles() {
        return ParticleTypes.PORTAL;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Zombie a lápiz. Versión "dibujada" que vive en la Libreta del Becario. */
public class ZombieDibujoEntity extends ZombieEntity {
    public ZombieDibujoEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        // Sin refuerzos de zombi al recibir golpes (como el Zombie Naranja)
        EntityAttributeInstance refuerzos = getAttributeInstance(EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS);
        if (refuerzos != null) {
            refuerzos.clearModifiers();
            refuerzos.setBaseValue(0);
        }
        return r;
    }

    @Override protected boolean canConvertInWater() { return false; }

    /** En la Libreta el sol es de papel: no quema. */
    @Override protected boolean isAffectedByDaylight() { return false; }
    @Override protected boolean burnsInDaylight() { return false; }
}

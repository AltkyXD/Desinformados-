package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;

/** Zombie a lápiz. Versión "dibujada" que vive en la Libreta del Becario. */
public class ZombieDibujoEntity extends ZombieEntity {
    public ZombieDibujoEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override protected boolean canConvertInWater() { return false; }
}

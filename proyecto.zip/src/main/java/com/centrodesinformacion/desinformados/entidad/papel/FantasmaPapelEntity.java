package com.centrodesinformacion.desinformados.entidad.papel;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Fantasma de Papel (Libreta): una sábana-fantasma dibujada que se pasa el día flotando.
 * Si te ve, va a por ti, te agarra y te sube rápido (0,75 bloques por tick). Si le pegas UNA vez te suelta;
 * si no, te sube unos 30 bloques (o 2 s) y te deja caer. Después descansa 10 s antes de volver a agarrar a nadie.
 * Todo el movimiento lo hace a mano (sin gravedad, sin navegación).
 */
public class FantasmaPapelEntity extends HostileEntity {
    private static final double VELOCIDAD = 0.32;      // persiguiendo
    private static final double PASEO = 0.10;          // de paseo
    private static final double SUBIDA = 0.75;         // bloques por tick con alguien agarrado
    private static final int MAX_AGARRE = 40;          // 2 s (menos de los 4 s que el servidor tolera "flotando")
    private static final double ALTURA_MAX = 30;       // bloques que te puede subir
    private static final int DESCANSO = 200;           // 10 s sin agarrar tras soltar

    @Nullable private UUID agarrado;
    private int ticksAgarre;
    private double yInicio;
    private int descanso;
    @Nullable private Vec3d destino;

    public FantasmaPapelEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 12.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0);
    }

    @Override
    protected void initGoals() {
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));   // solo si te ve
    }

    /** Flota: ni cae ni se hace daño al caer. */
    @Override
    public boolean handleFallDamage(float distancia, float multiplicador, DamageSource fuente) {
        return false;
    }

    public boolean estaAgarrando() {
        return agarrado != null;
    }

    private static boolean valido(@Nullable ServerPlayerEntity p) {
        return p != null && p.isAlive() && !p.isCreative() && !p.isSpectator();
    }

    @Override
    public void tick() {
        setNoGravity(true);
        super.tick();
        if (!(getWorld() instanceof ServerWorld mundo)) return;
        if (descanso > 0) descanso--;
        if (age % 20 == 0) mundo.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.3, getZ(), 2, 0.3, 0.2, 0.3, 0.0);

        if (agarrado != null) {
            tickAgarre(mundo);
            return;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo instanceof ServerPlayerEntity p && valido(p) && descanso == 0) {
            // a por la cabeza del jugador
            Vec3d cabeza = new Vec3d(p.getX(), p.getY() + p.getHeight() + 0.1, p.getZ());
            volarHacia(cabeza, VELOCIDAD);
            if (getPos().squaredDistanceTo(cabeza) < 1.6 * 1.6) agarrar(p);
        } else {
            pasear();
        }
    }

    /** Ajusta la velocidad poco a poco hacia un punto y mira hacia donde va. */
    private void volarHacia(Vec3d punto, double velocidad) {
        Vec3d dif = punto.subtract(getPos());
        if (dif.lengthSquared() < 0.0004) return;
        Vec3d v = getVelocity().multiply(0.75).add(dif.normalize().multiply(velocidad * 0.35));
        if (v.length() > velocidad) v = v.normalize().multiply(velocidad);
        setVelocity(v);
        if (v.horizontalLengthSquared() > 1.0E-4) {
            float yaw = (float) (MathHelper.atan2(v.z, v.x) * (180f / Math.PI)) - 90f;
            setYaw(yaw);
            setBodyYaw(yaw);
            setHeadYaw(yaw);
        }
    }

    /** De paseo: flota entre 4 y 9 bloques por encima del suelo, cambiando de rumbo de vez en cuando. */
    private void pasear() {
        if (destino == null || getPos().squaredDistanceTo(destino) < 1.5 || horizontalCollision || random.nextInt(120) == 0) {
            double x = getX() + random.nextBetween(-10, 10);
            double z = getZ() + random.nextBetween(-10, 10);
            destino = new Vec3d(x, suelo(BlockPos.ofFloored(x, getY(), z)) + 4 + random.nextInt(6), z);
        }
        volarHacia(destino, PASEO);
    }

    /** Altura del suelo bajo una posición (busca hasta 24 bloques hacia abajo). */
    private double suelo(BlockPos desde) {
        BlockPos.Mutable pos = desde.mutableCopy();
        for (int i = 0; i < 24; i++) {
            if (!getWorld().getBlockState(pos).getCollisionShape(getWorld(), pos).isEmpty()) return pos.getY() + 1;
            pos.move(0, -1, 0);
        }
        return desde.getY() - 8;
    }

    private void agarrar(ServerPlayerEntity p) {
        if (p.hasVehicle()) p.stopRiding();
        agarrado = p.getUuid();
        ticksAgarre = 0;
        yInicio = p.getY();
        destino = null;
        getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_PHANTOM_SWOOP, SoundCategory.HOSTILE, 1f, 1.5f);
        p.sendMessage(Text.literal("¡Un Fantasma de Papel te lleva volando! Pégale para soltarte").formatted(Formatting.RED, Formatting.BOLD), true);
    }

    private void tickAgarre(ServerWorld mundo) {
        ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(agarrado);
        if (!valido(p) || p.getWorld() != mundo || p.squaredDistanceTo(this) > 36) {
            soltar(p, false);
            return;
        }
        ticksAgarre++;
        // Arriba los dos: el jugador sube y el fantasma se queda pegado encima de su cabeza
        p.setVelocity(0, SUBIDA, 0);
        p.velocityModified = true;
        setPosition(p.getX(), p.getY() + p.getHeight() + 0.1, p.getZ());
        setVelocity(0, SUBIDA, 0);
        if (ticksAgarre % 4 == 0) mundo.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY(), p.getZ(), 2, 0.2, 0.1, 0.2, 0.0);
        boolean techo = ticksAgarre > 6 && p.verticalCollision;
        if (ticksAgarre >= MAX_AGARRE || p.getY() - yInicio >= ALTURA_MAX || techo) soltar(p, false);
    }

    /** Suelta al jugador (golpeado = porque le ha pegado). */
    private void soltar(@Nullable ServerPlayerEntity p, boolean golpeado) {
        agarrado = null;
        descanso = DESCANSO;
        setVelocity((random.nextDouble() - 0.5) * 0.6, 0.25, (random.nextDouble() - 0.5) * 0.6);
        if (p != null) {
            p.sendMessage(golpeado
                    ? Text.literal("¡Te has soltado del Fantasma de Papel!").formatted(Formatting.GREEN)
                    : Text.literal("El Fantasma de Papel te ha soltado... desde muy arriba").formatted(Formatting.GRAY, Formatting.ITALIC), true);
        }
        getWorld().playSound(null, getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.HOSTILE, 1f, 0.7f);
    }

    /** Un golpe de cualquier jugador le hace soltar a quien lleve. */
    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && agarrado != null && !getWorld().isClient() && fuente.getAttacker() instanceof PlayerEntity) {
            soltar(getServer() == null ? null : getServer().getPlayerManager().getPlayer(agarrado), true);
        }
        return r;
    }

    @Override
    public void remove(RemovalReason razon) {
        if (!getWorld().isClient() && agarrado != null) {
            soltar(getServer() == null ? null : getServer().getPlayerManager().getPlayer(agarrado), false);
        }
        super.remove(razon);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        setNoGravity(true);
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ITEM_BOOK_PAGE_TURN; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ITEM_BOOK_PUT; }
}

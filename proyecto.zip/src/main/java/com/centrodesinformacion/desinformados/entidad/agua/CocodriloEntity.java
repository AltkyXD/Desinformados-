package com.centrodesinformacion.desinformados.entidad.agua;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.control.AquaticMoveControl;
import net.minecraft.entity.ai.control.YawAdjustingLookControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.WanderAroundGoal;
import net.minecraft.entity.ai.pathing.AmphibiousSwimNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.ai.pathing.PathNodeType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

import java.util.EnumSet;

/**
 * Cocodrilo: mob anfibio y hostil (HostileEntity, no WaterCreatureEntity: así no se asfixia en tierra).
 * Nada bien (se mueve como el ajolote: AquaticMoveControl + AmphibiousSwimNavigation, sin gravedad en el agua),
 * respira bajo el agua y también fuera (no se ahoga en ningún sitio) y anda por tierra a velocidad de zombi.
 * Si su mordisco alcanza a un jugador que está en el agua, lo agarra con la boca: hasta 12 s lo lleva pegado al morro
 * mientras nada hacia el fondo, quitándole medio corazón cada 2,5 s. Lo suelta a los 12 s, al recibir 3 golpes de ese
 * jugador, si muere o si salen los dos del agua. Luego tarda 8 s en poder agarrar otra vez.
 */
public class CocodriloEntity extends HostileEntity {
    private static final TrackedData<Boolean> AGARRANDO = DataTracker.registerData(CocodriloEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public static final int DURACION_AGARRE = 12 * 20;   // 12 s como mucho
    public static final int CADA_DANIO = 50;              // medio corazón cada 2,5 s
    public static final int ENFRIAMIENTO = 8 * 20;        // 8 s antes de volver a agarrar
    public static final int GOLPES_PARA_SOLTAR = 3;
    private static final float DANIO_AGARRE = 1.0f;       // medio corazón
    private static final double DELANTE_BOCA = 1.35;      // a cuántos bloques del centro queda la presa (el morro mide ~1,45)

    // Estado del agarre (solo en el servidor; no se guarda: al recargar el mundo, suelta)
    private PlayerEntity presa;
    private int agarreTicks;
    private int golpes;
    private int puedeAgarrarEn;

    public CocodriloEntity(EntityType<? extends CocodriloEntity> type, World world) {
        super(type, world);
        // Como el ajolote: nada con cabeceo (sube y baja según el pitch) y en tierra camina
        this.moveControl = new AquaticMoveControl(this, 85, 10, 0.02f, 0.25f, false);
        this.lookControl = new YawAdjustingLookControl(this, 10);
        this.setPathfindingPenalty(PathNodeType.WATER, 0.0f);
        this.experiencePoints = 15;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
                .add(EntityAttributes.GENERIC_ARMOR, 4.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.5)
                // con AquaticMoveControl: en el agua 1,0 x 0,02 (~4 bloques/s), en tierra 1,0 x 0,25 (como un zombi)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0)
                .add(EntityAttributes.GENERIC_STEP_HEIGHT, 1.0);   // sube a la orilla sin tener que saltar
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(AGARRANDO, false);
    }

    /** Para el modelo: con alguien en la boca la mandíbula se queda medio abierta. */
    public boolean estaAgarrando() {
        return dataTracker.get(AGARRANDO);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(1, new ArrastrarGoal());
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(5, new WanderAroundGoal(this, 0.7, 60));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        // Va a por los jugadores que están en el agua, o que se acercan demasiado a la orilla (8 bloques)
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true,
                objetivo -> objetivo.isTouchingWater() || objetivo.squaredDistanceTo(this) < 64.0));
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new AmphibiousSwimNavigation(this, world);
    }

    // ============================== Movimiento y respiración ==============================

    /** En el agua nada sin gravedad (como el ajolote); fuera, el movimiento normal de tierra. */
    @Override
    public void travel(Vec3d movementInput) {
        if (isLogicalSideForUpdatingMovement() && isTouchingWater()) {
            updateVelocity(getMovementSpeed(), movementInput);
            move(MovementType.SELF, getVelocity());
            setVelocity(getVelocity().multiply(0.9));
        } else {
            super.travel(movementInput);
        }
    }

    /**
     * Respira bajo el agua (y fuera, como cualquier mob): nunca se ahoga. En 1.21.1 canBreatheInWater() es final
     * (va por la etiqueta can_breathe_under_water), así que se hace como los peces (WaterCreatureEntity):
     * el aire se rellena después de cada baseTick y nunca llega a -20, que es cuando se recibe daño por ahogo.
     */
    @Override
    public void baseTick() {
        super.baseTick();
        if (isAlive()) setAir(getMaxAir());
    }

    /** Las corrientes no lo arrastran. */
    @Override
    public boolean isPushedByFluids() {
        return false;
    }

    /** Prefiere el agua al deambular (y así también puede aparecer de día: el hostil normal solo quiere sitios oscuros). */
    @Override
    public float getPathfindingFavor(BlockPos pos, WorldView world) {
        return world.getFluidState(pos).isIn(FluidTags.WATER) ? 10.0f : super.getPathfindingFavor(pos, world);
    }

    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    // ============================== Aparición ==============================

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Puede aparecer dentro del agua (el MobEntity normal no deja aparecer si la caja toca líquido). */
    @Override
    public boolean canSpawn(WorldView world) {
        return world.doesNotIntersectEntities(this);
    }

    // ============================== Sonidos ==============================

    @Override
    public SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_HOGLIN_AMBIENT;
    }

    @Override
    public SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RAVAGER_HURT;
    }

    @Override
    public SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RAVAGER_DEATH;
    }

    @Override
    public float getSoundPitch() {
        return super.getSoundPitch() * 0.75f;
    }

    @Override
    public int getMinAmbientSoundDelay() {
        return 200;
    }

    // ============================== El agarre ==============================

    private static boolean valido(PlayerEntity p) {
        return p != null && p.isAlive() && !p.isRemoved() && !p.isCreative() && !p.isSpectator();
    }

    /** Si su mordisco acierta a un jugador que está en el agua, lo agarra. */
    @Override
    public boolean tryAttack(Entity target) {
        boolean acierta = super.tryAttack(target);
        if (acierta && presa == null && age >= puedeAgarrarEn && isAlive() && !getWorld().isClient()
                && target instanceof PlayerEntity p && valido(p) && p.isTouchingWater() && !p.hasVehicle() && nadieLoTiene(p)) {
            agarrar(p);
        }
        return acierta;
    }

    /** Que no se lo disputen dos cocodrilos a la vez. */
    private boolean nadieLoTiene(PlayerEntity p) {
        return getWorld().getEntitiesByClass(CocodriloEntity.class, p.getBoundingBox().expand(8.0), c -> c.presa == p).isEmpty();
    }

    private void agarrar(PlayerEntity p) {
        presa = p;
        agarreTicks = 0;
        golpes = 0;
        dataTracker.set(AGARRANDO, true);
        getNavigation().stop();
        getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_EVOKER_FANGS_ATTACK, SoundCategory.HOSTILE, 1.2f, 0.6f);
        p.sendMessage(Text.literal("¡Un cocodrilo te ha agarrado! Golpéalo 3 veces para soltarte").formatted(Formatting.RED, Formatting.BOLD), true);
    }

    private void soltar() {
        PlayerEntity p = presa;
        presa = null;
        agarreTicks = 0;
        golpes = 0;
        puedeAgarrarEn = age + ENFRIAMIENTO;
        dataTracker.set(AGARRANDO, false);
        if (p != null && p.isAlive() && !p.isRemoved()) {
            p.sendMessage(Text.literal("¡Te has librado del cocodrilo!").formatted(Formatting.GREEN), true);
        }
    }

    /** Dónde va la presa: delante del morro (sigue el cabeceo al bucear). */
    private Vec3d boca() {
        Vec3d delante = getRotationVector();
        return new Vec3d(getX() + delante.x * DELANTE_BOCA, getY() + 0.1 + delante.y * DELANTE_BOCA * 0.6, getZ() + delante.z * DELANTE_BOCA);
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient() && presa != null) sujetar();
    }

    private void sujetar() {
        PlayerEntity p = presa;
        if (!isAlive() || !valido(p) || p.getWorld() != getWorld() || p.hasVehicle()
                || agarreTicks >= DURACION_AGARRE || golpes >= GOLPES_PARA_SOLTAR
                || (!p.isTouchingWater() && !isTouchingWater()) || squaredDistanceTo(p) > 64.0) {
            soltar();
            return;
        }
        agarreTicks++;
        // Pegado al morro: si se ha alejado mucho (más de 3 bloques) se le teletransporta; si no, se le tira hacia la boca
        Vec3d boca = boca();
        Vec3d hacia = boca.subtract(p.getPos());
        if (hacia.lengthSquared() > 9.0) {
            p.requestTeleport(boca.x, boca.y, boca.z);
        } else {
            Vec3d vel = hacia.multiply(0.5);
            if (vel.lengthSquared() > 0.64) vel = vel.normalize().multiply(0.8);
            p.setVelocity(vel);
            p.velocityModified = true;
        }
        p.fallDistance = 0f;

        if (agarreTicks % CADA_DANIO == 0) {
            p.damage(getDamageSources().mobAttack(this), DANIO_AGARRE);
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_EVOKER_FANGS_ATTACK, SoundCategory.HOSTILE, 0.8f, 0.7f);
        }
        if (agarreTicks % 20 == 0 && valido(p)) {
            p.sendMessage(Text.literal("¡Un cocodrilo te arrastra al fondo! Golpéalo para soltarte (" + golpes + "/" + GOLPES_PARA_SOLTAR + ")")
                    .formatted(Formatting.RED, Formatting.BOLD), true);
        }
        if (agarreTicks % 8 == 0 && p.isSubmergedInWater() && getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.BUBBLE, p.getX(), p.getY() + 0.6, p.getZ(), 5, 0.25, 0.3, 0.25, 0.05);
        }
    }

    /** Los golpes de la presa cuentan para soltarse (3 golpes que hagan daño). */
    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean recibe = super.damage(source, amount);
        if (recibe && presa != null && !getWorld().isClient() && source.getAttacker() == presa) {
            golpes++;
            if (golpes < GOLPES_PARA_SOLTAR) {
                presa.sendMessage(Text.literal("¡Golpe! " + golpes + "/" + GOLPES_PARA_SOLTAR).formatted(Formatting.GOLD, Formatting.BOLD), true);
            }
        }
        return recibe;
    }

    /**
     * Busca el agua más profunda alrededor (debajo y en 8 direcciones a 8 bloques), sin cargar chunks:
     * como mucho 9 columnas de 24 bloques cada segundo.
     */
    private BlockPos buscarFondo(ServerWorld sw) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int x0 = getBlockX(), y0 = getBlockY(), z0 = getBlockZ();
        double giro = getRandom().nextDouble() * Math.PI / 4;
        BlockPos mejor = null;
        int mejorY = Integer.MAX_VALUE;
        for (int i = 0; i < 9; i++) {
            int x = x0, z = z0;
            if (i > 0) {
                double ang = giro + (i - 1) * Math.PI / 4;
                x = x0 + MathHelper.floor(Math.cos(ang) * 8.0);
                z = z0 + MathHelper.floor(Math.sin(ang) * 8.0);
            }
            m.set(x, y0, z);
            if (!sw.isChunkLoaded(m) || !sw.getFluidState(m).isIn(FluidTags.WATER)) continue;
            int y = y0;
            while (y > sw.getBottomY() + 1 && y0 - y < 24) {
                m.set(x, y - 1, z);
                if (!sw.getFluidState(m).isIn(FluidTags.WATER)) break;
                y--;
            }
            if (y < mejorY) {
                mejorY = y;
                mejor = new BlockPos(x, y, z);
            }
        }
        return mejor;
    }

    /** Mientras tiene a alguien en la boca, nada hacia el fondo (y no hace nada más). */
    private class ArrastrarGoal extends Goal {
        private int recalcular;

        ArrastrarGoal() {
            setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
        }

        @Override
        public boolean canStart() {
            return presa != null;
        }

        @Override
        public boolean shouldContinue() {
            return presa != null;
        }

        @Override
        public boolean shouldRunEveryTick() {
            return true;
        }

        @Override
        public void start() {
            recalcular = 0;
        }

        @Override
        public void stop() {
            getNavigation().stop();
        }

        @Override
        public void tick() {
            if (--recalcular <= 0) {
                recalcular = 20;
                if (getWorld() instanceof ServerWorld sw) {
                    BlockPos fondo = buscarFondo(sw);
                    if (fondo != null) getNavigation().startMovingTo(fondo.getX() + 0.5, fondo.getY() + 0.1, fondo.getZ() + 0.5, 1.1);
                }
            }
            // Empujoncito hacia abajo mientras quede agua debajo (por si no encuentra camino)
            if (isTouchingWater() && getWorld().getFluidState(getBlockPos().down()).isIn(FluidTags.WATER)) {
                setVelocity(getVelocity().add(0.0, -0.02, 0.0));
            }
        }
    }
}

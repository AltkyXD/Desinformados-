package com.centrodesinformacion.desinformados.entidad.papel;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Difficulty;
import net.minecraft.world.Heightmap;

import java.util.List;

/**
 * Mobs de papel de la Libreta (parte 2): Travensaño de Papel, Fantasma de Papel y Avión de Papel.
 * Aparecen en los biomas de la Libreta (los pone el datapack de biomas: hoja_llanura y hoja_bosque).
 */
public final class ModPapel {
    private ModPapel() {}

    public static final EntityType<TravensanoPapelEntity> TRAVENSANO_PAPEL = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("travensano_papel"),
            EntityType.Builder.<TravensanoPapelEntity>create(TravensanoPapelEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("travensano_papel"));

    public static final EntityType<FantasmaPapelEntity> FANTASMA_PAPEL = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("fantasma_papel"),
            EntityType.Builder.<FantasmaPapelEntity>create(FantasmaPapelEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.8f, 1.4f).maxTrackingRange(10).build("fantasma_papel"));

    public static final EntityType<AvionPapelEntity> AVION_PAPEL = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("avion_papel"),
            EntityType.Builder.<AvionPapelEntity>create(AvionPapelEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.8f, 0.4f).maxTrackingRange(10).build("avion_papel"));

    private static Item huevo(String id, EntityType<? extends MobEntity> tipo, int base, int manchas) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, base, manchas, new Item.Settings()));
    }

    public static final Item HUEVO_TRAVENSANO_PAPEL = huevo("travensano_papel", TRAVENSANO_PAPEL, 0xF4F0E6, 0xE03CBE);
    public static final Item HUEVO_FANTASMA_PAPEL = huevo("fantasma_papel", FANTASMA_PAPEL, 0xF4F0E6, 0xBAC8E8);
    public static final Item HUEVO_AVION_PAPEL = huevo("avion_papel", AVION_PAPEL, 0xF4F0E6, 0x8A8A92);

    private static final List<Item> HUEVOS = List.of(HUEVO_TRAVENSANO_PAPEL, HUEVO_FANTASMA_PAPEL, HUEVO_AVION_PAPEL);

    /** Lo llama Desinformados.onInitialize. */
    public static void inicializar() {
        FabricDefaultAttributeRegistry.register(TRAVENSANO_PAPEL, TravensanoPapelEntity.atributos());
        FabricDefaultAttributeRegistry.register(FANTASMA_PAPEL, FantasmaPapelEntity.atributos());
        FabricDefaultAttributeRegistry.register(AVION_PAPEL, AvionPapelEntity.atributos());

        SpawnRestriction.register(TRAVENSANO_PAPEL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> m.getDifficulty() != Difficulty.PEACEFUL && HostileEntity.isSpawnDark(m, p, rnd)
                        && MobEntity.canMobSpawn(t, m, r, p, rnd));
        SpawnRestriction.register(FANTASMA_PAPEL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd));
        // (en la Libreta no hay tope de "pocos": es su casa)
        // El Avión es un "phantom", no un HostileEntity: misma regla de oscuridad escrita a mano
        SpawnRestriction.register(AVION_PAPEL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> m.getDifficulty() != Difficulty.PEACEFUL && HostileEntity.isSpawnDark(m, p, rnd)
                        && MobEntity.canMobSpawn(t, m, r, p, rnd));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item h : HUEVOS) e.add(h);
        });
    }
}

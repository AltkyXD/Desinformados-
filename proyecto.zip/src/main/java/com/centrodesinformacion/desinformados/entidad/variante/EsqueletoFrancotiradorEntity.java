package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Esqueleto Francotirador: te ve desde 40 bloques y dispara una sola flecha cada 3 segundos
 * (en cualquier dificultad), pero cada flecha hace un 50 % más de daño (modificador en ModVariantes).
 */
public class EsqueletoFrancotiradorEntity extends SkeletonEntity {
    /** Tensar el arco (20 ticks) + esta espera = 60 ticks = 3 segundos entre flechas. */
    private static final int ESPERA_ARCO = 40;
    private static final int MINIMO_ENTRE_FLECHAS = 55;

    private int recarga = 0;

    public EsqueletoFrancotiradorEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return AbstractSkeletonEntity.createAbstractSkeletonAttributes()
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    // Intervalos del BowAttackGoal vanilla (normal 40, difícil 20): siempre 40 => una flecha cada 3 s.
    // Sin @Override a propósito: si la firma vanilla no fuera accesible, compila igual y manda la recarga de shootAt.
    public int getHardAttackInterval() {
        return ESPERA_ARCO;
    }

    public int getRegularAttackInterval() {
        return ESPERA_ARCO;
    }

    @Override
    public void tick() {
        super.tick();
        if (recarga > 0) recarga--;
    }

    @Override
    public void shootAt(LivingEntity objetivo, float tension) {
        if (recarga > 0) return;            // red de seguridad: nunca dos flechas en menos de ~3 s
        recarga = MINIMO_ENTRE_FLECHAS;
        super.shootAt(objetivo, tension);
    }
}

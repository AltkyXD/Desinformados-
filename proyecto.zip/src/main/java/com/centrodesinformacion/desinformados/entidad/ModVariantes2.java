package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.variante2.CreeperBuloEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.CuboNegroEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.CuboPurpuraEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.FurroGiganteEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.GarabatoElasticoEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.RuidoBlancoEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.TravensanoPesadoEntity;
import com.centrodesinformacion.desinformados.entidad.variante2.ZombieLimonEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Difficulty;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LightType;

import java.util.List;

/**
 * Variantes de los mobs del mod (parte 1 de 2): tipos, atributos, aparición natural y huevos.
 * Todas bloqueadas hasta su tele azul (TelesVariantes2): las que heredan el canSpawn del original miran
 * Mobs.bloqueadoEn(getType()), es decir, su PROPIO tipo; el Travensaño Pesado sobrescribe desbloqueadoSolo.
 */
public final class ModVariantes2 {
    private ModVariantes2() {}

    // =============================== Tipos ===============================

    /** Mismo tamaño que el Creeper Oscuro. */
    public static final EntityType<CreeperBuloEntity> CREEPER_BULO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_bulo"),
            EntityType.Builder.<CreeperBuloEntity>create(CreeperBuloEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_bulo"));

    /** x1,5 del Furro (0,6 x 1,95): el renderer también lo escala x1,5. */
    public static final EntityType<FurroGiganteEntity> FURRO_GIGANTE = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("furro_gigante"),
            EntityType.Builder.<FurroGiganteEntity>create(FurroGiganteEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.9f, 2.925f).eyeHeight(2.61f).maxTrackingRange(8).build("furro_gigante"));

    public static final EntityType<CuboNegroEntity> CUBO_NEGRO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("cubo_negro"),
            EntityType.Builder.<CuboNegroEntity>create(CuboNegroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.52f, 0.52f).maxTrackingRange(10).build("cubo_negro"));

    public static final EntityType<ZombieLimonEntity> ZOMBIE_LIMON = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_limon"),
            EntityType.Builder.<ZombieLimonEntity>create(ZombieLimonEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_limon"));

    public static final EntityType<GarabatoElasticoEntity> GARABATO_ELASTICO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("garabato_elastico"),
            EntityType.Builder.<GarabatoElasticoEntity>create(GarabatoElasticoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).maxTrackingRange(8).build("garabato_elastico"));

    public static final EntityType<RuidoBlancoEntity> RUIDO_BLANCO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("ruido_blanco"),
            EntityType.Builder.<RuidoBlancoEntity>create(RuidoBlancoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.7f).maxTrackingRange(10).build("ruido_blanco"));

    public static final EntityType<TravensanoPesadoEntity> TRAVENSANO_PESADO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("travensano_pesado"),
            EntityType.Builder.<TravensanoPesadoEntity>create(TravensanoPesadoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("travensano_pesado"));

    /** Del Nether, como el Cubo Rojo: no le afecta el fuego. */
    public static final EntityType<CuboPurpuraEntity> CUBO_PURPURA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("cubo_purpura"),
            EntityType.Builder.<CuboPurpuraEntity>create(CuboPurpuraEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.52f, 0.52f).makeFireImmune().maxTrackingRange(10).build("cubo_purpura"));

    // =============================== Huevos ===============================

    private static Item huevo(String id, EntityType<? extends MobEntity> tipo, int base, int manchas) {
        return Registry.register(Registries.ITEM, Desinformados.id(id + "_spawn_egg"), new SpawnEggItem(tipo, base, manchas, new Item.Settings()));
    }

    public static final Item HUEVO_CREEPER_BULO = huevo("creeper_bulo", CREEPER_BULO, 0xC9C6B8, 0x1E1E1E);
    public static final Item HUEVO_FURRO_GIGANTE = huevo("furro_gigante", FURRO_GIGANTE, 0x6B4226, 0xD8B98A);
    public static final Item HUEVO_CUBO_NEGRO = huevo("cubo_negro", CUBO_NEGRO, 0x111111, 0x6A2C91);
    public static final Item HUEVO_ZOMBIE_LIMON = huevo("zombie_limon", ZOMBIE_LIMON, 0xF2E53D, 0x4E8A2E);
    public static final Item HUEVO_GARABATO_ELASTICO = huevo("garabato_elastico", GARABATO_ELASTICO, 0xF5F1E6, 0xD02020);
    public static final Item HUEVO_RUIDO_BLANCO = huevo("ruido_blanco", RUIDO_BLANCO, 0x9A9A9A, 0x1A1A1A);
    public static final Item HUEVO_TRAVENSANO_PESADO = huevo("travensano_pesado", TRAVENSANO_PESADO, 0x5A6A80, 0x2B2F3A);
    public static final Item HUEVO_CUBO_PURPURA = huevo("cubo_purpura", CUBO_PURPURA, 0x8A2BE2, 0xD8A0FF);

    private static final List<Item> HUEVOS = List.of(HUEVO_CREEPER_BULO, HUEVO_FURRO_GIGANTE, HUEVO_CUBO_NEGRO, HUEVO_ZOMBIE_LIMON,
            HUEVO_GARABATO_ELASTICO, HUEVO_RUIDO_BLANCO, HUEVO_TRAVENSANO_PESADO, HUEVO_CUBO_PURPURA);

    /** Lo llama Desinformados.onInitialize, después de ModVariantes.inicializar(). */
    public static void inicializar() {
        // ---------- Atributos ----------
        FabricDefaultAttributeRegistry.register(CREEPER_BULO, CreeperEntity.createCreeperAttributes());
        FabricDefaultAttributeRegistry.register(FURRO_GIGANTE, FurroGiganteEntity.atributos());
        FabricDefaultAttributeRegistry.register(CUBO_NEGRO, HostileEntity.createHostileAttributes());       // como el Cubo Blanco
        FabricDefaultAttributeRegistry.register(ZOMBIE_LIMON, ZombieNaranjaEntity.atributos());             // misma vida y velocidad que el Naranja
        FabricDefaultAttributeRegistry.register(GARABATO_ELASTICO, GarabatoEntity.atributos());
        FabricDefaultAttributeRegistry.register(RUIDO_BLANCO, InterferenciaEntity.atributos());
        FabricDefaultAttributeRegistry.register(TRAVENSANO_PESADO, TravensanoEntity.atributos());
        FabricDefaultAttributeRegistry.register(CUBO_PURPURA, HostileEntity.createHostileAttributes());     // como el Cubo Rojo

        // ---------- Aparición natural (pesos bajos: son versiones raras; bloqueadas hasta su tele azul) ----------
        var overworld = BiomeSelectors.foundInOverworld();

        // Creeper Bulo: como el Oscuro (su canSpawn heredado: solo en cuevas, por debajo de la capa 50 y sin cielo)
        SpawnRestriction.register(CREEPER_BULO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 1));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, CREEPER_BULO, 7, 1, 1);

        // Furro Gigante: en la superficie a cualquier hora (de día menos), como el Furro
        SpawnRestriction.register(FURRO_GIGANTE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos) && ModEntidades.aVeces(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 1));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, FURRO_GIGANTE, 6, 1, 1);

        // Cubo Negro: en la superficie y de noche, como el Cubo Blanco
        SpawnRestriction.register(CUBO_NEGRO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos)
                        && HostileEntity.isSpawnDark(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random)
                        && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, CUBO_NEGRO, 7, 1, 1);

        // Zombie Limón: lugares oscuros, como el Naranja
        SpawnRestriction.register(ZOMBIE_LIMON, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (t, m, r, p, rnd) -> HostileEntity.canSpawnInDark(t, m, r, p, rnd) && ModEntidades.pocos(m, t, p, r, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, ZOMBIE_LIMON, 9, 1, 1);

        // Garabato Elástico: en la superficie a cualquier hora (de día menos), como el Garabato
        SpawnRestriction.register(GARABATO_ELASTICO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> ModEntidades.enSuperficie(mundo, pos) && ModEntidades.aVeces(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random) && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, GARABATO_ELASTICO, 7, 1, 1);

        // Ruido Blanco: solo en oscuridad total (sin cielo y sin ninguna luz), como la Interferencia
        SpawnRestriction.register(RUIDO_BLANCO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && !mundo.isSkyVisible(pos)
                        && mundo.getLightLevel(LightType.BLOCK, pos) == 0
                        && mundo.getLightLevel(LightType.SKY, pos) == 0
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random)
                        && ModEntidades.pocos(mundo, tipo, pos, razon, 1));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, RUIDO_BLANCO, 7, 1, 1);

        // Travensaño Pesado: lugares oscuros, como el Travensaño (no es HostileEntity: regla de oscuridad a mano)
        SpawnRestriction.register(TRAVENSANO_PESADO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && HostileEntity.isSpawnDark(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random)
                        && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(overworld, SpawnGroup.MONSTER, TRAVENSANO_PESADO, 7, 1, 1);

        // Cubo Púrpura: Nether, a oscuras, como el Cubo Rojo (es un "slime": regla de oscuridad a mano)
        SpawnRestriction.register(CUBO_PURPURA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != Difficulty.PEACEFUL
                        && HostileEntity.isSpawnDark(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random)
                        && ModEntidades.pocos(mundo, tipo, pos, razon, 2));
        BiomeModifications.addSpawn(BiomeSelectors.foundInTheNether(), SpawnGroup.MONSTER, CUBO_PURPURA, 7, 1, 1);

        // ---------- Huevos en la pestaña de herramientas ----------
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item h : HUEVOS) e.add(h);
        });
    }
}

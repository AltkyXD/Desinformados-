package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.Vida;
import com.centrodesinformacion.desinformados.entidad.InterferenciaEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Ruido Blanco: las mismas costumbres que la Interferencia (solo en oscuridad total, miedo a las antorchas, rápido,
 * 4 corazones, desaparece al tocarte), pero SIN el susto en pantalla: Náuseas 6 s + Ceguera 3 s y 3 corazones menos
 * durante 1 minuto (Vida.sustoTemporal: modificador temporal que se quita a los 60 s y no se guarda al salir ni sobrevive a morir).
 * Un corazón de alma evita perder los corazones, como con la Interferencia. No se clona con "interferencias_clon".
 */
public class RuidoBlancoEntity extends InterferenciaEntity {
    private static final int CORAZONES = 3;
    private static final int SEGUNDOS = 60;

    public RuidoBlancoEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void asustar(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 6 * 20, 0, false, true), this);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 3 * 20, 0, false, true), this);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.HOSTILE, 0.7f, 1.6f); // chisporroteo
        if (Vida.gastarAlma(p)) {
            p.sendMessage(Text.literal("Un corazón de alma ha protegido tus corazones del Ruido Blanco").formatted(Formatting.AQUA), false);
        } else {
            Vida.sustoTemporal(p, CORAZONES, SEGUNDOS);
            p.sendMessage(Text.literal("El Ruido Blanco te ha quitado 3 corazones durante 1 minuto").formatted(Formatting.GRAY), false);
        }
    }

    /** Sus clones serían Interferencias (con susto): este no se clona. */
    @Override
    protected boolean seClona() {
        return false;
    }
}

package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Abeja Asesina: siempre enfadada con el jugador más cercano a menos de 16 bloques.
 * Su picadura da Veneno II 8 segundos y NO muere al picar: pica como mucho cada 2 segundos.
 * 6 corazones, pega 1,5. No existe en pacífico.
 */
public class AbejaAsesinaEntity extends BeeEntity {
    private static final double RADIO = 16;
    private static final int ENTRE_PICADURAS = 40;   // 2 s
    private static final int VENENO = 8 * 20;

    private int espera = 0;

    public AbejaAsesinaEntity(EntityType<? extends BeeEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return BeeEntity.createBeeAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 12.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || !isAlive()) return;
        if (espera > 0) espera--;
        if (age % 20 != 0) return;
        PlayerEntity p = getWorld().getClosestPlayer(getX(), getY(), getZ(), RADIO, true);
        if (!Variantes.valido(p)) return;
        setAngryAt(p.getUuid());
        setAngerTime(400);
        if (getTarget() != p) setTarget(p);
    }

    /**
     * Picadura propia (sin llamar a la de la abeja normal, que la marca como "ha picado" y la mata al rato):
     * daño de picadura + Veneno II 8 s, y luego 2 segundos de espera.
     */
    @Override
    public boolean tryAttack(Entity objetivo) {
        if (espera > 0) return false;
        DamageSource fuente = getDamageSources().sting(this);
        boolean golpe = objetivo.damage(fuente, (float) getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE));
        if (golpe) {
            espera = ENTRE_PICADURAS;
            if (objetivo instanceof LivingEntity vivo) {
                vivo.setStingerCount(vivo.getStingerCount() + 1);
                vivo.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, VENENO, 1), this);
            }
            playSound(SoundEvents.ENTITY_BEE_STING, 1f, 1f);
        }
        return golpe;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    /** Es un monstruo: en pacífico desaparece. */
    @Override
    public boolean isDisallowedInPeaceful() {
        return true;
    }

    /** Como los monstruos: puede desaparecer lejos de los jugadores. */
    @Override
    public boolean canImmediatelyDespawn(double distanciaCuadrada) {
        return true;
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.world.World;

/** Creeper a lápiz. Versión "dibujada" que vive en la Libreta del Becario. */
public class CreeperDibujoEntity extends CreeperEntity {
    public CreeperDibujoEntity(EntityType<? extends CreeperEntity> type, World world) {
        super(type, world);
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Brandon: rápido y frágil (8 corazones). Te ataca primero desde lejos con rayos azules que te
 * paralizan medio segundo. La primera vez que le pegas llega Kevin a tanquear: mientras Kevin esté
 * cerca, los golpes que le des a Brandon se los come Kevin. Los rayos no le hacen nada a Kevin.
 */
public class BrandonEntity extends HostileEntity {
    private static final TrackedData<Boolean> DISPARANDO = DataTracker.registerData(BrandonEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    static final DustParticleEffect AZUL = new DustParticleEffect(new Vector3f(0.35f, 0.82f, 1f), 1.1f);
    private static final int CARGA = 14;           // tiempo para esquivar el rayo
    private static final int ESPERA = 45;          // entre rayos
    private static final float DANO_RAYO = 4f;
    private static final int STUN = 10;            // medio segundo

    /** Cambio de dificultad: Brandon cura a Kevin, dispara más rápido y Kevin tiene el doble de vida. */
    public static final String MEJORA = "brandon_mejorado";
    private static final int CURA_CADA = 60;       // cada 3 s
    private static final float CURA = 4f;          // 2 corazones

    private UUID kevin;
    private boolean kevinLlamado = false;

    public BrandonEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 15;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(DISPARANDO, false);
    }

    public boolean isDisparando() {
        return dataTracker.get(DISPARANDO);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new RayosGoal());
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this, KevinEntity.class));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    // ------------------------------------------------------------ Kevin

    KevinEntity kevin() {
        if (kevin == null || !(getWorld() instanceof ServerWorld sw)) return null;
        return sw.getEntity(kevin) instanceof KevinEntity k && k.isAlive() ? k : null;
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        if (getWorld().isClient() || !(fuente.getAttacker() instanceof PlayerEntity jugador)) return super.damage(fuente, cantidad);
        if (!kevinLlamado) {
            kevinLlamado = true;
            llamarKevin(jugador);
            return super.damage(fuente, cantidad);
        }
        KevinEntity k = kevin();
        if (k != null && k.squaredDistanceTo(this) < 16 && !isInvulnerableTo(fuente)) {
            // Kevin se interpone y se come el golpe
            ServerWorld sw = (ServerWorld) getWorld();
            sw.spawnParticles(ParticleTypes.CRIT, k.getX(), k.getBodyY(0.6), k.getZ(), 8, 0.3, 0.3, 0.3, 0.2);
            sw.playSound(null, k.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.HOSTILE, 0.9f, 0.8f);
            k.damage(fuente, cantidad);
            if (jugador instanceof ServerPlayerEntity sp && random.nextInt(3) == 0) {
                sp.sendMessage(Text.literal("Kevin: «¡A Brandon no lo tocas!»").formatted(Formatting.GRAY), true);
            }
            return false;
        }
        return super.damage(fuente, cantidad);
    }

    private void llamarKevin(PlayerEntity jugador) {
        if (!(getWorld() instanceof ServerWorld sw)) return;
        KevinEntity k = ModEntidades.KEVIN.create(sw);
        if (k == null) return;
        Vec3d hacia = jugador.getPos().subtract(getPos()).multiply(1, 0, 1);
        hacia = hacia.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : hacia.normalize();
        Vec3d pos = getPos().add(hacia.multiply(1.5));
        BlockPos bp = BlockPos.ofFloored(pos);
        if (!sw.getBlockState(bp).getCollisionShape(sw, bp).isEmpty()) pos = getPos();
        k.refreshPositionAndAngles(pos.x, getY(), pos.z, getYaw(), 0f);
        k.setBrandon(getUuid());
        k.setTarget(jugador);
        k.addCommandTag(com.centrodesinformacion.desinformados.Mobs.MARCA_EVENTO);
        sw.spawnEntity(k);
        kevin = k.getUuid();
        setPersistent();
        k.setPersistent();
        sw.spawnParticles(ParticleTypes.POOF, k.getX(), k.getBodyY(0.5), k.getZ(), 30, 0.4, 0.8, 0.4, 0.05);
        sw.spawnParticles(ParticleTypes.CLOUD, k.getX(), k.getY() + 0.1, k.getZ(), 15, 0.6, 0.05, 0.6, 0.02);
        sw.playSound(null, k.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_REPAIR, SoundCategory.HOSTILE, 1f, 0.7f);
        sw.playSound(null, k.getBlockPos(), SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, SoundCategory.HOSTILE, 0.8f, 1.3f);
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.squaredDistanceTo(this) < 32 * 32) {
                p.sendMessage(Text.literal("¡Kevin ha llegado para cubrir a Brandon!").formatted(Formatting.DARK_GRAY, Formatting.BOLD), true);
            }
        }
    }

    // ------------------------------------------------------------ rayos

    /** Mantiene la distancia (ni muy cerca ni muy lejos) y dispara rayos que se pueden esquivar. */
    private class RayosGoal extends Goal {
        private int espera = 20;
        private int carga = 0;
        private Vec3d apuntado;

        RayosGoal() { setControls(EnumSet.of(Control.MOVE, Control.LOOK)); }

        @Override
        public boolean canStart() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean shouldContinue() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive() && !(t instanceof PlayerEntity p && (p.isCreative() || p.isSpectator()));
        }

        @Override
        public void stop() {
            carga = 0;
            dataTracker.set(DISPARANDO, false);
        }

        @Override
        public boolean shouldRunEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity t = getTarget();
            if (t == null) return;
            getLookControl().lookAt(t, 30f, 30f);
            double dist = distanceTo(t);
            boolean ve = getVisibilityCache().canSee(t);
            if (carga > 0) {
                getNavigation().stop();
                carga--;
                if (getWorld() instanceof ServerWorld sw) {
                    Vec3d mano = getPos().add(getRotationVector().multiply(0.6)).add(0, 1.3, 0);
                    sw.spawnParticles(AZUL, mano.x, mano.y, mano.z, 3, 0.15, 0.15, 0.15, 0);
                    sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, mano.x, mano.y, mano.z, 2, 0.2, 0.2, 0.2, 0.05);
                }
                if (carga == 0) {
                    disparar(apuntado);
                    dataTracker.set(DISPARANDO, false);
                    espera = mejorado() ? ESPERA / 2 + random.nextInt(8) : ESPERA + random.nextInt(15);
                }
                return;
            }
            if (dist > 15 || !ve) {
                getNavigation().startMovingTo(t, 1.0);
            } else if (dist < 7) {
                Vec3d lejos = getPos().subtract(t.getPos()).multiply(1, 0, 1);
                lejos = lejos.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : lejos.normalize();
                Vec3d destino = getPos().add(lejos.multiply(6));
                getNavigation().startMovingTo(destino.x, destino.y, destino.z, 1.25);
            } else {
                getNavigation().stop();
            }
            if (--espera <= 0 && ve && dist <= 22) {
                carga = mejorado() ? CARGA - 4 : CARGA;
                apuntado = t.getEyePos().add(0, -0.3, 0);   // apunta a donde estás AHORA: muévete para esquivarlo
                dataTracker.set(DISPARANDO, true);
                getWorld().playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 0.8f, 2f);
            }
        }
    }

    private void disparar(Vec3d apuntado) {
        if (!(getWorld() instanceof ServerWorld sw) || apuntado == null) return;
        Vec3d desde = getEyePos().add(getRotationVector().multiply(0.4)).add(0, -0.2, 0);
        Vec3d dir = apuntado.subtract(desde);
        if (dir.lengthSquared() < 0.01) return;
        Vec3d hasta = desde.add(dir.normalize().multiply(24));
        BlockHitResult choque = sw.raycast(new RaycastContext(desde, hasta, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, this));
        if (choque.getType() != HitResult.Type.MISS) hasta = choque.getPos();

        // El rayo: zigzag de partículas azules
        double largo = desde.distanceTo(hasta);
        Vec3d paso = hasta.subtract(desde).normalize();
        for (double d = 0; d < largo; d += 0.35) {
            double ox = (random.nextDouble() - 0.5) * 0.18, oy = (random.nextDouble() - 0.5) * 0.18, oz = (random.nextDouble() - 0.5) * 0.18;
            Vec3d p = desde.add(paso.multiply(d)).add(ox, oy, oz);
            sw.spawnParticles(AZUL, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            if (random.nextInt(4) == 0) sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.02);
        }
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.HOSTILE, 0.7f, 1.9f);

        // El Muñeco de Prueba también recibe los rayos (para probar)
        for (MunecoEntity m : sw.getEntitiesByClass(MunecoEntity.class, getBoundingBox().expand(26), x -> true)) {
            if (m.getBoundingBox().expand(0.3).raycast(desde, hasta).isPresent()) m.damage(getDamageSources().mobAttack(this), DANO_RAYO);
        }
        // A quién le da: solo jugadores (ni a Kevin ni a otros mobs)
        for (ServerPlayerEntity p : sw.getPlayers()) {
            if (p.isCreative() || p.isSpectator() || p.squaredDistanceTo(this) > 26 * 26) continue;
            if (p.getBoundingBox().expand(0.3).raycast(desde, hasta).isEmpty()) continue;
            if (p.damage(getDamageSources().mobAttack(this), DANO_RAYO)) {
                aturdir(p);
                sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getBodyY(0.5), p.getZ(), 20, 0.3, 0.6, 0.3, 0.1);
            }
        }
    }

    /** Medio segundo paralizado: no te puedes mover, ni saltar, ni pegar bien. */
    private static void aturdir(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, STUN, 9, false, false, true));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, STUN, 4, false, false, true));
        p.setVelocity(0, Math.min(0, p.getVelocity().y), 0);
        p.velocityModified = true;
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 0.6f, 2f);
    }

    static boolean mejorado(World mundo) {
        return mundo.getServer() != null
                && com.centrodesinformacion.desinformados.EstadoServidor.get(mundo.getServer()).tieneCambio(MEJORA);
    }

    private boolean mejorado() {
        return mejorado(getWorld());
    }

    /** Con la mejora: le lanza un rayo curativo a Kevin si está herido y cerca. */
    private void curarKevin(ServerWorld sw) {
        KevinEntity k = kevin();
        if (k == null || k.getHealth() >= k.getMaxHealth() || k.squaredDistanceTo(this) > 12 * 12) return;
        k.heal(CURA);
        Vec3d desde = getPos().add(0, 1.3, 0), hasta = k.getPos().add(0, 1.0, 0);
        Vec3d paso = hasta.subtract(desde);
        int n = (int) (paso.length() / 0.3);
        for (int i = 0; i <= n; i++) {
            Vec3d p = desde.add(paso.multiply(i / (double) Math.max(1, n)));
            sw.spawnParticles(AZUL, p.x, p.y, p.z, 1, 0.03, 0.03, 0.03, 0);
        }
        sw.spawnParticles(ParticleTypes.HAPPY_VILLAGER, k.getX(), k.getBodyY(0.6), k.getZ(), 8, 0.35, 0.5, 0.35, 0);
        sw.playSound(null, k.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.HOSTILE, 1f, 1.6f);
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient() && age % CURA_CADA == 0 && getWorld() instanceof ServerWorld sc && mejorado()) curarKevin(sc);
        // chispas que le salen del pelo
        if (!getWorld().isClient() && age % 12 == 0 && getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1.9, getZ(), 2, 0.25, 0.1, 0.25, 0.02);
        }
    }

    // ------------------------------------------------------------ guardado

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("KevinLlamado", kevinLlamado);
        if (kevin != null) nbt.putUuid("Kevin", kevin);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        kevinLlamado = nbt.getBoolean("KevinLlamado");
        if (nbt.containsUuid("Kevin")) kevin = nbt.getUuid("Kevin");
    }
}

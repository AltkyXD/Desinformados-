package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.network.ManipuladoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/**
 * Angel Manipulador: si te ve, te "manipula": tu cámara queda fija en él, no puedes moverte,
 * tu pantalla se pone azul y te arrastra hacia él. Cuando te tiene cerca, tienes 2 segundos
 * para matarlo antes de que explote. 10 corazones.
 */
public class AngelEntity extends HostileEntity {
    private static final double ALCANCE = 16;
    private static final double CERCA = 2.5;
    private static final int MECHA = 40; // 2 segundos

    @Nullable private ServerPlayerEntity manipulado;
    private int mecha = 0;

    public AngelEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && (world.getServer() == null
                || !EstadoServidor.get(world.getServer()).tieneCambio("angel"))) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        setCustomName(Text.literal("Angel"));
        setCustomNameVisible(true);
        if (reason != SpawnReason.NATURAL) setPersistent();
        return super.initialize(world, difficulty, reason, data);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld mundo)) return;
        if (age % 6 == 0) mundo.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 2, 0.4, 0.7, 0.4, 0.05);

        ServerPlayerEntity p = getTarget() instanceof ServerPlayerEntity sp && sp.isAlive() && !sp.isCreative() && !sp.isSpectator() ? sp : null;
        if (p == null || distanceTo(p) > ALCANCE || (!canSee(p) && manipulado == null)) {
            soltar();
            return;
        }
        if (manipulado != p) {
            soltar();
            manipulado = p;
            mundo.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 1f, 0.6f);
            p.sendMessage(Text.literal("Angel te está manipulando...").formatted(Formatting.BLUE, Formatting.BOLD), true);
        }
        getNavigation().stop();
        getLookControl().lookAt(p, 30f, 30f);
        if (age % 4 == 0 && ServerPlayNetworking.canSend(p, ManipuladoPayload.ID)) {
            ServerPlayNetworking.send(p, new ManipuladoPayload(getId(), 10));
        }
        // Rayos de manipulación entre los dos
        if (age % 3 == 0) {
            Vec3d a = getEyePos(), b = p.getEyePos();
            for (int i = 0; i <= 8; i++) {
                Vec3d v = a.lerp(b, i / 8.0);
                mundo.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, v.x, v.y, v.z, 1, 0.05, 0.05, 0.05, 0);
            }
        }

        double dist = distanceTo(p);
        if (dist > CERCA) {
            // Te arrastra hacia él
            Vec3d dir = getPos().subtract(p.getPos()).normalize().multiply(0.42);
            p.setVelocity(dir.x, Math.max(p.getVelocity().y, dir.y * 0.5), dir.z);
            p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
            p.fallDistance = 0;
        } else {
            // Ya te tiene: 2 segundos para matarlo
            mecha++;
            if (mecha == 1) mundo.playSound(null, getBlockPos(), SoundEvents.ENTITY_CREEPER_PRIMED, SoundCategory.HOSTILE, 1f, 0.7f);
            if (mecha % 10 == 0 && mecha < MECHA) {
                p.sendMessage(Text.literal("¡Mátalo! " + String.format("%.1f", (MECHA - mecha) / 20f) + " s").formatted(Formatting.RED, Formatting.BOLD), true);
            }
            mundo.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 6, 0.5, 0.8, 0.5, 0.2);
            if (mecha >= MECHA) explotar(mundo);
        }
    }

    private void explotar(ServerWorld mundo) {
        soltar();
        mundo.spawnParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
        mundo.createExplosion(this, getX(), getY(), getZ(), 3.5f, World.ExplosionSourceType.NONE);
        discard();
    }

    private void soltar() {
        if (manipulado != null && ServerPlayNetworking.canSend(manipulado, ManipuladoPayload.ID)) {
            ServerPlayNetworking.send(manipulado, new ManipuladoPayload(getId(), 0));
        }
        manipulado = null;
        mecha = 0;
    }

    @Override
    public void remove(RemovalReason razon) {
        if (!getWorld().isClient()) soltar();
        super.remove(razon);
    }
}

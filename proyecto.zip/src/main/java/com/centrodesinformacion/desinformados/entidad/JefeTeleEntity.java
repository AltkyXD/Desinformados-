package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import com.centrodesinformacion.desinformados.network.JefePayload;
import com.centrodesinformacion.desinformados.network.ManipuladoPayload;
import com.centrodesinformacion.desinformados.pasivas.Pasivas;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * JEFE FINAL: La Desinformación (una tele de 5x5).
 * Fase 0: una tele de 5x5 que da saltitos sin rumbo, con estática y apagándose. A los 3 golpes despierta.
 * Fase 1: le salen tentáculos de estática que la levantan, ojos y barra de vida. No se mueve: lanza mobs de estática
 *         por montones hacia todas partes y dispara rayos de estática al jugador que mira (esquivables corriendo).
 * Fase 2: los tentáculos se glitchean, salen más y la tele se despega del suelo. Salta por la arena, sigue disparando,
 *         lanza mobs de todo el juego (menos los clones) y cada 30 segundos lanza una tele roja con algo malo.
 *         Además dispara abanicos de 5 rayos. Sus teles rojas salen pequeñas en una esquina. No habla.
 * Fase 3 (SEÑAL PERDIDA): se teletransporta por toda la arena (avisa 1 s antes: el sitio de llegada echa chispas),
 *         le salen dos tentáculos de los lados que agarran al que esté cerca y lo aplastan (1 corazón cada 1,25 s).
 *         Para soltarse hay que pulsar AGACHARSE 5 veces. Mientras tenga a alguien agarrado no se teletransporta
 *         (es el momento de pegarle). Ola de estática por el suelo: hay que saltarla.
 * En las fases 1 y 3, "lluvia de estática": marca círculos bajo los jugadores y 1,5 s después caen rayos ahí.
 * Las tres barras de vida son de 340 (3 x 340 = 1020; Minecraft no deja pasar de 1024).
 */
public class JefeTeleEntity extends HostileEntity {
    public static final String MARCA_ESBIRRO = "desinfo_esbirro_tele";
    public static final float VIDA_FASE = 340f;                    // cada fase tiene su barra entera (3 barras)
    /** Aguanta el doble: recibe la mitad de daño (la vida máxima de Minecraft no pasa de 1024). */
    public static final float RESISTENCIA = 0.5f;
    /** Cada cuánto lanza mobs (ticks). Un 25 % más de espera = un 20 % menos de mobs. */
    private static final int MOBS_FASE_1 = 100, MOBS_FASE_2 = 150;
    public static final int TRANSICION_1 = 100, TRANSICION_2 = 120, TRANSICION_3 = 140;
    /** Fase 3: veces que hay que agacharse para soltarse de un tentáculo. */
    public static final int AGACHARSE_PARA_SOLTAR = 5;
    private static final int AGARRE_MAX = 240;                    // 12 s como mucho, luego te lanza
    private static final int AGARRE_DANIO_CADA = 25;              // 1 corazón cada 1,25 s
    private static final int AVISO_TP = 20;                       // 1 s de aviso antes de teletransportarse
    public static final int GOLPES_PARA_DESPERTAR = 3;
    private static final int RADIO_ARENA = 48;
    /** Máximo de esbirros vivos a la vez en la fase 2 (incluida la lluvia de creepers). */
    private static final int MAX_ESBIRROS = 30;

    private static final TrackedData<Integer> FASE = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TRANSICION = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> GOLPES = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> OBJETIVO = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** Fase 3: id del jugador agarrado por el tentáculo derecho (0) e izquierdo (1); -1 = libre. */
    private static final TrackedData<Integer> AGARRE_0 = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> AGARRE_1 = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** Fase 3: ticks que faltan para teletransportarse (el renderer hace parpadear la tele); 0 = nada. */
    private static final TrackedData<Integer> TP = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos casa = null;
    private int esperaSalto = 40, esperaRayo = 40, esperaMobs = 60, esperaTeleRoja = 600;
    private int esperaLluvia = 160, esperaAbanico = 200, esperaOla = 200, esperaTp = 80, esperaAgarre = 40;
    private Vec3d tpDestino = null;
    // fase 3: los dos tentáculos de los lados
    private final UUID[] agarrados = new UUID[2];
    private final int[] agarreTicks = new int[2], agachadas = new int[2];
    private final boolean[] estabaAgachado = new boolean[2];
    private final java.util.Map<UUID, Integer> agarreLibreDesde = new java.util.HashMap<>();   // jugador -> age a partir del que se le puede volver a agarrar
    private boolean enElAire = false;
    private final List<UUID> esbirros = new ArrayList<>();
    private final Set<UUID> conBarra = new HashSet<>();

    public JefeTeleEntity(EntityType<? extends HostileEntity> tipo, World mundo) {
        super(tipo, mundo);
        setPersistent();
        experiencePoints = 500;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, VIDA_FASE * 3)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FASE, 0);
        builder.add(TRANSICION, 0);
        builder.add(GOLPES, 0);
        builder.add(OBJETIVO, -1);
        builder.add(AGARRE_0, -1);
        builder.add(AGARRE_1, -1);
        builder.add(TP, 0);
    }

    public int getFase() { return dataTracker.get(FASE); }
    public int getTransicion() { return dataTracker.get(TRANSICION); }
    public int getGolpes() { return dataTracker.get(GOLPES); }
    public int getObjetivoId() { return dataTracker.get(OBJETIVO); }
    /** Fase 3: id del jugador que tiene agarrado el tentáculo de ese lado (0 = derecho, 1 = izquierdo), o -1. */
    public int getAgarrado(int lado) { return dataTracker.get(lado == 0 ? AGARRE_0 : AGARRE_1); }
    public int getAvisoTp() { return dataTracker.get(TP); }

    /** Fase 3: punta de los tentáculos de los lados, en coordenadas de la tele (x a los lados, z hacia la pantalla). */
    public static Vec3d puntaLateral(int lado) {
        return new Vec3d(lado == 0 ? 5.4 : -5.4, elevacion(3) + 1.4, 0.8);
    }

    /** Cuánto la levantan los tentáculos (en bloques), sin contar la animación. */
    public static float elevacion(int fase) { return fase == 0 ? 0f : fase == 1 ? 2f : 4f; }

    /** De coordenadas de la tele a coordenadas del mundo (relativas a su posición). */
    private Vec3d aMundo(Vec3d local) {
        return local.rotateY(-getYaw() * MathHelper.RADIANS_PER_DEGREE);
    }

    // ---------------------------------------------------------------- tamaño (crece con los tentáculos)
    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        float alto = 5f + elevacion(getFase());
        return EntityDimensions.fixed(5f, alto).withEyeHeight(alto - 2f);
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (FASE.equals(data)) calculateDimensions();
    }

    @Override protected void initGoals() { }   // se controla a mano
    @Override public boolean isPushable() { return false; }
    @Override public boolean canImmediatelyDespawn(double d) { return false; }
    @Override protected boolean isDisallowedInPeaceful() { return false; }
    @Override public void takeKnockback(double fuerza, double x, double z) { }
    @Override public boolean handleFallDamage(float distancia, float mult, DamageSource fuente) { return false; }

    // ---------------------------------------------------------------- daño
    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        if (fuente.isOf(DamageTypes.OUT_OF_WORLD) || fuente.isOf(DamageTypes.GENERIC_KILL)) return super.damage(fuente, cantidad);
        // solo le hacen daño los jugadores (sus propios mobs, explosiones de creepers, fuego, caídas... nada)
        if (!(fuente.getAttacker() instanceof PlayerEntity jugador) || jugador.isSpectator()) return false;
        if (getWorld().isClient()) return false;
        if (getTransicion() > 0) return false;                                        // invulnerable mientras se transforma
        if (getFase() == 0) {                                                         // dormida: cuenta los golpes
            int g = getGolpes() + 1;
            dataTracker.set(GOLPES, g);
            playSound(ModSounds.TV_ESTATICA, 1.5f, 0.6f + g * 0.2f);
            ((ServerWorld) getWorld()).spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 2.5, getZ(), 40, 2, 2, 2, 0.05);
            if (g >= GOLPES_PARA_DESPERTAR) empezarFase(1);
            return false;
        }
        boolean ok = super.damage(fuente, cantidad * RESISTENCIA);
        if (getFase() == 1 && getHealth() <= VIDA_FASE * 2) {                        // fin de la fase 1
            setHealth(VIDA_FASE * 2);
            empezarFase(2);
        } else if (getFase() == 2 && getHealth() <= VIDA_FASE) {                     // fin de la fase 2
            setHealth(VIDA_FASE);
            empezarFase(3);
        }
        return ok;
    }

    /** Para probar: /desinfo jefe fase <n>. */
    public void forzarFase(int fase) {
        fase = MathHelper.clamp(fase, 1, 3);
        setHealth(VIDA_FASE * (4 - fase));
        empezarFase(fase);
    }

    private void empezarFase(int fase) {
        soltarTodos();
        if (fase == 1) setHealth(getMaxHealth());                                      // por si venía de una partida guardada con otra vida
        tpDestino = null;
        dataTracker.set(TP, 0);
        dataTracker.set(FASE, fase);
        dataTracker.set(TRANSICION, fase == 1 ? TRANSICION_1 : fase == 2 ? TRANSICION_2 : TRANSICION_3);
        calculateDimensions();
        ServerWorld w = (ServerWorld) getWorld();
        w.playSound(null, getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.HOSTILE, 3f, 0.5f);
        w.playSound(null, getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 3f, 0.5f);
        if (fase == 3) w.playSound(null, getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 2f, 0.6f);
        String[][] titulos = {
                {"LA DESINFORMACIÓN", "ha despertado"},
                {"FASE 2", "Se ha despegado del suelo"},
                {"FASE 3: SEÑAL PERDIDA", "Se teletransporta y agarra. Agachaos 5 veces para soltaros"}};
        Formatting color = fase == 1 ? Formatting.GRAY : fase == 2 ? Formatting.RED : Formatting.DARK_RED;
        for (ServerPlayerEntity p : jugadoresCerca()) {
            p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket(5, 50, 15));
            p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.SubtitleS2CPacket(
                    Text.literal(titulos[fase - 1][1]).formatted(Formatting.GRAY)));
            p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.TitleS2CPacket(
                    Text.literal(titulos[fase - 1][0]).formatted(color, Formatting.BOLD)));
        }
        // rayos de adorno alrededor de la arena (no queman ni hacen daño)
        if (fase >= 2) {
            BlockPos c = casa != null ? casa : getBlockPos();
            int n = fase == 2 ? 6 : 10;
            for (int k = 0; k < n; k++) {
                int k2 = k;
                Tareas.programar(k * 4, () -> {
                    if (isRemoved()) return;
                    double a = k2 * Math.PI * 2 / n, r = 12 + random.nextDouble() * 6;
                    net.minecraft.entity.LightningEntity rayo = EntityType.LIGHTNING_BOLT.create(w);
                    if (rayo == null) return;
                    rayo.setCosmetic(true);
                    rayo.refreshPositionAfterTeleport(c.getX() + 0.5 + Math.cos(a) * r, c.getY(), c.getZ() + 0.5 + Math.sin(a) * r);
                    w.spawnEntity(rayo);
                });
            }
        }
        esperaRayo = 60;
        esperaMobs = 40;
        esperaSalto = 40;
        esperaTeleRoja = 600;
        esperaLluvia = 160;
        esperaAbanico = 200;
        esperaOla = 160;
        esperaTp = 60;
        esperaAgarre = 40;
    }

    // ---------------------------------------------------------------- comportamiento
    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient() || !isAlive()) return;                             // muerta (animación de muerte): ya no ataca
        ServerWorld w = (ServerWorld) getWorld();
        if (casa == null) casa = getBlockPos();
        int fase = getFase();
        int trans = getTransicion();

        ServerPlayerEntity objetivo = buscarObjetivo();
        dataTracker.set(OBJETIVO, objetivo != null ? objetivo.getId() : -1);
        if (objetivo != null && fase > 0) mirarA(objetivo);

        if (trans > 0) {                                                               // animación de transformación
            dataTracker.set(TRANSICION, trans - 1);
            setVelocity(0, getVelocity().y, 0);
            if (age % 4 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 1, getZ(), 30, 2.5, 1, 2.5, 0.08);
            if (fase == 2 && age % 6 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 2, getZ(), 15, 2.5, 2, 2.5, 0.3);
            if (trans % 20 == 0) playSound(ModSounds.TV_ESTATICA, 2f, 0.5f + random.nextFloat() * 0.5f);
            actualizarBarra();
            return;
        }

        switch (fase) {
            case 0 -> saltitos();
            case 1 -> {
                setVelocity(0, getVelocity().y, 0);                                  // no se mueve de su sitio
                if (--esperaMobs <= 0) { lanzarMobs(4 + random.nextInt(3), false); esperaMobs = MOBS_FASE_1; }
                if (objetivo != null && --esperaRayo <= 0) { disparar(objetivo, 0.75); esperaRayo = 40; }
                if (--esperaLluvia <= 0) { lluviaEstatica(); esperaLluvia = 200 + random.nextInt(80); }
            }
            case 2 -> {
                saltoGrande(objetivo);
                if (--esperaMobs <= 0) { lanzarMobs(3 + random.nextInt(3), true); esperaMobs = MOBS_FASE_2; }
                if (objetivo != null && --esperaRayo <= 0) { disparar(objetivo, 0.9); esperaRayo = 30; }
                if (objetivo != null && --esperaAbanico <= 0) { abanico(objetivo); esperaAbanico = 220 + random.nextInt(60); }
                if (--esperaTeleRoja <= 0) { teleRoja(); esperaTeleRoja = 600; }
            }
            case 3 -> {
                if (enElAire && isOnGround()) enElAire = false;
                if (isOnGround()) setVelocity(0, getVelocity().y, 0);
                if (getAvisoTp() < 0) dataTracker.set(TP, getAvisoTp() + 1);             // recién teletransportada: invisible unos ticks
                tickAgarres(w);
                teletransporte(w);
                if (--esperaMobs <= 0) { lanzarMobs(2 + random.nextInt(2), true); esperaMobs = 220; }
                if (objetivo != null && --esperaRayo <= 0) { disparar(objetivo, 1.0); esperaRayo = 35; }
                if (--esperaLluvia <= 0) { lluviaEstatica(); esperaLluvia = 220 + random.nextInt(80); }
                if (--esperaOla <= 0 && tpDestino == null) { olaEstatica(); esperaOla = 240 + random.nextInt(80); }
                if (--esperaTeleRoja <= 0) { teleRoja(); esperaTeleRoja = 700; }
                if (age % 2 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + elevacion(3) + 2.5, getZ(), 2, 2.5, 2.5, 2.5, 0.2);
            }
            default -> { }
        }
        if (fase == 0 && age % 10 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 2.5, getZ(), 6, 2, 2, 0.6, 0.02);
        if (fase > 0 && age % 3 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.5, getZ(), 4, 2.5, 0.5, 2.5, 0.05);
        if (age % 5 == 0) actualizarBarra();
        if (age % 40 == 0) esbirros.removeIf(id -> !(w.getEntity(id) instanceof LivingEntity l) || !l.isAlive());
    }

    private List<ServerPlayerEntity> jugadoresCerca() {
        List<ServerPlayerEntity> l = new ArrayList<>();
        for (ServerPlayerEntity p : ((ServerWorld) getWorld()).getPlayers())
            if (p.squaredDistanceTo(this) < RADIO_ARENA * RADIO_ARENA && !p.isSpectator() && p.isAlive()) l.add(p);
        return l;
    }

    private boolean estaAgarrado(ServerPlayerEntity p) {
        return p.getUuid().equals(agarrados[0]) || p.getUuid().equals(agarrados[1]);
    }

    private ServerPlayerEntity buscarObjetivo() {
        ServerPlayerEntity mejor = null;
        double d = Double.MAX_VALUE;
        for (ServerPlayerEntity p : jugadoresCerca()) {
            if (p.isCreative() || estaAgarrado(p)) continue;                           // al que tiene agarrado no lo mira ni le dispara
            double dd = p.squaredDistanceTo(this);
            if (dd < d) { d = dd; mejor = p; }
        }
        return mejor;
    }

    /** La tele gira hacia el jugador: lo está mirando. */
    private void mirarA(LivingEntity t) {
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        float quiere = (float) (MathHelper.atan2(dz, dx) * MathHelper.DEGREES_PER_RADIAN) - 90f;
        float yaw = getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(quiere - getYaw()), -8f, 8f);
        setYaw(yaw);
        setBodyYaw(yaw);
        setHeadYaw(yaw);
    }

    /** Centro de la pantalla (de donde salen rayos y mobs). */
    private Vec3d pantalla() {
        float alto = elevacion(getFase());
        Vec3d frente = Vec3d.fromPolar(0, getYaw()).multiply(2.9);                     // delante del frente (la tele mide 5 de fondo)
        return new Vec3d(getX() + frente.x, getY() + alto + 2.8, getZ() + frente.z);
    }

    // --- fase 0: saltitos sin rumbo
    private void saltitos() {
        if (!isOnGround() || --esperaSalto > 0) return;
        esperaSalto = 30 + random.nextInt(40);
        double a = random.nextDouble() * Math.PI * 2, f = 0.12 + random.nextDouble() * 0.12;
        Vec3d dir = new Vec3d(Math.cos(a), 0, Math.sin(a));
        if (casa != null && getBlockPos().getSquaredDistance(casa) > 36)                 // no se aleja de donde la pusieron
            dir = Vec3d.ofBottomCenter(casa).subtract(getPos()).multiply(1, 0, 1).normalize();
        setVelocity(dir.x * f, 0.42, dir.z * f);
        velocityModified = true;
        setYaw(getYaw() + (random.nextFloat() - 0.5f) * 60f);
        setBodyYaw(getYaw());
        setHeadYaw(getYaw());
        playSound(SoundEvents.BLOCK_ANVIL_LAND, 0.35f, 1.6f);
    }

    // --- fase 2: saltos por la arena, con golpe al caer
    private void saltoGrande(ServerPlayerEntity objetivo) {
        if (enElAire && isOnGround()) {                                              // aterriza: onda de choque
            enElAire = false;
            ServerWorld w = (ServerWorld) getWorld();
            w.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5, getZ(), 6, 2.5, 0.3, 2.5, 0);
            w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.5, getZ(), 80, 4, 0.5, 4, 0.2);
            w.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 1.2f, 0.6f);
            for (ServerPlayerEntity p : jugadoresCerca()) {
                double d = p.distanceTo(this);
                if (d > 6 || p.isCreative()) continue;
                p.damage(getDamageSources().mobAttack(this), 6f);
                Vec3d emp = p.getPos().subtract(getPos()).multiply(1, 0, 1).normalize().multiply(1.1);
                p.addVelocity(emp.x, 0.5, emp.z);
                p.velocityModified = true;
            }
        }
        if (!isOnGround()) return;
        setVelocity(0, getVelocity().y, 0);
        if (--esperaSalto > 0) return;
        esperaSalto = 50 + random.nextInt(40);
        BlockPos centro = casa != null ? casa : getBlockPos();
        Vec3d destino;
        if (objetivo != null && random.nextBoolean()) destino = objetivo.getPos();
        else {
            double a = random.nextDouble() * Math.PI * 2, r = 4 + random.nextDouble() * 14;
            destino = Vec3d.ofBottomCenter(centro).add(Math.cos(a) * r, 0, Math.sin(a) * r);
        }
        Vec3d d = destino.subtract(getPos()).multiply(1, 0, 1);
        double largo = Math.min(14, d.length());
        Vec3d h = largo > 0.1 ? d.normalize().multiply(largo / 9.4) : Vec3d.ZERO;     // en el aire se frena (0.91 por tick)
        setVelocity(h.x, 0.95, h.z);
        velocityModified = true;
        enElAire = true;
        playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 0.6f);
    }

    // --- lluvia de estática (fases 1 y 3): círculos bajo los jugadores y, 1,5 s después, caen rayos ahí
    private void lluviaEstatica() {
        ServerWorld w = (ServerWorld) getWorld();
        List<Vec3d> marcas = new ArrayList<>();
        for (ServerPlayerEntity p : jugadoresCerca()) {
            if (p.isCreative() || estaAgarrado(p) || marcas.size() >= 8) continue;
            marcas.add(p.getPos().add((random.nextDouble() - 0.5) * 3, 0, (random.nextDouble() - 0.5) * 3));
            p.sendMessage(Text.literal("⚡ ¡Lluvia de estática! Salid de los círculos").formatted(Formatting.AQUA), true);
        }
        if (marcas.isEmpty()) return;
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 2f, 1.6f);
        for (int k = 0; k < 6; k++) {
            Tareas.programar(k * 5, () -> {
                if (isRemoved() || !isAlive()) return;
                for (Vec3d m : marcas) anillo(w, m, 2.2, ParticleTypes.ELECTRIC_SPARK, 24);
            });
        }
        Tareas.programar(30, () -> {
            if (isRemoved() || !isAlive()) return;
            for (Vec3d m : marcas) {
                w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, m.x, m.y + 2, m.z, 60, 0.6, 2, 0.6, 0.4);
                w.spawnParticles(ParticleTypes.WHITE_ASH, m.x, m.y + 0.5, m.z, 40, 1.5, 0.3, 1.5, 0.1);
                w.spawnParticles(ParticleTypes.FLASH, m.x, m.y + 1, m.z, 1, 0, 0, 0, 0);
                w.playSound(null, m.x, m.y, m.z, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.HOSTILE, 1.2f, 1.4f);
                for (ServerPlayerEntity p : jugadoresCerca()) {
                    if (p.isCreative()) continue;
                    double dx = p.getX() - m.x, dz = p.getZ() - m.z;
                    if (dx * dx + dz * dz < 2.2 * 2.2 && Math.abs(p.getY() - m.y) < 3)
                        p.damage(getDamageSources().indirectMagic(this, this), 5f);
                }
            }
        });
    }

    private static void anillo(ServerWorld w, Vec3d c, double r, net.minecraft.particle.ParticleEffect tipo, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            w.spawnParticles(tipo, c.x + Math.cos(a) * r, c.y + 0.15, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    // --- abanico (fase 2): 5 rayos a la vez en abanico hacia el objetivo
    private void abanico(ServerPlayerEntity t) {
        ServerWorld w = (ServerWorld) getWorld();
        Vec3d desde = pantalla();
        Vec3d dir = t.getEyePos().add(0, -0.4, 0).subtract(desde);
        w.playSound(null, desde.x, desde.y, desde.z, SoundEvents.ENTITY_EVOKER_PREPARE_ATTACK, SoundCategory.HOSTILE, 2f, 0.7f);
        for (int k = -2; k <= 2; k++) {
            Vec3d d = dir.rotateY(k * 13f * MathHelper.RADIANS_PER_DEGREE);
            RayoEstaticaEntity.disparar(w, this, desde, desde.add(d), 0.85, 5f);
        }
    }

    // --- ola de estática (fase 3): un anillo que se abre por el suelo; hay que saltarlo
    private void olaEstatica() {
        ServerWorld w = (ServerWorld) getWorld();
        Vec3d centro = getPos();
        for (ServerPlayerEntity p : jugadoresCerca())
            p.sendMessage(Text.literal("〰 ¡OLA DE ESTÁTICA! ¡SALTAD!").formatted(Formatting.DARK_AQUA, Formatting.BOLD), true);
        w.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.HOSTILE, 2f, 1.2f);
        Set<UUID> tocados = new HashSet<>();
        for (int k = 0; k <= 18; k++) {
            int radio = k + 2;
            Tareas.programar(20 + k, () -> {
                if (isRemoved() || !isAlive()) return;
                anillo(w, centro, radio, ParticleTypes.ELECTRIC_SPARK, radio * 6);
                if (radio % 3 == 0) anillo(w, centro, radio, ParticleTypes.WHITE_ASH, radio * 3);
                if (radio == 2) w.playSound(null, centro.x, centro.y, centro.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 1.5f, 1.6f);
                for (ServerPlayerEntity p : jugadoresCerca()) {
                    if (p.isCreative() || tocados.contains(p.getUuid())) continue;
                    double dx = p.getX() - centro.x, dz = p.getZ() - centro.z, d = Math.sqrt(dx * dx + dz * dz);
                    if (d < radio - 1.0 || d > radio + 0.5 || Math.abs(p.getY() - centro.y) > 2.5 || !p.isOnGround()) continue;
                    tocados.add(p.getUuid());
                    p.damage(getDamageSources().indirectMagic(this, this), 6f);
                    Vec3d emp = new Vec3d(dx, 0, dz).normalize().multiply(0.9);
                    p.addVelocity(emp.x, 0.45, emp.z);
                    p.velocityModified = true;
                }
            });
        }
    }

    // --- teletransporte (fase 3): el sitio de llegada echa chispas 1 s antes
    private void teletransporte(ServerWorld w) {
        if (agarrados[0] != null || agarrados[1] != null) {                         // con alguien agarrado se queda quieta
            if (tpDestino != null) { tpDestino = null; dataTracker.set(TP, 0); }
            return;
        }
        if (tpDestino == null) {
            if (getAvisoTp() < 0 || --esperaTp > 0) return;
            tpDestino = buscarSitio(w);
            if (tpDestino == null) { esperaTp = 20; return; }
            dataTracker.set(TP, AVISO_TP);
            w.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.HOSTILE, 2.5f, 0.5f);
            w.playSound(null, tpDestino.x, tpDestino.y, tpDestino.z, ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 2f, 1.4f);
            return;
        }
        int falta = getAvisoTp() - 1;
        dataTracker.set(TP, Math.max(0, falta));
        if (falta % 3 == 0) {
            anillo(w, tpDestino, 3.0, ParticleTypes.REVERSE_PORTAL, 30);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, tpDestino.x, tpDestino.y + 1, tpDestino.z, 15, 2, 1, 2, 0.2);
        }
        if (falta > 0) return;
        Vec3d antes = getPos();
        w.spawnParticles(ParticleTypes.WHITE_ASH, antes.x, antes.y + 3, antes.z, 150, 2.5, 3, 2.5, 0.2);
        w.spawnParticles(ParticleTypes.REVERSE_PORTAL, antes.x, antes.y + 3, antes.z, 80, 2.5, 3, 2.5, 0.3);
        requestTeleport(tpDestino.x, tpDestino.y, tpDestino.z);
        setVelocity(Vec3d.ZERO);
        w.playSound(null, getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 3f, 0.4f);
        w.playSound(null, getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 2f, 0.6f);
        w.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1, getZ(), 4, 2, 0.5, 2, 0);
        for (ServerPlayerEntity p : jugadoresCerca()) {                               // al llegar, empuja a los que estén debajo
            if (p.isCreative() || p.distanceTo(this) > 5) continue;
            p.damage(getDamageSources().mobAttack(this), 4f);
            Vec3d emp = p.getPos().subtract(getPos()).multiply(1, 0, 1).normalize().multiply(1.0);
            p.addVelocity(emp.x, 0.5, emp.z);
            p.velocityModified = true;
        }
        tpDestino = null;
        dataTracker.set(TP, -4);                                                       // el cliente no la dibuja 4 ticks (si no, se ve deslizarse)
        esperaTp = 60 + random.nextInt(40);
    }

    /** Un sitio libre de la arena (en el suelo) a más de 7 bloques de donde está. */
    private Vec3d buscarSitio(ServerWorld w) {
        BlockPos centro = casa != null ? casa : getBlockPos();
        for (int intento = 0; intento < 16; intento++) {
            double a = random.nextDouble() * Math.PI * 2, r = 4 + random.nextDouble() * 15;
            int x = MathHelper.floor(centro.getX() + 0.5 + Math.cos(a) * r), z = MathHelper.floor(centro.getZ() + 0.5 + Math.sin(a) * r);
            for (int y = centro.getY() + 6; y >= centro.getY() - 6; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                if (w.getBlockState(pos.down()).getCollisionShape(w, pos.down()).isEmpty()) continue;
                Vec3d dest = new Vec3d(x + 0.5, y, z + 0.5);
                if (dest.squaredDistanceTo(getPos()) < 49) break;
                if (w.isSpaceEmpty(this, getBoundingBox().offset(dest.subtract(getPos())))) return dest;
                break;
            }
        }
        return null;
    }

    // --- tentáculos de los lados (fase 3): agarran y aplastan; se sale agachándose 5 veces
    private void tickAgarres(ServerWorld w) {
        for (int lado = 0; lado < 2; lado++) if (agarrados[lado] != null) sujetar(w, lado);
        if (--esperaAgarre > 0 || tpDestino != null) return;
        esperaAgarre = 10;
        for (ServerPlayerEntity p : jugadoresCerca()) {
            if (p.isCreative() || p.hasVehicle() || estaAgarrado(p)) continue;
            if (age < agarreLibreDesde.getOrDefault(p.getUuid(), 0)) continue;
            Vec3d local = p.getPos().subtract(getPos()).rotateY(getYaw() * MathHelper.RADIANS_PER_DEGREE);   // del mundo a la tele
            if (local.horizontalLengthSquared() > 9.5 * 9.5 || Math.abs(local.y) > 6 || !canSee(p)) continue;
            int lado = local.x >= 0 ? 0 : 1;
            if (agarrados[lado] != null) lado = 1 - lado;
            if (agarrados[lado] != null) return;
            agarrar(w, p, lado);
            esperaAgarre = 60;
            return;
        }
    }

    private void agarrar(ServerWorld w, ServerPlayerEntity p, int lado) {
        agarrados[lado] = p.getUuid();
        agarreTicks[lado] = 0;
        agachadas[lado] = 0;
        estabaAgachado[lado] = p.isSneaking();
        dataTracker.set(lado == 0 ? AGARRE_0 : AGARRE_1, p.getId());
        if (p.hasVehicle()) p.stopRiding();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_FANGS_ATTACK, SoundCategory.HOSTILE, 1.5f, 0.6f);
        w.playSound(null, p.getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 1.2f, 1.3f);
        p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket(2, 30, 8));
        p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.SubtitleS2CPacket(
                Text.literal("Pulsa AGACHARSE " + AGACHARSE_PARA_SOLTAR + " veces para soltarte").formatted(Formatting.YELLOW)));
        p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.TitleS2CPacket(
                Text.literal("¡TE HA AGARRADO!").formatted(Formatting.DARK_RED, Formatting.BOLD)));
    }

    private void sujetar(ServerWorld w, int lado) {
        ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(agarrados[lado]);
        if (p == null || !p.isAlive() || p.isSpectator() || p.isCreative() || p.getWorld() != w || p.squaredDistanceTo(this) > 400) {
            soltar(lado, p, false);
            return;
        }
        agarreTicks[lado]++;
        // en la punta del tentáculo, a un lado de la tele, con los pies colgando
        Vec3d punta = getPos().add(aMundo(puntaLateral(lado))).add(0, -1.0, 0);
        Vec3d hacia = punta.subtract(p.getPos());
        if (hacia.lengthSquared() > 4.0) {
            p.requestTeleport(punta.x, punta.y, punta.z);
        } else {
            Vec3d vel = hacia.multiply(0.6);
            if (vel.lengthSquared() > 0.64) vel = vel.normalize().multiply(0.8);
            p.setVelocity(vel);
            p.velocityModified = true;
        }
        p.fallDistance = 0f;
        // Levitación invisible mientras cuelga: sin gravedad y el servidor no le echa por "volar"
        if (agarreTicks[lado] % 5 == 1)
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 12, 0, false, false, false));
        // agacharse: cada vez que pasa de no agachado a agachado cuenta una
        boolean ag = p.isSneaking();
        if (ag && !estabaAgachado[lado]) {
            agachadas[lado]++;
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.PLAYERS, 1f, 0.7f + agachadas[lado] * 0.15f);
        }
        estabaAgachado[lado] = ag;
        if (agachadas[lado] >= AGACHARSE_PARA_SOLTAR) { soltar(lado, p, true); return; }
        if (agarreTicks[lado] % AGARRE_DANIO_CADA == 0) {
            p.damage(getDamageSources().mobAttack(this), 2f);
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_HONEY_BLOCK_SLIDE, SoundCategory.HOSTILE, 1.2f, 0.5f);
            w.spawnParticles(ParticleTypes.WHITE_ASH, p.getX(), p.getY() + 1, p.getZ(), 15, 0.4, 0.5, 0.4, 0.05);
        }
        if (agarreTicks[lado] % 5 == 1) {
            StringBuilder barra = new StringBuilder();
            for (int i = 0; i < AGACHARSE_PARA_SOLTAR; i++) barra.append(i < agachadas[lado] ? "■" : "□");
            p.sendMessage(Text.literal("¡Te aplasta! Pulsa AGACHARSE para soltarte  ").formatted(Formatting.RED)
                    .append(Text.literal(barra.toString()).formatted(Formatting.YELLOW)), true);
        }
        if (agarreTicks[lado] >= AGARRE_MAX) soltar(lado, p, false);                  // se cansa y te lanza
    }

    private void soltar(int lado, ServerPlayerEntity p, boolean librado) {
        agarrados[lado] = null;
        dataTracker.set(lado == 0 ? AGARRE_0 : AGARRE_1, -1);
        esperaAgarre = Math.max(esperaAgarre, 40);
        if (p == null) return;
        agarreLibreDesde.put(p.getUuid(), age + 120);                                  // 6 s sin poder agarrarle otra vez
        StatusEffectInstance lev = p.getStatusEffect(StatusEffects.LEVITATION);
        if (lev != null && lev.getDuration() <= 12 && !lev.shouldShowIcon()) p.removeStatusEffect(StatusEffects.LEVITATION);
        Vec3d fuera = p.getPos().subtract(getPos()).multiply(1, 0, 1);
        fuera = fuera.lengthSquared() > 0.01 ? fuera.normalize() : Vec3d.ZERO;
        p.setVelocity(fuera.x * (librado ? 0.5 : 1.3), librado ? 0.2 : 0.6, fuera.z * (librado ? 0.5 : 1.3));
        p.velocityModified = true;
        p.sendMessage(librado ? Text.literal("¡Te has soltado del tentáculo!").formatted(Formatting.GREEN, Formatting.BOLD)
                : Text.literal("El tentáculo te ha lanzado por los aires").formatted(Formatting.GRAY, Formatting.ITALIC), true);
        if (getWorld() instanceof ServerWorld w) w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1.2f, 0.5f);
    }

    private void soltarTodos() {
        for (int lado = 0; lado < 2; lado++) {
            if (agarrados[lado] == null) continue;
            ServerPlayerEntity p = getServer() == null ? null : getServer().getPlayerManager().getPlayer(agarrados[lado]);
            soltar(lado, p, false);
        }
    }

    // --- rayos de estática
    private void disparar(ServerPlayerEntity t, double velocidad) {
        Vec3d desde = pantalla();
        RayoEstaticaEntity.disparar((ServerWorld) getWorld(), this, desde, t.getEyePos().add(0, -0.4, 0), velocidad, 6f);
    }

    // --- lanzar mobs
    @SuppressWarnings("unchecked")
    private static final EntityType<? extends MobEntity>[] MOBS_ESTATICA = new EntityType[]{
            ModEntidades.ZOMBIE_ESTATICA, ModEntidades.ESQUELETO_ESTATICA, ModEntidades.ARANA_ESTATICA, ModEntidades.CREEPER_ESTATICA};

    /** Todo lo que habéis visto en el desafío, menos los clones (Ale, Ulises y el Angel). */
    @SuppressWarnings("unchecked")
    private static final EntityType<? extends MobEntity>[] MOBS_TODOS = new EntityType[]{
            ModEntidades.ZOMBIE_ESTATICA, ModEntidades.ESQUELETO_ESTATICA, ModEntidades.ARANA_ESTATICA, ModEntidades.CREEPER_ESTATICA,
            ModEntidades.CREEPER_OSCURO, ModEntidades.FURRO, ModEntidades.CUBO_BLANCO, ModEntidades.ZOMBIE_NARANJA, ModEntidades.GARABATO,
            ModEntidades.TRAVENSANO, ModEntidades.INTERFERENCIA, ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ESQUELETO_DIBUJO,
            ModEntidades.CREEPER_DIBUJO, ModEntidades.ARANA_DIBUJO, ModEntidades.FURRO_DIBUJO, ModEntidades.CREEPER_FUEGO,
            ModEntidades.CUBO_ROJO, ModEntidades.ESQUELETO_RAFAGA, ModEntidades.BRANDON, ModEntidades.KEVIN, ModEntidades.ALTKY};

    private void lanzarMobs(int cuantos, boolean todos) {
        ServerWorld w = (ServerWorld) getWorld();
        int maximo = todos ? MAX_ESBIRROS : 26;
        if (esbirros.size() >= maximo) return;
        Vec3d desde = pantalla();
        EntityType<? extends MobEntity>[] lista = todos ? MOBS_TODOS : MOBS_ESTATICA;
        for (int i = 0; i < cuantos && esbirros.size() < maximo; i++) {
            MobEntity m = lista[random.nextInt(lista.length)].create(w);
            if (m == null) continue;
            double a = random.nextDouble() * Math.PI * 2;                              // hacia todas direcciones
            m.refreshPositionAndAngles(desde.x, desde.y - 1, desde.z, (float) (a * MathHelper.DEGREES_PER_RADIAN), 0f);
            m.initialize(w, w.getLocalDifficulty(m.getBlockPos()), SpawnReason.EVENT, null);
            m.addCommandTag(Mobs.MARCA_EVENTO);
            m.addCommandTag(MARCA_ESBIRRO);
            m.setPersistent();
            double f = 0.45 + random.nextDouble() * 0.45;
            m.setVelocity(Math.cos(a) * f, 0.45 + random.nextDouble() * 0.3, Math.sin(a) * f);
            m.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 4, false, false));   // que no se rompa al caer
            if (w.spawnEntity(m)) esbirros.add(m.getUuid());
        }
        w.spawnParticles(ParticleTypes.WHITE_ASH, desde.x, desde.y, desde.z, 50, 1.5, 1.5, 1.5, 0.2);
        w.playSound(null, desde.x, desde.y, desde.z, ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 2f, 0.8f);
    }

    // --- teles rojas (fase 2, cada 30 s)
    private void teleRoja() {
        ServerWorld w = (ServerWorld) getWorld();
        List<ServerPlayerEntity> jugadores = jugadoresCerca();
        if (jugadores.isEmpty()) return;
        int tipo = random.nextInt(6);
        String[][] textos = {
                {"¡LLUVIA DE CREEPERS OSCUROS!", "Mirad arriba. Cuidado con los corazones."},
                {"LENTITUD II", "Todos más lentos durante 15 segundos."},
                {"PASIVAS APAGADAS", "20 segundos sin pasivas. Ahora sois normales."},
                {"STUN", "3 segundos sin moveros. Mirad a la tele."},
                {"QUEMADURA", "Os quemáis. Solo una vez... por ahora."},
                {"CONTROLES INVERTIDOS", "8 segundos con los controles al revés."}};
        // tele pequeña en una esquina (TvOverlay, color "rojo_jefe") para que se siga viendo la pelea
        EventoTvPayload aviso = new EventoTvPayload("rojo_jefe", textos[tipo][0], textos[tipo][1]);
        Text chat = Text.literal("📺 Tele roja: ").formatted(Formatting.DARK_RED, Formatting.BOLD)
                .append(Text.literal(textos[tipo][0]).formatted(Formatting.RED, Formatting.BOLD))
                .append(Text.literal(" — " + textos[tipo][1] + " (en 8 segundos)").formatted(Formatting.GRAY));
        for (ServerPlayerEntity p : jugadores) {
            if (ServerPlayNetworking.canSend(p, EventoTvPayload.ID)) ServerPlayNetworking.send(p, aviso);
            p.sendMessage(chat, false);
        }
        int id = getId();
        Tareas.programar(172, () -> {                                                   // cuando la tele roja termina de salir
            if (isRemoved() || !isAlive()) return;
            List<ServerPlayerEntity> ahora = jugadoresCerca();
            switch (tipo) {
                case 0 -> {
                    for (int k = 0; k < 6; k++) Tareas.programar(k * 40, () -> {
                        if (isRemoved() || !isAlive()) return;
                        for (ServerPlayerEntity p : jugadoresCerca()) {
                            if (esbirros.size() >= MAX_ESBIRROS) break;                // también cuentan para el límite
                            CreeperOscuroEntity c = ModEntidades.CREEPER_OSCURO.create(w);
                            if (c == null) continue;
                            c.refreshPositionAndAngles(p.getX() + (random.nextDouble() - 0.5) * 6, p.getY() + 12, p.getZ() + (random.nextDouble() - 0.5) * 6, 0, 0);
                            c.addCommandTag(Mobs.MARCA_EVENTO);
                            c.addCommandTag(MARCA_ESBIRRO);
                            if (w.spawnEntity(c)) esbirros.add(c.getUuid());           // así se quitan al morir la tele
                        }
                    });
                }
                case 1 -> ahora.forEach(p -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 300, 1)));
                case 2 -> ahora.forEach(p -> Pasivas.apagarTodas(p, 400));
                case 3 -> ahora.forEach(p -> {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 9, false, false, true));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 60, 4, false, false, true));
                    p.setVelocity(0, Math.min(0, p.getVelocity().y), 0);
                    p.velocityModified = true;
                    if (ServerPlayNetworking.canSend(p, ManipuladoPayload.ID)) ServerPlayNetworking.send(p, new ManipuladoPayload(id, 60));
                    w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 0.8f, 1.6f);
                });
                case 4 -> ahora.forEach(p -> p.setOnFireFor(5));
                case 5 -> ahora.forEach(p -> {
                    if (ServerPlayNetworking.canSend(p, com.centrodesinformacion.desinformados.network.InvertidoPayload.ID))
                        ServerPlayNetworking.send(p, new com.centrodesinformacion.desinformados.network.InvertidoPayload(160));
                    w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.8f, 1.6f);
                });
                default -> { }
            }
        });
    }

    // ---------------------------------------------------------------- barra de vida (de estática, en el HUD)
    /** 0..1 de la fase actual; mientras se transforma, la barra se va llenando. */
    public float progresoBarra() {
        int fase = getFase(), t = getTransicion();
        if (t > 0) return 1f - t / (float) (fase == 1 ? TRANSICION_1 : fase == 2 ? TRANSICION_2 : TRANSICION_3);
        if (fase == 1) return MathHelper.clamp((getHealth() - VIDA_FASE * 2) / VIDA_FASE, 0f, 1f);
        if (fase == 2) return MathHelper.clamp((getHealth() - VIDA_FASE) / VIDA_FASE, 0f, 1f);
        return MathHelper.clamp(getHealth() / VIDA_FASE, 0f, 1f);
    }

    private void actualizarBarra() {
        boolean visible = getFase() > 0 && isAlive();
        JefePayload datos = new JefePayload(getId(), getFase(), progresoBarra(), visible);
        Set<UUID> ahora = new HashSet<>();
        for (ServerPlayerEntity p : ((ServerWorld) getWorld()).getPlayers()) {
            if (!ServerPlayNetworking.canSend(p, JefePayload.ID)) continue;
            if (visible && p.squaredDistanceTo(this) < 80 * 80) {
                ServerPlayNetworking.send(p, datos);
                ahora.add(p.getUuid());
            } else if (conBarra.contains(p.getUuid())) {
                ServerPlayNetworking.send(p, new JefePayload(getId(), getFase(), 0f, false));
            }
        }
        conBarra.clear();
        conBarra.addAll(ahora);
    }

    private void esconderBarra() {
        if (!(getWorld() instanceof ServerWorld w)) return;
        for (ServerPlayerEntity p : w.getPlayers())
            if (ServerPlayNetworking.canSend(p, JefePayload.ID)) ServerPlayNetworking.send(p, new JefePayload(getId(), getFase(), 0f, false));
        conBarra.clear();
    }

    private void quitarEsbirros() {
        if (!(getWorld() instanceof ServerWorld w)) return;
        for (UUID id : esbirros) if (w.getEntity(id) != null) w.getEntity(id).discard();
        esbirros.clear();
        // y lo que invocaron ellos (Kevin, dibujos de Altky, clones de Interferencia): heredan la marca de esbirro
        for (MobEntity m : w.getEntitiesByClass(MobEntity.class, getBoundingBox().expand(RADIO_ARENA * 2, RADIO_ARENA, RADIO_ARENA * 2),
                e -> e.getCommandTags().contains(MARCA_ESBIRRO))) m.discard();
    }

    // ---------------------------------------------------------------- muerte
    @Override
    public void onDeath(DamageSource fuente) {
        super.onDeath(fuente);
        if (!(getWorld() instanceof ServerWorld w)) return;
        soltarTodos();
        quitarEsbirros();
        esconderBarra();
        com.centrodesinformacion.desinformados.EstadoServidor.get(w.getServer()).agregarCambio(
                com.centrodesinformacion.desinformados.dimension.Dimensiones.JEFE_DERROTADO);   // ya no vuelve a salir al romper la tele
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 3, getZ(), 3, 1.5, 1.5, 1.5, 0);
        w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 3, getZ(), 400, 4, 4, 4, 0.3);
        w.playSound(null, getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 4f, 0.4f);
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.HOSTILE, 4f, 0.5f);
        w.getServer().getPlayerManager().broadcast(Text.literal("📺 ¡LA DESINFORMACIÓN HA SIDO APAGADA!").formatted(Formatting.GREEN, Formatting.BOLD), false);
        // suelta el Orbe de Estática (no desaparece, no se quema y brilla para que se vea)
        net.minecraft.entity.ItemEntity orbe = new net.minecraft.entity.ItemEntity(w, getX(), getY() + 1.5, getZ(),
                new net.minecraft.item.ItemStack(com.centrodesinformacion.desinformados.ModItems.ORBE_ESTATICA));
        orbe.setNeverDespawn();
        orbe.setInvulnerable(true);
        orbe.setGlowing(true);
        orbe.setVelocity(0, 0.35, 0);
        w.spawnEntity(orbe);
        w.getServer().getPlayerManager().broadcast(Text.literal("Ha quedado un Orbe de Estática... dadle clic derecho.").formatted(Formatting.GRAY, Formatting.ITALIC), false);
    }

    @Override
    public void remove(RemovalReason razon) {
        if (!getWorld().isClient()) soltarTodos();
        if (!getWorld().isClient() && razon.shouldDestroy()) { quitarEsbirros(); esconderBarra(); }
        super.remove(razon);
    }

    // ---------------------------------------------------------------- guardar
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Fase", getFase());
        nbt.putInt("Golpes", getGolpes());
        if (casa != null) nbt.putLong("Casa", casa.asLong());
        long[] ids = new long[esbirros.size() * 2];
        for (int i = 0; i < esbirros.size(); i++) {
            ids[i * 2] = esbirros.get(i).getMostSignificantBits();
            ids[i * 2 + 1] = esbirros.get(i).getLeastSignificantBits();
        }
        nbt.putLongArray("Esbirros", ids);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(FASE, MathHelper.clamp(nbt.getInt("Fase"), 0, 3));
        dataTracker.set(GOLPES, nbt.getInt("Golpes"));
        if (nbt.contains("Casa")) casa = BlockPos.fromLong(nbt.getLong("Casa"));
        long[] ids = nbt.getLongArray("Esbirros");
        esbirros.clear();
        for (int i = 0; i + 1 < ids.length; i += 2) esbirros.add(new UUID(ids[i], ids[i + 1]));
        calculateDimensions();
    }
}

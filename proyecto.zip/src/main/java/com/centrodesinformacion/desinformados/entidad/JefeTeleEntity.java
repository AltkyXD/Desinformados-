package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import com.centrodesinformacion.desinformados.network.JefePayload;
import com.centrodesinformacion.desinformados.network.ManipuladoPayload;
import com.centrodesinformacion.desinformados.pasivas.Pasivas;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * JEFE FINAL: La Desinformación (una tele de 5x5).
 * Fase 0: una tele de 5x5 que da saltitos sin rumbo, con estática y apagándose. A los 3 golpes despierta.
 * Fase 1: le salen tentáculos de estática que la levantan, ojos y barra de vida. No se mueve: lanza mobs de estática
 *         por montones hacia todas partes y dispara rayos de estática al jugador que mira (esquivables corriendo).
 * Fase 2: los tentáculos se glitchean, salen más y la tele se despega del suelo. Salta por la arena, sigue disparando,
 *         lanza mobs de todo el juego (menos los clones) y cada 30 segundos lanza una tele roja con algo malo.
 */
public class JefeTeleEntity extends HostileEntity {
    public static final String MARCA_ESBIRRO = "desinfo_esbirro_tele";
    public static final float VIDA_FASE = 400f;                    // cada fase tiene su barra entera
    public static final int TRANSICION_1 = 100, TRANSICION_2 = 120;
    public static final int GOLPES_PARA_DESPERTAR = 3;
    private static final int RADIO_ARENA = 48;

    private static final TrackedData<Integer> FASE = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TRANSICION = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> GOLPES = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> OBJETIVO = DataTracker.registerData(JefeTeleEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos casa = null;
    private int esperaSalto = 40, esperaRayo = 40, esperaMobs = 60, esperaTeleRoja = 600;
    private boolean enElAire = false;
    private final List<UUID> esbirros = new ArrayList<>();
    private final Set<UUID> conBarra = new HashSet<>();

    public JefeTeleEntity(EntityType<? extends HostileEntity> tipo, World mundo) {
        super(tipo, mundo);
        setPersistent();
        experiencePoints = 500;
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, VIDA_FASE * 2)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FASE, 0);
        builder.add(TRANSICION, 0);
        builder.add(GOLPES, 0);
        builder.add(OBJETIVO, -1);
    }

    public int getFase() { return dataTracker.get(FASE); }
    public int getTransicion() { return dataTracker.get(TRANSICION); }
    public int getGolpes() { return dataTracker.get(GOLPES); }
    public int getObjetivoId() { return dataTracker.get(OBJETIVO); }

    /** Cuánto la levantan los tentáculos (en bloques), sin contar la animación. */
    public static float elevacion(int fase) { return fase == 0 ? 0f : fase == 1 ? 2f : 4f; }

    // ---------------------------------------------------------------- tamaño (crece con los tentáculos)
    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        float alto = 5f + elevacion(getFase());
        return EntityDimensions.fixed(5f, alto).withEyeHeight(alto - 2f);
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (FASE.equals(data)) calculateDimensions();
    }

    @Override protected void initGoals() { }   // se controla a mano
    @Override public boolean isPushable() { return false; }
    @Override public boolean canImmediatelyDespawn(double d) { return false; }
    @Override protected boolean isDisallowedInPeaceful() { return false; }
    @Override public void takeKnockback(double fuerza, double x, double z) { }
    @Override public boolean handleFallDamage(float distancia, float mult, DamageSource fuente) { return false; }

    // ---------------------------------------------------------------- daño
    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        if (fuente.isOf(DamageTypes.OUT_OF_WORLD) || fuente.isOf(DamageTypes.GENERIC_KILL)) return super.damage(fuente, cantidad);
        // solo le hacen daño los jugadores (sus propios mobs, explosiones de creepers, fuego, caídas... nada)
        if (!(fuente.getAttacker() instanceof PlayerEntity jugador) || jugador.isSpectator()) return false;
        if (getWorld().isClient()) return false;
        if (getTransicion() > 0) return false;                                        // invulnerable mientras se transforma
        if (getFase() == 0) {                                                         // dormida: cuenta los golpes
            int g = getGolpes() + 1;
            dataTracker.set(GOLPES, g);
            playSound(ModSounds.TV_ESTATICA, 1.5f, 0.6f + g * 0.2f);
            ((ServerWorld) getWorld()).spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 2.5, getZ(), 40, 2, 2, 2, 0.05);
            if (g >= GOLPES_PARA_DESPERTAR) empezarFase(1);
            return false;
        }
        boolean ok = super.damage(fuente, cantidad);
        if (getFase() == 1 && getHealth() <= VIDA_FASE) {                            // fin de la fase 1
            setHealth(VIDA_FASE);
            empezarFase(2);
        }
        return ok;
    }

    private void empezarFase(int fase) {
        dataTracker.set(FASE, fase);
        dataTracker.set(TRANSICION, fase == 1 ? TRANSICION_1 : TRANSICION_2);
        calculateDimensions();
        ServerWorld w = (ServerWorld) getWorld();
        w.playSound(null, getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.HOSTILE, 3f, 0.5f);
        w.playSound(null, getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 3f, 0.5f);
        for (ServerPlayerEntity p : jugadoresCerca()) {
            p.sendMessage(Text.literal(fase == 1 ? "📺 La Desinformación ha despertado..." : "📺 ¡LA DESINFORMACIÓN SE HA DESPEGADO DEL SUELO!")
                    .formatted(fase == 1 ? Formatting.GRAY : Formatting.DARK_RED, Formatting.BOLD), true);
        }
        esperaRayo = 60;
        esperaMobs = 40;
        esperaSalto = 40;
        esperaTeleRoja = 600;
    }

    // ---------------------------------------------------------------- comportamiento
    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        ServerWorld w = (ServerWorld) getWorld();
        if (casa == null) casa = getBlockPos();
        int fase = getFase();
        int trans = getTransicion();

        ServerPlayerEntity objetivo = buscarObjetivo();
        dataTracker.set(OBJETIVO, objetivo != null ? objetivo.getId() : -1);
        if (objetivo != null && fase > 0) mirarA(objetivo);

        if (trans > 0) {                                                               // animación de transformación
            dataTracker.set(TRANSICION, trans - 1);
            setVelocity(0, getVelocity().y, 0);
            if (age % 4 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 1, getZ(), 30, 2.5, 1, 2.5, 0.08);
            if (fase == 2 && age % 6 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 2, getZ(), 15, 2.5, 2, 2.5, 0.3);
            if (trans % 20 == 0) playSound(ModSounds.TV_ESTATICA, 2f, 0.5f + random.nextFloat() * 0.5f);
            actualizarBarra();
            return;
        }

        switch (fase) {
            case 0 -> saltitos();
            case 1 -> {
                setVelocity(0, getVelocity().y, 0);                                  // no se mueve de su sitio
                if (--esperaMobs <= 0) { lanzarMobs(4 + random.nextInt(3), false); esperaMobs = 80; }
                if (objetivo != null && --esperaRayo <= 0) { disparar(objetivo, 0.75); esperaRayo = 40; }
            }
            case 2 -> {
                saltoGrande(objetivo);
                if (--esperaMobs <= 0) { lanzarMobs(3 + random.nextInt(3), true); esperaMobs = 120; }
                if (objetivo != null && --esperaRayo <= 0) { disparar(objetivo, 0.9); esperaRayo = 30; }
                if (--esperaTeleRoja <= 0) { teleRoja(); esperaTeleRoja = 600; }
            }
            default -> { }
        }
        if (fase == 0 && age % 10 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 2.5, getZ(), 6, 2, 2, 0.6, 0.02);
        if (fase > 0 && age % 3 == 0) w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.5, getZ(), 4, 2.5, 0.5, 2.5, 0.05);
        if (age % 5 == 0) actualizarBarra();
        if (age % 40 == 0) esbirros.removeIf(id -> !(w.getEntity(id) instanceof LivingEntity l) || !l.isAlive());
    }

    private List<ServerPlayerEntity> jugadoresCerca() {
        List<ServerPlayerEntity> l = new ArrayList<>();
        for (ServerPlayerEntity p : ((ServerWorld) getWorld()).getPlayers())
            if (p.squaredDistanceTo(this) < RADIO_ARENA * RADIO_ARENA && !p.isSpectator() && p.isAlive()) l.add(p);
        return l;
    }

    private ServerPlayerEntity buscarObjetivo() {
        ServerPlayerEntity mejor = null;
        double d = Double.MAX_VALUE;
        for (ServerPlayerEntity p : jugadoresCerca()) {
            if (p.isCreative()) continue;
            double dd = p.squaredDistanceTo(this);
            if (dd < d) { d = dd; mejor = p; }
        }
        return mejor;
    }

    /** La tele gira hacia el jugador: lo está mirando. */
    private void mirarA(LivingEntity t) {
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        float quiere = (float) (MathHelper.atan2(dz, dx) * MathHelper.DEGREES_PER_RADIAN) - 90f;
        float yaw = getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(quiere - getYaw()), -8f, 8f);
        setYaw(yaw);
        setBodyYaw(yaw);
        setHeadYaw(yaw);
    }

    /** Centro de la pantalla (de donde salen rayos y mobs). */
    private Vec3d pantalla() {
        float alto = elevacion(getFase());
        Vec3d frente = Vec3d.fromPolar(0, getYaw()).multiply(0.9);
        return new Vec3d(getX() + frente.x, getY() + alto + 3.0, getZ() + frente.z);
    }

    // --- fase 0: saltitos sin rumbo
    private void saltitos() {
        if (!isOnGround() || --esperaSalto > 0) return;
        esperaSalto = 30 + random.nextInt(40);
        double a = random.nextDouble() * Math.PI * 2, f = 0.12 + random.nextDouble() * 0.12;
        Vec3d dir = new Vec3d(Math.cos(a), 0, Math.sin(a));
        if (casa != null && getBlockPos().getSquaredDistance(casa) > 36)                 // no se aleja de donde la pusieron
            dir = Vec3d.ofBottomCenter(casa).subtract(getPos()).multiply(1, 0, 1).normalize();
        setVelocity(dir.x * f, 0.42, dir.z * f);
        velocityModified = true;
        setYaw(getYaw() + (random.nextFloat() - 0.5f) * 60f);
        setBodyYaw(getYaw());
        setHeadYaw(getYaw());
        playSound(SoundEvents.BLOCK_ANVIL_LAND, 0.35f, 1.6f);
    }

    // --- fase 2: saltos por la arena, con golpe al caer
    private void saltoGrande(ServerPlayerEntity objetivo) {
        if (enElAire && isOnGround()) {                                              // aterriza: onda de choque
            enElAire = false;
            ServerWorld w = (ServerWorld) getWorld();
            w.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5, getZ(), 6, 2.5, 0.3, 2.5, 0);
            w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 0.5, getZ(), 80, 4, 0.5, 4, 0.2);
            w.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 1.2f, 0.6f);
            for (ServerPlayerEntity p : jugadoresCerca()) {
                double d = p.distanceTo(this);
                if (d > 6 || p.isCreative()) continue;
                p.damage(getDamageSources().mobAttack(this), 6f);
                Vec3d emp = p.getPos().subtract(getPos()).multiply(1, 0, 1).normalize().multiply(1.1);
                p.addVelocity(emp.x, 0.5, emp.z);
                p.velocityModified = true;
            }
        }
        if (!isOnGround()) return;
        setVelocity(0, getVelocity().y, 0);
        if (--esperaSalto > 0) return;
        esperaSalto = 50 + random.nextInt(40);
        BlockPos centro = casa != null ? casa : getBlockPos();
        Vec3d destino;
        if (objetivo != null && random.nextBoolean()) destino = objetivo.getPos();
        else {
            double a = random.nextDouble() * Math.PI * 2, r = 4 + random.nextDouble() * 14;
            destino = Vec3d.ofBottomCenter(centro).add(Math.cos(a) * r, 0, Math.sin(a) * r);
        }
        Vec3d d = destino.subtract(getPos()).multiply(1, 0, 1);
        double largo = Math.min(14, d.length());
        Vec3d h = largo > 0.1 ? d.normalize().multiply(largo / 9.4) : Vec3d.ZERO;     // en el aire se frena (0.91 por tick)
        setVelocity(h.x, 0.95, h.z);
        velocityModified = true;
        enElAire = true;
        playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 0.6f);
    }

    // --- rayos de estática
    private void disparar(ServerPlayerEntity t, double velocidad) {
        Vec3d desde = pantalla();
        RayoEstaticaEntity.disparar((ServerWorld) getWorld(), this, desde, t.getEyePos().add(0, -0.4, 0), velocidad, 6f);
    }

    // --- lanzar mobs
    @SuppressWarnings("unchecked")
    private static final EntityType<? extends MobEntity>[] MOBS_ESTATICA = new EntityType[]{
            ModEntidades.ZOMBIE_ESTATICA, ModEntidades.ESQUELETO_ESTATICA, ModEntidades.ARANA_ESTATICA, ModEntidades.CREEPER_ESTATICA};

    /** Todo lo que habéis visto en el desafío, menos los clones (Ale, Ulises y el Angel). */
    @SuppressWarnings("unchecked")
    private static final EntityType<? extends MobEntity>[] MOBS_TODOS = new EntityType[]{
            ModEntidades.ZOMBIE_ESTATICA, ModEntidades.ESQUELETO_ESTATICA, ModEntidades.ARANA_ESTATICA, ModEntidades.CREEPER_ESTATICA,
            ModEntidades.CREEPER_OSCURO, ModEntidades.FURRO, ModEntidades.CUBO_BLANCO, ModEntidades.ZOMBIE_NARANJA, ModEntidades.GARABATO,
            ModEntidades.TRAVENSANO, ModEntidades.INTERFERENCIA, ModEntidades.ZOMBIE_DIBUJO, ModEntidades.ESQUELETO_DIBUJO,
            ModEntidades.CREEPER_DIBUJO, ModEntidades.ARANA_DIBUJO, ModEntidades.FURRO_DIBUJO, ModEntidades.CREEPER_FUEGO,
            ModEntidades.CUBO_ROJO, ModEntidades.ESQUELETO_RAFAGA, ModEntidades.BRANDON, ModEntidades.KEVIN, ModEntidades.ALTKY};

    private void lanzarMobs(int cuantos, boolean todos) {
        ServerWorld w = (ServerWorld) getWorld();
        int maximo = todos ? 30 : 26;
        if (esbirros.size() >= maximo) return;
        Vec3d desde = pantalla();
        EntityType<? extends MobEntity>[] lista = todos ? MOBS_TODOS : MOBS_ESTATICA;
        for (int i = 0; i < cuantos && esbirros.size() < maximo; i++) {
            MobEntity m = lista[random.nextInt(lista.length)].create(w);
            if (m == null) continue;
            double a = random.nextDouble() * Math.PI * 2;                              // hacia todas direcciones
            m.refreshPositionAndAngles(desde.x, desde.y - 1, desde.z, (float) (a * MathHelper.DEGREES_PER_RADIAN), 0f);
            m.initialize(w, w.getLocalDifficulty(m.getBlockPos()), SpawnReason.EVENT, null);
            m.addCommandTag(Mobs.MARCA_EVENTO);
            m.addCommandTag(MARCA_ESBIRRO);
            m.setPersistent();
            double f = 0.45 + random.nextDouble() * 0.45;
            m.setVelocity(Math.cos(a) * f, 0.45 + random.nextDouble() * 0.3, Math.sin(a) * f);
            m.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 4, false, false));   // que no se rompa al caer
            if (w.spawnEntity(m)) esbirros.add(m.getUuid());
        }
        w.spawnParticles(ParticleTypes.WHITE_ASH, desde.x, desde.y, desde.z, 50, 1.5, 1.5, 1.5, 0.2);
        w.playSound(null, desde.x, desde.y, desde.z, ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 2f, 0.8f);
    }

    // --- teles rojas (fase 2, cada 30 s)
    private void teleRoja() {
        ServerWorld w = (ServerWorld) getWorld();
        List<ServerPlayerEntity> jugadores = jugadoresCerca();
        if (jugadores.isEmpty()) return;
        int tipo = random.nextInt(5);
        String[][] textos = {
                {"¡LLUVIA DE CREEPERS OSCUROS!", "Mirad arriba. Cuidado con los corazones."},
                {"LENTITUD II", "Todos más lentos durante 15 segundos."},
                {"PASIVAS APAGADAS", "20 segundos sin pasivas. Ahora sois normales."},
                {"STUN", "3 segundos sin moveros. Mirad a la tele."},
                {"QUEMADURA", "Os quemáis. Solo una vez... por ahora."}};
        EventoTvPayload aviso = new EventoTvPayload("rojo", textos[tipo][0], textos[tipo][1]);
        for (ServerPlayerEntity p : jugadores)
            if (ServerPlayNetworking.canSend(p, EventoTvPayload.ID)) ServerPlayNetworking.send(p, aviso);
        int id = getId();
        Tareas.programar(172, () -> {                                                   // cuando la tele roja termina de salir
            if (isRemoved() || !isAlive()) return;
            List<ServerPlayerEntity> ahora = jugadoresCerca();
            switch (tipo) {
                case 0 -> {
                    for (int k = 0; k < 6; k++) Tareas.programar(k * 40, () -> {
                        if (isRemoved()) return;
                        for (ServerPlayerEntity p : jugadoresCerca()) {
                            CreeperOscuroEntity c = ModEntidades.CREEPER_OSCURO.create(w);
                            if (c == null) continue;
                            c.refreshPositionAndAngles(p.getX() + (random.nextDouble() - 0.5) * 6, p.getY() + 12, p.getZ() + (random.nextDouble() - 0.5) * 6, 0, 0);
                            c.addCommandTag(Mobs.MARCA_EVENTO);
                            c.addCommandTag(MARCA_ESBIRRO);
                            w.spawnEntity(c);
                        }
                    });
                }
                case 1 -> ahora.forEach(p -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 300, 1)));
                case 2 -> ahora.forEach(p -> Pasivas.apagarTodas(p, 400));
                case 3 -> ahora.forEach(p -> {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 9, false, false, true));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 60, 4, false, false, true));
                    p.setVelocity(0, Math.min(0, p.getVelocity().y), 0);
                    p.velocityModified = true;
                    if (ServerPlayNetworking.canSend(p, ManipuladoPayload.ID)) ServerPlayNetworking.send(p, new ManipuladoPayload(id, 60));
                    w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 0.8f, 1.6f);
                });
                case 4 -> ahora.forEach(p -> p.setOnFireFor(5));
                default -> { }
            }
        });
    }

    // ---------------------------------------------------------------- barra de vida (de estática, en el HUD)
    /** 0..1 de la fase actual; mientras se transforma, la barra se va llenando. */
    public float progresoBarra() {
        int fase = getFase(), t = getTransicion();
        if (t > 0) return 1f - t / (float) (fase == 1 ? TRANSICION_1 : TRANSICION_2);
        if (fase == 1) return MathHelper.clamp((getHealth() - VIDA_FASE) / VIDA_FASE, 0f, 1f);
        return MathHelper.clamp(getHealth() / VIDA_FASE, 0f, 1f);
    }

    private void actualizarBarra() {
        boolean visible = getFase() > 0 && isAlive();
        JefePayload datos = new JefePayload(getId(), getFase(), progresoBarra(), visible);
        Set<UUID> ahora = new HashSet<>();
        for (ServerPlayerEntity p : ((ServerWorld) getWorld()).getPlayers()) {
            if (!ServerPlayNetworking.canSend(p, JefePayload.ID)) continue;
            if (visible && p.squaredDistanceTo(this) < 80 * 80) {
                ServerPlayNetworking.send(p, datos);
                ahora.add(p.getUuid());
            } else if (conBarra.contains(p.getUuid())) {
                ServerPlayNetworking.send(p, new JefePayload(getId(), getFase(), 0f, false));
            }
        }
        conBarra.clear();
        conBarra.addAll(ahora);
    }

    private void esconderBarra() {
        if (!(getWorld() instanceof ServerWorld w)) return;
        for (ServerPlayerEntity p : w.getPlayers())
            if (ServerPlayNetworking.canSend(p, JefePayload.ID)) ServerPlayNetworking.send(p, new JefePayload(getId(), getFase(), 0f, false));
        conBarra.clear();
    }

    private void quitarEsbirros() {
        if (!(getWorld() instanceof ServerWorld w)) return;
        for (UUID id : esbirros) if (w.getEntity(id) != null) w.getEntity(id).discard();
        esbirros.clear();
    }

    // ---------------------------------------------------------------- muerte
    @Override
    public void onDeath(DamageSource fuente) {
        super.onDeath(fuente);
        if (!(getWorld() instanceof ServerWorld w)) return;
        quitarEsbirros();
        esconderBarra();
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 3, getZ(), 3, 1.5, 1.5, 1.5, 0);
        w.spawnParticles(ParticleTypes.WHITE_ASH, getX(), getY() + 3, getZ(), 400, 4, 4, 4, 0.3);
        w.playSound(null, getBlockPos(), ModSounds.TV_ESTATICA, SoundCategory.HOSTILE, 4f, 0.4f);
        w.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.HOSTILE, 4f, 0.5f);
        w.getServer().getPlayerManager().broadcast(Text.literal("📺 ¡LA DESINFORMACIÓN HA SIDO APAGADA!").formatted(Formatting.GREEN, Formatting.BOLD), false);
        // suelta el Orbe de Estática (no desaparece, no se quema y brilla para que se vea)
        net.minecraft.entity.ItemEntity orbe = new net.minecraft.entity.ItemEntity(w, getX(), getY() + 1.5, getZ(),
                new net.minecraft.item.ItemStack(com.centrodesinformacion.desinformados.ModItems.ORBE_ESTATICA));
        orbe.setNeverDespawn();
        orbe.setInvulnerable(true);
        orbe.setGlowing(true);
        orbe.setVelocity(0, 0.35, 0);
        w.spawnEntity(orbe);
        w.getServer().getPlayerManager().broadcast(Text.literal("Ha quedado un Orbe de Estática... dadle clic derecho.").formatted(Formatting.GRAY, Formatting.ITALIC), false);
    }

    @Override
    public void remove(RemovalReason razon) {
        if (!getWorld().isClient() && razon.shouldDestroy()) { quitarEsbirros(); esconderBarra(); }
        super.remove(razon);
    }

    // ---------------------------------------------------------------- guardar
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Fase", getFase());
        nbt.putInt("Golpes", getGolpes());
        if (casa != null) nbt.putLong("Casa", casa.asLong());
        long[] ids = new long[esbirros.size() * 2];
        for (int i = 0; i < esbirros.size(); i++) {
            ids[i * 2] = esbirros.get(i).getMostSignificantBits();
            ids[i * 2 + 1] = esbirros.get(i).getLeastSignificantBits();
        }
        nbt.putLongArray("Esbirros", ids);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(FASE, MathHelper.clamp(nbt.getInt("Fase"), 0, 2));
        dataTracker.set(GOLPES, nbt.getInt("Golpes"));
        if (nbt.contains("Casa")) casa = BlockPos.fromLong(nbt.getLong("Casa"));
        long[] ids = nbt.getLongArray("Esbirros");
        esbirros.clear();
        for (int i = 0; i + 1 < ids.length; i += 2) esbirros.add(new UUID(ids[i], ids[i + 1]));
        calculateDimensions();
    }
}

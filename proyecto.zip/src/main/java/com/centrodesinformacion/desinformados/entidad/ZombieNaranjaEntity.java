package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

/** Zombie Naranja: solo recibe daño de proyectiles. 20% más rápido, 15 corazones y 25% más fuerte que un zombie normal. */
public class ZombieNaranjaEntity extends ZombieEntity {
    public ZombieNaranjaEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.23 * 1.2)  // normal 0.23 · bebé ~0.35
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)            // zombie normal: 20 (10 corazones)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0 * 1.25);  // 25% más que un zombie (3)
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean proyectil = fuente.isIn(DamageTypeTags.IS_PROJECTILE);
        if (!proyectil && !fuente.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (!getWorld().isClient() && fuente.getAttacker() instanceof ServerPlayerEntity p) {
                p.sendMessage(Text.literal("¡Al Zombie Naranja solo le afectan los proyectiles!").formatted(Formatting.GOLD), true);
                getWorld().playSound(null, getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.HOSTILE, 1f, 0.8f);
            }
            return false;
        }
        return super.damage(fuente, cantidad);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && world.getServer() != null && Mobs.estaBloqueado(world.getServer(), getType())) {
            return false;
        }
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        setBaby(false);
        // Sin refuerzos: no llama a zombies normales al recibir flechas
        EntityAttributeInstance refuerzos = getAttributeInstance(EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS);
        if (refuerzos != null) {
            refuerzos.clearModifiers();
            refuerzos.setBaseValue(0);
        }
        return r;
    }

    @Override protected boolean burnsInDaylight() { return false; }
    @Override protected boolean canConvertInWater() { return false; }
}

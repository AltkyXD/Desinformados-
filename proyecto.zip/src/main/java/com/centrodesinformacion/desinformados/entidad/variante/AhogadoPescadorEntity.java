package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Ahogado Pescador: cada 3 segundos, a los jugadores que estén en el agua a menos de 10 bloques
 * les da un tirón de unos 1,2 bloques hacia él. Lleva una caña de pescar.
 */
public class AhogadoPescadorEntity extends DrownedEntity {
    private static final int CADA = 3 * 20;
    private static final double RADIO = 10;
    private static final double TIRON = 0.25;   // con el rozamiento del agua son ~1,2 bloques

    /** A quién ya le ha dicho "¡Te ha pescado!" (solo la primera vez). */
    private final Set<UUID> avisados = new HashSet<>();

    public AhogadoPescadorEntity(EntityType<? extends DrownedEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Siempre con su caña (ni tridentes ni conchas). */
    @Override
    protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.FISHING_ROD));
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData r = super.initialize(world, difficulty, reason, data);
        Variantes.zombieSinExtras(this);
        setCanPickUpLoot(false);
        return r;
    }

    /** Siempre adulto (la textura es de adulto). */
    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    @Override
    public void tick() {
        super.tick();
        if (age % CADA != 0 || !(getWorld() instanceof ServerWorld sw) || !isAlive()) return;
        boolean pesca = false;
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(RADIO),
                j -> Variantes.valido(j) && j.isTouchingWater() && j.squaredDistanceTo(this) <= RADIO * RADIO)) {
            Vec3d hacia = getPos().subtract(p.getPos());
            if (hacia.lengthSquared() < 2.25) continue;   // ya está pegado a él
            Vec3d tiron = hacia.normalize().multiply(TIRON);
            p.addVelocity(tiron.x, tiron.y, tiron.z);
            p.velocityModified = true;
            pesca = true;
            if (p instanceof ServerPlayerEntity sp && avisados.add(sp.getUuid())) {
                sp.sendMessage(Text.literal("¡Te ha pescado!").formatted(Formatting.AQUA, Formatting.BOLD), true);
            }
        }
        if (pesca) sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_FISHING_BOBBER_RETRIEVE, SoundCategory.HOSTILE, 1f, 0.8f);
    }
}

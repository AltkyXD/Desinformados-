package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Mancha;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Tintero: una mancha de tinta mal dibujada en un trozo de hoja, con ojos y cara de enfado.
 * Vive en la Libreta. Si te golpea te mancha la pantalla 8 s (que da Lentitud y Debilidad mientras dura).
 * Al morir se deshace en un charco de tinta (partículas).
 */
public class TinteroEntity extends HostileEntity {
    /** Lo que dura la mancha de su golpe (ticks). */
    public static final int TICKS_MANCHA = 160;

    public TinteroEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && objetivo instanceof ServerPlayerEntity p && getWorld() instanceof ServerWorld mundo) {
            Mancha.manchar(p, TICKS_MANCHA);
            mundo.spawnParticles(ParticleTypes.SQUID_INK, p.getX(), p.getEyeY(), p.getZ(), 12, 0.3, 0.3, 0.3, 0.02);
            mundo.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1f, 0.7f);
            p.sendMessage(Text.literal("¡Un Tintero te ha pringado de tinta!").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
        }
        return golpe;
    }

    @Override
    public void tick() {
        super.tick();
        // va goteando tinta
        if (age % 15 == 0 && getWorld() instanceof ServerWorld mundo) {
            mundo.spawnParticles(ParticleTypes.SQUID_INK, getX(), getY() + 0.2, getZ(), 1, 0.25, 0.05, 0.25, 0.0);
        }
    }

    @Override
    public void onDeath(DamageSource fuente) {
        super.onDeath(fuente);
        if (getWorld() instanceof ServerWorld mundo) {
            mundo.spawnParticles(ParticleTypes.SQUID_INK, getX(), getY() + 0.4, getZ(), 30, 0.5, 0.3, 0.5, 0.05);
        }
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_SLIME_SQUISH_SMALL; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_SLIME_HURT_SMALL; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_SLIME_DEATH_SMALL; }
}

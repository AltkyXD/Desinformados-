package com.centrodesinformacion.desinformados.entidad.variante3;

import com.centrodesinformacion.desinformados.Mobs;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Esqueleto de Fuego (Nether, variante del Esqueleto Ráfaga): dispara como un esqueleto normal, pero todas sus flechas
 * salen ardiendo (al acertar te prenden fuego 5 segundos, como las de un arco con Fuego). No le afecta el fuego
 * (su tipo es makeFireImmune) y va soltando llamas. Bloqueado hasta su tele azul.
 */
public class EsqueletoFuegoEntity extends SkeletonEntity {
    public EsqueletoFuegoEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    /** Igual que el esqueleto wither: la flecha sale encendida. */
    @Override
    protected PersistentProjectileEntity createArrowProjectile(ItemStack flecha, float fuerza, ItemStack arco) {
        PersistentProjectileEntity proyectil = super.createArrowProjectile(flecha, fuerza, arco);
        proyectil.setOnFireFor(100f);
        return proyectil;
    }

    @Override
    public void tick() {
        super.tick();
        if (age % 10 == 0 && getWorld() instanceof ServerWorld mundo) {
            mundo.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 1.2, getZ(), 2, 0.25, 0.5, 0.25, 0.01);
        }
    }
}

package com.centrodesinformacion.desinformados.entidad;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/**
 * Ulises: 7 corazones. Cuando te ve, se te queda mirando fijamente 8 segundos
 * y lanza un rayo rojo brillante que te quita la mitad de la vida que tengas.
 * Si pierde la línea de visión, la carga se reinicia.
 */
public class UlisesEntity extends HostileEntity {
    private static final int CARGA_NORMAL = 160; // 8 segundos
    private static final int CARGA_RAPIDA = 100; // 5 segundos con "ulises_rapido"
    private static final int DESCANSO = 80;      // 4 segundos tras disparar
    private static final float ALCANCE = 20f;

    private int carga = 0;
    private int descanso = 0;

    public UlisesEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder atributos() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    /** Solo aparece de forma natural después de su tele amarilla ("ulises"). */
    @Override
    public boolean canSpawn(net.minecraft.world.WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(world)) return super.canSpawn(world, reason);
        if (reason == SpawnReason.NATURAL && (world.getServer() == null
                || !com.centrodesinformacion.desinformados.EstadoServidor.get(world.getServer()).tieneCambio("ulises"))) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        setCustomName(Text.literal("Ulises"));
        setCustomNameVisible(true);
        if (reason != SpawnReason.NATURAL) setPersistent(); // los que aparecen solos sí pueden desaparecer
        return super.initialize(world, difficulty, reason, data);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld mundo)) return;
        if (descanso > 0) { descanso--; return; }

        if (!(getTarget() instanceof ServerPlayerEntity p) || !p.isAlive() || p.isCreative() || p.isSpectator()) {
            carga = 0;
            return;
        }
        double dist = distanceTo(p);
        if (dist > ALCANCE || !canSee(p)) {
            if (carga > 0) p.sendMessage(Text.literal("Ulises te ha perdido de vista...").formatted(Formatting.GRAY), true);
            carga = 0;
            if (dist > 10) getNavigation().startMovingTo(p, 1.0); // se acerca para verte mejor
            return;
        }

        // Se queda quieto mirándote fijamente
        getNavigation().stop();
        getLookControl().lookAt(p, 30f, 30f);
        carga++;
        final int CARGA_TOTAL = com.centrodesinformacion.desinformados.EstadoServidor.get(mundo.getServer()).tieneCambio("ulises_rapido") ? CARGA_RAPIDA : CARGA_NORMAL;

        Vec3d ojos = getEyePos();
        Vec3d objetivo = p.getEyePos().subtract(0, 0.2, 0);
        if (carga % 4 == 0) {
            float intensidad = carga / (float) CARGA_TOTAL;
            linea(mundo, ojos, objetivo, new DustParticleEffect(new Vector3f(1f, 0.15f, 0.15f), 0.4f + intensidad * 0.8f),
                    (int) (4 + intensidad * 20));
        }
        if (carga == 1) {
            mundo.playSound(null, getBlockPos(), SoundEvents.ENTITY_GUARDIAN_ATTACK, SoundCategory.HOSTILE, 1f, 0.8f);
        }
        if (carga % 20 == 0 && carga < CARGA_TOTAL) {
            int seg = (CARGA_TOTAL - carga) / 20;
            p.sendMessage(Text.literal("Ulises se te ha quedado mirando... " + seg).formatted(Formatting.RED), true);
        }

        if (carga >= CARGA_TOTAL) {
            disparar(mundo, p, ojos, objetivo);
            carga = 0;
            descanso = DESCANSO;
        }
    }

    private void disparar(ServerWorld mundo, ServerPlayerEntity p, Vec3d desde, Vec3d hasta) {
        linea(mundo, desde, hasta, new DustParticleEffect(new Vector3f(1f, 0.05f, 0.05f), 2.0f), 60);
        linea(mundo, desde, hasta, ParticleTypes.FLAME, 15);
        mundo.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.HOSTILE, 1.5f, 1.6f);
        mundo.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 0.6f, 1.8f);
        float danio = p.getHealth() * 0.5f; // la mitad de la vida que tengas en ese momento
        if (danio > 0) p.damage(getDamageSources().indirectMagic(this, this), danio);
        p.sendMessage(Text.literal("Ulises se ha proyectado sobre ti: el amor no fue real").formatted(Formatting.DARK_RED, Formatting.BOLD), true);
    }

    private static void linea(ServerWorld mundo, Vec3d desde, Vec3d hasta, net.minecraft.particle.ParticleEffect particula, int puntos) {
        for (int i = 0; i <= puntos; i++) {
            Vec3d p = desde.lerp(hasta, i / (double) puntos);
            mundo.spawnParticles(particula, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
    }

    @Override
    public boolean damage(DamageSource fuente, float cantidad) {
        boolean r = super.damage(fuente, cantidad);
        if (r && carga > 0) carga = Math.max(0, carga - 20); // si le pegas, le cuesta concentrarse
        return r;
    }
}

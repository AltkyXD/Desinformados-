package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntidades {
    public static final EntityType<CreeperOscuroEntity> CREEPER_OSCURO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("creeper_oscuro"),
            EntityType.Builder.create(CreeperOscuroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_oscuro"));

    public static void inicializar() {
        FabricDefaultAttributeRegistry.register(CREEPER_OSCURO, CreeperEntity.createCreeperAttributes());
        SpawnRestriction.register(CREEPER_OSCURO, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        // Se añade a los biomas, pero no aparece hasta que se desbloquea con un cambio de dificultad
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CREEPER_OSCURO, 60, 1, 2);
    }
}

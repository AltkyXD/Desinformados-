package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntidades {
    public static final EntityType<CreeperOscuroEntity> CREEPER_OSCURO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("creeper_oscuro"),
            EntityType.Builder.create(CreeperOscuroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_oscuro"));

    public static final EntityType<FurroEntity> FURRO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("furro"),
            EntityType.Builder.create(FurroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("furro"));

    public static final EntityType<CuboBlancoEntity> CUBO_BLANCO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("cubo_blanco"),
            EntityType.Builder.create(CuboBlancoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.52f, 0.52f).maxTrackingRange(10).build("cubo_blanco"));

    public static final EntityType<ZombieNaranjaEntity> ZOMBIE_NARANJA = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("zombie_naranja"),
            EntityType.Builder.create(ZombieNaranjaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_naranja"));

    public static final EntityType<GarabatoEntity> GARABATO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("garabato"),
            EntityType.Builder.create(GarabatoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).maxTrackingRange(8).build("garabato"));

    /** Superficie = con el cielo a la vista. Nada en pacífico. */
    private static boolean enSuperficie(net.minecraft.world.ServerWorldAccess mundo, net.minecraft.util.math.BlockPos pos) {
        return mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                && (mundo.isSkyVisible(pos) || com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(mundo)
                    || mundo.toServerWorld().getRegistryKey() == net.minecraft.world.World.NETHER);
    }

    public static final EntityType<AleEntity> ALE = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("ale"),
            EntityType.Builder.create(AleEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("ale"));

    public static final EntityType<TravensanoEntity> TRAVENSANO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("travensano"),
            EntityType.Builder.create(TravensanoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("travensano"));

    public static final EntityType<UlisesEntity> ULISES = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("ulises"),
            EntityType.Builder.create(UlisesEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("ulises"));

    public static final EntityType<InterferenciaEntity> INTERFERENCIA = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("interferencia"),
            EntityType.Builder.create(InterferenciaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.7f).maxTrackingRange(10).build("interferencia"));

    public static final EntityType<AngelEntity> ANGEL = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("angel"),
            EntityType.Builder.create(AngelEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("angel"));

    public static final EntityType<ZombieEstaticaEntity> ZOMBIE_ESTATICA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_estatica"),
            EntityType.Builder.create(ZombieEstaticaEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_estatica"));
    public static final EntityType<EsqueletoEstaticaEntity> ESQUELETO_ESTATICA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_estatica"),
            EntityType.Builder.create(EsqueletoEstaticaEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.99f).eyeHeight(1.74f).maxTrackingRange(8).build("esqueleto_estatica"));
    public static final EntityType<AranaEstaticaEntity> ARANA_ESTATICA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("arana_estatica"),
            EntityType.Builder.create(AranaEstaticaEntity::new, SpawnGroup.MONSTER).dimensions(1.4f, 0.9f).eyeHeight(0.65f).maxTrackingRange(8).build("arana_estatica"));
    public static final EntityType<CreeperEstaticaEntity> CREEPER_ESTATICA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_estatica"),
            EntityType.Builder.create(CreeperEstaticaEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_estatica"));

    public static final EntityType<ZombieDibujoEntity> ZOMBIE_DIBUJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("zombie_dibujo"),
            EntityType.Builder.create(ZombieDibujoEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(10).build("zombie_dibujo"));
    public static final EntityType<EsqueletoDibujoEntity> ESQUELETO_DIBUJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_dibujo"),
            EntityType.Builder.create(EsqueletoDibujoEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.99f).maxTrackingRange(10).build("esqueleto_dibujo"));
    public static final EntityType<CreeperDibujoEntity> CREEPER_DIBUJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_dibujo"),
            EntityType.Builder.create(CreeperDibujoEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.7f).maxTrackingRange(10).build("creeper_dibujo"));
    public static final EntityType<AranaDibujoEntity> ARANA_DIBUJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("arana_dibujo"),
            EntityType.Builder.create(AranaDibujoEntity::new, SpawnGroup.MONSTER).dimensions(1.4f, 0.9f).maxTrackingRange(10).build("arana_dibujo"));

    public static final EntityType<GatoCuboEntity> GATO_CUBO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("gato_cubo"),
            EntityType.Builder.create(GatoCuboEntity::new, SpawnGroup.MISC).dimensions(0.9f, 0.9f).maxTrackingRange(10).build("gato_cubo"));

    public static final EntityType<CreeperFuegoEntity> CREEPER_FUEGO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("creeper_fuego"),
            EntityType.Builder.create(CreeperFuegoEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.7f).makeFireImmune().maxTrackingRange(8).build("creeper_fuego"));
    public static final EntityType<CuboRojoEntity> CUBO_ROJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("cubo_rojo"),
            EntityType.Builder.create(CuboRojoEntity::new, SpawnGroup.MONSTER).dimensions(0.52f, 0.52f).makeFireImmune().maxTrackingRange(10).build("cubo_rojo"));
    public static final EntityType<EsqueletoRafagaEntity> ESQUELETO_RAFAGA = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("esqueleto_rafaga"),
            EntityType.Builder.create(EsqueletoRafagaEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.99f).makeFireImmune().maxTrackingRange(8).build("esqueleto_rafaga"));

    public static final EntityType<BrandonEntity> BRANDON = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("brandon"),
            EntityType.Builder.create(BrandonEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("brandon"));
    public static final EntityType<KevinEntity> KEVIN = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("kevin"),
            EntityType.Builder.create(KevinEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("kevin"));

    public static final EntityType<AltkyEntity> ALTKY = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("altky"),
            EntityType.Builder.create(AltkyEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("altky"));
    public static final EntityType<FurroDibujoEntity> FURRO_DIBUJO = Registry.register(Registries.ENTITY_TYPE, Desinformados.id("furro_dibujo"),
            EntityType.Builder.create(FurroDibujoEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(10).build("furro_dibujo"));

    public static void inicializar() {
        // ---------- Altky y sus dibujos ----------
        FabricDefaultAttributeRegistry.register(ALTKY, AltkyEntity.atributos());
        FabricDefaultAttributeRegistry.register(FURRO_DIBUJO, FurroDibujoEntity.atributos());
        SpawnRestriction.register(ALTKY, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ALTKY, 12, 1, 1);
        // ---------- Brandon y Kevin ----------
        FabricDefaultAttributeRegistry.register(BRANDON, BrandonEntity.atributos());
        FabricDefaultAttributeRegistry.register(KEVIN, KevinEntity.atributos());
        SpawnRestriction.register(BRANDON, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        // Brandon aparece solo (bloqueado hasta su tele amarilla); Kevin solo llega cuando le pegas a Brandon
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, BRANDON, 15, 1, 1);
        // ---------- Mobs nuevos del Nether ----------
        FabricDefaultAttributeRegistry.register(CREEPER_FUEGO, CreeperEntity.createCreeperAttributes());
        FabricDefaultAttributeRegistry.register(CUBO_ROJO, net.minecraft.entity.mob.HostileEntity.createHostileAttributes());
        FabricDefaultAttributeRegistry.register(ESQUELETO_RAFAGA, net.minecraft.entity.mob.AbstractSkeletonEntity.createAbstractSkeletonAttributes());
        SpawnRestriction.register(CREEPER_FUEGO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        // El Cubo Rojo es un "slime", no un HostileEntity: misma regla de oscuridad escrita a mano
        SpawnRestriction.register(CUBO_ROJO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && HostileEntity.isSpawnDark(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        SpawnRestriction.register(ESQUELETO_RAFAGA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        var nether = BiomeSelectors.foundInTheNether();
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, CREEPER_FUEGO, 50, 1, 2);
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, CUBO_ROJO, 40, 1, 2);
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, ESQUELETO_RAFAGA, 40, 1, 2);
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, ZOMBIE_NARANJA, 40, 1, 3);
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, FURRO, 30, 1, 2);
        BiomeModifications.addSpawn(nether, SpawnGroup.MONSTER, TRAVENSANO, 25, 1, 3);
        FabricDefaultAttributeRegistry.register(GATO_CUBO, GatoCuboEntity.atributos());
        // Mobs dibujados de la Libreta (sustituyen a los normales que aparecen allí)
        // Mobs dibujados: más rápidos pero con menos vida
        FabricDefaultAttributeRegistry.register(ZOMBIE_DIBUJO, net.minecraft.entity.mob.ZombieEntity.createZombieAttributes()
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH, 12.0)
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32));
        FabricDefaultAttributeRegistry.register(ESQUELETO_DIBUJO, net.minecraft.entity.mob.AbstractSkeletonEntity.createAbstractSkeletonAttributes()
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH, 12.0)
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34));
        FabricDefaultAttributeRegistry.register(CREEPER_DIBUJO, CreeperEntity.createCreeperAttributes()
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH, 12.0)
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34));
        FabricDefaultAttributeRegistry.register(ARANA_DIBUJO, net.minecraft.entity.mob.SpiderEntity.createSpiderAttributes()
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.40));

        // Mobs de estática: solo aparecen en el Interior de la Tele (por su bioma)
        FabricDefaultAttributeRegistry.register(ZOMBIE_ESTATICA, net.minecraft.entity.mob.ZombieEntity.createZombieAttributes());
        FabricDefaultAttributeRegistry.register(ESQUELETO_ESTATICA, net.minecraft.entity.mob.AbstractSkeletonEntity.createAbstractSkeletonAttributes());
        FabricDefaultAttributeRegistry.register(ARANA_ESTATICA, net.minecraft.entity.mob.SpiderEntity.createSpiderAttributes());
        FabricDefaultAttributeRegistry.register(CREEPER_ESTATICA, CreeperEntity.createCreeperAttributes());
        SpawnRestriction.register(ZOMBIE_ESTATICA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(ESQUELETO_ESTATICA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(ARANA_ESTATICA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(CREEPER_ESTATICA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        FabricDefaultAttributeRegistry.register(ANGEL, AngelEntity.atributos());
        SpawnRestriction.register(ANGEL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ANGEL, 12, 1, 1);
        FabricDefaultAttributeRegistry.register(INTERFERENCIA, InterferenciaEntity.atributos());
        // Solo en cuevas y sitios en oscuridad absoluta: sin cielo encima y sin ninguna luz de bloques
        SpawnRestriction.register(INTERFERENCIA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && !mundo.isSkyVisible(pos)
                        && mundo.getLightLevel(net.minecraft.world.LightType.BLOCK, pos) == 0
                        && mundo.getLightLevel(net.minecraft.world.LightType.SKY, pos) == 0
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, INTERFERENCIA, 30, 1, 1);
        FabricDefaultAttributeRegistry.register(ULISES, UlisesEntity.atributos());
        SpawnRestriction.register(ULISES, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ULISES, 12, 1, 1);
        FabricDefaultAttributeRegistry.register(ALE, AleEntity.atributos());
        FabricDefaultAttributeRegistry.register(TRAVENSANO, TravensanoEntity.atributos());
        // Tras su tele amarilla aparecen solos en lugares oscuros (antes, solo con huevo o /summon)
        SpawnRestriction.register(ALE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ALE, 12, 1, 1);
        SpawnRestriction.register(TRAVENSANO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && HostileEntity.isSpawnDark(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, TRAVENSANO, 24, 1, 3);
        FabricDefaultAttributeRegistry.register(GARABATO, GarabatoEntity.atributos());
        // Garabato: en la superficie, a cualquier hora
        SpawnRestriction.register(GARABATO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, GARABATO, 80, 1, 4);
        FabricDefaultAttributeRegistry.register(ZOMBIE_NARANJA, ZombieNaranjaEntity.atributos());
        SpawnRestriction.register(ZOMBIE_NARANJA, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ZOMBIE_NARANJA, 100, 1, 3);
        FabricDefaultAttributeRegistry.register(CUBO_BLANCO, net.minecraft.entity.mob.HostileEntity.createHostileAttributes());
        // Cubo Blanco: solo en la superficie y de noche
        SpawnRestriction.register(CUBO_BLANCO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos)
                        && HostileEntity.isSpawnDark(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CUBO_BLANCO, 60, 1, 3);
        FabricDefaultAttributeRegistry.register(FURRO, FurroEntity.atributos());
        // Furro: en la superficie, a cualquier hora
        SpawnRestriction.register(FURRO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, FURRO, 100, 1, 2);
        FabricDefaultAttributeRegistry.register(CREEPER_OSCURO, CreeperEntity.createCreeperAttributes());
        SpawnRestriction.register(CREEPER_OSCURO, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        // Se añade a los biomas, pero no aparece hasta que se desbloquea con un cambio de dificultad
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CREEPER_OSCURO, 120, 1, 2);
    }
}

package com.centrodesinformacion.desinformados.entidad;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntidades {
    public static final EntityType<CreeperOscuroEntity> CREEPER_OSCURO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("creeper_oscuro"),
            EntityType.Builder.create(CreeperOscuroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.7f).maxTrackingRange(8).build("creeper_oscuro"));

    public static final EntityType<FurroEntity> FURRO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("furro"),
            EntityType.Builder.create(FurroEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("furro"));

    public static final EntityType<CuboBlancoEntity> CUBO_BLANCO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("cubo_blanco"),
            EntityType.Builder.create(CuboBlancoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.52f, 0.52f).maxTrackingRange(10).build("cubo_blanco"));

    public static final EntityType<ZombieNaranjaEntity> ZOMBIE_NARANJA = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("zombie_naranja"),
            EntityType.Builder.create(ZombieNaranjaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.74f).maxTrackingRange(8).build("zombie_naranja"));

    public static final EntityType<GarabatoEntity> GARABATO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("garabato"),
            EntityType.Builder.create(GarabatoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).maxTrackingRange(8).build("garabato"));

    /** Superficie = con el cielo a la vista. Nada en pacífico. */
    private static boolean enSuperficie(net.minecraft.world.ServerWorldAccess mundo, net.minecraft.util.math.BlockPos pos) {
        return mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL && mundo.isSkyVisible(pos);
    }

    public static final EntityType<AleEntity> ALE = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("ale"),
            EntityType.Builder.create(AleEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("ale"));

    public static final EntityType<TravensanoEntity> TRAVENSANO = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("travensano"),
            EntityType.Builder.create(TravensanoEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("travensano"));

    public static final EntityType<UlisesEntity> ULISES = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("ulises"),
            EntityType.Builder.create(UlisesEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).eyeHeight(1.62f).maxTrackingRange(10).build("ulises"));

    public static final EntityType<InterferenciaEntity> INTERFERENCIA = Registry.register(Registries.ENTITY_TYPE,
            Desinformados.id("interferencia"),
            EntityType.Builder.create(InterferenciaEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f).eyeHeight(1.7f).maxTrackingRange(10).build("interferencia"));

    public static void inicializar() {
        FabricDefaultAttributeRegistry.register(INTERFERENCIA, InterferenciaEntity.atributos());
        // Solo en cuevas y sitios en oscuridad absoluta: sin cielo encima y sin ninguna luz de bloques
        SpawnRestriction.register(INTERFERENCIA, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && !mundo.isSkyVisible(pos)
                        && mundo.getLightLevel(net.minecraft.world.LightType.BLOCK, pos) == 0
                        && mundo.getLightLevel(net.minecraft.world.LightType.SKY, pos) == 0
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, INTERFERENCIA, 15, 1, 1);
        FabricDefaultAttributeRegistry.register(ULISES, UlisesEntity.atributos());
        SpawnRestriction.register(ULISES, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ULISES, 8, 1, 1);
        FabricDefaultAttributeRegistry.register(ALE, AleEntity.atributos());
        FabricDefaultAttributeRegistry.register(TRAVENSANO, TravensanoEntity.atributos());
        // Tras su tele amarilla aparecen solos en lugares oscuros (antes, solo con huevo o /summon)
        SpawnRestriction.register(ALE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ALE, 8, 1, 1);
        SpawnRestriction.register(TRAVENSANO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> mundo.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                        && HostileEntity.isSpawnDark(mundo, pos, random) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, TRAVENSANO, 12, 1, 2);
        FabricDefaultAttributeRegistry.register(GARABATO, GarabatoEntity.atributos());
        // Garabato: en la superficie, a cualquier hora
        SpawnRestriction.register(GARABATO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, GARABATO, 40, 1, 2);
        FabricDefaultAttributeRegistry.register(ZOMBIE_NARANJA, ZombieNaranjaEntity.atributos());
        SpawnRestriction.register(ZOMBIE_NARANJA, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ZOMBIE_NARANJA, 50, 1, 3);
        FabricDefaultAttributeRegistry.register(CUBO_BLANCO, net.minecraft.entity.mob.HostileEntity.createHostileAttributes());
        // Cubo Blanco: solo en la superficie y de noche
        SpawnRestriction.register(CUBO_BLANCO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos)
                        && HostileEntity.isSpawnDark(mundo, pos, random)
                        && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CUBO_BLANCO, 30, 1, 1);
        FabricDefaultAttributeRegistry.register(FURRO, FurroEntity.atributos());
        // Furro: en la superficie, a cualquier hora
        SpawnRestriction.register(FURRO, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                (tipo, mundo, razon, pos, random) -> enSuperficie(mundo, pos) && MobEntity.canMobSpawn(tipo, mundo, razon, pos, random));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, FURRO, 50, 1, 3);
        FabricDefaultAttributeRegistry.register(CREEPER_OSCURO, CreeperEntity.createCreeperAttributes());
        SpawnRestriction.register(CREEPER_OSCURO, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        // Se añade a los biomas, pero no aparece hasta que se desbloquea con un cambio de dificultad
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CREEPER_OSCURO, 60, 1, 2);
    }
}

package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.ZombieNaranjaEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Zombie Limón: lo contrario del Zombie Naranja. Los proyectiles no le hacen nada: solo le hacen daño los golpes
 * cuerpo a cuerpo (de jugadores o de mobs) y lo que se salta la invulnerabilidad (/kill, el vacío).
 * Sus golpes dan Náuseas 5 s ("ácido"). Misma vida, velocidad y fuerza que el Naranja (atributos del Naranja).
 */
public class ZombieLimonEntity extends ZombieNaranjaEntity {
    private static final int TICKS_NAUSEAS = 5 * 20;

    public ZombieLimonEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected boolean leAfecta(DamageSource fuente) {
        if (fuente.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
        if (fuente.isIn(DamageTypeTags.IS_PROJECTILE)) return false;
        return fuente.isOf(DamageTypes.PLAYER_ATTACK) || fuente.isOf(DamageTypes.MOB_ATTACK) || fuente.isOf(DamageTypes.MOB_ATTACK_NO_AGGRO);
    }

    @Override
    protected Text avisoInmune() {
        return Text.literal("¡Al Zombie Limón solo le afectan los golpes cuerpo a cuerpo!").formatted(Formatting.YELLOW);
    }

    /** Ácido: si su golpe entra, Náuseas 5 segundos. */
    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean r = super.tryAttack(objetivo);
        if (r && !getWorld().isClient() && objetivo instanceof ServerPlayerEntity p && !p.isCreative() && !p.isSpectator()) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, TICKS_NAUSEAS, 0, false, true), this);
        }
        return r;
    }
}

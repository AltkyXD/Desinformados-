package com.centrodesinformacion.desinformados.entidad.variante;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Enderman Bromista: si te pega, te teletransporta a un sitio seguro al azar a entre 6 y 10 bloques
 * (como la fruta coral: 16 intentos, 2 bloques de aire sobre un bloque sólido, nunca dentro del Centro).
 */
public class EndermanBromistaEntity extends EndermanEntity {
    private static final int INTENTOS = 16;
    private static final double MIN = 6, MAX = 10;

    public EndermanBromistaEntity(EntityType<? extends EndermanEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && !getWorld().isClient() && objetivo instanceof ServerPlayerEntity p && Variantes.valido(p)) {
            bromear(p);
        }
        return golpe;
    }

    private void bromear(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        EstadoServidor estado = EstadoServidor.get(w.getServer());
        double x0 = p.getX(), y0 = p.getY(), z0 = p.getZ();
        int yBase = MathHelper.floor(y0);
        for (int i = 0; i < INTENTOS; i++) {
            double angulo = random.nextDouble() * Math.PI * 2;
            double distancia = MIN + random.nextDouble() * (MAX - MIN);
            int x = MathHelper.floor(x0 + Math.cos(angulo) * distancia);
            int z = MathHelper.floor(z0 + Math.sin(angulo) * distancia);
            for (int dy = 4; dy >= -4; dy--) {
                BlockPos pies = new BlockPos(x, yBase + dy, z);
                if (!esSeguro(w, pies, estado)) continue;
                if (p.hasVehicle()) p.stopRiding();
                w.spawnParticles(ParticleTypes.PORTAL, x0, y0 + 1, z0, 30, 0.4, 0.8, 0.4, 0.3);
                w.playSound(null, x0, y0, z0, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1f, 1.3f);
                p.requestTeleport(x + 0.5, pies.getY(), z + 0.5);
                p.fallDistance = 0;
                w.playSound(null, x + 0.5, pies.getY(), z + 0.5, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1f, 1.3f);
                p.sendMessage(Text.literal("¡El Enderman Bromista te ha cambiado de sitio!").formatted(Formatting.DARK_PURPLE), true);
                return;
            }
        }
    }

    /** Hueco de 2 bloques de aire sobre un bloque sólido, cargado, dentro del borde y fuera del Centro. */
    private static boolean esSeguro(ServerWorld w, BlockPos pies, EstadoServidor estado) {
        if (pies.getY() - 1 < w.getBottomY() || pies.getY() + 2 > w.getTopY()) return false;
        if (!w.getWorldBorder().contains(pies) || !w.isChunkLoaded(pies)) return false;
        BlockPos suelo = pies.down();
        return w.isAir(pies) && w.isAir(pies.up())
                && w.getBlockState(suelo).isSolidBlock(w, suelo)
                && !Reglas.enSpawn(w, pies, estado);
    }
}

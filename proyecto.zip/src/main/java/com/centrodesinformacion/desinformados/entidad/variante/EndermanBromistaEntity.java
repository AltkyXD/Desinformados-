package com.centrodesinformacion.desinformados.entidad.variante;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Mobs;
import com.centrodesinformacion.desinformados.Reglas;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * Enderman Bromista: si te pega, te gasta una broma: un efecto al azar (mareo, ceguera, levitación, lentitud, debilidad,
 * hambre, fatiga, brillo, oscuridad, supersalto, supervelocidad... o los controles al revés).
 * (Antes te teletransportaba, pero eso ya lo hace la mutación «enderman_teletransporte».)
 */
public class EndermanBromistaEntity extends EndermanEntity {
    private static final int INTENTOS = 16;
    private static final double MIN = 6, MAX = 10;

    public EndermanBromistaEntity(EntityType<? extends EndermanEntity> type, World world) {
        super(type, world);
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason reason) {
        if (reason == SpawnReason.NATURAL && Mobs.bloqueadoEn(world, getType())) return false;
        return super.canSpawn(world, reason);
    }

    @Override
    public boolean tryAttack(Entity objetivo) {
        boolean golpe = super.tryAttack(objetivo);
        if (golpe && !getWorld().isClient() && objetivo instanceof ServerPlayerEntity p && Variantes.valido(p)) {
            bromear(p);
        }
        return golpe;
    }

    /** Las bromas: efecto, duración (ticks), nivel y cómo se llama en el aviso. */
    private record Broma(net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> efecto, int ticks, int nivel, String nombre) {}
    private static final Broma[] BROMAS = {
            new Broma(net.minecraft.entity.effect.StatusEffects.NAUSEA, 140, 0, "¡mareo!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.BLINDNESS, 60, 0, "¡a oscuras!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.LEVITATION, 50, 0, "¡a volar!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.SLOWNESS, 100, 2, "¡pies de plomo!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.WEAKNESS, 140, 0, "¡brazos de gelatina!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.HUNGER, 200, 1, "¡qué hambre!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.MINING_FATIGUE, 200, 1, "¡pico de juguete!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.GLOWING, 300, 0, "¡te ven desde lejos!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.DARKNESS, 120, 0, "¡apagón!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.JUMP_BOOST, 160, 4, "¡muelles en los pies!"),
            new Broma(net.minecraft.entity.effect.StatusEffects.SPEED, 120, 3, "¡turbo sin frenos!")};

    /** Al pegarte te gasta una broma: un efecto al azar (y a veces, los controles al revés). */
    private void bromear(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        String nombre;
        if (random.nextInt(BROMAS.length + 1) == 0) {
            if (ServerPlayNetworking.canSend(p, com.centrodesinformacion.desinformados.network.InvertidoPayload.ID))
                ServerPlayNetworking.send(p, new com.centrodesinformacion.desinformados.network.InvertidoPayload(80));
            nombre = "¡controles al revés!";
        } else {
            Broma b = BROMAS[random.nextInt(BROMAS.length)];
            p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(b.efecto(), b.ticks(), b.nivel()), this);
            nombre = b.nombre();
        }
        w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.8, 0.4, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_AMBIENT, SoundCategory.HOSTILE, 1f, 1.8f);
        p.sendMessage(Text.literal("El Enderman Bromista te ha gastado una broma: " + nombre).formatted(Formatting.DARK_PURPLE), true);
    }

    /** Hueco de 2 bloques de aire sobre un bloque sólido, cargado, dentro del borde y fuera del Centro. */
    private static boolean esSeguro(ServerWorld w, BlockPos pies, EstadoServidor estado) {
        if (pies.getY() - 1 < w.getBottomY() || pies.getY() + 2 > w.getTopY()) return false;
        if (!w.getWorldBorder().contains(pies) || !w.isChunkLoaded(pies)) return false;
        BlockPos suelo = pies.down();
        return w.isAir(pies) && w.isAir(pies.up())
                && w.getBlockState(suelo).isSolidBlock(w, suelo)
                && !Reglas.enSpawn(w, pies, estado);
    }
}

package com.centrodesinformacion.desinformados.entidad.variante2;

import com.centrodesinformacion.desinformados.entidad.CuboBlancoEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/**
 * Cubo Negro: como el Cubo Blanco (Lentitud I al tocarte, no hace daño), pero un 50 % más rápido y,
 * en vez de la pantalla en blanco, te deja a oscuras: Ceguera 4 s + Oscuridad 6 s (efectos vanilla).
 */
public class CuboNegroEntity extends CuboBlancoEntity {
    private static final double VELOCIDAD = 0.18 * 1.5;   // Cubo Blanco: 0,18
    private static final int TICKS_CEGUERA = 4 * 20;
    private static final int TICKS_OSCURIDAD = 6 * 20;

    public CuboNegroEntity(EntityType<? extends SlimeEntity> type, World world) {
        super(type, world);
    }

    /** CuboBlancoEntity fija su velocidad (0,18) en cada setSize: aquí se sube después. */
    @Override
    public void setSize(int size, boolean heal) {
        super.setSize(size, heal);
        var vel = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (vel != null) vel.setBaseValue(VELOCIDAD);
    }

    /** En vez del flash blanco: a oscuras. */
    @Override
    protected void destello(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, TICKS_CEGUERA, 0, false, true), this);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, TICKS_OSCURIDAD, 0, false, true), this);
    }

    @Override
    protected void alTocar(ServerPlayerEntity p) {
        p.sendMessage(Text.literal("El Cubo Negro te ha tocado... y se ha hecho de noche.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
    }

    @Override
    protected ParticleEffect getParticles() {
        return ParticleTypes.SMOKE;
    }
}

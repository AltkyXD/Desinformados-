package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.ModBloques;
import com.centrodesinformacion.desinformados.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

import java.util.Optional;

/** Tinta: el "agua" de la Libreta del Becario. Se comporta como agua, pero mancha la pantalla. */
public abstract class TintaFluid extends FlowableFluid {
    @Override public Fluid getFlowing() { return ModFluidos.TINTA_FLUYENDO; }
    @Override public Fluid getStill() { return ModFluidos.TINTA; }
    @Override public Item getBucketItem() { return ModItems.CUBO_TINTA; }
    @Override protected boolean isInfinite(World world) { return true; }

    @Override
    protected void beforeBreakingBlock(WorldAccess world, BlockPos pos, BlockState state) {
        BlockEntity be = state.hasBlockEntity() ? world.getBlockEntity(pos) : null;
        Block.dropStacks(state, world, pos, be);
    }

    @Override protected int getMaxFlowDistance(WorldView world) { return 4; }
    @Override protected int getLevelDecreasePerBlock(WorldView world) { return 1; }
    @Override public int getTickRate(WorldView world) { return 5; }
    @Override protected float getBlastResistance() { return 100.0f; }

    @Override
    protected boolean canBeReplacedWith(FluidState state, BlockView world, BlockPos pos, Fluid fluid, Direction direction) {
        return false;
    }

    @Override
    protected BlockState toBlockState(FluidState state) {
        return ModBloques.TINTA.getDefaultState().with(Properties.LEVEL_15, getBlockStateLevel(state));
    }

    @Override public boolean matchesType(Fluid fluid) { return fluid == getStill() || fluid == getFlowing(); }
    @Override public Optional<SoundEvent> getBucketFillSound() { return Optional.of(SoundEvents.ITEM_BUCKET_FILL); }

    public static class Quieta extends TintaFluid {
        @Override public int getLevel(FluidState state) { return 8; }
        @Override public boolean isStill(FluidState state) { return true; }
    }

    public static class Fluyendo extends TintaFluid {
        @Override
        protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
            super.appendProperties(builder);
            builder.add(LEVEL);
        }
        @Override public int getLevel(FluidState state) { return state.get(LEVEL); }
        @Override public boolean isStill(FluidState state) { return false; }
    }
}

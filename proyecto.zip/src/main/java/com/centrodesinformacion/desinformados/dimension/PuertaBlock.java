package com.centrodesinformacion.desinformados.dimension;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * Bloque de un solo uso como portal: fuera de su dimensión te lleva dentro; dentro de ella te devuelve.
 * Puerta de Oficina -> Redacción. Salida de la Tele -> vuelve del Interior de la Tele.
 */
public class PuertaBlock extends HorizontalFacingBlock {
    private final RegistryKey<World> destino;
    private final MapCodec<PuertaBlock> codec;

    public PuertaBlock(Settings settings, RegistryKey<World> destino) {
        super(settings);
        this.destino = destino;
        this.codec = createCodec(s -> new PuertaBlock(s, destino));
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return codec; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient() && player instanceof ServerPlayerEntity p) {
            if (world.getRegistryKey() == destino) Dimensiones.volver(p);
            else if (destino == Dimensiones.REDACCION) Dimensiones.entrarRedaccion(p);
            else Dimensiones.entrarTele(p);
        }
        return ActionResult.SUCCESS;
    }
}

package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * La Libreta del Becario: una libreta plana sobre el escritorio.
 * Cerrada no deja entrar; abierta (con /desinfo portal libreta abrir) te lleva a la Libreta.
 * Dentro de la Libreta siempre está abierta y te devuelve.
 */
public class LibretaBlock extends HorizontalFacingBlock {
    public static final MapCodec<LibretaBlock> CODEC = createCodec(LibretaBlock::new);
    public static final BooleanProperty ABIERTA = BooleanProperty.of("abierta");
    public static final String MARCA_ABIERTA = "sys:libreta_abierta";
    private static final VoxelShape CERRADA = Block.createCuboidShape(3, 0, 1, 13, 2, 15);
    private static final VoxelShape ABIERTA_N = Block.createCuboidShape(0, 0, 1, 16, 1.5, 15);
    private static final VoxelShape ABIERTA_E = Block.createCuboidShape(1, 0, 0, 15, 1.5, 16);
    private static final VoxelShape CERRADA_E = Block.createCuboidShape(1, 0, 3, 15, 2, 13);

    public LibretaBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(ABIERTA, false));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, ABIERTA);
    }

    public static boolean debeEstarAbierta(World world) {
        if (world.getRegistryKey() == Dimensiones.LIBRETA) return true;
        return world.getServer() != null && EstadoServidor.get(world.getServer()).tieneCambio(MARCA_ABIERTA);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        boolean abierta = !ctx.getWorld().isClient() && debeEstarAbierta(ctx.getWorld());
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite()).with(ABIERTA, abierta);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        boolean ns = state.get(FACING).getAxis() == Direction.Axis.Z;
        if (state.get(ABIERTA)) return ns ? ABIERTA_N : ABIERTA_E;
        return ns ? CERRADA : CERRADA_E;
    }

    /** Revisa cada 2 segundos si tiene que abrirse o cerrarse. */
    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState viejo, boolean notify) {
        if (!world.isClient()) world.scheduleBlockTick(pos, this, 40);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        boolean abierta = debeEstarAbierta(world);
        if (state.get(ABIERTA) != abierta) {
            world.setBlockState(pos, state.with(ABIERTA, abierta), Block.NOTIFY_ALL);
            world.playSound(null, pos, net.minecraft.sound.SoundEvents.ITEM_BOOK_PAGE_TURN, net.minecraft.sound.SoundCategory.BLOCKS, 1f, abierta ? 1f : 0.7f);
        }
        world.scheduleBlockTick(pos, this, 40);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient() && player instanceof ServerPlayerEntity p) {
            if (world.getRegistryKey() == Dimensiones.LIBRETA) Dimensiones.volver(p);
            else if (!debeEstarAbierta(world)) {
                p.sendMessage(Text.literal("Solo es una libreta").formatted(Formatting.GRAY, Formatting.ITALIC), true);
                world.playSound(null, pos, net.minecraft.sound.SoundEvents.ITEM_BOOK_PUT, net.minecraft.sound.SoundCategory.BLOCKS, 1f, 1f);
            } else Dimensiones.entrarLibreta(p);
        }
        return ActionResult.SUCCESS;
    }
}

package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModFluidos {
    public static final FlowableFluid TINTA = Registry.register(Registries.FLUID, Desinformados.id("tinta"), new TintaFluid.Quieta());
    public static final FlowableFluid TINTA_FLUYENDO = Registry.register(Registries.FLUID, Desinformados.id("tinta_fluyendo"), new TintaFluid.Fluyendo());

    public static boolean esTinta(net.minecraft.fluid.FluidState estado) {
        return estado.getFluid() == TINTA || estado.getFluid() == TINTA_FLUYENDO;
    }
}

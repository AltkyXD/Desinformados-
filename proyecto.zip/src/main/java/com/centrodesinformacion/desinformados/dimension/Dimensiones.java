package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Eventos;
import com.centrodesinformacion.desinformados.ModBloques;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Las dos dimensiones del mod: el Interior de la Tele y la Redacción. */
public class Dimensiones {
    public static final RegistryKey<World> TELE = RegistryKey.of(RegistryKeys.WORLD, Desinformados.id("interior_tele"));
    public static final RegistryKey<World> REDACCION = RegistryKey.of(RegistryKeys.WORLD, Desinformados.id("redaccion"));

    /** Altura del suelo de la Redacción (capas planas: bedrock, piedra x3, moqueta). */
    public static final int SUELO_REDACCION = 4;
    /** Dónde aparece quien entra a la Redacción (lejos del escenario, para que haya que recorrer la mazmorra). */
    public static final BlockPos LLEGADA_REDACCION = new BlockPos(408, SUELO_REDACCION + 1, 8);
    public static final BlockPos LLEGADA_TELE = new BlockPos(0, 60, 0);

    private record Vuelta(RegistryKey<World> mundo, Vec3d pos) {}
    private static final Map<UUID, Vuelta> VUELTAS = new HashMap<>();

    public static boolean esDelMod(RegistryKey<World> k) {
        return k == TELE || k == REDACCION;
    }

    public static boolean esDelMod(WorldAccess w) {
        return w instanceof ServerWorldAccess s && esDelMod(s.toServerWorld().getRegistryKey());
    }

    // ------------------------------------------------------------------ viajes

    private static void guardarVuelta(ServerPlayerEntity p) {
        if (!esDelMod(p.getServerWorld().getRegistryKey())) {
            VUELTAS.put(p.getUuid(), new Vuelta(p.getServerWorld().getRegistryKey(), p.getPos()));
        }
    }

    public static void entrarTele(ServerPlayerEntity p) {
        ServerWorld tele = p.getServer().getWorld(TELE);
        if (tele == null) return;
        guardarVuelta(p);
        prepararLlegadaTele(tele);
        p.teleport(tele, LLEGADA_TELE.getX() + 0.5, LLEGADA_TELE.getY(), LLEGADA_TELE.getZ() + 0.5, p.getYaw(), p.getPitch());
        efectoViaje(p, "Has entrado en el Interior de la Tele...");
    }

    public static void entrarRedaccion(ServerPlayerEntity p) {
        ServerWorld red = p.getServer().getWorld(REDACCION);
        if (red == null) return;
        guardarVuelta(p);
        prepararLlegadaRedaccion(red);
        BlockPos l = LLEGADA_REDACCION;
        p.teleport(red, l.getX() + 0.5, l.getY(), l.getZ() + 0.5, -90f, 0f);
        efectoViaje(p, "Bienvenido a la Redacción. Sigue la alfombra roja...");
    }

    public static void volver(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Vuelta v = VUELTAS.remove(p.getUuid());
        ServerWorld destino = v != null ? server.getWorld(v.mundo()) : null;
        if (destino == null) {
            destino = server.getOverworld();
            BlockPos s = destino.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, destino.getSpawnPos());
            v = new Vuelta(World.OVERWORLD, Vec3d.ofBottomCenter(s));
        }
        p.teleport(destino, v.pos().x, v.pos().y, v.pos().z, p.getYaw(), p.getPitch());
        efectoViaje(p, "Has vuelto.");
    }

    private static void efectoViaje(ServerPlayerEntity p, String mensaje) {
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.4f, 1.6f);
        p.sendMessage(Text.literal(mensaje).formatted(Formatting.GRAY, Formatting.ITALIC), true);
    }

    // ------------------------------------------------------------------ zonas de llegada

    private static void prepararLlegadaTele(ServerWorld w) {
        BlockPos c = LLEGADA_TELE;
        w.getChunk(c);
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                w.setBlockState(c.add(x, -1, z), ModBloques.BLOQUE_ESTATICA.getDefaultState());
                for (int y = 0; y <= 4; y++) w.setBlockState(c.add(x, y, z), Blocks.AIR.getDefaultState());
            }
        }
        w.setBlockState(c.add(0, 0, -3), ModBloques.SALIDA_TELE.getDefaultState()
                .with(PuertaBlock.FACING, Direction.SOUTH));
    }

    private static void prepararLlegadaRedaccion(ServerWorld w) {
        BlockPos c = LLEGADA_REDACCION;
        w.getChunk(c);
        for (int y = 0; y <= 2; y++) {
            for (int dz = -1; dz <= 1; dz++) w.setBlockState(c.add(0, y, dz), Blocks.AIR.getDefaultState());
        }
        w.setBlockState(c.add(2, 0, 0), ModBloques.PUERTA_OFICINA.getDefaultState().with(PuertaBlock.FACING, Direction.WEST));
        w.setBlockState(c.add(2, 1, 0), Blocks.AIR.getDefaultState());
    }

    // ------------------------------------------------------------------ teles portal

    /** Rompe (o repara) todas las teles portal colocadas. */
    public static int romperTeles(MinecraftServer server, boolean rota) {
        EstadoServidor estado = EstadoServidor.get(server);
        ServerWorld w = server.getOverworld();
        int n = 0;
        for (long l : estado.getTelesPortal()) {
            BlockPos origen = BlockPos.fromLong(l);
            w.getChunk(origen);
            BlockState base = w.getBlockState(origen);
            if (!(base.getBlock() instanceof TelePortalBlock)) continue;
            Direction derecha = base.get(TelePortalBlock.FACING).rotateYCounterclockwise();
            for (int px = 0; px < 4; px++) {
                for (int py = 0; py < 4; py++) {
                    BlockPos q = origen.offset(derecha, px).up(py);
                    BlockState s = w.getBlockState(q);
                    if (s.getBlock() instanceof TelePortalBlock) w.setBlockState(q, s.with(TelePortalBlock.ROTA, rota), Block.NOTIFY_ALL);
                }
            }
            Vec3d centro = Vec3d.ofCenter(origen.offset(derecha, 1).up(2));
            if (rota) {
                w.playSound(null, origen, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 2f, 0.6f);
                w.playSound(null, origen, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.BLOCKS, 1f, 0.7f);
                w.spawnParticles(ParticleTypes.EXPLOSION, centro.x, centro.y, centro.z, 3, 1, 1, 1, 0);
                w.spawnParticles(ParticleTypes.WHITE_ASH, centro.x, centro.y, centro.z, 200, 1.5, 1.5, 1.5, 0.1);
            }
            n++;
        }
        if (rota && n > 0) {
            Eventos.mostrarTele(server, "rojo", "¡La tele se ha roto!",
                    "Algo ha atravesado la pantalla desde dentro. Ahora hay un vórtice de estática en el spawn... y parece que se puede entrar.");
        }
        return n;
    }
}

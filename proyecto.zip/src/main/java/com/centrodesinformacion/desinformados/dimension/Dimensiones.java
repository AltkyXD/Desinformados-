package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Eventos;
import com.centrodesinformacion.desinformados.ModBloques;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Dimensiones del mod:
 *  - Interior de la Tele: la del jefe final. Cuartito de llegada -> túnel largo -> arena.
 *  - Libreta del Becario: un mundo normal (altura 0-256 como en 1.16) con minerales nuevos y mobs dibujados.
 */
public class Dimensiones {
    public static final RegistryKey<World> TELE = RegistryKey.of(RegistryKeys.WORLD, Desinformados.id("interior_tele"));
    public static final RegistryKey<World> LIBRETA = RegistryKey.of(RegistryKeys.WORLD, Desinformados.id("libreta"));

    // Estructura de la Tele (se construye por código la primera vez)
    public static final int SUELO = 63;
    public static final BlockPos LLEGADA_TELE = new BlockPos(0, SUELO + 1, 0);
    private static final int TUNEL_INICIO = 5, TUNEL_FIN = 84;
    public static final BlockPos CENTRO_ARENA = new BlockPos(TUNEL_FIN + 30, SUELO, 0);
    private static final int RADIO_ARENA = 28, ALTO_ARENA = 24;
    private static final String MARCA_ARENA = "sys:arena_tele";

    private record Vuelta(RegistryKey<World> mundo, Vec3d pos) {}
    private static final Map<UUID, Vuelta> VUELTAS = new HashMap<>();

    /** Dimensiones a las que se viaja (para guardar el punto de vuelta). */
    public static boolean esDeViaje(RegistryKey<World> k) {
        return k == TELE || k == LIBRETA;
    }

    /** En el Interior de la Tele todos los mobs del mod están libres (su casa). */
    public static boolean esDelMod(RegistryKey<World> k) {
        return k == TELE;
    }

    public static boolean esDelMod(WorldAccess w) {
        return w instanceof ServerWorldAccess s && esDelMod(s.toServerWorld().getRegistryKey());
    }

    // ------------------------------------------------------------------ viajes

    private static void guardarVuelta(ServerPlayerEntity p) {
        if (!esDeViaje(p.getServerWorld().getRegistryKey())) {
            VUELTAS.put(p.getUuid(), new Vuelta(p.getServerWorld().getRegistryKey(), p.getPos()));
        }
    }

    public static void entrarTele(ServerPlayerEntity p) {
        ServerWorld tele = p.getServer().getWorld(TELE);
        if (tele == null) return;
        guardarVuelta(p);
        construirTele(tele, false);
        p.teleport(tele, LLEGADA_TELE.getX() + 0.5, LLEGADA_TELE.getY(), LLEGADA_TELE.getZ() + 0.5, -90f, 0f);
        efectoViaje(p, "Has entrado en el Interior de la Tele... sigue el túnel.");
    }

    public static void entrarLibreta(ServerPlayerEntity p) {
        ServerWorld lib = p.getServer().getWorld(LIBRETA);
        if (lib == null) return;
        guardarVuelta(p);
        BlockPos tierra = buscarTierra(lib);
        lib.getChunk(tierra);
        BlockPos top = lib.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, tierra);
        if (top.getY() <= lib.getBottomY() + 1) top = new BlockPos(tierra.getX(), 80, tierra.getZ());
        if (!lib.getFluidState(top).isEmpty() || !lib.getFluidState(top.down()).isEmpty()) {
            // Plan B: islita de papel sobre la tinta
            int y = Math.max(top.getY(), lib.getChunkManager().getChunkGenerator().getSeaLevel() + 1);
            top = new BlockPos(tierra.getX(), y, tierra.getZ());
            for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) {
                lib.setBlockState(top.add(dx, -1, dz), ModBloques.CESPED_PAPEL.getDefaultState());
                lib.setBlockState(top.add(dx, 0, dz), net.minecraft.block.Blocks.AIR.getDefaultState());
                lib.setBlockState(top.add(dx, 1, dz), net.minecraft.block.Blocks.AIR.getDefaultState());
            }
        }
        // La libreta de vuelta (siempre abierta), al lado de donde aparecéis
        BlockPos ret = lib.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, top.east(2));
        if (!lib.getFluidState(ret.down()).isEmpty()) ret = top.north(2);
        if (!(lib.getBlockState(ret).getBlock() instanceof LibretaBlock))
            lib.setBlockState(ret, ModBloques.LIBRETA_PORTAL.getDefaultState()
                    .with(LibretaBlock.FACING, Direction.WEST).with(LibretaBlock.ABIERTA, true));
        p.teleport(lib, top.getX() + 0.5, top.getY(), top.getZ() + 0.5, -90f, 0f);
        efectoViaje(p, "Has entrado en la Libreta del Becario...");
    }

    private static BlockPos llegadaLibreta = null;
    private static long semillaLlegada = 0;

    /**
     * Busca tierra firme cerca del centro SIN generar terreno: primero mira la "continentalidad" del ruido
     * (rapidísimo) y solo comprueba la altura real en unos pocos candidatos. Nunca tarda más de unos milisegundos.
     */
    public static BlockPos buscarTierra(ServerWorld w) {
        if (llegadaLibreta != null && semillaLlegada == w.getSeed()) return llegadaLibreta;
        var gen = w.getChunkManager().getChunkGenerator();
        var ruido = w.getChunkManager().getNoiseConfig();
        var muestreo = ruido.getMultiNoiseSampler();
        int mar = gen.getSeaLevel();
        BlockPos encontrado = null;
        int comprobaciones = 0;
        busqueda:
        for (int r = 0; r <= 4000; r += 64) {
            int pasos = r == 0 ? 1 : (int) Math.ceil(2 * Math.PI * r / 64);
            for (int i = 0; i < pasos; i++) {
                double a = 2 * Math.PI * i / pasos;
                int x = (int) Math.round(r * Math.cos(a)), z = (int) Math.round(r * Math.sin(a));
                var punto = muestreo.sample(net.minecraft.world.biome.source.BiomeCoords.fromBlock(x),
                        net.minecraft.world.biome.source.BiomeCoords.fromBlock(mar),
                        net.minecraft.world.biome.source.BiomeCoords.fromBlock(z));
                if (net.minecraft.world.biome.source.util.MultiNoiseUtil.toFloat(punto.continentalnessNoise()) < 0.05f) continue;
                if (comprobaciones++ >= 24) break busqueda;   // como mucho 24 cálculos de altura reales
                if (gen.getHeight(x, z, Heightmap.Type.OCEAN_FLOOR_WG, w, ruido) > mar + 2) {
                    encontrado = new BlockPos(x, 0, z);
                    break busqueda;
                }
            }
        }
        if (encontrado == null) encontrado = BlockPos.ORIGIN;
        llegadaLibreta = encontrado;
        semillaLlegada = w.getSeed();
        return encontrado;
    }


    public static void volver(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Vuelta v = VUELTAS.remove(p.getUuid());
        ServerWorld destino = v != null ? server.getWorld(v.mundo()) : null;
        if (destino == null) {
            destino = server.getOverworld();
            BlockPos s = destino.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, destino.getSpawnPos());
            v = new Vuelta(World.OVERWORLD, Vec3d.ofBottomCenter(s));
        }
        p.teleport(destino, v.pos().x, v.pos().y, v.pos().z, p.getYaw(), p.getPitch());
        efectoViaje(p, "Has vuelto.");
    }

    private static void efectoViaje(ServerPlayerEntity p, String mensaje) {
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.4f, 1.6f);
        p.sendMessage(Text.literal(mensaje).formatted(Formatting.GRAY, Formatting.ITALIC), true);
    }

    // ------------------------------------------------------------------ estructura de la Tele

    /** Cuartito (9x9) -> túnel de 80 bloques -> arena circular. Solo se construye una vez (o forzado). */
    public static void construirTele(ServerWorld w, boolean forzar) {
        EstadoServidor estado = EstadoServidor.get(w.getServer());
        if (estado.tieneCambio(MARCA_ARENA) && !forzar) return;
        BlockState muro = ModBloques.MURO_ESTATICA.getDefaultState();
        BlockState aire = Blocks.AIR.getDefaultState();
        BlockState luz = Blocks.SEA_LANTERN.getDefaultState();
        int f = Block.NOTIFY_LISTENERS;
        int y0 = SUELO;

        // Cuartito de llegada: x -4..4, z -4..4, 5 de alto
        for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) for (int y = y0; y <= y0 + 6; y++) {
            boolean borde = x == -5 || x == 5 || z == -5 || z == 5 || y == y0 || y == y0 + 6;
            boolean puerta = x == 5 && Math.abs(z) <= 1 && y > y0 && y <= y0 + 3;
            w.setBlockState(new BlockPos(x, y, z), borde && !puerta ? muro : aire, f);
        }
        w.setBlockState(new BlockPos(0, y0 + 6, 0), luz, f);
        w.setBlockState(new BlockPos(-4, y0 + 1, 0), ModBloques.SALIDA_TELE.getDefaultState().with(PuertaBlock.FACING, Direction.EAST), f);

        // Túnel largo: 3 de ancho, 4 de alto, a oscuras salvo alguna luz (ahí aparecen los mobs de estática)
        for (int x = TUNEL_INICIO; x <= TUNEL_FIN; x++) for (int z = -3; z <= 3; z++) for (int y = y0; y <= y0 + 5; y++) {
            boolean borde = Math.abs(z) == 3 || y == y0 || y == y0 + 5;
            if (!borde && Math.abs(z) > 1) borde = true;
            w.setBlockState(new BlockPos(x, y, z), borde ? muro : aire, f);
        }
        for (int x = TUNEL_INICIO + 10; x < TUNEL_FIN; x += 20) w.setBlockState(new BlockPos(x, y0 + 5, 0), luz, f);

        // Arena circular, bien iluminada
        int cx = CENTRO_ARENA.getX(), cz = CENTRO_ARENA.getZ();
        for (int dx = -RADIO_ARENA - 1; dx <= RADIO_ARENA + 1; dx++) for (int dz = -RADIO_ARENA - 1; dz <= RADIO_ARENA + 1; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > RADIO_ARENA + 1) continue;
            boolean pared = d > RADIO_ARENA - 0.5;
            for (int y = y0; y <= y0 + ALTO_ARENA; y++) {
                boolean borde = pared || y == y0 || y == y0 + ALTO_ARENA;
                boolean entrada = pared && dx < 0 && Math.abs(dz) <= 1 && y > y0 && y <= y0 + 4;
                BlockState s = borde && !entrada ? muro : aire;
                if (y == y0 && !pared && (dx * dx + dz * dz) % 37 == 0) s = luz;
                if (y == y0 + ALTO_ARENA && !pared && Math.floorMod(dx, 6) == 0 && Math.floorMod(dz, 6) == 0) s = luz;
                w.setBlockState(new BlockPos(cx + dx, y, cz + dz), s, f);
            }
        }
        // Unir túnel y arena
        for (int x = TUNEL_FIN; x <= cx - RADIO_ARENA + 1; x++) for (int z = -1; z <= 1; z++) for (int y = y0 + 1; y <= y0 + 4; y++) {
            w.setBlockState(new BlockPos(x, y, z), aire, f);
        }
        estado.agregarCambio(MARCA_ARENA);
    }

    // ------------------------------------------------------------------ teles portal

    /** Rompe (o repara) todas las teles portal colocadas. */
    public static int romperTeles(MinecraftServer server, boolean rota) {
        EstadoServidor estado = EstadoServidor.get(server);
        ServerWorld w = server.getOverworld();
        int n = 0;
        for (long l : estado.getTelesPortal()) {
            BlockPos origen = BlockPos.fromLong(l);
            w.getChunk(origen);
            BlockState base = w.getBlockState(origen);
            if (!(base.getBlock() instanceof TelePortalBlock)) continue;
            Direction derecha = base.get(TelePortalBlock.FACING).rotateYCounterclockwise();
            for (int px = 0; px < 4; px++) {
                for (int py = 0; py < 4; py++) {
                    BlockPos q = origen.offset(derecha, px).up(py);
                    BlockState s = w.getBlockState(q);
                    if (s.getBlock() instanceof TelePortalBlock) w.setBlockState(q, s.with(TelePortalBlock.ROTA, rota), Block.NOTIFY_ALL);
                }
            }
            Vec3d centro = Vec3d.ofCenter(origen.offset(derecha, 1).up(2));
            if (rota) {
                w.playSound(null, origen, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 2f, 0.6f);
                w.playSound(null, origen, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.BLOCKS, 1f, 0.7f);
                w.spawnParticles(ParticleTypes.EXPLOSION, centro.x, centro.y, centro.z, 3, 1, 1, 1, 0);
                w.spawnParticles(ParticleTypes.WHITE_ASH, centro.x, centro.y, centro.z, 200, 1.5, 1.5, 1.5, 0.1);
            }
            n++;
        }
        if (rota && n > 0) {
            ServerWorld tele = server.getWorld(TELE);
            if (tele != null) construirTele(tele, false);
            Eventos.mostrarTele(server, "rojo", "¡La tele se ha roto!",
                    "Algo ha atravesado la pantalla desde dentro. Ahora hay un vórtice de estática en el spawn... y al otro lado os espera quien dañó el reactor.");
        }
        return n;
    }
}

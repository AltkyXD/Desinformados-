package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Desinformados;
import com.mojang.serialization.Codec;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.inventory.LootableInventory;
import net.minecraft.loot.LootTable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/** Cofres con Rumores repartidos por las cuevas del Interior de la Tele. */
public class CofreFeature extends Feature<DefaultFeatureConfig> {
    public static final RegistryKey<LootTable> BOTIN = RegistryKey.of(RegistryKeys.LOOT_TABLE, Desinformados.id("chests/tele"));

    public CofreFeature(Codec<DefaultFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        BlockPos p = ctx.getOrigin();
        if (!w.isAir(p)) return false;
        for (int i = 0; i < 20 && p.getY() > w.getBottomY() + 6; i++) {
            if (!w.isAir(p.down())) {
                Direction d = Direction.Type.HORIZONTAL.random(ctx.getRandom());
                w.setBlockState(p, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, d), 2);
                LootableInventory.setLootTable(w, ctx.getRandom(), p, BOTIN);
                return true;
            }
            p = p.down();
        }
        return false;
    }
}

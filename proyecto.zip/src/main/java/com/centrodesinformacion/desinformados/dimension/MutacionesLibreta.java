package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.entidad.*;
import com.centrodesinformacion.desinformados.network.ManchaPayload;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/**
 * Cambio de dificultad de la Libreta "libreta_mejorada" (amarillo). Solo se puede lanzar con la libreta abierta:
 *  - zombies dibujados: Debilidad 4 s al golpearte.
 *  - esqueletos dibujados: sus flechas dan Lentitud II 3 s.
 *  - creepers dibujados: su explosión ciega 3 s y mancha la pantalla de tinta.
 *  - arañas dibujadas: te dejan 4 s en una telaraña.
 *  - Garabatos: al morir en la Libreta, 50 % de que reaparezcan (una vez).
 */
public class MutacionesLibreta {
    /** Un solo cambio de dificultad que mejora a todos los mobs de la Libreta. */
    public static final String ID = "libreta_mejorada";
    public static final java.util.List<String> IDS = java.util.List.of(ID);

    public static boolean libretaAbierta(MinecraftServer server) {
        return EstadoServidor.get(server).tieneCambio(LibretaBlock.MARCA_ABIERTA);
    }

    private static boolean activo(MinecraftServer s, String id) {
        return EstadoServidor.get(s).tieneCambio(id);
    }

    private static void manchar(ServerPlayerEntity p, int ticks) {
        if (ServerPlayNetworking.canSend(p, ManchaPayload.ID)) ServerPlayNetworking.send(p, new ManchaPayload(ticks));
    }

    public static void registrar() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((victima, fuente, cantidad) -> {
            if (!(victima instanceof ServerPlayerEntity p)) return true;
            MinecraftServer s = p.getServer();
            if (s == null) return true;
            Entity atacante = fuente.getAttacker();
            if (atacante instanceof ZombieDibujoEntity && activo(s, ID)) {
                // con la goma de borrar te borran un poco la fuerza
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
            } else if (atacante instanceof EsqueletoDibujoEntity && activo(s, ID)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
            } else if (atacante instanceof CreeperDibujoEntity && activo(s, ID)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
                manchar(p, 200);
            } else if (atacante instanceof AranaDibujoEntity && activo(s, ID)) {
                ServerWorld w = p.getServerWorld();
                BlockPos pies = p.getBlockPos();
                if (w.getBlockState(pies).isAir()) {
                    w.setBlockState(pies, Blocks.COBWEB.getDefaultState());
                    Tareas.programar(80, () -> {
                        if (w.getBlockState(pies).isOf(Blocks.COBWEB)) w.removeBlock(pies, false);
                    });
                }
            }
            return true;
        });

        // Garabatos redibujados: al morir en la Libreta, 50 % de que el becario lo vuelva a dibujar
        ServerLivingEntityEvents.AFTER_DEATH.register((entidad, fuente) -> {
            if (!(entidad instanceof GarabatoEntity) || !(entidad.getWorld() instanceof ServerWorld w)) return;
            if (w.getRegistryKey() != Dimensiones.LIBRETA || !activo(w.getServer(), ID)) return;
            if (entidad.getCommandTags().contains("desinfo_redibujado") || w.getRandom().nextBoolean()) return;
            double x = entidad.getX(), y = entidad.getY(), z = entidad.getZ();
            Tareas.programar(30, () -> {
                GarabatoEntity nuevo = ModEntidades.GARABATO.create(w);
                if (nuevo == null) return;
                nuevo.refreshPositionAndAngles(x, y, z, w.getRandom().nextFloat() * 360f, 0f);
                nuevo.addCommandTag("desinfo_redibujado"); // solo se redibuja una vez
                w.spawnEntity(nuevo);
                w.spawnParticles(net.minecraft.particle.ParticleTypes.SQUID_INK, x, y + 1, z, 20, 0.4, 0.6, 0.4, 0.02);
            });
        });
    }
}

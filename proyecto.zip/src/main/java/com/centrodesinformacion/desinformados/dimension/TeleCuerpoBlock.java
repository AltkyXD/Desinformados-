package com.centrodesinformacion.desinformados.dimension;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * El cuerpo de la Tele Gigante (lo que hay detrás de la pantalla): mueble de madera, el tubo que se estrecha
 * con rejillas de ventilación por detrás y la antena de orejas de conejo encima. Se pone y se quita junto con la tele.
 * PX = hacia la derecha, PY = hacia arriba, PZ = hacia atrás (desde el frente).
 */
public class TeleCuerpoBlock extends HorizontalFacingBlock {
    public static final MapCodec<TeleCuerpoBlock> CODEC = createCodec(TeleCuerpoBlock::new);

    public enum Parte implements StringIdentifiable {
        MADERA("madera"), TUBO("tubo"), REJILLA("rejilla"), ANTENA("antena");
        private final String nombre;
        Parte(String nombre) { this.nombre = nombre; }
        @Override public String asString() { return nombre; }
    }

    public static final EnumProperty<Parte> PARTE = EnumProperty.of("parte", Parte.class);
    public static final IntProperty PX = IntProperty.of("px", 0, 4);
    public static final IntProperty PY = IntProperty.of("py", 0, 5);
    public static final IntProperty PZ = IntProperty.of("pz", 1, 4);
    private static final VoxelShape ANTENA = Block.createCuboidShape(4, 0, 5, 12, 4, 11);

    public TeleCuerpoBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PARTE, Parte.MADERA)
                .with(PX, 0).with(PY, 0).with(PZ, 1));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PARTE, PX, PY, PZ);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return state.get(PARTE) == Parte.ANTENA ? ANTENA : VoxelShapes.fullCube();
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return getOutlineShape(state, world, pos, ctx);
    }

    /** Dónde está el bloque de origen de la tele (esquina de abajo a la izquierda del frente). */
    static BlockPos origen(BlockState s, BlockPos pos) {
        Direction facing = s.get(FACING);
        Direction derecha = facing.rotateYCounterclockwise();
        return pos.offset(derecha, -s.get(PX)).down(s.get(PY)).offset(facing.getOpposite(), -s.get(PZ));
    }

    /** Si alguien quita una pieza del cuerpo (un admin en creativo), desaparece la tele entera. */
    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this) && !TelePortalBlock.quitando && !world.isClient()) {
            BlockPos o = origen(state, pos);
            if (world.getBlockState(o).getBlock() instanceof TelePortalBlock)
                world.setBlockState(o, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }
}

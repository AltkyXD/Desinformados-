package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModBloques;
import com.mojang.serialization.Codec;
import net.minecraft.block.*;
import net.minecraft.block.enums.SlabType;
import net.minecraft.inventory.LootableInventory;
import net.minecraft.loot.LootTable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/**
 * Genera la Redacción chunk a chunk: cada chunk es un despacho de 15x15 con puertas,
 * mesas, montones de periódicos, archivadores con botín y una alfombra roja que señala
 * hacia el Escenario (el gran salón del jefe final, alrededor de 0,0).
 */
public class OficinaFeature extends Feature<DefaultFeatureConfig> {
    public static final RegistryKey<LootTable> BOTIN = RegistryKey.of(RegistryKeys.LOOT_TABLE, Desinformados.id("chests/redaccion"));
    private static final int RADIO_ESCENARIO = 2; // chunks

    public OficinaFeature(Codec<DefaultFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        Random r = ctx.getRandom();
        int cx = ctx.getOrigin().getX() >> 4, cz = ctx.getOrigin().getZ() >> 4;
        int x0 = cx << 4, z0 = cz << 4;
        int y = Dimensiones.SUELO_REDACCION + 1;
        int techo = y + 6;

        if (Math.abs(cx) <= RADIO_ESCENARIO && Math.abs(cz) <= RADIO_ESCENARIO) {
            escenario(w, r, cx, cz, x0, z0, y, techo);
            return true;
        }

        BlockState pared = ModBloques.PARED_OFICINA.getDefaultState();
        // Paredes norte (z=0) y oeste (x=0) con una o dos puertas cada una
        int puertaN = 3 + r.nextInt(10), puertaO = 3 + r.nextInt(10);
        int puertaN2 = r.nextInt(3) == 0 ? 3 + r.nextInt(10) : -10;
        for (int i = 0; i < 16; i++) {
            for (int dy = 0; dy < 6; dy++) {
                boolean huecoN = dy < 3 && (Math.abs(i - puertaN) <= 0 || i == puertaN + 1 || i == puertaN2 || i == puertaN2 + 1);
                boolean huecoO = dy < 3 && (i == puertaO || i == puertaO + 1);
                if (!huecoN) w.setBlockState(new BlockPos(x0 + i, y + dy, z0), pared, 2);
                if (!huecoO) w.setBlockState(new BlockPos(x0, y + dy, z0 + i), pared, 2);
            }
        }

        // Alfombra roja hacia el Escenario
        int ccx = x0 + 8, ccz = z0 + 8;
        int dx = -ccx, dz = -ccz;
        Direction hacia = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        for (int k = -4; k <= 5; k++) {
            BlockPos p = new BlockPos(ccx, y, ccz).offset(hacia, k);
            if (w.isAir(p)) w.setBlockState(p, Blocks.RED_CARPET.getDefaultState(), 2);
        }

        // Luz en el techo (algunos despachos se quedan a oscuras: ahí aparecen los clones)
        if (r.nextFloat() < 0.45f) w.setBlockState(new BlockPos(ccx, techo, ccz), Blocks.SEA_LANTERN.getDefaultState(), 2);

        // Mobiliario
        int mesas = 2 + r.nextInt(4);
        for (int i = 0; i < mesas; i++) {
            BlockPos p = new BlockPos(x0 + 2 + r.nextInt(12), y, z0 + 2 + r.nextInt(12));
            if (!w.isAir(p) || !w.isAir(p.east())) continue;
            BlockState mesa = Blocks.DARK_OAK_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP);
            w.setBlockState(p, mesa, 2);
            w.setBlockState(p.east(), mesa, 2);
            if (w.isAir(p.south())) w.setBlockState(p.south(), Blocks.SPRUCE_STAIRS.getDefaultState()
                    .with(StairsBlock.FACING, Direction.NORTH), 2);
            if (r.nextBoolean()) w.setBlockState(p.up(), ModBloques.PILA_PERIODICOS.getDefaultState(), 2);
        }
        int pilas = 1 + r.nextInt(4);
        for (int i = 0; i < pilas; i++) {
            BlockPos p = new BlockPos(x0 + 1 + r.nextInt(14), y, z0 + 1 + r.nextInt(14));
            if (!w.isAir(p)) continue;
            w.setBlockState(p, ModBloques.PILA_PERIODICOS.getDefaultState(), 2);
            if (r.nextBoolean() && w.isAir(p.up())) w.setBlockState(p.up(), ModBloques.PILA_PERIODICOS.getDefaultState(), 2);
        }
        // Archivador con botín (barril)
        if (r.nextFloat() < 0.14f) {
            BlockPos p = new BlockPos(x0 + 1 + r.nextInt(2), y, z0 + 2 + r.nextInt(12));
            if (w.isAir(p)) {
                w.setBlockState(p, Blocks.BARREL.getDefaultState().with(BarrelBlock.FACING, Direction.EAST), 2);
                LootableInventory.setLootTable(w, r, p, BOTIN);
            }
        }
        return true;
    }

    /** El gran salón del Escenario: sin paredes, columnas, luz y un estrado en el centro. */
    private void escenario(StructureWorldAccess w, Random r, int cx, int cz, int x0, int z0, int y, int techo) {
        BlockState columna = Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState();
        for (int[] c : new int[][]{{3, 3}, {3, 12}, {12, 3}, {12, 12}}) {
            if (cx == 0 && cz == 0) break;
            for (int dy = 0; dy < 6; dy++) w.setBlockState(new BlockPos(x0 + c[0], y + dy, z0 + c[1]), columna, 2);
            w.setBlockState(new BlockPos(x0 + c[0], techo, z0 + c[1]), Blocks.SEA_LANTERN.getDefaultState(), 2);
        }
        // Moqueta roja de gala por todo el salón
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                BlockPos p = new BlockPos(x0 + i, y, z0 + j);
                if (w.isAir(p) && (i + j) % 2 == 0) w.setBlockState(p, Blocks.RED_CARPET.getDefaultState(), 2);
            }
        }
        if (cx == 0 && cz == 0) {
            // Estrado del jefe final
            for (int i = 2; i <= 13; i++) {
                for (int j = 2; j <= 13; j++) {
                    w.setBlockState(new BlockPos(x0 + i, y, z0 + j), Blocks.POLISHED_BLACKSTONE.getDefaultState(), 2);
                    w.setBlockState(new BlockPos(x0 + i, y + 1, z0 + j), Blocks.AIR.getDefaultState(), 2);
                    if (i >= 4 && i <= 11 && j >= 4 && j <= 11) {
                        w.setBlockState(new BlockPos(x0 + i, y + 1, z0 + j), Blocks.POLISHED_BLACKSTONE_SLAB.getDefaultState(), 2);
                    }
                }
            }
            w.setBlockState(new BlockPos(x0 + 8, y + 2, z0 + 8), Blocks.LECTERN.getDefaultState(), 2);
            for (int[] c : new int[][]{{2, 2}, {2, 13}, {13, 2}, {13, 13}}) {
                w.setBlockState(new BlockPos(x0 + c[0], techo, z0 + c[1]), Blocks.SEA_LANTERN.getDefaultState(), 2);
            }
        }
    }
}

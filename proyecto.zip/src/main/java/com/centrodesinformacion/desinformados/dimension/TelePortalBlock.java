package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * La tele gigante del spawn (4x4 bloques). Muestra estática; cuando se rompe con
 * /desinfo portal tele romper, la pantalla se vuelve un vórtice y al entrar te lleva al Interior de la Tele.
 */
public class TelePortalBlock extends HorizontalFacingBlock {
    public static final MapCodec<TelePortalBlock> CODEC = createCodec(TelePortalBlock::new);
    public static final IntProperty PX = IntProperty.of("px", 0, 3);
    public static final IntProperty PY = IntProperty.of("py", 0, 3);
    public static final BooleanProperty ROTA = BooleanProperty.of("rota");
    private static final Map<UUID, Long> ESPERA = new HashMap<>();

    public TelePortalBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PX, 0).with(PY, 0).with(ROTA, false));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PX, PY, ROTA);
    }

    private static boolean esPantalla(BlockState s) {
        return s.get(PX) <= 2 && s.get(PY) >= 1;
    }

    private static BlockPos origen(BlockState s, BlockPos pos) {
        Direction derecha = s.get(FACING).rotateYCounterclockwise();
        return pos.offset(derecha, -s.get(PX)).down(s.get(PY));
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction facing = ctx.getHorizontalPlayerFacing().getOpposite();
        Direction derecha = facing.rotateYCounterclockwise();
        World w = ctx.getWorld();
        BlockPos o = ctx.getBlockPos();
        for (int px = 0; px < 4; px++) {
            for (int py = 0; py < 4; py++) {
                if ((px > 0 || py > 0) && !w.getBlockState(o.offset(derecha, px).up(py)).canReplace(ctx)) return null;
            }
        }
        return getDefaultState().with(FACING, facing);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        Direction derecha = state.get(FACING).rotateYCounterclockwise();
        for (int px = 0; px < 4; px++) {
            for (int py = 0; py < 4; py++) {
                if (px == 0 && py == 0) continue;
                world.setBlockState(pos.offset(derecha, px).up(py), state.with(PX, px).with(PY, py), Block.NOTIFY_ALL);
            }
        }
        if (!world.isClient() && world.getServer() != null) EstadoServidor.get(world.getServer()).agregarTelePortal(pos.asLong());
    }

    /** Si se quita una parte, desaparece la tele entera. */
    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this)) {
            BlockPos o = origen(state, pos);
            Direction derecha = state.get(FACING).rotateYCounterclockwise();
            for (int px = 0; px < 4; px++) {
                for (int py = 0; py < 4; py++) {
                    BlockPos q = o.offset(derecha, px).up(py);
                    if (!q.equals(pos) && world.getBlockState(q).isOf(this)) {
                        world.setBlockState(q, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
                    }
                }
            }
            if (!world.isClient() && world.getServer() != null) EstadoServidor.get(world.getServer()).quitarTelePortal(o.asLong());
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return state.get(ROTA) && esPantalla(state) ? VoxelShapes.empty() : VoxelShapes.fullCube();
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world.isClient() || !state.get(ROTA) || !esPantalla(state) || !(entity instanceof ServerPlayerEntity p)) return;
        long ahora = world.getTime();
        if (ahora - ESPERA.getOrDefault(p.getUuid(), -100L) < 60) return;
        ESPERA.put(p.getUuid(), ahora);
        Dimensiones.entrarTele(p);
    }
}

package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.EstadoServidor;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * La tele gigante del spawn: un televisor de 5x5x5. El frente (5x5 bloques: pantalla de 4x4, panel a la derecha y base abajo)
 * tiene relieve (marco plateado, perillas y placas de latón); detrás va el cuerpo (TeleCuerpoBlock): mueble de madera,
 * el tubo que se estrecha con rejillas y la antena encima. Muestra estática; cuando se rompe con
 * /desinfo portal tele romper, la pantalla se vuelve un vórtice y al entrar te lleva al Interior de la Tele.
 */
public class TelePortalBlock extends HorizontalFacingBlock {
    public static final MapCodec<TelePortalBlock> CODEC = createCodec(TelePortalBlock::new);
    public static final IntProperty PX = IntProperty.of("px", 0, 4);
    public static final IntProperty PY = IntProperty.of("py", 0, 4);
    public static final BooleanProperty ROTA = BooleanProperty.of("rota");
    public static final int TAM = 5;
    private static final Map<UUID, Long> ESPERA = new HashMap<>();
    /** true mientras se está quitando la tele entera (para que las piezas no se llamen unas a otras). */
    static boolean quitando = false;

    /** Una pieza del cuerpo: PX derecha, PY arriba, PZ hacia atrás. */
    public record Pieza(int px, int py, int pz, TeleCuerpoBlock.Parte parte) {}

    /** El cuerpo de 5x5x4 detrás del frente: 2 capas de mueble de madera, el tubo y el fondo con rejillas, y la antena encima. */
    public static final java.util.List<Pieza> CUERPO = crearCuerpo();

    private static java.util.List<Pieza> crearCuerpo() {
        java.util.List<Pieza> l = new java.util.ArrayList<>();
        for (int pz = 1; pz <= 2; pz++)
            for (int px = 0; px < TAM; px++) for (int py = 0; py < TAM; py++) l.add(new Pieza(px, py, pz, TeleCuerpoBlock.Parte.MADERA));
        for (int px = 0; px < TAM; px++) for (int py = 1; py < TAM; py++) l.add(new Pieza(px, py, 3, TeleCuerpoBlock.Parte.TUBO));
        for (int px = 1; px <= 3; px++) for (int py = 1; py <= 3; py++) l.add(new Pieza(px, py, 4, TeleCuerpoBlock.Parte.REJILLA));
        l.add(new Pieza(2, TAM, 2, TeleCuerpoBlock.Parte.ANTENA));
        return java.util.List.copyOf(l);
    }

    public static BlockPos posicion(BlockPos origen, Direction facing, Pieza p) {
        return origen.offset(facing.rotateYCounterclockwise(), p.px()).up(p.py()).offset(facing.getOpposite(), p.pz());
    }

    /** Pone el cuerpo detrás del frente (soloLibre: solo donde haya aire o algo reemplazable, para las teles ya puestas). */
    public static void construirCuerpo(World world, BlockPos origen, Direction facing, boolean soloLibre) {
        for (Pieza p : CUERPO) {
            BlockPos q = posicion(origen, facing, p);
            if (soloLibre && !world.getBlockState(q).isReplaceable()) continue;
            world.setBlockState(q, com.centrodesinformacion.desinformados.ModBloques.TELE_CUERPO.getDefaultState()
                    .with(TeleCuerpoBlock.FACING, facing).with(TeleCuerpoBlock.PARTE, p.parte())
                    .with(TeleCuerpoBlock.PX, p.px()).with(TeleCuerpoBlock.PY, p.py()).with(TeleCuerpoBlock.PZ, p.pz()), Block.NOTIFY_ALL);
        }
    }

    private static void quitarCuerpo(World world, BlockPos origen, Direction facing) {
        for (Pieza p : CUERPO) {
            BlockPos q = posicion(origen, facing, p);
            if (world.getBlockState(q).getBlock() instanceof TeleCuerpoBlock)
                world.setBlockState(q, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
        }
    }

    /** Las teles que ya estaban puestas (de antes de tener cuerpo) lo reciben al arrancar el servidor. */
    public static void asegurarCuerpos(net.minecraft.server.MinecraftServer server) {
        net.minecraft.server.world.ServerWorld w = server.getOverworld();
        for (long l : EstadoServidor.get(server).getTelesPortal()) {
            BlockPos o = BlockPos.fromLong(l);
            w.getChunk(o);
            BlockState b = w.getBlockState(o);
            if (!(b.getBlock() instanceof TelePortalBlock) || b.get(PX) != 0 || b.get(PY) != 0) continue;
            Pieza primera = CUERPO.get(0);
            if (w.getBlockState(posicion(o, b.get(FACING), primera)).getBlock() instanceof TeleCuerpoBlock) continue;   // ya lo tiene
            construirCuerpo(w, o, b.get(FACING), true);
        }
    }

    public TelePortalBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(PX, 0).with(PY, 0).with(ROTA, false));
    }

    @Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PX, PY, ROTA);
    }

    private static boolean esPantalla(BlockState s) {
        return s.get(PX) <= TAM - 2 && s.get(PY) >= 1;
    }

    private static BlockPos origen(BlockState s, BlockPos pos) {
        Direction derecha = s.get(FACING).rotateYCounterclockwise();
        return pos.offset(derecha, -s.get(PX)).down(s.get(PY));
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction facing = ctx.getHorizontalPlayerFacing().getOpposite();
        Direction derecha = facing.rotateYCounterclockwise();
        World w = ctx.getWorld();
        BlockPos o = ctx.getBlockPos();
        for (int px = 0; px < TAM; px++) {
            for (int py = 0; py < TAM; py++) {
                if ((px > 0 || py > 0) && !w.getBlockState(o.offset(derecha, px).up(py)).canReplace(ctx)) return null;
            }
        }
        for (Pieza p : CUERPO) if (!w.getBlockState(posicion(o, facing, p)).canReplace(ctx)) return null;   // hueco para el cuerpo (5 de fondo)
        return getDefaultState().with(FACING, facing);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        Direction derecha = state.get(FACING).rotateYCounterclockwise();
        for (int px = 0; px < TAM; px++) {
            for (int py = 0; py < TAM; py++) {
                if (px == 0 && py == 0) continue;
                world.setBlockState(pos.offset(derecha, px).up(py), state.with(PX, px).with(PY, py), Block.NOTIFY_ALL);
            }
        }
        construirCuerpo(world, pos, state.get(FACING), false);
        if (!world.isClient() && world.getServer() != null) EstadoServidor.get(world.getServer()).agregarTelePortal(pos.asLong());
    }

    /** Si se quita una parte, desaparece la tele entera. */
    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState nuevo, boolean moved) {
        if (!nuevo.isOf(this) && !quitando) {
            BlockPos o = origen(state, pos);
            Direction derecha = state.get(FACING).rotateYCounterclockwise();
            quitando = true;
            try {
                for (int px = 0; px < TAM; px++) {
                    for (int py = 0; py < TAM; py++) {
                        BlockPos q = o.offset(derecha, px).up(py);
                        if (!q.equals(pos) && world.getBlockState(q).isOf(this)) {
                            world.setBlockState(q, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
                        }
                    }
                }
                quitarCuerpo(world, o, state.get(FACING));
            } finally {
                quitando = false;
            }
            if (!world.isClient() && world.getServer() != null) EstadoServidor.get(world.getServer()).quitarTelePortal(o.asLong());
        }
        super.onStateReplaced(state, world, pos, nuevo, moved);
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        return state.get(ROTA) && esPantalla(state) ? VoxelShapes.empty() : VoxelShapes.fullCube();
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world.isClient() || !state.get(ROTA) || !esPantalla(state) || !(entity instanceof ServerPlayerEntity p)) return;
        long ahora = world.getTime();
        if (ahora - ESPERA.getOrDefault(p.getUuid(), -100L) < 60) return;
        ESPERA.put(p.getUuid(), ahora);
        // al volver apareces DELANTE de la tele (dentro de la pantalla te volvería a tragar)
        Direction f = state.get(FACING);
        BlockPos delante = origen(state, pos).offset(f.rotateYCounterclockwise(), 2).offset(f, 2);
        if (!world.getBlockState(delante).getCollisionShape(world, delante).isEmpty()
                || !world.getBlockState(delante.up()).getCollisionShape(world, delante.up()).isEmpty())
            delante = world.getTopPosition(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, delante);
        Dimensiones.entrarTele(p, net.minecraft.util.math.Vec3d.ofBottomCenter(delante));
    }

    /** Al volver de la Tele: la misma espera que al entrar, para que no te trague otra vez nada más llegar. */
    static void darEspera(ServerPlayerEntity p, long ahora) {
        ESPERA.put(p.getUuid(), ahora);
    }
}

package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.ModBloques;
import com.mojang.serialization.Codec;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/**
 * Pocito de tinta en la superficie de la Libreta. Solo lee y escribe bloques cercanos
 * (no consulta biomas), así que no rompe la generación de chunks como el "lake" de vanilla.
 */
public class PozoTintaFeature extends Feature<DefaultFeatureConfig> {
    public PozoTintaFeature(Codec<DefaultFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        Random r = ctx.getRandom();
        BlockPos o = ctx.getOrigin();
        int y = o.getY() - 1;                       // bloque del suelo
        if (y <= w.getBottomY() + 5) return false;
        int rx = 2 + r.nextInt(3), rz = 2 + r.nextInt(3);
        int hondo = 1 + r.nextInt(3);

        // 1) Comprobar: suelo sólido en todo el pozo y en el borde (para que la tinta no se escape)
        for (int dx = -rx - 1; dx <= rx + 1; dx++) {
            for (int dz = -rz - 1; dz <= rz + 1; dz++) {
                double d = (dx * dx) / (double) ((rx + 1) * (rx + 1)) + (dz * dz) / (double) ((rz + 1) * (rz + 1));
                if (d > 1.0) continue;
                BlockPos p = new BlockPos(o.getX() + dx, y, o.getZ() + dz);
                BlockState s = w.getBlockState(p);
                if (!s.isSolidBlock(w, p) || !w.getFluidState(p).isEmpty()) return false;
                if (!w.getBlockState(p.up()).isAir() && !w.getBlockState(p.up()).isReplaceable()) return false;
            }
        }
        // 2) Cavar la hondonada y llenarla de tinta
        BlockState tinta = ModBloques.TINTA.getDefaultState();
        for (int dx = -rx; dx <= rx; dx++) {
            for (int dz = -rz; dz <= rz; dz++) {
                double d = (dx * dx) / (double) (rx * rx) + (dz * dz) / (double) (rz * rz);
                if (d > 1.0) continue;
                int prof = Math.max(1, (int) Math.round(hondo * (1.0 - d) + 0.4));
                for (int k = 0; k < prof; k++) {
                    BlockPos p = new BlockPos(o.getX() + dx, y - k, o.getZ() + dz);
                    w.setBlockState(p, tinta, 2);
                }
                // fondo de arena de papel
                BlockPos fondo = new BlockPos(o.getX() + dx, y - prof, o.getZ() + dz);
                if (w.getBlockState(fondo).isSolidBlock(w, fondo)) w.setBlockState(fondo, ModBloques.ARENA_PAPEL.getDefaultState(), 2);
                BlockPos arriba = new BlockPos(o.getX() + dx, y + 1, o.getZ() + dz);
                if (!w.getBlockState(arriba).isAir()) w.setBlockState(arriba, Blocks.AIR.getDefaultState(), 2);
            }
        }
        return true;
    }
}

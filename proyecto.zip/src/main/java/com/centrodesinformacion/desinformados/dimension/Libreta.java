package com.centrodesinformacion.desinformados.dimension;

import com.centrodesinformacion.desinformados.Tareas;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import com.centrodesinformacion.desinformados.network.ManchaPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Map;

/**
 * La Libreta del Becario. Los mobs normales que aparecen ahí se convierten en su versión "dibujada".
 * Solo hay mobs hostiles, el agua es tinta y todo está hecho de papel.
 */
public class Libreta {
    private static final Map<EntityType<?>, EntityType<? extends MobEntity>> DIBUJOS = Map.of(
            EntityType.ZOMBIE, ModEntidades.ZOMBIE_DIBUJO,
            EntityType.SKELETON, ModEntidades.ESQUELETO_DIBUJO,
            EntityType.CREEPER, ModEntidades.CREEPER_DIBUJO,
            EntityType.SPIDER, ModEntidades.ARANA_DIBUJO);

    /** Cuánto dura la mancha de tinta en la pantalla después de salir (ticks). */
    public static final int TICKS_MANCHA = 160;

    public static void registrar() {
        // Los minerales (solo Estática y Garatita) y los árboles de papel vienen en los biomas de la Libreta (datapack).

        // Tinta: si te toca, te mancha los bordes de la pantalla
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 5 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator() || !tocaTinta(p)) continue;
                if (ServerPlayNetworking.canSend(p, ManchaPayload.ID)) ServerPlayNetworking.send(p, new ManchaPayload(TICKS_MANCHA));
            }
        });

        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (mundo.getRegistryKey() != Dimensiones.LIBRETA) return;
            EntityType<? extends MobEntity> dibujo = DIBUJOS.get(entidad.getType());
            if (dibujo != null) Tareas.programar(1, () -> convertir(entidad, mundo, dibujo));
        });
    }

    public static boolean tocaTinta(Entity e) {
        Box caja = e.getBoundingBox().contract(0.001);
        for (BlockPos pos : BlockPos.iterate(BlockPos.ofFloored(caja.minX, caja.minY, caja.minZ),
                BlockPos.ofFloored(caja.maxX, caja.maxY, caja.maxZ))) {
            var fluido = e.getWorld().getFluidState(pos);
            if (ModFluidos.esTinta(fluido) && pos.getY() + fluido.getHeight(e.getWorld(), pos) >= caja.minY) return true;
        }
        return false;
    }

    private static void convertir(Entity viejo, ServerWorld mundo, EntityType<? extends MobEntity> tipo) {
        if (viejo.isRemoved()) return;
        MobEntity nuevo = tipo.create(mundo);
        if (nuevo == null) return;
        nuevo.refreshPositionAndAngles(viejo.getX(), viejo.getY(), viejo.getZ(), viejo.getYaw(), viejo.getPitch());
        if (viejo instanceof MobEntity m) {
            nuevo.setBaby(m.isBaby());
            if (m.isPersistent()) nuevo.setPersistent();
        }
        nuevo.initialize(mundo, mundo.getLocalDifficulty(nuevo.getBlockPos()), SpawnReason.CONVERSION, null);
        if (viejo instanceof MobEntity m) {
            nuevo.setBaby(m.isBaby());
            for (net.minecraft.entity.EquipmentSlot s : net.minecraft.entity.EquipmentSlot.values()) nuevo.equipStack(s, m.getEquippedStack(s).copy());
        }
        viejo.discard();
        mundo.spawnEntity(nuevo);
    }
}

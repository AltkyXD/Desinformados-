package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.MisionesPayload;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Misiones del Reactor. Diarias (para pasar el día hace falta que el 75% las complete) y secundarias.
 * Se activan con /desinfo mision diaria|secundaria <id>. Los jugadores las ven con la tecla L.
 */
public class Misiones {
    public record Mision(String id, String titulo, String descripcion, Predicate<ServerPlayerEntity> cumple) {}

    public static final Map<String, Mision> TODAS = new LinkedHashMap<>();
    public static final double PORCENTAJE_DIA = 0.75;

    private static void mision(String id, String titulo, String descripcion, Predicate<ServerPlayerEntity> cumple) {
        TODAS.put(id, new Mision(id, titulo, descripcion, cumple));
    }

    static {
        // ========================= LISTA DE MISIONES =========================
        mision("full_hierro", "Full hierro", "Equípate la armadura de hierro completa: casco, peto, pantalones y botas.",
                p -> p.getEquippedStack(EquipmentSlot.HEAD).isOf(Items.IRON_HELMET)
                        && p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.IRON_CHESTPLATE)
                        && p.getEquippedStack(EquipmentSlot.LEGS).isOf(Items.IRON_LEGGINGS)
                        && p.getEquippedStack(EquipmentSlot.FEET).isOf(Items.IRON_BOOTS));
    }

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            comprobar(server);
            if (server.getTicks() % 40 == 0) sincronizar(server);
        });
    }

    private static void comprobar(MinecraftServer server) {
        EstadoServidor estado = EstadoServidor.get(server);
        for (String id : estado.getMisionesActivas().keySet()) {
            Mision m = TODAS.get(id);
            if (m == null) continue;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator() || estado.misionCompletada(id, p.getUuid())) continue;
                if (m.cumple().test(p)) completar(server, m, p, estado);
            }
        }
    }

    private static void completar(MinecraftServer server, Mision m, ServerPlayerEntity p, EstadoServidor estado) {
        estado.completarMision(m.id(), p.getUuid());
        boolean diaria = "diaria".equals(estado.getMisionesActivas().get(m.id()));
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 40, 10));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(m.titulo()).formatted(Formatting.WHITE)));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("¡MISIÓN COMPLETADA!").formatted(diaria ? Formatting.GOLD : Formatting.AQUA, Formatting.BOLD)));
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1f, 1f);
        server.getPlayerManager().broadcast(Text.literal(p.getGameProfile().getName() + " ha completado la misión ")
                .formatted(Formatting.GRAY).append(Text.literal(m.titulo()).formatted(diaria ? Formatting.GOLD : Formatting.AQUA)), false);
        if (diaria) {
            int total = jugadoresVivos(server);
            int hechos = completadosEnLinea(server, m.id());
            if (total > 0 && hechos >= Math.ceil(total * PORCENTAJE_DIA)) {
                server.getPlayerManager().broadcast(Text.literal("¡Misión diaria \"" + m.titulo() + "\" superada por el grupo! (" + hechos + "/" + total + ")")
                        .formatted(Formatting.GREEN, Formatting.BOLD), false);
            }
        }
        sincronizar(server);
    }

    private static int jugadoresVivos(MinecraftServer server) {
        return (int) server.getPlayerManager().getPlayerList().stream().filter(p -> !p.isSpectator()).count();
    }

    private static int completadosEnLinea(MinecraftServer server, String id) {
        EstadoServidor estado = EstadoServidor.get(server);
        return (int) server.getPlayerManager().getPlayerList().stream()
                .filter(p -> !p.isSpectator() && estado.misionCompletada(id, p.getUuid())).count();
    }

    public static void sincronizar(MinecraftServer server) {
        EstadoServidor estado = EstadoServidor.get(server);
        int total = jugadoresVivos(server);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!ServerPlayNetworking.canSend(p, MisionesPayload.ID)) continue;
            JsonArray lista = new JsonArray();
            for (var e : estado.getMisionesActivas().entrySet()) {
                Mision m = TODAS.get(e.getKey());
                if (m == null) continue;
                JsonObject o = new JsonObject();
                o.addProperty("tipo", e.getValue());
                o.addProperty("titulo", m.titulo());
                o.addProperty("descripcion", m.descripcion());
                o.addProperty("hecha", estado.misionCompletada(m.id(), p.getUuid()));
                o.addProperty("grupo", completadosEnLinea(server, m.id()));
                o.addProperty("total", total);
                lista.add(o);
            }
            ServerPlayNetworking.send(p, new MisionesPayload(lista.toString()));
        }
    }

    public static List<String> ids() {
        return List.copyOf(TODAS.keySet());
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.MisionesPayload;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Misiones (tecla U).
 * - PRINCIPALES: una cadena. Se ve la actual y las ya superadas; la siguiente se revela cuando la completa el 75 % de los jugadores
 *   de la serie (redondeando hacia arriba: con 5 jugadores, 4). Cada uno cobra su premio al completarla. Al superarla el grupo,
 *   se desbloquea lo que toque (teles moradas: diamante, Nether, End, recetas...). Las "de grupo" (el dragón, el Centro de Estática
 *   y la Desinformación Pura) basta con que las haga uno y el premio es para todos.
 * - SECUNDARIAS: cada jugador las hace a su ritmo, todas disponibles desde el principio.
 * Cuando se acaban las principales y la tele está rota, el menú sale "fuera de servicio".
 */
public class Misiones {
    public enum Clase { PRINCIPAL, SECUNDARIA }

    /** Lo que recibe cada jugador (y cómo se lee en el menú). */
    public record Premio(String texto, Consumer<ServerPlayerEntity> dar) {}

    /**
     * progreso: {hecho, objetivo} para la barra (null = sí/no). alSuperar: lo que se desbloquea cuando la supera el grupo.
     */
    public record Mision(String id, Clase clase, String titulo, String descripcion, Premio premio, boolean deGrupo,
                         Predicate<ServerPlayerEntity> cumple, Function<ServerPlayerEntity, int[]> progreso,
                         Consumer<MinecraftServer> alSuperar) {}

    public static final List<Mision> PRINCIPALES = new ArrayList<>();
    public static final List<Mision> SECUNDARIAS = new ArrayList<>();
    public static final Map<String, Mision> TODAS = new LinkedHashMap<>();
    public static final double PORCENTAJE = 0.75;
    public static final String SUPERADA = "sys:mision_superada:";
    /** La Tele Gigante está rota (lo pone Dimensiones al romperla). */
    public static final String TELE_ROTA = "sys:tele_rota";
    public static final int TOTAL_GATOS = com.centrodesinformacion.desinformados.entidad.GatoCuboEntity.MAX_TIPO;   // todos menos el becario

    // ------------------------------------------------------------------ premios

    private static Premio premio(int rumores, int totems, int rojos, int azules, int pastillas) {
        List<String> partes = new ArrayList<>();
        if (rumores > 0) partes.add(rumores + " Rumores");
        if (totems > 0) partes.add(totems + (totems == 1 ? " tótem" : " tótems"));
        if (rojos > 0) partes.add(rojos + (rojos == 1 ? " corazón rojo" : " corazones rojos"));
        if (azules > 0) partes.add(azules + (azules == 1 ? " corazón azul" : " corazones azules"));
        if (pastillas > 0) partes.add(pastillas + (pastillas == 1 ? " Pastilla anti-Endcer" : " Pastillas anti-Endcer"));
        return new Premio(String.join(", ", partes), p -> {
            if (rumores > 0) Tragamonedas.darRumores(p, rumores);
            if (totems > 0) Tragamonedas.dar(p, new ItemStack(Items.TOTEM_OF_UNDYING, totems));
            if (rojos > 0) Tragamonedas.dar(p, new ItemStack(ModItems.CORAZON_ROJO, rojos));
            if (azules > 0) Tragamonedas.dar(p, new ItemStack(ModItems.CORAZON_ALMA, azules));
            if (pastillas > 0) Tragamonedas.dar(p, new ItemStack(ModItems.PASTILLA_ANTI_ENDCER, pastillas));
        });
    }

    private static Premio rumores(int n) {
        return premio(n, 0, 0, 0, 0);
    }

    // ------------------------------------------------------------------ comprobaciones

    private static int piezas(ServerPlayerEntity p, Item casco, Item peto, Item pantalones, Item botas) {
        int n = 0;
        if (p.getEquippedStack(EquipmentSlot.HEAD).isOf(casco)) n++;
        if (p.getEquippedStack(EquipmentSlot.CHEST).isOf(peto)) n++;
        if (p.getEquippedStack(EquipmentSlot.LEGS).isOf(pantalones)) n++;
        if (p.getEquippedStack(EquipmentSlot.FEET).isOf(botas)) n++;
        return n;
    }

    private static int hierro(ServerPlayerEntity p) { return piezas(p, Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS); }
    private static int diamante(ServerPlayerEntity p) { return piezas(p, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS); }
    private static int netherite(ServerPlayerEntity p) { return piezas(p, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS); }
    private static int garatita(ServerPlayerEntity p) { return piezas(p, ModGaratita.CASCO, ModGaratita.PETO, ModGaratita.PANTALONES, ModGaratita.BOTAS); }

    private static boolean lleva(ServerPlayerEntity p, Item... items) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) for (Item it : items) if (inv.getStack(i).isOf(it)) return true;
        return false;
    }

    /** Lo ha fabricado alguna vez (o lo lleva encima). */
    private static boolean fabrico(ServerPlayerEntity p, Item item) {
        return p.getStatHandler().getStat(Stats.CRAFTED, item) > 0 || lleva(p, item);
    }

    private static boolean dragonMuerto(MinecraftServer s) {
        ServerWorld end = s.getWorld(World.END);
        return end != null && end.getEnderDragonFight() != null && end.getEnderDragonFight().hasPreviouslyKilled();
    }

    private static int stat(ServerPlayerEntity p, Identifier custom) {
        return p.getStatHandler().getStat(Stats.CUSTOM, custom);
    }

    private static int matados(ServerPlayerEntity p, EntityType<?>... tipos) {
        int n = 0;
        for (EntityType<?> t : tipos) n += p.getStatHandler().getStat(Stats.KILLED, t);
        return n;
    }

    private static int minados(ServerPlayerEntity p, Block... bloques) {
        int n = 0;
        for (Block b : bloques) n += p.getStatHandler().getStat(Stats.MINED, b);
        return n;
    }

    private static List<Item> comidas = null;
    private static List<Block> troncos = null;
    private static List<EntityType<?>> mobsDelMod = null;

    private static int comido(ServerPlayerEntity p) {
        if (comidas == null) comidas = Registries.ITEM.stream().filter(i -> i.getComponents().contains(DataComponentTypes.FOOD)).toList();
        int n = 0;
        for (Item i : comidas) n += p.getStatHandler().getStat(Stats.USED, i);
        return n;
    }

    private static int talados(ServerPlayerEntity p) {
        if (troncos == null) troncos = Registries.BLOCK.stream().filter(b -> b.getDefaultState().isIn(BlockTags.LOGS)).toList();
        int n = 0;
        for (Block b : troncos) n += p.getStatHandler().getStat(Stats.MINED, b);
        return n;
    }

    private static int matadosDelMod(ServerPlayerEntity p) {
        if (mobsDelMod == null) {
            List<EntityType<?>> l = new ArrayList<>();
            for (EntityType<?> t : Registries.ENTITY_TYPE) {
                Identifier id = Registries.ENTITY_TYPE.getId(t);
                if (id.getNamespace().equals(Desinformados.MOD_ID) && !id.getPath().equals("gato_cubo")) l.add(t);
            }
            mobsDelMod = l;
        }
        int n = 0;
        for (EntityType<?> t : mobsDelMod) n += p.getStatHandler().getStat(Stats.KILLED, t);
        return n;
    }

    private static int contador(ServerPlayerEntity p, String clave) {
        return EstadoServidor.get(p.getServer()).getContador(p.getUuid(), clave);
    }

    // ------------------------------------------------------------------ las misiones

    private static void principal(String id, String titulo, String desc, Premio premio, Function<ServerPlayerEntity, int[]> progreso,
                                  Consumer<MinecraftServer> alSuperar) {
        Mision m = new Mision(id, Clase.PRINCIPAL, titulo, desc, premio, false, p -> { int[] v = progreso.apply(p); return v[0] >= v[1]; },
                progreso, alSuperar);
        PRINCIPALES.add(m);
        TODAS.put(id, m);
    }

    private static void deGrupo(String id, String titulo, String desc, Premio premio, Predicate<ServerPlayerEntity> cumple,
                                Consumer<MinecraftServer> alSuperar) {
        Mision m = new Mision(id, Clase.PRINCIPAL, titulo, desc, premio, true, cumple, null, alSuperar);
        PRINCIPALES.add(m);
        TODAS.put(id, m);
    }

    /** Secundaria con contador: hecho = valor, objetivo = meta. */
    private static void secundaria(String id, String titulo, String desc, int rumores, int meta, Function<ServerPlayerEntity, Integer> valor) {
        Mision m = new Mision(id, Clase.SECUNDARIA, titulo, desc, rumores(rumores), false, p -> valor.apply(p) >= meta,
                p -> new int[]{Math.min(meta, valor.apply(p)), meta}, null);
        SECUNDARIAS.add(m);
        TODAS.put(id, m);
    }

    static {
        // ============================== PRINCIPALES ==============================
        principal("pieza_hierro", "Una pieza de hierro", "Ponte al menos una pieza de armadura de hierro.",
                rumores(10), p -> new int[]{Math.min(1, hierro(p)), 1}, null);
        principal("full_hierro", "Full hierro", "Equípate la armadura de hierro completa: casco, peto, pantalones y botas.",
                rumores(30), p -> new int[]{hierro(p), 4}, s -> morada(s, "diamante"));
        principal("pieza_diamante", "Una pieza de diamante", "Ponte al menos una pieza de armadura de diamante.",
                rumores(20), p -> new int[]{Math.min(1, diamante(p)), 1}, null);
        principal("full_diamante", "Full diamante", "Equípate la armadura de diamante completa.",
                premio(30, 1, 0, 0, 0), p -> new int[]{diamante(p), 4}, s -> morada(s, "nether"));
        principal("pieza_netherite", "Una pieza de netherite", "Ponte al menos una pieza de armadura de netherite.",
                premio(30, 0, 5, 0, 0), p -> new int[]{Math.min(1, netherite(p)), 1}, null);
        principal("full_netherite", "Full netherite", "Equípate la armadura de netherite completa.",
                premio(150, 1, 0, 0, 0), p -> new int[]{netherite(p), 4}, s -> morada(s, "end"));
        deGrupo("dragon", "Matar al dragón", "Acabad con el Ender Dragon. Da igual quién lo haga: solo importa que esté muerto. El premio es para todos.",
                premio(120, 1, 0, 0, 3), p -> dragonMuerto(p.getServer()), Endcer::alMorirElDragon);
        principal("pieza_garatita", "Una pieza de Garatita", "Craftea una pieza de armadura de Garatita (con tenerla encima basta).",
                premio(200, 3, 0, 0, 0), p -> new int[]{garatita(p) > 0 || lleva(p, ModGaratita.CASCO, ModGaratita.PETO, ModGaratita.PANTALONES, ModGaratita.BOTAS) ? 1 : 0, 1},
                null);
        principal("full_garatita", "Full Garatita", "Equípate la armadura de Garatita completa.",
                premio(240, 0, 10, 0, 0), p -> new int[]{garatita(p), 4}, s -> morada(s, "receta_centro_estatica"));
        deGrupo("centro_estatica", "Centro de Estática", "Fabricad un Centro de Estática. Con que lo haga uno, el premio es para todos.",
                premio(250, 0, 5, 3, 0), p -> fabrico(p, ModItems.CENTRO_ESTATICA), Misiones::teleCentroEstatica);
        deGrupo("desinformacion_pura", "Desinformación Pura", "Fabricad la Desinformación Pura. Con que la haga uno, el premio es para todos.",
                premio(400, 3, 0, 0, 0), p -> fabrico(p, ModItems.CUBO_DESINFORMACION), Misiones::teleDesinformacionPura);

        // ============================== SECUNDARIAS ==============================
        secundaria("gatos", "Conoce al personal", "Habla con todos los gatos del Centro de Desinformación al menos una vez.", 10, TOTAL_GATOS,
                p -> EstadoServidor.get(p.getServer()).contarClaves(p.getUuid(), "gato:"));
        secundaria("cultivos", "Mano verde", "Cosecha al menos 10 cultivos maduros.", 10, 10, p -> contador(p, "cultivos"));
        secundaria("minar", "Picapedrero", "Mina 100 bloques (piedra, minerales... lo que se pique con pico).", 10, 100, p -> contador(p, "minados"));
        secundaria("comer", "Buen provecho", "Come 20 veces.", 10, 20, Misiones::comido);
        secundaria("pescar", "Paciencia de pescador", "Pesca 5 peces.", 15, 5, p -> stat(p, Stats.FISH_CAUGHT));
        secundaria("dormir", "Dulces sueños", "Duerme en una cama 3 veces.", 10, 3, p -> stat(p, Stats.SLEEP_IN_BED));
        secundaria("zombis", "Cazazombis", "Mata 15 zombis (de cualquier tipo).", 15, 15,
                p -> matados(p, EntityType.ZOMBIE, EntityType.ZOMBIE_VILLAGER, EntityType.HUSK, EntityType.DROWNED));
        secundaria("esqueletos", "Rompehuesos", "Mata 10 esqueletos.", 15, 10, p -> matados(p, EntityType.SKELETON, EntityType.STRAY, EntityType.BOGGED));
        secundaria("creepers", "Artificiero", "Mata 5 creepers antes de que hagan bum.", 15, 5, p -> matados(p, EntityType.CREEPER));
        secundaria("aranas", "Fumigador", "Mata 8 arañas.", 10, 8, p -> matados(p, EntityType.SPIDER, EntityType.CAVE_SPIDER));
        secundaria("endermen", "No le mires a los ojos", "Mata 3 endermen.", 20, 3, p -> matados(p, EntityType.ENDERMAN));
        secundaria("mobs_mod", "Experto en desinformación", "Mata 10 mobs de los que ha traído el Centro.", 20, 10, Misiones::matadosDelMod);
        secundaria("caminar", "Turista", "Recorre 5 km a pie.", 10, 5000,
                p -> (stat(p, Stats.WALK_ONE_CM) + stat(p, Stats.SPRINT_ONE_CM)) / 100);
        secundaria("nadar", "Sirena", "Nada 300 bloques.", 10, 300, p -> stat(p, Stats.SWIM_ONE_CM) / 100);
        secundaria("comerciar", "Regateo", "Comercia 5 veces con aldeanos.", 15, 5, p -> stat(p, Stats.TRADED_WITH_VILLAGER));
        secundaria("criar", "Cupido de granja", "Cría 5 animales.", 10, 5, p -> stat(p, Stats.ANIMALS_BRED));
        secundaria("encantar", "Abracadabra", "Encanta un objeto en la mesa de encantamientos.", 15, 1, p -> stat(p, Stats.ENCHANT_ITEM));
        secundaria("troncos", "Leñador", "Corta 64 troncos.", 10, 64, Misiones::talados);
        secundaria("hierro_mena", "Fiebre del hierro", "Mina 20 menas de hierro.", 15, 20, p -> minados(p, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE));
        secundaria("diamante_mena", "¡Diamantes!", "Mina una mena de diamante.", 15, 1, p -> minados(p, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE));
        secundaria("tragamonedas", "Probando suerte", "Juega 10 veces en las tragamonedas del casino.", 10, 10, p -> contador(p, "tragamonedas"));
        secundaria("ruleta", "Rojo o negro", "Juega 5 veces a la ruleta del casino.", 10, 5, p -> contador(p, "ruleta"));
        secundaria("dj", "Pon la música", "Pídele una canción a DJ Miaumix.", 10, 1, p -> contador(p, "dj"));
        secundaria("baile", "Rey de la pista", "Pasa 60 segundos en la pista de baile.", 10, 60, p -> contador(p, "baile"));
        secundaria("banco", "Ahorrador", "Deposita 100 Rumores en el Banco.", 10, 100, p -> contador(p, "banco"));
        secundaria("disco", "Melómano", "Pon un disco en un tocadiscos.", 10, 1, p -> stat(p, Stats.PLAY_RECORD));
        secundaria("antorchas", "Que se haga la luz", "Fabrica 64 antorchas.", 10, 64, p -> p.getStatHandler().getStat(Stats.CRAFTED, Items.TORCH));
        secundaria("pociones", "Alquimista", "Bébete 3 pociones.", 15, 3, p -> p.getStatHandler().getStat(Stats.USED, Items.POTION));
    }

    // ------------------------------------------------------------------ teles de desbloqueo

    /** Muestra la tele de un evento en morado y aplica su efecto ya (así no se pierde aunque se cierre el servidor). */
    private static void morada(MinecraftServer s, String eventoId) {
        Eventos.Evento ev = Eventos.TODOS.get(eventoId);
        if (ev == null) return;
        Eventos.mostrarTele(s, "morado", ev.titulo(), ev.descripcion());
        ev.accion().accept(s);
    }

    private static void teleCentroEstatica(MinecraftServer s) {
        Eventos.mostrarTele(s, "morado", "¡El Centro de Estática está vivo!",
                "Notáis cómo zumba su energía... Podríais canalizarla hacia la Tele Gigante, pero antes hay que convertirla en un material puro. "
                        + "Nueva receta: Desinformación Pura (lingotes de netherite en las esquinas, Fragmento de Estática arriba, bloques de diamante "
                        + "a los lados, Bloque de Garatita abajo y el Centro de Estática en medio).");
        EstadoServidor e = EstadoServidor.get(s);
        e.agregarCambio("receta_desinformacion_pura");
        e.agregarCambio("receta_bloque_garatita");
        Crafteos.sincronizarTodos(s);
    }

    private static void teleDesinformacionPura(MinecraftServer s) {
        Eventos.mostrarTele(s, "morado", "¿Y si la usáis cerca de la Tele?",
                "La Desinformación Pura vibra cada vez que os acercáis a la Tele Gigante del techo del Centro. Igual deberíais usarla justo ahí... "
                        + "¿Qué podría salir mal?");
    }

    // ------------------------------------------------------------------ estado

    public static boolean superada(MinecraftServer s, Mision m) {
        return EstadoServidor.get(s).tieneCambio(SUPERADA + m.id());
    }

    /** La principal que toca ahora (PRINCIPALES.size() si ya están todas). */
    public static int actual(MinecraftServer s) {
        for (int i = 0; i < PRINCIPALES.size(); i++) if (!superada(s, PRINCIPALES.get(i))) return i;
        return PRINCIPALES.size();
    }

    public static boolean fueraDeServicio(MinecraftServer s) {
        return actual(s) >= PRINCIPALES.size() && EstadoServidor.get(s).tieneCambio(TELE_ROTA);
    }

    /** Jugadores de la serie que cuentan para el 75 % (los eliminados no cuentan). */
    private static List<UUID> serie(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        List<UUID> l = new ArrayList<>();
        for (UUID u : e.getJugadoresSerie().keySet()) if (!e.estaMuerto(u)) l.add(u);
        return l;
    }

    public static int necesarios(int total) {
        return (int) Math.ceil(total * PORCENTAJE - 1e-9);
    }

    private static int hechosDelGrupo(MinecraftServer s, Mision m) {
        EstadoServidor e = EstadoServidor.get(s);
        int n = 0;
        for (UUID u : serie(s)) if (e.misionCompletada(m.id(), u)) n++;
        return n;
    }

    private static boolean juega(ServerPlayerEntity p) {
        return !p.isSpectator() && !p.isCreative();
    }

    // ------------------------------------------------------------------ reloj

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            comprobar(server);
            if (server.getTicks() % 40 == 0) {
                sincronizar(server);
                String lista = String.join(",", EstadoServidor.get(server).getCambios());
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    if (ServerPlayNetworking.canSend(p, com.centrodesinformacion.desinformados.network.CambiosPayload.ID))
                        ServerPlayNetworking.send(p, new com.centrodesinformacion.desinformados.network.CambiosPayload(lista));
                }
            }
        });
        net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((d, acceso, entorno) -> d.register(
                net.minecraft.server.command.CommandManager.literal("desinfo").requires(src -> src.hasPermissionLevel(2))
                        .then(net.minecraft.server.command.CommandManager.literal("mision")
                                .executes(c -> estado(c.getSource()))
                                .then(net.minecraft.server.command.CommandManager.literal("superar").executes(c -> {
                                    String t = forzarActual(c.getSource().getServer());
                                    if (t == null) { c.getSource().sendError(Text.literal("No quedan misiones principales (o no hay nadie conectado).")); return 0; }
                                    c.getSource().sendFeedback(() -> Text.literal("Misión superada a la fuerza: " + t).formatted(Formatting.YELLOW), true);
                                    return 1;
                                }))
                                .then(net.minecraft.server.command.CommandManager.literal("completar")
                                        .then(net.minecraft.server.command.CommandManager.argument("jugador", net.minecraft.command.argument.EntityArgumentType.player())
                                                .then(net.minecraft.server.command.CommandManager.argument("id", com.mojang.brigadier.arguments.StringArgumentType.word())
                                                        .suggests((c, b) -> net.minecraft.command.CommandSource.suggestMatching(ids(), b))
                                                        .executes(c -> {
                                                            ServerPlayerEntity p = net.minecraft.command.argument.EntityArgumentType.getPlayer(c, "jugador");
                                                            String id = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "id");
                                                            boolean ok = completarPara(c.getSource().getServer(), p, id);
                                                            if (!ok) { c.getSource().sendError(Text.literal("No existe esa misión o ya la tenía.")); return 0; }
                                                            c.getSource().sendFeedback(() -> Text.literal("Misión " + id + " completada para " + p.getGameProfile().getName()), true);
                                                            return 1;
                                                        }))))
                                .then(net.minecraft.server.command.CommandManager.literal("reiniciar").executes(c -> {
                                    reiniciar(c.getSource().getServer());
                                    c.getSource().sendFeedback(() -> Text.literal("Misiones reiniciadas: vuelve a empezar la cadena (lo ya desbloqueado se queda).")
                                            .formatted(Formatting.YELLOW), true);
                                    return 1;
                                }))
                                .then(net.minecraft.server.command.CommandManager.literal("jugadores")
                                        .executes(c -> {
                                            var e = EstadoServidor.get(c.getSource().getServer());
                                            String l = e.getJugadoresSerie().isEmpty() ? "nadie" : String.join(", ", e.getJugadoresSerie().values());
                                            c.getSource().sendFeedback(() -> Text.literal("Jugadores de la serie (" + e.getJugadoresSerie().size() + "): " + l), false);
                                            return 1;
                                        })
                                        .then(net.minecraft.server.command.CommandManager.literal("quitar")
                                                .then(net.minecraft.server.command.CommandManager.argument("nombre", com.mojang.brigadier.arguments.StringArgumentType.word())
                                                        .suggests((c, b) -> net.minecraft.command.CommandSource.suggestMatching(
                                                                EstadoServidor.get(c.getSource().getServer()).getJugadoresSerie().values(), b))
                                                        .executes(c -> {
                                                            String n = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "nombre");
                                                            boolean ok = EstadoServidor.get(c.getSource().getServer()).quitarJugadorSerie(n);
                                                            if (!ok) { c.getSource().sendError(Text.literal("Ese jugador no estaba en la lista.")); return 0; }
                                                            c.getSource().sendFeedback(() -> Text.literal(n + " ya no cuenta para el 75 % (si vuelve a jugar en supervivencia, vuelve a contar).")
                                                                    .formatted(Formatting.YELLOW), true);
                                                            return 1;
                                                        })))))));
        // cultivos cosechados y bloques minados (para las secundarias)
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity p) || !juega(p)) return;
            EstadoServidor e = EstadoServidor.get(p.getServer());
            if (state.getBlock() instanceof CropBlock cultivo && cultivo.isMature(state)) e.sumarContador(p.getUuid(), "cultivos", 1);
            if (state.isIn(BlockTags.PICKAXE_MINEABLE)) e.sumarContador(p.getUuid(), "minados", 1);
        });
    }

    /** Para las secundarias con contador propio (tragamonedas, ruleta, DJ, banco...). */
    public static void sumar(ServerPlayerEntity p, String clave, int n) {
        if (p.getServer() == null || !juega(p)) return;
        EstadoServidor.get(p.getServer()).sumarContador(p.getUuid(), clave, n);
    }

    /** Ha hablado con un gato (cuenta cada tipo una vez). */
    public static void hablarGato(ServerPlayerEntity p, int tipo) {
        if (p.getServer() == null || tipo <= 0) return;
        EstadoServidor e = EstadoServidor.get(p.getServer());
        if (e.getContador(p.getUuid(), "gato:" + tipo) == 0) e.setContador(p.getUuid(), "gato:" + tipo, 1);
    }

    private static void comprobar(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        List<ServerPlayerEntity> jugando = new ArrayList<>();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            if (!juega(p)) continue;
            jugando.add(p);
            e.registrarJugador(p.getUuid(), p.getGameProfile().getName());
            // premios de grupo que se ganaron mientras no estaba
            for (Mision m : PRINCIPALES) {
                if (e.quitarPremioPendiente(m.id() + "|" + p.getUuid())) entregar(p, m, true);
            }
        }
        // baile: un segundo más por cada jugador encima de la pista
        for (ServerPlayerEntity p : jugando) {
            if (p.getWorld().getBlockState(p.getBlockPos().down()).isOf(ModBloques.PISTA_BAILE)) e.sumarContador(p.getUuid(), "baile", 1);
        }
        int actual = actual(s);
        for (int i = 0; i <= Math.min(actual, PRINCIPALES.size() - 1); i++) {
            Mision m = PRINCIPALES.get(i);
            if (m.deGrupo()) {
                if (superada(s, m)) continue;
                for (ServerPlayerEntity p : jugando) {
                    if (m.cumple().test(p)) { superarDeGrupo(s, m, p); break; }
                }
            } else {
                for (ServerPlayerEntity p : jugando) {
                    if (!e.misionCompletada(m.id(), p.getUuid()) && m.cumple().test(p)) completar(s, m, p);
                }
            }
        }
        for (Mision m : SECUNDARIAS) {
            for (ServerPlayerEntity p : jugando) {
                if (!e.misionCompletada(m.id(), p.getUuid()) && m.cumple().test(p)) completar(s, m, p);
            }
        }
        // ¿el grupo ya ha superado la actual?
        if (actual < PRINCIPALES.size()) {
            Mision m = PRINCIPALES.get(actual);
            int total = serie(s).size();
            if (!m.deGrupo() && total > 0 && hechosDelGrupo(s, m) >= necesarios(total)) superar(s, m);
        }
    }

    private static void entregar(ServerPlayerEntity p, Mision m, boolean pendiente) {
        if (m.premio() == null) return;
        m.premio().dar().accept(p);
        p.sendMessage(Text.literal(pendiente ? "Premio de la misión \"" + m.titulo() + "\" (mientras no estabas): " : "Recompensa: ")
                .formatted(Formatting.GOLD).append(Text.literal(m.premio().texto()).formatted(Formatting.YELLOW)), false);
    }

    private static void titulo(ServerPlayerEntity p, String arriba, String abajo, Formatting color) {
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 40, 10));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(abajo).formatted(Formatting.WHITE)));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal(arriba).formatted(color, Formatting.BOLD)));
    }

    private static void completar(MinecraftServer s, Mision m, ServerPlayerEntity p) {
        EstadoServidor.get(s).completarMision(m.id(), p.getUuid());
        entregar(p, m, false);
        boolean principal = m.clase() == Clase.PRINCIPAL;
        titulo(p, principal ? "¡MISIÓN COMPLETADA!" : "¡SECUNDARIA COMPLETADA!", m.titulo(), principal ? Formatting.GOLD : Formatting.AQUA);
        p.getServerWorld().playSound(null, p.getBlockPos(), principal ? SoundEvents.UI_TOAST_CHALLENGE_COMPLETE : SoundEvents.ENTITY_PLAYER_LEVELUP,
                SoundCategory.PLAYERS, 1f, 1f);
        if (principal) {
            int total = serie(s).size();
            s.getPlayerManager().broadcast(Text.literal(p.getGameProfile().getName() + " ha completado la misión ").formatted(Formatting.GRAY)
                    .append(Text.literal(m.titulo()).formatted(Formatting.GOLD))
                    .append(Text.literal(" (" + hechosDelGrupo(s, m) + "/" + necesarios(total) + " para avanzar)").formatted(Formatting.GRAY)), false);
        } else {
            p.sendMessage(Text.literal("Misión secundaria completada: ").formatted(Formatting.AQUA).append(Text.literal(m.titulo()).formatted(Formatting.WHITE)), false);
        }
        sincronizar(s);
    }

    /** El 75 % la ha completado: se desbloquea lo suyo y se revela la siguiente. */
    private static void superar(MinecraftServer s, Mision m) {
        EstadoServidor.get(s).agregarCambio(SUPERADA + m.id());
        s.getPlayerManager().broadcast(Text.literal("¡El grupo ha superado la misión \"" + m.titulo() + "\"!").formatted(Formatting.GREEN, Formatting.BOLD), false);
        if (m.alSuperar() != null) m.alSuperar().accept(s);
        revelarSiguiente(s, m.alSuperar() != null);
        sincronizar(s);
    }

    /** Misión de grupo: la ha hecho uno (o ha pasado en el mundo) y el premio es para todos los de la serie. */
    private static void superarDeGrupo(MinecraftServer s, Mision m, ServerPlayerEntity quien) {
        EstadoServidor e = EstadoServidor.get(s);
        e.agregarCambio(SUPERADA + m.id());
        for (UUID u : e.getJugadoresSerie().keySet()) {
            if (e.misionCompletada(m.id(), u)) continue;
            e.completarMision(m.id(), u);
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(u);
            if (p != null) {
                entregar(p, m, false);
                titulo(p, "¡MISIÓN COMPLETADA!", m.titulo(), Formatting.GOLD);
                p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1f, 1f);
            } else {
                e.agregarPremioPendiente(m.id() + "|" + u);
            }
        }
        String quienLoHizo = m.id().equals("dragon") ? "¡El dragón ha caído!" : "¡" + quien.getGameProfile().getName() + " lo ha conseguido!";
        s.getPlayerManager().broadcast(Text.literal(quienLoHizo + " Misión \"" + m.titulo() + "\" superada: premio para todos.")
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
        if (m.alSuperar() != null) m.alSuperar().accept(s);
        revelarSiguiente(s, m.alSuperar() != null);
        sincronizar(s);
    }

    private static void revelarSiguiente(MinecraftServer s, boolean hayTele) {
        int i = actual(s);
        if (i >= PRINCIPALES.size()) return;
        Mision sig = PRINCIPALES.get(i);
        Tareas.programar(hayTele ? Eventos.RETRASO_TELE + 40 : 40, () -> s.getPlayerManager().broadcast(
                Text.literal("[NUEVA MISIÓN] ").formatted(Formatting.GOLD, Formatting.BOLD)
                        .append(Text.literal(sig.titulo() + ": ").formatted(Formatting.WHITE))
                        .append(Text.literal(sig.descripcion() + " (tecla U)").formatted(Formatting.GRAY)), false));
    }

    // ------------------------------------------------------------------ al cliente

    public static void sincronizar(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        int total = serie(s).size();
        int actual = actual(s);
        boolean fuera = fueraDeServicio(s);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            if (!ServerPlayNetworking.canSend(p, MisionesPayload.ID)) continue;
            JsonObject raiz = new JsonObject();
            raiz.addProperty("fuera", fuera);
            raiz.addProperty("total", total);
            raiz.addProperty("necesarios", necesarios(total));
            JsonArray prin = new JsonArray();
            for (int i = 0; i <= Math.min(actual, PRINCIPALES.size() - 1); i++) prin.add(json(s, e, PRINCIPALES.get(i), p));
            raiz.add("principales", prin);
            raiz.addProperty("ocultas", Math.max(0, PRINCIPALES.size() - actual - 1));
            JsonArray sec = new JsonArray();
            for (Mision m : SECUNDARIAS) sec.add(json(s, e, m, p));
            raiz.add("secundarias", sec);
            ServerPlayNetworking.send(p, new MisionesPayload(raiz.toString()));
        }
    }

    private static JsonObject json(MinecraftServer s, EstadoServidor e, Mision m, ServerPlayerEntity p) {
        JsonObject o = new JsonObject();
        o.addProperty("titulo", m.titulo());
        o.addProperty("descripcion", m.descripcion());
        o.addProperty("recompensa", m.premio() == null ? "" : m.premio().texto());
        o.addProperty("hecha", e.misionCompletada(m.id(), p.getUuid()));
        o.addProperty("grupo", m.deGrupo());
        if (m.clase() == Clase.PRINCIPAL) {
            o.addProperty("superada", superada(s, m));
            o.addProperty("hechos", hechosDelGrupo(s, m));
        }
        if (m.progreso() != null && !e.misionCompletada(m.id(), p.getUuid())) {
            int[] v = m.progreso().apply(p);
            o.addProperty("valor", v[0]);
            o.addProperty("meta", v[1]);
        }
        return o;
    }

    private static int estado(net.minecraft.server.command.ServerCommandSource src) {
        MinecraftServer s = src.getServer();
        int i = actual(s);
        int total = serie(s).size();
        if (i >= PRINCIPALES.size()) {
            src.sendFeedback(() -> Text.literal("Ya se superaron todas las misiones principales." + (fueraDeServicio(s) ? " El menú está fuera de servicio (tele rota)." : ""))
                    .formatted(Formatting.GREEN), false);
            return 1;
        }
        Mision m = PRINCIPALES.get(i);
        String grupo = m.deGrupo() ? "basta con que la haga uno" : hechosDelGrupo(s, m) + "/" + necesarios(total) + " necesarios (de " + total + " jugadores)";
        src.sendFeedback(() -> Text.literal("Misión " + (i + 1) + "/" + PRINCIPALES.size() + ": " + m.titulo() + " · " + grupo).formatted(Formatting.GOLD), false);
        return 1;
    }

    public static List<String> ids() {
        return List.copyOf(TODAS.keySet());
    }

    // ------------------------------------------------------------------ comandos de admin

    /** Marca la misión actual como superada por el grupo (para probar o si alguien se ha quedado atrás). */
    public static String forzarActual(MinecraftServer s) {
        int i = actual(s);
        if (i >= PRINCIPALES.size()) return null;
        Mision m = PRINCIPALES.get(i);
        if (m.deGrupo()) {
            ServerPlayerEntity alguien = s.getPlayerManager().getPlayerList().isEmpty() ? null : s.getPlayerManager().getPlayerList().get(0);
            if (alguien == null) return null;
            superarDeGrupo(s, m, alguien);
        } else {
            superar(s, m);
        }
        return m.titulo();
    }

    public static boolean completarPara(MinecraftServer s, ServerPlayerEntity p, String id) {
        Mision m = TODAS.get(id);
        if (m == null || EstadoServidor.get(s).misionCompletada(id, p.getUuid())) return false;
        completar(s, m, p);
        return true;
    }

    public static void reiniciar(MinecraftServer s) {
        EstadoServidor e = EstadoServidor.get(s);
        e.limpiarMisiones();
        for (Mision m : PRINCIPALES) e.quitarCambio(SUPERADA + m.id());
        sincronizar(s);
    }
}

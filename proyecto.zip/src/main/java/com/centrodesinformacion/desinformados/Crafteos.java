package com.centrodesinformacion.desinformados;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Set;

/** Objetos que no se pueden craftear hasta que se desbloquean: equipo de diamante y las recetas nuevas del mod. */
public class Crafteos {
    private static final Set<Item> DIAMANTE = Set.of(
            Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

    public static final String CAMBIO_DIAMANTE = "crafteo_diamante";

    /** Recetas nuevas del mod: cada una se desbloquea con su propio evento verde (/desinfo lanzar <id>). */
    private static java.util.Map<Item, String> nuevas() {
        return java.util.Map.of(
                ModBloques.LIBRETA_PORTAL.asItem(), "receta_libreta",
                ModItems.CENTRO_ESTATICA, "receta_centro_estatica",
                ModItems.CUBO_DESINFORMACION, "receta_desinformacion_pura",
                ModBloques.BLOQUE_GARATITA.asItem(), "receta_bloque_garatita");
    }

    /** Devuelve el resultado permitido (vacío si está bloqueado). */
    public static ItemStack filtrar(ItemStack resultado) {
        if (resultado.isEmpty() || Desinformados.SERVER == null) return resultado;
        if (DIAMANTE.contains(resultado.getItem()) && !EstadoServidor.get(Desinformados.SERVER).tieneCambio(CAMBIO_DIAMANTE)) {
            return ItemStack.EMPTY;
        }
        String cambio = nuevas().get(resultado.getItem());
        if (cambio != null && !EstadoServidor.get(Desinformados.SERVER).tieneCambio(cambio)) return ItemStack.EMPTY;
        return resultado;
    }

    private static final java.util.List<String> RECETAS_DIAMANTE = java.util.List.of(
            "minecraft:diamond_sword", "minecraft:diamond_pickaxe", "minecraft:diamond_axe", "minecraft:diamond_shovel",
            "minecraft:diamond_hoe", "minecraft:diamond_helmet", "minecraft:diamond_chestplate", "minecraft:diamond_leggings",
            "minecraft:diamond_boots");
    private static final java.util.Map<String, String> RECETAS_NUEVAS = java.util.Map.of(
            "desinformados:libreta_portal", "receta_libreta",
            "desinformados:centro_estatica", "receta_centro_estatica",
            "desinformados:cubo_desinformacion", "receta_desinformacion_pura",
            "desinformados:bloque_garatita", "receta_bloque_garatita");

    /**
     * Oculta del librito de recetas las que siguen bloqueadas (y las muestra al desbloquearse).
     * Vanilla vuelve a enseñar las de diamante al conseguir un diamante, así que se revisa cada 2 segundos.
     */
    public static void sincronizar(net.minecraft.server.network.ServerPlayerEntity p) {
        var server = p.getServer();
        if (server == null) return;
        EstadoServidor estado = EstadoServidor.get(server);
        java.util.List<net.minecraft.recipe.RecipeEntry<?>> quitar = new java.util.ArrayList<>();
        java.util.List<net.minecraft.recipe.RecipeEntry<?>> dar = new java.util.ArrayList<>();
        boolean diamante = estado.tieneCambio(CAMBIO_DIAMANTE);
        for (String id : RECETAS_DIAMANTE) {
            server.getRecipeManager().get(net.minecraft.util.Identifier.of(id)).ifPresent(r -> {
                if (!diamante && p.getRecipeBook().contains(r)) quitar.add(r);
            });
        }
        RECETAS_NUEVAS.forEach((id, cambio) -> server.getRecipeManager().get(net.minecraft.util.Identifier.of(id)).ifPresent(r -> {
            boolean libre = estado.tieneCambio(cambio);
            if (!libre && p.getRecipeBook().contains(r)) quitar.add(r);
            else if (libre && !p.getRecipeBook().contains(r)) dar.add(r);
        }));
        if (!quitar.isEmpty()) p.lockRecipes(quitar);
        if (!dar.isEmpty()) p.unlockRecipes(dar);
    }

    public static void sincronizarTodos(net.minecraft.server.MinecraftServer server) {
        for (var p : server.getPlayerManager().getPlayerList()) sincronizar(p);
    }

    public static void registrar() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 40 == 0) sincronizarTodos(server);
        });
    }

    public static boolean esEquipoDiamante(ItemStack s) {
        return DIAMANTE.contains(s.getItem());
    }
}

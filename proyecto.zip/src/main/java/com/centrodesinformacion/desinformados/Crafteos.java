package com.centrodesinformacion.desinformados;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Set;

/** Objetos que no se pueden craftear hasta que se desbloquean (ahora: equipo de diamante). */
public class Crafteos {
    private static final Set<Item> DIAMANTE = Set.of(
            Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

    public static final String CAMBIO_DIAMANTE = "crafteo_diamante";

    /** Devuelve el resultado permitido (vacío si está bloqueado). */
    public static ItemStack filtrar(ItemStack resultado) {
        if (resultado.isEmpty() || Desinformados.SERVER == null) return resultado;
        if (DIAMANTE.contains(resultado.getItem()) && !EstadoServidor.get(Desinformados.SERVER).tieneCambio(CAMBIO_DIAMANTE)) {
            return ItemStack.EMPTY;
        }
        return resultado;
    }

    public static boolean esEquipoDiamante(ItemStack s) {
        return DIAMANTE.contains(s.getItem());
    }
}

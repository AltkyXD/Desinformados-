package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: la cinemática terminó, llévame al Centro. */
public record IntroFinPayload(int nada) implements CustomPayload {
    public static final CustomPayload.Id<IntroFinPayload> ID = new CustomPayload.Id<>(Desinformados.id("intro_fin"));
    public static final PacketCodec<RegistryByteBuf, IntroFinPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, IntroFinPayload::nada, IntroFinPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

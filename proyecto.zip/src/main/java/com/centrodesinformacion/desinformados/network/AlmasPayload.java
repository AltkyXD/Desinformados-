package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Le dice al cliente cuántos puntos de alma tiene (2 puntos = 1 corazón azul). */
public record AlmasPayload(float puntos) implements CustomPayload {
    public static final CustomPayload.Id<AlmasPayload> ID = new CustomPayload.Id<>(Desinformados.id("almas"));
    public static final PacketCodec<RegistryByteBuf, AlmasPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.FLOAT, AlmasPayload::puntos, AlmasPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

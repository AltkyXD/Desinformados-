package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: "depositar" o "sacar:<color>" con una cantidad. */
public record BancoAccionPayload(String accion, int cantidad) implements CustomPayload {
    public static final CustomPayload.Id<BancoAccionPayload> ID = new CustomPayload.Id<>(Desinformados.id("banco_accion"));
    public static final PacketCodec<RegistryByteBuf, BancoAccionPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, BancoAccionPayload::accion, PacketCodecs.VAR_INT, BancoAccionPayload::cantidad, BancoAccionPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

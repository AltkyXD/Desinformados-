package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: jugada de Blackjack ("repartir" con la apuesta, "pedir", "plantarse" o "doblar"). */
public record BlackjackAccionPayload(String accion, int apuesta) implements CustomPayload {
    public static final CustomPayload.Id<BlackjackAccionPayload> ID = new CustomPayload.Id<>(Desinformados.id("blackjack_accion"));
    public static final PacketCodec<RegistryByteBuf, BlackjackAccionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, BlackjackAccionPayload::accion,
            PacketCodecs.VAR_INT, BlackjackAccionPayload::apuesta,
            BlackjackAccionPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

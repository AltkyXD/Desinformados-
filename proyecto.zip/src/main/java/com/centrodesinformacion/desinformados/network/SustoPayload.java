package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Screamer a pantalla completa durante X ticks. */
public record SustoPayload(int ticks) implements CustomPayload {
    public static final CustomPayload.Id<SustoPayload> ID = new CustomPayload.Id<>(Desinformados.id("susto"));
    public static final PacketCodec<RegistryByteBuf, SustoPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, SustoPayload::ticks, SustoPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

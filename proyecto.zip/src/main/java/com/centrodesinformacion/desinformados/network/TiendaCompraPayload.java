package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: comprar la oferta 'indice' del vendedor 'entidad'. */
public record TiendaCompraPayload(int entidad, int indice) implements CustomPayload {
    public static final CustomPayload.Id<TiendaCompraPayload> ID = new CustomPayload.Id<>(Desinformados.id("tienda_compra"));
    public static final PacketCodec<RegistryByteBuf, TiendaCompraPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, TiendaCompraPayload::entidad, PacketCodecs.VAR_INT, TiendaCompraPayload::indice, TiendaCompraPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Lista de misiones para la pantalla de la tecla L, en formato JSON. */
public record MisionesPayload(String json) implements CustomPayload {
    public static final CustomPayload.Id<MisionesPayload> ID = new CustomPayload.Id<>(Desinformados.id("misiones"));
    public static final PacketCodec<RegistryByteBuf, MisionesPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, MisionesPayload::json, MisionesPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

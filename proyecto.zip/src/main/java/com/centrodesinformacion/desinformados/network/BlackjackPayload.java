package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

import java.util.ArrayList;
import java.util.List;

/**
 * Servidor -> cliente: cómo va la mano de Blackjack. Cartas 0..51 (-1 = boca abajo).
 * fase: 0 = sin mano (apostando), 1 = jugando, 2 = terminada. pago = lo que cobraste (incluida la apuesta).
 */
public record BlackjackPayload(int rumores, int apuesta, int fase, int pago, List<Integer> jugador, List<Integer> banca,
                               String mensaje, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<BlackjackPayload> ID = new CustomPayload.Id<>(Desinformados.id("blackjack"));
    public static final PacketCodec<RegistryByteBuf, BlackjackPayload> CODEC = PacketCodec.of(BlackjackPayload::escribir, BlackjackPayload::leer);

    private void escribir(RegistryByteBuf b) {
        b.writeVarInt(rumores);
        b.writeVarInt(apuesta);
        b.writeVarInt(fase);
        b.writeVarInt(pago);
        escribirLista(b, jugador);
        escribirLista(b, banca);
        b.writeString(mensaje);
        b.writeBoolean(abrir);
    }

    private static BlackjackPayload leer(RegistryByteBuf b) {
        int rumores = b.readVarInt(), apuesta = b.readVarInt(), fase = b.readVarInt(), pago = b.readVarInt();
        List<Integer> jugador = leerLista(b), banca = leerLista(b);
        return new BlackjackPayload(rumores, apuesta, fase, pago, jugador, banca, b.readString(), b.readBoolean());
    }

    private static void escribirLista(RegistryByteBuf b, List<Integer> l) {
        b.writeVarInt(l.size());
        for (int c : l) b.writeVarInt(c);
    }

    private static List<Integer> leerLista(RegistryByteBuf b) {
        int n = Math.min(b.readVarInt(), 32);
        List<Integer> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) l.add(b.readVarInt());
        return l;
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

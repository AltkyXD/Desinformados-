package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Enciende o apaga el borde rojo de la pantalla del jugador. */
public record BordePayload(boolean activo) implements CustomPayload {
    public static final CustomPayload.Id<BordePayload> ID = new CustomPayload.Id<>(Desinformados.id("borde"));
    public static final PacketCodec<RegistryByteBuf, BordePayload> CODEC =
            PacketCodec.tuple(PacketCodecs.BOOL, BordePayload::activo, BordePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

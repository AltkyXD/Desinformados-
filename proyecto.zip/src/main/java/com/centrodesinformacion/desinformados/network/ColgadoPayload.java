package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> clientes: este jugador está (o ya no está) colgado de un borde con los Guantes de Escala, para ponerle los brazos arriba. */
public record ColgadoPayload(int entidad, boolean colgado) implements CustomPayload {
    public static final CustomPayload.Id<ColgadoPayload> ID = new CustomPayload.Id<>(Desinformados.id("colgado"));
    public static final PacketCodec<RegistryByteBuf, ColgadoPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, ColgadoPayload::entidad, PacketCodecs.BOOL, ColgadoPayload::colgado, ColgadoPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: apuesta a "rojo", "negro" o "verde" con esa cantidad de Rumores. */
public record RuletaApuestaPayload(String color, int cantidad) implements CustomPayload {
    public static final CustomPayload.Id<RuletaApuestaPayload> ID = new CustomPayload.Id<>(Desinformados.id("ruleta_apuesta"));
    public static final PacketCodec<RegistryByteBuf, RuletaApuestaPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, RuletaApuestaPayload::color,
            PacketCodecs.VAR_INT, RuletaApuestaPayload::cantidad,
            RuletaApuestaPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

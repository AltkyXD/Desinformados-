package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: abre/actualiza la tienda de un Gato Cubo (dinero = Banco + monedas). */
public record TiendaPayload(int entidad, int tipo, int dinero, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<TiendaPayload> ID = new CustomPayload.Id<>(Desinformados.id("tienda"));
    public static final PacketCodec<RegistryByteBuf, TiendaPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, TiendaPayload::entidad, PacketCodecs.VAR_INT, TiendaPayload::tipo,
            PacketCodecs.VAR_INT, TiendaPayload::dinero, PacketCodecs.BOOL, TiendaPayload::abrir, TiendaPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

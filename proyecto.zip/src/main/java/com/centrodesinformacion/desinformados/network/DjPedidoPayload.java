package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: pedirle al DJ la canción 'indice'. */
public record DjPedidoPayload(int entidad, int indice) implements CustomPayload {
    public static final CustomPayload.Id<DjPedidoPayload> ID = new CustomPayload.Id<>(Desinformados.id("dj_pedido"));
    public static final PacketCodec<RegistryByteBuf, DjPedidoPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, DjPedidoPayload::entidad, PacketCodecs.VAR_INT, DjPedidoPayload::indice, DjPedidoPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

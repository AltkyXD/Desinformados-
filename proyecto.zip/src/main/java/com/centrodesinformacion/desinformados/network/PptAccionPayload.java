package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: "apuesta" (valor = cantidad), "acuerdo", "elegir" (valor = 0 Piedra, 1 Papel, 2 Tijera) o "salir". */
public record PptAccionPayload(String accion, int valor) implements CustomPayload {
    public static final CustomPayload.Id<PptAccionPayload> ID = new CustomPayload.Id<>(Desinformados.id("piedra_papel_tijera_accion"));
    public static final PacketCodec<RegistryByteBuf, PptAccionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, PptAccionPayload::accion,
            PacketCodecs.VAR_INT, PptAccionPayload::valor,
            PptAccionPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

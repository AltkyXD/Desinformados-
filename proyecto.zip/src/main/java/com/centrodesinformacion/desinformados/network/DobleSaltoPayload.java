package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: he hecho un doble salto (para reiniciar la caída). */
public record DobleSaltoPayload(int nada) implements CustomPayload {
    public static final CustomPayload.Id<DobleSaltoPayload> ID = new CustomPayload.Id<>(Desinformados.id("doble_salto"));
    public static final PacketCodec<RegistryByteBuf, DobleSaltoPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, DobleSaltoPayload::nada, DobleSaltoPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

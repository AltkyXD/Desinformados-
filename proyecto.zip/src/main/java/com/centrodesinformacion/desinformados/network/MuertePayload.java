package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Animación de eliminación: la tele cae, se parte y aparece el nombre. */
public record MuertePayload(String nombre) implements CustomPayload {
    public static final CustomPayload.Id<MuertePayload> ID = new CustomPayload.Id<>(Desinformados.id("muerte"));
    public static final PacketCodec<RegistryByteBuf, MuertePayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, MuertePayload::nombre, MuertePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: activar/desactivar una pasiva. */
public record PasivaTogglePayload(String id) implements CustomPayload {
    public static final CustomPayload.Id<PasivaTogglePayload> ID = new CustomPayload.Id<>(Desinformados.id("pasiva_toggle"));
    public static final PacketCodec<RegistryByteBuf, PasivaTogglePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, PasivaTogglePayload::id, PasivaTogglePayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

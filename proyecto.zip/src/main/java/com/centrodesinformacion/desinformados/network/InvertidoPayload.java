package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Invierte los controles del jugador durante X ticks. */
public record InvertidoPayload(int ticks) implements CustomPayload {
    public static final CustomPayload.Id<InvertidoPayload> ID = new CustomPayload.Id<>(Desinformados.id("invertido"));
    public static final PacketCodec<RegistryByteBuf, InvertidoPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, InvertidoPayload::ticks, InvertidoPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: la barra de vida de estática del jefe final (Desinformación). */
public record JefePayload(int entidad, int fase, float progreso, boolean visible) implements CustomPayload {
    public static final CustomPayload.Id<JefePayload> ID = new CustomPayload.Id<>(Desinformados.id("jefe_tele"));
    public static final PacketCodec<RegistryByteBuf, JefePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, JefePayload::entidad, PacketCodecs.VAR_INT, JefePayload::fase,
            PacketCodecs.FLOAT, JefePayload::progreso, PacketCodecs.BOOL, JefePayload::visible, JefePayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

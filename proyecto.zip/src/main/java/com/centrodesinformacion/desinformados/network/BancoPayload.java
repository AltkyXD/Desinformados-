package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: saldo del banco (y si hay que abrir la pantalla). */
public record BancoPayload(int saldo, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<BancoPayload> ID = new CustomPayload.Id<>(Desinformados.id("banco"));
    public static final PacketCodec<RegistryByteBuf, BancoPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, BancoPayload::saldo, PacketCodecs.BOOL, BancoPayload::abrir, BancoPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

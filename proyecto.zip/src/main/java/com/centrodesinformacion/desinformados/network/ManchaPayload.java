package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Mancha los bordes de la pantalla con tinta durante X ticks. */
public record ManchaPayload(int ticks) implements CustomPayload {
    public static final CustomPayload.Id<ManchaPayload> ID = new CustomPayload.Id<>(Desinformados.id("mancha"));
    public static final PacketCodec<RegistryByteBuf, ManchaPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, ManchaPayload::ticks, ManchaPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: empieza la cinemática de bienvenida. */
public record IntroPayload(String jugador) implements CustomPayload {
    public static final CustomPayload.Id<IntroPayload> ID = new CustomPayload.Id<>(Desinformados.id("intro"));
    public static final PacketCodec<RegistryByteBuf, IntroPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, IntroPayload::jugador, IntroPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: terminaron los créditos, llévame a casa. */
public record FinalFinPayload(int nada) implements CustomPayload {
    public static final CustomPayload.Id<FinalFinPayload> ID = new CustomPayload.Id<>(Desinformados.id("final_fin"));
    public static final PacketCodec<RegistryByteBuf, FinalFinPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, FinalFinPayload::nada, FinalFinPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

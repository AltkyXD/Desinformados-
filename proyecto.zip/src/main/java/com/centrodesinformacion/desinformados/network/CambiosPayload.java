package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Lista de cambios de dificultad activos, separados por comas (para efectos que corren en el cliente). */
public record CambiosPayload(String lista) implements CustomPayload {
    public static final CustomPayload.Id<CambiosPayload> ID = new CustomPayload.Id<>(Desinformados.id("cambios"));
    public static final PacketCodec<RegistryByteBuf, CambiosPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, CambiosPayload::lista, CambiosPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

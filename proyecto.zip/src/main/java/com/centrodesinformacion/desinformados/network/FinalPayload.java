package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: empieza la cinemática final (con los nombres de los protagonistas para los créditos). */
public record FinalPayload(String jugadores) implements CustomPayload {
    public static final CustomPayload.Id<FinalPayload> ID = new CustomPayload.Id<>(Desinformados.id("final"));
    public static final PacketCodec<RegistryByteBuf, FinalPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, FinalPayload::jugadores, FinalPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

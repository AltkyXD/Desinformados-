package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: pasivas compradas y activas (separadas por comas). */
public record PasivasPayload(String compradas, String activas) implements CustomPayload {
    public static final CustomPayload.Id<PasivasPayload> ID = new CustomPayload.Id<>(Desinformados.id("pasivas"));
    public static final PacketCodec<RegistryByteBuf, PasivasPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, PasivasPayload::compradas, PacketCodecs.STRING, PasivasPayload::activas, PasivasPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

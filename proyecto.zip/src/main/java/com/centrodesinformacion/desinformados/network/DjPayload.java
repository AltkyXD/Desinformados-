package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: menú del DJ (dinero del jugador, canción sonando o -1, segundos que le quedan). */
public record DjPayload(int entidad, int dinero, int sonando, int quedan, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<DjPayload> ID = new CustomPayload.Id<>(Desinformados.id("dj"));
    public static final PacketCodec<RegistryByteBuf, DjPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, DjPayload::entidad, PacketCodecs.VAR_INT, DjPayload::dinero,
            PacketCodecs.VAR_INT, DjPayload::sonando, PacketCodecs.VAR_INT, DjPayload::quedan,
            PacketCodecs.BOOL, DjPayload::abrir, DjPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: notificación en la esquina (como los logros) con un objeto de icono (id del objeto). */
public record NotificacionPayload(String titulo, String texto, String icono) implements CustomPayload {
    public static final CustomPayload.Id<NotificacionPayload> ID = new CustomPayload.Id<>(Desinformados.id("notificacion"));
    public static final PacketCodec<RegistryByteBuf, NotificacionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, NotificacionPayload::titulo,
            PacketCodecs.STRING, NotificacionPayload::texto,
            PacketCodecs.STRING, NotificacionPayload::icono,
            NotificacionPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

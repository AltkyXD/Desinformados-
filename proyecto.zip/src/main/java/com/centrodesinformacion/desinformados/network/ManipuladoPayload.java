package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** El Angel Manipulador controla al jugador: cámara fija en la entidad, sin moverse, pantalla azul. ticks = 0 lo suelta. */
public record ManipuladoPayload(int entidad, int ticks) implements CustomPayload {
    public static final CustomPayload.Id<ManipuladoPayload> ID = new CustomPayload.Id<>(Desinformados.id("manipulado"));
    public static final PacketCodec<RegistryByteBuf, ManipuladoPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, ManipuladoPayload::entidad, PacketCodecs.VAR_INT, ManipuladoPayload::ticks, ManipuladoPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

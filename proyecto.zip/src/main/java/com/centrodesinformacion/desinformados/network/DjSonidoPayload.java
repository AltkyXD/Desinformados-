package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Servidor -> cliente: el DJ empieza a sonar (bucle, disco o canción) en (x, y, z).
 * El cliente solo lo oye mientras sus pies estén entre minY y maxY (el piso del DJ);
 * fuera de ese piso el sonido sigue corriendo en silencio, así al volver se oye por donde va.
 */
/** desde = ticks que ya lleva sonando (para quien llega a mitad: empieza por donde va). */
public record DjSonidoPayload(Identifier sonido, double x, double y, double z, float volumen, double minY, double maxY, int desde) implements CustomPayload {
    public static final CustomPayload.Id<DjSonidoPayload> ID = new CustomPayload.Id<>(Desinformados.id("dj_sonido"));
    public static final PacketCodec<RegistryByteBuf, DjSonidoPayload> CODEC = PacketCodec.of(DjSonidoPayload::escribir, DjSonidoPayload::leer);

    private void escribir(RegistryByteBuf b) {
        b.writeIdentifier(sonido);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeFloat(volumen);
        b.writeDouble(minY);
        b.writeDouble(maxY);
        b.writeVarInt(desde);
    }

    private static DjSonidoPayload leer(RegistryByteBuf b) {
        return new DjSonidoPayload(b.readIdentifier(), b.readDouble(), b.readDouble(), b.readDouble(), b.readFloat(), b.readDouble(), b.readDouble(), b.readVarInt());
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

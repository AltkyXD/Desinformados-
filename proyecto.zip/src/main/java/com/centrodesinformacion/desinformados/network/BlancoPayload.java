package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Pone la pantalla del jugador en blanco durante X ticks. */
public record BlancoPayload(int ticks) implements CustomPayload {
    public static final CustomPayload.Id<BlancoPayload> ID = new CustomPayload.Id<>(Desinformados.id("blanco"));
    public static final PacketCodec<RegistryByteBuf, BlancoPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, BlancoPayload::ticks, BlancoPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

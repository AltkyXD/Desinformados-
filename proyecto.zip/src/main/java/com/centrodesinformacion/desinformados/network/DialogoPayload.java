package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: lo que dice un Gato Cubo (se muestra encima de la barra de objetos). */
public record DialogoPayload(String nombre, int color, String texto) implements CustomPayload {
    public static final CustomPayload.Id<DialogoPayload> ID = new CustomPayload.Id<>(Desinformados.id("dialogo"));
    public static final PacketCodec<RegistryByteBuf, DialogoPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, DialogoPayload::nombre, PacketCodecs.VAR_INT, DialogoPayload::color,
            PacketCodecs.STRING, DialogoPayload::texto, DialogoPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}

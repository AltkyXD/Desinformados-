package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/**
 * Servidor -> cliente: los Rumores que lleva el jugador y, si acaba de apostar, el número que va a salir
 * (para que la rueda se pare justo ahí) y lo que gana (0 = pierde). numero = -1: solo actualizar el saldo.
 */
public record RuletaPayload(int rumores, int numero, int premio, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<RuletaPayload> ID = new CustomPayload.Id<>(Desinformados.id("ruleta"));
    public static final PacketCodec<RegistryByteBuf, RuletaPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, RuletaPayload::rumores,
            PacketCodecs.INTEGER, RuletaPayload::numero,
            PacketCodecs.VAR_INT, RuletaPayload::premio,
            PacketCodecs.BOOL, RuletaPayload::abrir,
            RuletaPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Paquete que el servidor manda a todos para mostrar la tele. */
public record EventoTvPayload(String color, String titulo, String descripcion) implements CustomPayload {
    public static final CustomPayload.Id<EventoTvPayload> ID = new CustomPayload.Id<>(Desinformados.id("evento_tv"));
    public static final PacketCodec<RegistryByteBuf, EventoTvPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, EventoTvPayload::color,
            PacketCodecs.STRING, EventoTvPayload::titulo,
            PacketCodecs.STRING, EventoTvPayload::descripcion,
            EventoTvPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

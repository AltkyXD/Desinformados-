package com.centrodesinformacion.desinformados.network;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

/**
 * Servidor -> cliente: cómo está la mesa de Piedra, Papel o Tijera vista por este jugador.
 * yo = su asiento (0, 1 o -1 si solo mira). Jugadas: 0 Piedra, 1 Papel, 2 Tijera, -1 nada.
 */
public record PptPayload(int fase, String nombre0, String nombre1, int propuesta0, int propuesta1, boolean ok0, boolean ok1,
                         int yo, int miEleccion, boolean rivalEligio, int ultima0, int ultima1, int bote, int segundos,
                         int rumores, String mensaje, boolean abrir) implements CustomPayload {
    public static final CustomPayload.Id<PptPayload> ID = new CustomPayload.Id<>(Desinformados.id("piedra_papel_tijera"));
    public static final PacketCodec<RegistryByteBuf, PptPayload> CODEC = PacketCodec.of(PptPayload::escribir, PptPayload::leer);

    private void escribir(RegistryByteBuf b) {
        b.writeVarInt(fase);
        b.writeString(nombre0);
        b.writeString(nombre1);
        b.writeVarInt(propuesta0);
        b.writeVarInt(propuesta1);
        b.writeBoolean(ok0);
        b.writeBoolean(ok1);
        b.writeVarInt(yo);
        b.writeVarInt(miEleccion);
        b.writeBoolean(rivalEligio);
        b.writeVarInt(ultima0);
        b.writeVarInt(ultima1);
        b.writeVarInt(bote);
        b.writeVarInt(segundos);
        b.writeVarInt(rumores);
        b.writeString(mensaje);
        b.writeBoolean(abrir);
    }

    private static PptPayload leer(RegistryByteBuf b) {
        int fase = b.readVarInt();
        String n0 = b.readString(), n1 = b.readString();
        int p0 = b.readVarInt(), p1 = b.readVarInt();
        boolean ok0 = b.readBoolean(), ok1 = b.readBoolean();
        int yo = b.readVarInt(), mia = b.readVarInt();
        boolean rival = b.readBoolean();
        int u0 = b.readVarInt(), u1 = b.readVarInt(), bote = b.readVarInt(), seg = b.readVarInt(), rum = b.readVarInt();
        String msg = b.readString();
        boolean abrir = b.readBoolean();
        return new PptPayload(fase, n0, n1, p0, p1, ok0, ok1, yo, mia, rival, u0, u1, bote, seg, rum, msg, abrir);
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.centrodesinformacion.desinformados;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent TV_ESTATICA = crear("tv_estatica");
    public static final SoundEvent EVENTO_VERDE = crear("evento_verde");
    public static final SoundEvent EVENTO_ROJO = crear("evento_rojo");
    public static final SoundEvent EVENTO_AMARILLO = crear("evento_amarillo");
    public static final SoundEvent SUSTO = crear("susto");
    public static final SoundEvent GATO_VOZ = crear("gato_voz");
    public static final SoundEvent KAWAII_VOZ = crear("kawaii_voz");
    public static final SoundEvent ROBOT_VOZ = crear("robot_voz");
    public static final SoundEvent INTRO_CANCION = crear("intro_cancion");
    public static final SoundEvent DJ_ESPONTANEO = crear("dj_espontaneo");
    public static final SoundEvent DJ_HOMBRE_DENIGRANTE = crear("dj_hombre_denigrante");
    public static final SoundEvent DJ_ME_PORTO_BONITO = crear("dj_me_porto_bonito");
    public static final SoundEvent DJ_CHICHABEBA = crear("dj_chichabeba");

    private static SoundEvent crear(String nombre) {
        Identifier id = Desinformados.id(nombre);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void inicializar() {
    }
}

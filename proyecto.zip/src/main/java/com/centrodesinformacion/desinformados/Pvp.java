package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * PvP: por defecto apagado (Reglas). /desinfo pvp si | no  — lo activa o lo desactiva para todos (se guarda en el mundo).
 * También ajusta el PvP del propio servidor (el "pvp" de server.properties) mientras el mod lo tenga activado.
 */
public final class Pvp {
    private Pvp() {}

    private static final String ACTIVO = "sys:pvp_activo";

    public static boolean activo(MinecraftServer s) {
        return s != null && EstadoServidor.get(s).tieneCambio(ACTIVO);
    }

    public static void registrar() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> { if (activo(s)) s.setPvpEnabled(true); });
        CommandRegistrationCallback.EVENT.register((d, acceso, entorno) -> d.register(literal("desinfo").requires(src -> src.hasPermissionLevel(2))
                .then(literal("pvp")
                        .executes(c -> {
                            boolean on = activo(c.getSource().getServer());
                            c.getSource().sendFeedback(() -> Text.literal("PvP " + (on ? "ACTIVADO" : "desactivado") + ". Usa /desinfo pvp si | no")
                                    .formatted(on ? Formatting.RED : Formatting.GRAY), false);
                            return 1;
                        })
                        .then(literal("si").executes(c -> cambiar(c.getSource().getServer(), true)))
                        .then(literal("no").executes(c -> cambiar(c.getSource().getServer(), false))))));
    }

    private static int cambiar(MinecraftServer s, boolean on) {
        EstadoServidor e = EstadoServidor.get(s);
        if (on) e.agregarCambio(ACTIVO); else e.quitarCambio(ACTIVO);
        e.markDirty();
        if (on) s.setPvpEnabled(true);
        s.getPlayerManager().broadcast(Text.literal(on ? "⚔ ¡PvP ACTIVADO! Ahora os podéis hacer daño entre vosotros."
                : "PvP desactivado: ya no os podéis hacer daño entre vosotros.").formatted(on ? Formatting.RED : Formatting.GREEN), false);
        return 1;
    }
}

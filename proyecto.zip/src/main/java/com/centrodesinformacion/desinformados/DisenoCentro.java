package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Decoración del Centro completo (el del mundo nuevo) y sus gatos.
 * GENERADO con el script de diseño: posiciones locales (x = derecha, y = desde el suelo de la planta baja,
 * z = hacia el fondo; la entrada está en -z). Planta baja: recepción, sala de espera y tiendas.
 * Piso 2: pista de baile con el DJ y los rincones de los gatos. Piso 3: casino. Techo: la Tele Gigante y El Gato.
 */
final class DisenoCentro {
    private DisenoCentro() {}

    static void decorar(ServerWorld w, ConstructorCentro.Sistema s, List<BlockPos> conectar) {
        D d = new D(w, s, conectar);

        // ---------- Planta baja ----------
        d.pared(-33.75, 3, ModBloques.PANTALLA_NOTICIAS);
        d.pared(-56.25, 3, ModBloques.PANTALLA_NOTICIAS);
        d.pared(-101.25, 3, ModBloques.CUADRO_GATO);
        d.pared(-78.75, 3, ModBloques.CUADRO_GATO);
        d.pared(123.75, 3, ModBloques.CUADRO_GATO);
        d.pared(-123.75, 3, ModBloques.CUADRO_GATO);
        d.pared(146.25, 3, ModBloques.CUADRO_GATO);
        d.pared(-146.25, 3, ModBloques.CUADRO_GATO);
        d.deco(0, 5, -19, ModBloques.LETRERO_CENTRO, 0, 1);
        d.deco(0, 6, -21, ModBloques.LETRERO_CENTRO, 0, -1);
        d.deco(-3, 1, -19, ModBloques.MACETA_GATERA, 0, 1);
        d.deco(3, 1, -19, ModBloques.MACETA_GATERA, 0, 1);
        d.colocar(-1, 1, -10, d.estado(ModBloques.RECEPCION, 0, -1));
        d.deco(-2, 1, -9, ModBloques.LAMPARA_GATO, 0, -1);
        d.deco(2, 1, -10, ModBloques.MACETA_GATERA, 0, -1);
        d.b(0, 1, 2, Blocks.CHISELED_STONE_BRICKS.getDefaultState());
        d.deco(0, 2, 2, ModBloques.ESTATUA_GATO, 0, -1);
        d.deco(-2, 1, 2, ModBloques.MACETA_GATERA, 0, -1);
        d.deco(2, 1, 2, ModBloques.MACETA_GATERA, 0, -1);
        d.silla(-16, 1, -4, 1, 0);
        d.silla(-11, 1, -4, -1, 0);
        d.silla(-16, 1, -3, 1, 0);
        d.silla(-11, 1, -3, -1, 0);
        d.silla(-16, 1, -2, 1, 0);
        d.silla(-11, 1, -2, -1, 0);
        d.silla(-16, 1, 0, 1, 0);
        d.silla(-11, 1, 0, -1, 0);
        d.silla(-16, 1, 1, 1, 0);
        d.silla(-11, 1, 1, -1, 0);
        d.silla(-16, 1, 2, 1, 0);
        d.silla(-11, 1, 2, -1, 0);
        d.mesa(-16, 1, -1);
        d.deco(-16, 2, -1, ModBloques.TAZA_GATO, 1, 0);
        d.mesa(-11, 1, -1);
        d.deco(-11, 2, -1, ModBloques.TAZA_GATO, -1, 0);
        d.deco(-17, 1, -6, ModBloques.MACETA_GATERA, 1, 0);
        d.deco(-10, 1, -6, ModBloques.MACETA_GATERA, -1, 0);
        d.deco(-13, 1, -6, ModBloques.LAMPARA_GATO, 0, 1);
        d.deco(-13, 1, 4, ModBloques.LAMPARA_GATO, 0, -1);
        d.mesa(-16, 1, 5);
        d.b(-16, 2, 5, Blocks.BREWING_STAND.getDefaultState());
        d.mesa(-16, 1, 6);
        d.deco(-16, 2, 6, ModBloques.TAZA_GATO, 1, 0);
        d.b(-16, 1, 7, Blocks.BARREL.getDefaultState());
        d.b(13, 1, -7, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(13, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(14, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(15, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(16, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(17, 4, -7, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(13, 1, -6, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(13, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(14, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(15, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(16, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(17, 4, -6, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(13, 1, -5, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(13, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(14, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(15, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(16, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.b(17, 4, -5, Blocks.PURPLE_WOOL.getDefaultState());
        d.bc(13, 2, -7, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, -7, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 2, -5, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, -5, Blocks.SPRUCE_FENCE.getDefaultState());
        d.b(12, 3, -6, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
        d.b(13, 1, -1, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(13, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(14, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(15, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(16, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(17, 4, -1, Blocks.RED_WOOL.getDefaultState());
        d.b(13, 1, 0, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(13, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(14, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(15, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(16, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(17, 4, 0, Blocks.RED_WOOL.getDefaultState());
        d.b(13, 1, 1, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.b(13, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.b(14, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.b(15, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.b(16, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.b(17, 4, 1, Blocks.RED_WOOL.getDefaultState());
        d.bc(13, 2, -1, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, -1, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 2, 1, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, 1, Blocks.SPRUCE_FENCE.getDefaultState());
        d.b(12, 3, 0, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
        d.b(13, 1, 5, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(13, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(14, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(15, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(16, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(17, 4, 5, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(13, 1, 6, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(13, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(14, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(15, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(16, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(17, 4, 6, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(13, 1, 7, Blocks.SMOOTH_QUARTZ.getDefaultState());
        d.b(12, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(13, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(14, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(15, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(16, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.b(17, 4, 7, Blocks.ORANGE_WOOL.getDefaultState());
        d.bc(13, 2, 5, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, 5, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 2, 7, Blocks.SPRUCE_FENCE.getDefaultState());
        d.bc(13, 3, 7, Blocks.SPRUCE_FENCE.getDefaultState());
        d.b(12, 3, 6, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
        d.b(17, 1, -7, Blocks.BOOKSHELF.getDefaultState());
        d.b(17, 2, -7, Blocks.BOOKSHELF.getDefaultState());
        d.b(17, 1, -5, Blocks.BOOKSHELF.getDefaultState());
        d.b(17, 2, -5, Blocks.BOOKSHELF.getDefaultState());
        d.b(17, 1, -6, Blocks.AMETHYST_BLOCK.getDefaultState());
        d.b(17, 2, -6, Blocks.AMETHYST_CLUSTER.getDefaultState());
        d.mesa(17, 1, -1);
        d.b(17, 2, -1, Blocks.BREWING_STAND.getDefaultState());
        d.b(17, 1, 1, Blocks.WATER_CAULDRON.getDefaultState().with(net.minecraft.block.LeveledCauldronBlock.LEVEL, 3));
        d.b(17, 1, 5, Blocks.RAW_IRON_BLOCK.getDefaultState());
        d.b(17, 1, 7, Blocks.RAW_GOLD_BLOCK.getDefaultState());
        d.b(17, 2, 7, Blocks.RAW_COPPER_BLOCK.getDefaultState());
        d.b(-14, 1, 10, Blocks.BARREL.getDefaultState());
        d.b(-15, 1, 11, Blocks.CAULDRON.getDefaultState());
        d.b(-12, 1, 12, Blocks.COMPOSTER.getDefaultState());
        d.b(-10, 1, 13, Blocks.COMPOSTER.getDefaultState());
        d.deco(10, 1, 10, ModBloques.CAMA_GATO, 0, -1);
        d.deco(12, 1, 11, ModBloques.CAMA_GATO, 0, -1);
        d.deco(14, 1, 9, ModBloques.RASCADOR, -1, 0);
        d.deco(9, 1, 12, ModBloques.PELUCHE_GATO, 0, -1);
        d.deco(16, 1, 2, ModBloques.MACETA_GATERA, -1, 0);
        d.alfombras(1, Blocks.RED_CARPET, -1, -19, 1, -12);
        d.alfombras(1, Blocks.CYAN_CARPET, -15, -5, -12, 3);
        d.alfombras(1, Blocks.LIGHT_BLUE_CARPET, 8, 8, 15, 13);

        // ---------- Piso 2 ----------
        d.pared(-101.25, 10, ModBloques.CUADRO_GATO);
        d.pared(101.25, 10, ModBloques.CUADRO_GATO);
        d.pared(-78.75, 10, ModBloques.CUADRO_GATO);
        d.pared(78.75, 10, ModBloques.CUADRO_GATO);
        d.pared(-33.75, 10, ModBloques.CUADRO_GATO);
        d.pared(-56.25, 10, ModBloques.CUADRO_GATO);
        d.pared(33.75, 10, ModBloques.CUADRO_GATO);
        d.pared(123.75, 10, ModBloques.PANTALLA_NOTICIAS);
        d.b(-4, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-4, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-2, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-1, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(0, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(1, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(2, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(3, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, -4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, -3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, -2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, -1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, 0, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, 1, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, 2, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, 3, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(4, 7, 4, ModBloques.PISTA_BAILE.getDefaultState());
        d.b(-3, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-3, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-3, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-2, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-2, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-2, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-1, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-1, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(-1, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.b(0, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(0, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(0, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.b(1, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(1, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(1, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.b(2, 7, 6, Blocks.BLACK_WOOL.getDefaultState());
        d.b(2, 7, 7, Blocks.BLACK_WOOL.getDefaultState());
        d.b(2, 7, 8, Blocks.BLACK_WOOL.getDefaultState());
        d.colocar(-1, 8, 6, d.estado(ModBloques.MESA_DJ, 0, -1));
        d.b(-3, 8, 6, Blocks.JUKEBOX.getDefaultState());
        d.b(-3, 9, 6, Blocks.NOTE_BLOCK.getDefaultState());
        d.b(2, 8, 6, Blocks.JUKEBOX.getDefaultState());
        d.b(2, 9, 6, Blocks.NOTE_BLOCK.getDefaultState());
        d.silla(-3, 8, -6, 0, 1);
        d.silla(-2, 8, -6, 0, 1);
        d.silla(-1, 8, -6, 0, 1);
        d.silla(1, 8, -6, 0, 1);
        d.silla(2, 8, -6, 0, 1);
        d.silla(3, 8, -6, 0, 1);
        d.silla(-6, 8, -2, 1, 0);
        d.silla(6, 8, -2, -1, 0);
        d.silla(-6, 8, -1, 1, 0);
        d.silla(6, 8, -1, -1, 0);
        d.silla(-6, 8, 0, 1, 0);
        d.silla(6, 8, 0, -1, 0);
        d.silla(-6, 8, 1, 1, 0);
        d.silla(6, 8, 1, -1, 0);
        d.silla(-6, 8, 2, 1, 0);
        d.silla(6, 8, 2, -1, 0);
        d.deco(-7, 8, -7, ModBloques.LAMPARA_GATO, 0, 1);
        d.deco(7, 8, -7, ModBloques.LAMPARA_GATO, 0, 1);
        d.deco(-7, 8, 7, ModBloques.LAMPARA_GATO, 0, -1);
        d.deco(7, 8, 7, ModBloques.LAMPARA_GATO, 0, -1);
        d.deco(-17, 8, 0, ModBloques.MACETA_GATERA, 1, 0);
        d.deco(17, 8, 0, ModBloques.MACETA_GATERA, -1, 0);
        d.bc(-12, 8, -8, Blocks.SPRUCE_FENCE.getDefaultState());
        d.deco(-12, 9, -8, ModBloques.CUADRO_GATO, 1, 0);
        d.bc(-14, 8, -10, Blocks.SPRUCE_FENCE.getDefaultState());
        d.deco(-14, 9, -10, ModBloques.CUADRO_GATO, 1, 0);
        d.mesa(-15, 8, -6);
        d.deco(-15, 9, -6, ModBloques.TAZA_GATO, 1, 0);
        d.mesa(-16, 8, -5);
        d.deco(-16, 9, -5, ModBloques.LAMPARA_GATO, 1, 0);
        d.mirando(16, 8, -10, Blocks.SMOKER.getDefaultState(), -1, 0);
        d.mirando(16, 8, -9, Blocks.FURNACE.getDefaultState(), -1, 0);
        d.mesa(16, 8, -8);
        d.mesa(16, 8, -7);
        d.deco(16, 9, -7, ModBloques.TAZA_GATO, -1, 0);
        d.b(16, 8, -6, Blocks.BARREL.getDefaultState());
        d.b(14, 8, -12, Blocks.WATER_CAULDRON.getDefaultState().with(net.minecraft.block.LeveledCauldronBlock.LEVEL, 3));
        d.mesa(11, 8, -8);
        d.deco(11, 9, -8, ModBloques.TAZA_GATO, 1, 0);
        d.mesa(11, 8, -7);
        d.silla(10, 8, -8, 1, 0);
        d.silla(10, 8, -7, 1, 0);
        d.silla(12, 8, -8, -1, 0);
        d.silla(12, 8, -7, -1, 0);
        d.deco(-14, 8, 7, ModBloques.CAMA_GATO, 0, 1);
        d.deco(-12, 8, 9, ModBloques.CAMA_GATO, 0, 1);
        d.deco(-14, 8, 10, ModBloques.CAMA_GATO, 0, 1);
        d.deco(-10, 8, 11, ModBloques.RASCADOR, 0, -1);
        d.deco(-16, 8, 8, ModBloques.RASCADOR, 1, 0);
        d.deco(-11, 8, 6, ModBloques.PELUCHE_GATO, 0, -1);
        d.deco(-13, 8, 11, ModBloques.PELUCHE_GATO, 0, -1);
        d.mesa(15, 8, 6);
        d.b(15, 9, 6, Blocks.BREWING_STAND.getDefaultState());
        d.mesa(15, 8, 7);
        d.mesa(15, 8, 8);
        d.deco(15, 9, 8, ModBloques.LAMPARA_GATO, -1, 0);
        d.b(16, 8, 9, Blocks.BOOKSHELF.getDefaultState());
        d.b(16, 9, 9, Blocks.BOOKSHELF.getDefaultState());
        d.b(12, 8, 11, Blocks.WATER_CAULDRON.getDefaultState().with(net.minecraft.block.LeveledCauldronBlock.LEVEL, 3));
        d.b(10, 8, 11, Blocks.IRON_BLOCK.getDefaultState());
        d.b(10, 9, 11, Blocks.LIGHTNING_ROD.getDefaultState());
        d.pintura(8, -15, -12, -10, -6);
        d.alfombras(8, Blocks.PINK_CARPET, -16, 5, -10, 12);
        d.alfombras(8, Blocks.WHITE_CARPET, 10, 5, 15, 11);

        // ---------- Piso 3: casino ----------
        d.colocar(-15, 15, -7, d.estado(ModBloques.TRAGAMONEDAS_AZUL, 1, 0));
        d.colocar(15, 15, -7, d.estado(ModBloques.TRAGAMONEDAS_MORADA, -1, 0));
        d.colocar(-15, 15, -3, d.estado(ModBloques.TRAGAMONEDAS_AZUL, 1, 0));
        d.colocar(15, 15, -3, d.estado(ModBloques.TRAGAMONEDAS_MORADA, -1, 0));
        d.colocar(-15, 15, 1, d.estado(ModBloques.TRAGAMONEDAS_AZUL, 1, 0));
        d.colocar(15, 15, 1, d.estado(ModBloques.TRAGAMONEDAS_MORADA, -1, 0));
        d.colocar(-15, 15, 5, d.estado(ModBloques.TRAGAMONEDAS_AZUL, 1, 0));
        d.colocar(15, 15, 5, d.estado(ModBloques.TRAGAMONEDAS_MORADA, -1, 0));
        d.colocar(-13, 15, 11, d.estado(ModBloques.TRAGAMONEDAS_GRIS, 0, -1));
        d.colocar(-9, 15, 11, d.estado(ModBloques.TRAGAMONEDAS_GRIS, 0, -1));
        d.colocar(9, 15, 11, d.estado(ModBloques.TRAGAMONEDAS_GRIS, 0, -1));
        d.colocar(13, 15, 11, d.estado(ModBloques.TRAGAMONEDAS_GRIS, 0, -1));
        d.b(-3, 15, 0, ModBloques.RULETA.getDefaultState());
        d.b(3, 15, 0, ModBloques.RULETA.getDefaultState());
        d.colocar(-8, 15, -12, d.estado(ModBloques.BANCO, 0, 1));
        d.b(-7, 15, -7, Blocks.GOLD_BLOCK.getDefaultState());
        d.b(-7, 16, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 17, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 18, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 19, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 20, -7, Blocks.SEA_LANTERN.getDefaultState());
        d.b(7, 15, -7, Blocks.GOLD_BLOCK.getDefaultState());
        d.b(7, 16, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 17, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 18, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 19, -7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 20, -7, Blocks.SEA_LANTERN.getDefaultState());
        d.b(-7, 15, 7, Blocks.GOLD_BLOCK.getDefaultState());
        d.b(-7, 16, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 17, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 18, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 19, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(-7, 20, 7, Blocks.SEA_LANTERN.getDefaultState());
        d.b(7, 15, 7, Blocks.GOLD_BLOCK.getDefaultState());
        d.b(7, 16, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 17, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 18, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 19, 7, Blocks.QUARTZ_PILLAR.getDefaultState());
        d.b(7, 20, 7, Blocks.SEA_LANTERN.getDefaultState());
        d.deco(-11, 15, 8, ModBloques.LAMPARA_GATO, 0, -1);
        d.deco(11, 15, 8, ModBloques.LAMPARA_GATO, 0, -1);
        d.deco(-11, 15, -9, ModBloques.MACETA_GATERA, 0, 1);
        d.deco(11, 15, -9, ModBloques.MACETA_GATERA, 0, 1);
        d.alfombraCasino(15);

        // ---------- Techo ----------
        d.tarima(-6, 21, 3);
        d.tarima(-6, 21, 4);
        d.tarima(-6, 21, 5);
        d.tarima(-6, 21, 6);
        d.tarima(-6, 21, 7);
        d.tarima(-6, 21, 8);
        d.tarima(-6, 21, 9);
        d.tarima(-6, 21, 10);
        d.tarima(-6, 21, 11);
        d.tarima(-5, 21, 3);
        d.tarima(-5, 21, 4);
        d.tarima(-5, 21, 5);
        d.tarima(-5, 21, 6);
        d.tarima(-5, 21, 7);
        d.tarima(-5, 21, 8);
        d.tarima(-5, 21, 9);
        d.tarima(-5, 21, 10);
        d.tarima(-5, 21, 11);
        d.tarima(-4, 21, 3);
        d.tarima(-4, 21, 4);
        d.tarima(-4, 21, 5);
        d.tarima(-4, 21, 6);
        d.tarima(-4, 21, 7);
        d.tarima(-4, 21, 8);
        d.tarima(-4, 21, 9);
        d.tarima(-4, 21, 10);
        d.tarima(-4, 21, 11);
        d.tarima(-3, 21, 3);
        d.tarima(-3, 21, 4);
        d.tarima(-3, 21, 5);
        d.tarima(-3, 21, 6);
        d.tarima(-3, 21, 7);
        d.tarima(-3, 21, 8);
        d.tarima(-3, 21, 9);
        d.tarima(-3, 21, 10);
        d.tarima(-3, 21, 11);
        d.tarima(-2, 21, 3);
        d.tarima(-2, 21, 4);
        d.tarima(-2, 21, 5);
        d.tarima(-2, 21, 6);
        d.tarima(-2, 21, 7);
        d.tarima(-2, 21, 8);
        d.tarima(-2, 21, 9);
        d.tarima(-2, 21, 10);
        d.tarima(-2, 21, 11);
        d.tarima(-1, 21, 3);
        d.tarima(-1, 21, 4);
        d.tarima(-1, 21, 5);
        d.tarima(-1, 21, 6);
        d.tarima(-1, 21, 7);
        d.tarima(-1, 21, 8);
        d.tarima(-1, 21, 9);
        d.tarima(-1, 21, 10);
        d.tarima(-1, 21, 11);
        d.tarima(0, 21, 3);
        d.tarima(0, 21, 4);
        d.tarima(0, 21, 5);
        d.tarima(0, 21, 6);
        d.tarima(0, 21, 7);
        d.tarima(0, 21, 8);
        d.tarima(0, 21, 9);
        d.tarima(0, 21, 10);
        d.tarima(0, 21, 11);
        d.tarima(1, 21, 3);
        d.tarima(1, 21, 4);
        d.tarima(1, 21, 5);
        d.tarima(1, 21, 6);
        d.tarima(1, 21, 7);
        d.tarima(1, 21, 8);
        d.tarima(1, 21, 9);
        d.tarima(1, 21, 10);
        d.tarima(1, 21, 11);
        d.tarima(2, 21, 3);
        d.tarima(2, 21, 4);
        d.tarima(2, 21, 5);
        d.tarima(2, 21, 6);
        d.tarima(2, 21, 7);
        d.tarima(2, 21, 8);
        d.tarima(2, 21, 9);
        d.tarima(2, 21, 10);
        d.tarima(2, 21, 11);
        d.tarima(3, 21, 3);
        d.tarima(3, 21, 4);
        d.tarima(3, 21, 5);
        d.tarima(3, 21, 6);
        d.tarima(3, 21, 7);
        d.tarima(3, 21, 8);
        d.tarima(3, 21, 9);
        d.tarima(3, 21, 10);
        d.tarima(3, 21, 11);
        d.tarima(4, 21, 3);
        d.tarima(4, 21, 4);
        d.tarima(4, 21, 5);
        d.tarima(4, 21, 6);
        d.tarima(4, 21, 7);
        d.tarima(4, 21, 8);
        d.tarima(4, 21, 9);
        d.tarima(4, 21, 10);
        d.tarima(4, 21, 11);
        d.tarima(5, 21, 3);
        d.tarima(5, 21, 4);
        d.tarima(5, 21, 5);
        d.tarima(5, 21, 6);
        d.tarima(5, 21, 7);
        d.tarima(5, 21, 8);
        d.tarima(5, 21, 9);
        d.tarima(5, 21, 10);
        d.tarima(5, 21, 11);
        d.tarima(6, 21, 3);
        d.tarima(6, 21, 4);
        d.tarima(6, 21, 5);
        d.tarima(6, 21, 6);
        d.tarima(6, 21, 7);
        d.tarima(6, 21, 8);
        d.tarima(6, 21, 9);
        d.tarima(6, 21, 10);
        d.tarima(6, 21, 11);
        d.colocar(2, 22, 2, d.estado(ModBloques.TELE_PORTAL, 0, 1));
        d.silla(-4, 22, 8, 0, -1);
        d.silla(-4, 22, 10, 0, -1);
        d.silla(-3, 22, 8, 0, -1);
        d.silla(-3, 22, 10, 0, -1);
        d.silla(-2, 22, 8, 0, -1);
        d.silla(-2, 22, 10, 0, -1);
        d.silla(-1, 22, 8, 0, -1);
        d.silla(-1, 22, 10, 0, -1);
        d.silla(1, 22, 8, 0, -1);
        d.silla(1, 22, 10, 0, -1);
        d.silla(2, 22, 8, 0, -1);
        d.silla(2, 22, 10, 0, -1);
        d.silla(3, 22, 8, 0, -1);
        d.silla(3, 22, 10, 0, -1);
        d.silla(4, 22, 8, 0, -1);
        d.silla(4, 22, 10, 0, -1);
        d.farol(-6, 22, 3);
        d.farol(6, 22, 3);
        d.farol(-6, 22, 11);
        d.farol(6, 22, 11);
    }

    static void gatos(ServerWorld w, ConstructorCentro.Sistema s) {
        gato(w, s, GatoCuboEntity.RECEPCIONISTA, 0.0, 1, -9.0, 0, -1);   // Recepcionista
        gato(w, s, GatoCuboEntity.PERIODISTA, -11.0, 1, -11.0, 0, -1);   // Periodista
        gato(w, s, GatoCuboEntity.CONSERJE, -12.0, 1, 9.0, 0, 1);   // Conserje
        gato(w, s, GatoCuboEntity.VEND_PASIVAS, 15.0, 1, -6.0, -1, 0);   // Mago Pasivas
        gato(w, s, GatoCuboEntity.VEND_CORAZONES, 15.0, 1, 0.0, -1, 0);   // Enfermero
        gato(w, s, GatoCuboEntity.VEND_MINERALES, 15.0, 1, 6.0, -1, 0);   // Minero
        gato(w, s, GatoCuboEntity.GRANJERO, 6.0, 1, -12.0, 0, -1);   // Granjero
        gato(w, s, GatoCuboEntity.GATO_GATO, -13.0, 1, -1.0, 0, -1);   // Gato Gato
        gato(w, s, GatoCuboEntity.DETECTIVE, -8.0, 1, 4.0, 0, -1);   // Detective
        gato(w, s, GatoCuboEntity.PERRO, 6.0, 1, 3.0, 0, -1);   // Gato Perro
        gato(w, s, GatoCuboEntity.PLANO, -5.0, 1, 8.0, 0, -1);   // Gato 2D
        gato(w, s, GatoCuboEntity.NERD, 9.0, 1, 9.0, 0, -1);   // Nerd
        gato(w, s, GatoCuboEntity.DJ, -0.5, 8, 7.0, 0, -1);   // DJ Miaumix
        gato(w, s, GatoCuboEntity.FIESTERA, 0.0, 8, 0.0, 0, -1);   // Fiestera
        gato(w, s, GatoCuboEntity.KATEM, -11.0, 8, -9.0, 0, -1);   // Katemcita
        gato(w, s, GatoCuboEntity.CHEF, 13.0, 8, -8.0, -1, 0);   // Chef
        gato(w, s, GatoCuboEntity.MADRE, -12.0, 8, 7.0, 0, -1);   // Mamá
        gato(w, s, GatoCuboEntity.GATITO, -11.0, 8, 8.0, 0, -1);   // Gatito
        gato(w, s, GatoCuboEntity.CIENTIFICA, 13.0, 8, 7.0, 1, 0);   // Científica
        gato(w, s, GatoCuboEntity.ROBOT, 12.0, 8, 9.0, 0, -1);   // GATO-BOT
        gato(w, s, GatoCuboEntity.FUJOSHI, -8.0, 8, -3.0, 1, 0);   // Fujoshi
        gato(w, s, GatoCuboEntity.ANIME, 8.0, 8, -3.0, -1, 0);   // Kawaii
        gato(w, s, GatoCuboEntity.ROMANTICO, -8.0, 8, 3.0, 1, 0);   // Romántico
        gato(w, s, GatoCuboEntity.MILLONARIO, 8.0, 8, 3.0, -1, 0);   // Millonario
        gato(w, s, GatoCuboEntity.ELEGANTE, 0.0, 8, -9.0, 0, 1);   // Elegante
        gato(w, s, GatoCuboEntity.PRINCIPAL, -4.0, 22, 4.0, 0, 1);   // EL GATO
    }

    private static void gato(ServerWorld w, ConstructorCentro.Sistema s, int tipo, double x, int y, double z, int a, int c) {
        GatoCuboEntity g = com.centrodesinformacion.desinformados.entidad.ModEntidades.GATO_CUBO.create(w);
        if (g == null) return;
        Vec3d p = s.punto(x, y, z);
        float yaw = s.dir(a, c).asRotation();
        g.refreshPositionAndAngles(p.x, p.y, p.z, yaw, 0f);
        g.setHeadYaw(yaw);
        g.setBodyYaw(yaw);
        g.configurar(tipo, BlockPos.ofFloored(p));
        w.spawnEntity(g);
    }

    /** Ayudas para colocar en coordenadas locales. */
    private record D(ServerWorld w, ConstructorCentro.Sistema s, List<BlockPos> conectar) {
        void b(int x, int y, int z, BlockState st) {
            w.setBlockState(s.at(x, y, z), st, Block.NOTIFY_LISTENERS);
        }

        /** Vallas, muros, escalones...: se conectan con los vecinos al final. */
        void bc(int x, int y, int z, BlockState st) {
            b(x, y, z, st);
            conectar.add(s.at(x, y, z));
        }

        BlockState estado(Block bl, int a, int c) {
            return bl.getDefaultState().with(Properties.HORIZONTAL_FACING, s.dir(a, c));
        }

        void mirando(int x, int y, int z, BlockState st, int a, int c) {
            b(x, y, z, st.with(Properties.HORIZONTAL_FACING, s.dir(a, c)));
        }

        void deco(int x, int y, int z, Block bl, int a, int c) {
            b(x, y, z, estado(bl, a, c));
        }

        /** Silla (escalón de abeto): (a, c) es hacia dónde mira el que se sienta; el respaldo queda detrás. */
        void silla(int x, int y, int z, int a, int c) {
            bc(x, y, z, Blocks.SPRUCE_STAIRS.getDefaultState().with(StairsBlock.FACING, s.dir(-a, -c)));
        }

        void mesa(int x, int y, int z) {
            b(x, y, z, Blocks.SPRUCE_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP));
        }

        void farol(int x, int y, int z) {
            bc(x, y, z, Blocks.SPRUCE_FENCE.getDefaultState());
            b(x, y + 1, z, Blocks.LANTERN.getDefaultState());
        }

        /** Tarima de madera en el techo (las luces del techo se quedan). */
        void tarima(int x, int y, int z) {
            if (!w.getBlockState(s.at(x, y, z)).isOf(ModBloques.LUZ_INDUSTRIAL)) b(x, y, z, Blocks.SPRUCE_PLANKS.getDefaultState());
        }

        /** Muebles de varios bloques (recepción, mesa de DJ, tragamonedas, banco, tele): se ponen como si los pusiera un jugador. */
        void colocar(int x, int y, int z, BlockState st) {
            BlockPos q = s.at(x, y, z);
            w.setBlockState(q, st, Block.NOTIFY_ALL);
            st.getBlock().onPlaced(w, q, st, null, ItemStack.EMPTY);
        }

        /** Decoración colgada en la pared redonda, en ese ángulo (0 = la entrada, 90 = derecha), mirando hacia dentro. */
        void pared(double grados, int y, Block bl) {
            double a = Math.toRadians(grados), sx = Math.sin(a), sz = -Math.cos(a);
            int lx = 0, lz = 0;
            boolean hay = false;
            for (double r = 10; r <= ConstructorCentro.RADIO + 1; r += 0.25) {
                int dx = (int) Math.round(sx * r), dz = (int) Math.round(sz * r);
                if (!w.getBlockState(s.at(dx, y, dz)).isAir()) break;
                lx = dx; lz = dz; hay = true;
            }
            if (!hay) return;
            int fa = Math.abs(lx) >= Math.abs(lz) ? -Integer.signum(lx) : 0;
            int fc = Math.abs(lx) >= Math.abs(lz) ? 0 : -Integer.signum(lz);
            BlockPos q = s.at(lx, y, lz);
            if (w.getBlockState(q.offset(s.dir(fa, fc).getOpposite())).isAir()) return;    // no hay pared justo detrás
            w.setBlockState(q, estado(bl, fa, fc), Block.NOTIFY_LISTENERS);
        }

        private boolean dentro(int x, int z) {
            return x * x + z * z <= 18.6 * 18.6;
        }

        /** Alfombra en un rectángulo, solo donde hay aire con suelo debajo (no pisa los muebles). */
        void alfombras(int y, Block bl, int x0, int z0, int x1, int z1) {
            for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
                if (!dentro(x, z)) continue;
                BlockPos q = s.at(x, y, z);
                if (w.getBlockState(q).isAir() && w.getBlockState(q.down()).isSolidBlock(w, q.down())) w.setBlockState(q, bl.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }

        /** Manchas de pintura de colores en el estudio de Katemcita. */
        void pintura(int y, int x0, int z0, int x1, int z1) {
            Block[] colores = {Blocks.RED_CARPET, Blocks.YELLOW_CARPET, Blocks.LIME_CARPET, Blocks.LIGHT_BLUE_CARPET,
                    Blocks.MAGENTA_CARPET, Blocks.ORANGE_CARPET, Blocks.WHITE_CARPET, Blocks.PINK_CARPET};
            for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
                if ((x * 7 + z * 13) % 3 == 0) continue;                         // huecos entre manchas
                alfombras(y, colores[Math.floorMod(x * 3 + z * 5, colores.length)], x, z, x, z);
            }
        }

        /** El casino entero de alfombra roja, con un anillo dorado alrededor de las ruletas. */
        void alfombraCasino(int y) {
            for (int x = -19; x <= 19; x++) for (int z = -19; z <= 19; z++) {
                double r = Math.sqrt(x * x + z * z);
                alfombras(y, r > 9.5 && r <= 10.5 ? Blocks.YELLOW_CARPET : Blocks.RED_CARPET, x, z, x, z);
            }
        }
    }
}

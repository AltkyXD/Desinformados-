package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;

/**
 * Mobs bloqueados: no pueden existir en el mundo hasta que un evento los desbloquee.
 * Sirve para mobs del mod y de otros mods. Se puede bloquear uno ("mod:mob") o un mod entero ("mod:*").
 */
public class Mobs {
    /** Los mobs con esta etiqueta los ha invocado un evento: existen aunque su tipo esté bloqueado. */
    public static final String MARCA_EVENTO = "desinfo_evento";

    /** Mobs del mod que no aparecen solos y nunca están bloqueados. */
    private static final java.util.Set<String> SIN_BLOQUEO = java.util.Set.of("desinformados:ale", "desinformados:travensano", "desinformados:ulises", "desinformados:angel",
            "desinformados:zombie_estatica", "desinformados:esqueleto_estatica", "desinformados:arana_estatica", "desinformados:creeper_estatica");

    /** Bloqueo según dónde: en el Interior de la Tele y en la Redacción todos los mobs del mod están libres. */
    public static boolean bloqueadoEn(net.minecraft.world.WorldAccess mundo, EntityType<?> tipo) {
        if (com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(mundo)) return false;
        return mundo.getServer() != null && estaBloqueado(mundo.getServer(), tipo);
    }

    public static boolean estaBloqueado(MinecraftServer server, EntityType<?> tipo) {
        Identifier id = Registries.ENTITY_TYPE.getId(tipo);
        EstadoServidor estado = EstadoServidor.get(server);
        if (SIN_BLOQUEO.contains(id.toString())) return false;
        if (id.getNamespace().equals(Desinformados.MOD_ID) && !estado.getMobsDesbloqueados().contains(id.toString())) return true;
        return estado.getMobsBloqueados().contains(id.toString())
                || estado.getMobsBloqueados().contains(id.getNamespace() + ":*")
                        && !estado.getMobsDesbloqueados().contains(id.toString());
    }

    public static void registrar() {
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (entidad instanceof MobEntity && !entidad.getCommandTags().contains(MARCA_EVENTO)
                    && !com.centrodesinformacion.desinformados.dimension.Dimensiones.esDelMod(mundo.getRegistryKey())
                    && estaBloqueado(mundo.getServer(), entidad.getType())) {
                Tareas.programar(1, entidad::discard);
            }
        });
    }
}

package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;

/**
 * Mobs bloqueados: no pueden existir en el mundo hasta que un evento los desbloquee.
 * Sirve para mobs del mod y de otros mods. Se puede bloquear uno ("mod:mob") o un mod entero ("mod:*").
 */
public class Mobs {
    public static boolean estaBloqueado(MinecraftServer server, EntityType<?> tipo) {
        Identifier id = Registries.ENTITY_TYPE.getId(tipo);
        EstadoServidor estado = EstadoServidor.get(server);
        if (id.getNamespace().equals(Desinformados.MOD_ID) && !estado.getMobsDesbloqueados().contains(id.toString())) return true;
        return estado.getMobsBloqueados().contains(id.toString())
                || estado.getMobsBloqueados().contains(id.getNamespace() + ":*")
                        && !estado.getMobsDesbloqueados().contains(id.toString());
    }

    public static void registrar() {
        ServerEntityEvents.ENTITY_LOAD.register((entidad, mundo) -> {
            if (entidad instanceof MobEntity && estaBloqueado(mundo.getServer(), entidad.getType())) {
                Tareas.programar(1, entidad::discard);
            }
        });
    }
}

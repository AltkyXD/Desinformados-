package com.centrodesinformacion.desinformados;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Noche de Sangre (tele amarilla). Desde que sale, cada noche del Overworld tiene un 25 % de ser Noche de Sangre:
 * mientras dura, el límite de monstruos del Overworld se triplica (SpawnGroupMixin), así que aparecen el triple.
 * Se avisa al anochecer (título, sonido y barra roja) y termina al amanecer (o si se duerme la noche).
 * /desinfo noche_sangre forzar | parar  — para los admins (forzar: ahora si ya es de noche; si no, la próxima noche).
 */
public final class NocheSangre {
    private NocheSangre() {}

    public static final String ID = "noche_sangre";
    public static final float PROBABILIDAD = 0.25f;
    public static final int MULTIPLICADOR = 3;

    private static final String TIRADA = "sys:ns_tirada:";      // + número de día: esa noche ya se sorteó
    private static final String ACTIVA = "sys:ns_activa:";      // + número de día: esa noche es de sangre
    private static final String FORZADA = "sys:ns_forzada";     // la próxima noche lo será seguro
    private static final String MANUAL = "sys:ns_manual";       // la de ahora la forzó un admin (no depende de la tele)

    private static final int ANOCHECER = 13000, AMANECER = 23000;

    /** Lo lee SpawnGroupMixin: true solo mientras se está procesando el Overworld en una Noche de Sangre. */
    public static volatile boolean triplicar = false;
    private static boolean activaAhora = false;
    private static ServerBossBar barra;

    static void evento() {
        Eventos.amarillo(ID, "¡Llegan las Noches de Sangre!",
                "Desde ahora, cada noche tiene un 25 % de ser Noche de Sangre: hasta que amanezca aparecen el TRIPLE de monstruos. "
                        + "Se avisa al anochecer con una barra roja. Dormir la noche la termina.",
                "El Centro de Desinformación ha externalizado la luna a un proveedor más barato. A veces sale roja, y cuando sale roja, "
                        + "los monstruos vienen con acompañantes. El proveedor dice que es una característica.",
                server -> EstadoServidor.get(server).agregarCambio(ID));
    }

    public static void registrar() {
        ServerTickEvents.START_WORLD_TICK.register(mundo -> triplicar = activaAhora && mundo.getRegistryKey() == World.OVERWORLD);
        ServerTickEvents.END_WORLD_TICK.register(mundo -> triplicar = false);
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            actualizar(server);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            activaAhora = false;
            triplicar = false;
            if (barra != null) barra.clearPlayers();
            barra = null;
        });
        CommandRegistrationCallback.EVENT.register((d, acceso, entorno) -> d.register(literal("desinfo").requires(s -> s.hasPermissionLevel(2))
                .then(literal("noche_sangre")
                        .then(literal("forzar").executes(c -> {
                            MinecraftServer s = c.getSource().getServer();
                            EstadoServidor e = EstadoServidor.get(s);
                            long t = s.getOverworld().getTimeOfDay();
                            if (esDeNoche(t)) {
                                empezar(s, t / 24000L, true);
                                c.getSource().sendFeedback(() -> Text.literal("Noche de Sangre en marcha.").formatted(Formatting.DARK_RED), true);
                            } else {
                                e.agregarCambio(FORZADA);
                                c.getSource().sendFeedback(() -> Text.literal("La próxima noche será Noche de Sangre.").formatted(Formatting.DARK_RED), true);
                            }
                            return 1;
                        }))
                        .then(literal("parar").executes(c -> {
                            MinecraftServer s = c.getSource().getServer();
                            EstadoServidor.get(s).quitarCambio(FORZADA);
                            terminar(s, false);
                            c.getSource().sendFeedback(() -> Text.literal("Noche de Sangre parada.").formatted(Formatting.YELLOW), true);
                            return 1;
                        })))));
    }

    private static boolean esDeNoche(long tiempo) {
        long t = Math.floorMod(tiempo, 24000L);
        return t >= ANOCHECER && t < AMANECER;
    }

    private static void actualizar(MinecraftServer server) {
        ServerWorld mundo = server.getOverworld();
        if (mundo == null) return;
        EstadoServidor e = EstadoServidor.get(server);
        long tiempo = mundo.getTimeOfDay();
        long dia = Math.floorDiv(tiempo, 24000L);

        if (!esDeNoche(tiempo)) {                                     // de día: si había una, se acaba
            if (activaAhora || hayMarca(e, ACTIVA)) terminar(server, true);
            return;
        }
        if (e.tieneCambio(ACTIVA + dia)) {                            // ya es de sangre (p. ej. tras reiniciar el servidor)
            if (!e.tieneCambio(ID) && !e.tieneCambio(MANUAL)) {       // se quitó la tele (/desinfo desactivar todo): se acaba ya
                terminar(server, false);
                return;
            }
            if (!activaAhora) empezarSinAviso(server);
            barra(server, tiempo);
            return;
        }
        if (activaAhora) terminar(server, false);                     // marca de otro día: fuera
        if (e.tieneCambio(TIRADA + dia)) return;                      // esta noche ya se sorteó y no tocó

        boolean forzada = e.tieneCambio(FORZADA);
        if (!forzada && !e.tieneCambio(ID)) return;                   // sin la tele, nada
        e.getCambios().removeIf(c -> c.startsWith(TIRADA));
        e.agregarCambio(TIRADA + dia);
        if (forzada || ThreadLocalRandom.current().nextFloat() < PROBABILIDAD) empezar(server, dia, forzada);
    }

    private static boolean hayMarca(EstadoServidor e, String prefijo) {
        for (String c : e.getCambios()) if (c.startsWith(prefijo)) return true;
        return false;
    }

    private static void empezar(MinecraftServer server, long dia, boolean manual) {
        EstadoServidor e = EstadoServidor.get(server);
        e.quitarCambio(FORZADA);
        if (manual) e.agregarCambio(MANUAL);
        else e.quitarCambio(MANUAL);
        e.getCambios().removeIf(c -> c.startsWith(ACTIVA) || c.startsWith(TIRADA));
        e.agregarCambio(TIRADA + dia);                               // esta noche ya está sorteada: si se para, no se vuelve a sortear
        e.agregarCambio(ACTIVA + dia);
        e.markDirty();
        empezarSinAviso(server);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            p.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 70, 20));
            p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("Esta noche aparecen el triple de monstruos").formatted(Formatting.RED)));
            p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("NOCHE DE SANGRE").formatted(Formatting.DARK_RED, Formatting.BOLD)));
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.MASTER, 1f, 0.6f);
        }
        server.getPlayerManager().broadcast(Text.literal("☾ La luna se ha teñido de rojo: ¡Noche de Sangre! Hasta el amanecer aparecen el triple de monstruos.")
                .formatted(Formatting.DARK_RED), false);
    }

    private static void empezarSinAviso(MinecraftServer server) {
        activaAhora = true;
        if (barra == null) barra = new ServerBossBar(Text.literal("☾ Noche de Sangre").formatted(Formatting.DARK_RED),
                BossBar.Color.RED, BossBar.Style.NOTCHED_10);
        barra(server, server.getOverworld().getTimeOfDay());
    }

    /** Barra roja para los que están en el Overworld; se vacía hasta el amanecer. */
    private static void barra(MinecraftServer server, long tiempo) {
        if (barra == null) return;
        long t = Math.floorMod(tiempo, 24000L);
        barra.setPercent(Math.max(0f, Math.min(1f, (AMANECER - t) / (float) (AMANECER - ANOCHECER))));
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.getWorld().getRegistryKey() == World.OVERWORLD) barra.addPlayer(p);
            else barra.removePlayer(p);
        }
    }

    private static void terminar(MinecraftServer server, boolean avisar) {
        boolean estaba = activaAhora;
        activaAhora = false;
        triplicar = false;
        EstadoServidor e = EstadoServidor.get(server);
        e.getCambios().removeIf(c -> c.startsWith(ACTIVA));
        e.quitarCambio(MANUAL);
        e.markDirty();
        if (barra != null) barra.clearPlayers();
        if (avisar && estaba)
            server.getPlayerManager().broadcast(Text.literal("☀ Amanece. La Noche de Sangre ha terminado.").formatted(Formatting.GOLD), false);
    }
}

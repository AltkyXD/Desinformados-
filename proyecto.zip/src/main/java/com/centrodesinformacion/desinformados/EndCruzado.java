package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import com.centrodesinformacion.desinformados.entidad.ModVariantes;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.HoglinEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Cambio de dificultad "end_cruzado" (otro intercambio cultural, como el de la Libreta): los mobs del End (endermen,
 * endermites, shulkers y Endermen Bromistas) aparecen en el Overworld (de noche o a oscuras) y en el Nether, y al End
 * llegan mobs del Overworld, del Nether y del Centro. Su tele sale sola en el acto 5, cuando ya se ha abierto el End.
 */
public final class EndCruzado {
    private EndCruzado() {}

    public static final String ID = "end_cruzado";
    public static final String MARCA = "desinfo_cruzado_end";
    private static final int CADA = 100;              // cada 5 s se intenta por jugador
    private static final int MAXIMO_POR_JUGADOR = 6;  // de estos mobs vivos cerca de cada jugador

    /** Del End al Overworld y al Nether. */
    private static final EntityType<?>[] DEL_END = {
            EntityType.ENDERMAN, EntityType.ENDERMAN, EntityType.ENDERMITE, EntityType.ENDERMITE, EntityType.ENDERMITE,
            EntityType.SHULKER, ModVariantes.ENDERMAN_BROMISTA};
    /** Del Overworld, del Nether y del Centro al End. */
    private static final EntityType<?>[] AL_END = {
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.SPIDER, EntityType.WITCH,
            EntityType.BLAZE, EntityType.WITHER_SKELETON, EntityType.PIGLIN, EntityType.HOGLIN, EntityType.MAGMA_CUBE,
            ModEntidades.CREEPER_OSCURO, ModEntidades.FURRO, ModEntidades.ZOMBIE_NARANJA, ModEntidades.GARABATO, ModEntidades.TRAVENSANO};

    static void evento() {
        Eventos.amarillo(ID, "¡Intercambio cultural con el End!",
                "A partir de ahora los mobs del End (endermen, endermites, shulkers y Endermen Bromistas) aparecen también en el Overworld "
                        + "(de noche y en sitios oscuros) y en el Nether. Y al End llegan mobs del Overworld, del Nether y del Centro "
                        + "(zombies, esqueletos, creepers, brujas, blazes, piglins, Creepers Oscuros, Furros, Garabatos...).",
                "Después del éxito con la Libreta, el Centro de Desinformación ha abierto una oficina de intercambio en el End. "
                        + "Los shulkers quieren ver el sol, los zombies quieren ver el vacío. El dragón no ha firmado nada, pero ya no puede protestar.",
                server -> EstadoServidor.get(server).agregarCambio(ID));
    }

    public static void registrar() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % CADA != 50) return;                                     // desfasado del de la Libreta
            if (!EstadoServidor.get(server).tieneCambio(ID)) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator() || p.isCreative()) continue;
                ServerWorld w = p.getServerWorld();
                boolean overworld = w.getRegistryKey() == World.OVERWORLD;
                boolean nether = w.getRegistryKey() == World.NETHER;
                boolean end = w.getRegistryKey() == World.END;
                if (!overworld && !nether && !end) continue;
                if (w.getRandom().nextFloat() > 0.6f) continue;
                int cerca = w.getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(48), m -> m.getCommandTags().contains(MARCA)).size();
                if (cerca >= MAXIMO_POR_JUGADOR) continue;
                EntityType<?>[] lista = end ? AL_END : DEL_END;
                intentar(w, p, lista[w.getRandom().nextInt(lista.length)], overworld);
            }
        });
    }

    private static void intentar(ServerWorld w, ServerPlayerEntity p, EntityType<?> tipo, boolean enOverworld) {
        Random r = w.getRandom();
        for (int intento = 0; intento < 12; intento++) {
            double ang = r.nextDouble() * Math.PI * 2, dist = 18 + r.nextDouble() * 22;
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist), z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
            int y0 = p.getBlockY() + r.nextInt(17) - 8;
            for (int dy = 0; dy < 12; dy++) {
                BlockPos pos = new BlockPos(x, y0 - dy, z);
                if (!sitioValido(w, pos, enOverworld)) continue;
                if (!(tipo.create(w) instanceof MobEntity m)) return;
                m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, r.nextFloat() * 360f, 0f);
                if (!w.isSpaceEmpty(m)) { m.discard(); continue; }
                m.initialize(w, w.getLocalDifficulty(pos), SpawnReason.NATURAL, null);
                if (m instanceof AbstractPiglinEntity pig) pig.setImmuneToZombification(true);   // no se convierten fuera del Nether
                if (m instanceof HoglinEntity hog) hog.setImmuneToZombification(true);
                m.addCommandTag(MARCA);
                m.addCommandTag(Mobs.MARCA_EVENTO);
                w.spawnEntity(m);
                return;
            }
        }
    }

    private static boolean sitioValido(ServerWorld w, BlockPos pos, boolean enOverworld) {
        if (!w.getWorldBorder().contains(pos) || !w.isChunkLoaded(pos)) return false;
        if (Reglas.protegido(w, pos, 0)) return false;                                           // nunca dentro de la zona del Centro
        BlockPos abajo = pos.down();
        if (!w.getBlockState(abajo).isSolidBlock(w, abajo)) return false;
        if (!w.getBlockState(pos).getCollisionShape(w, pos).isEmpty() || !w.getFluidState(pos).isEmpty()) return false;
        if (!w.getBlockState(pos.up()).getCollisionShape(w, pos.up()).isEmpty()) return false;
        if (!w.getBlockState(pos.up(2)).getCollisionShape(w, pos.up(2)).isEmpty()) return false;  // los endermen miden 3
        return !enOverworld || HostileEntity.isSpawnDark(w, pos, w.getRandom());                 // en el Overworld, de noche o a oscuras
    }
}

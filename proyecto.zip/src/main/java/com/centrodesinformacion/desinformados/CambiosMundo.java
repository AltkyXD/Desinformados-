package com.centrodesinformacion.desinformados;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 22 cambios de dificultad nuevos del mundo y de los jugadores (teles amarillas).
 * (resfriado, rachas_viento y recorte_corazones se quitaron: sus constantes y su código siguen, pero ya no hay tele que los active.)
 * Aquí están los textos de las teles y el orden; la lógica de juego está en CambiosMundoEfectos.
 * Todos son una marca en EstadoServidor: si se quita (/desinfo desactivar todo), el efecto se para solo.
 */
public final class CambiosMundo {
    private CambiosMundo() {}

    public static final String ASTILLAS = "astillas";
    public static final String DIETA_VARIADA = "dieta_variada";
    public static final String ANIMALES_CHIVATOS = "animales_chivatos";
    public static final String BECARIO_ORDENA = "becario_ordena";
    public static final String LLUVIA_ACIDA = "lluvia_acida";
    public static final String COMIDA_CADUCA = "comida_caduca";
    public static final String MENAS_ESCURRIDIZAS = "menas_escurridizas";
    public static final String MOCHILA_PESADA = "mochila_pesada";
    public static final String CUEVAS_OSCURAS = "cuevas_oscuras";
    public static final String TORMENTAS = "tormentas";
    public static final String AGUA_HELADA = "agua_helada";
    public static final String DESLUMBRAMIENTO = "deslumbramiento";
    public static final String MENAS_GAS = "menas_gas";
    public static final String RESFRIADO = "resfriado";
    public static final String ESCUDOS_CANSAN = "escudos_cansan";
    public static final String NOCHES_LARGAS = "noches_largas";
    public static final String PULMONES_PEQUENOS = "pulmones_pequenos";
    public static final String HIPO = "hipo";
    public static final String MAREO_PORTALES = "mareo_portales";
    public static final String AGOBIO_NETHER = "agobio_nether";
    public static final String RACHAS_VIENTO = "rachas_viento";
    public static final String POCIONES_AGUADAS = "pociones_aguadas";
    public static final String RAYOS_METAL = "rayos_metal";
    public static final String RECORTE_CORAZONES = "recorte_corazones";
    public static final String COHETES_DEFECTUOSOS = "cohetes_defectuosos";

    /** Ids de todos los cambios de este archivo, en el orden en que deberían salir. */
    public static final List<String> IDS = List.of(
            ASTILLAS, DIETA_VARIADA, ANIMALES_CHIVATOS,                 // 1A
            BECARIO_ORDENA, LLUVIA_ACIDA, COMIDA_CADUCA,                // 1B
            MENAS_ESCURRIDIZAS, MOCHILA_PESADA, CUEVAS_OSCURAS,         // 2A
            TORMENTAS, AGUA_HELADA, DESLUMBRAMIENTO,                    // 2B
            MENAS_GAS, ESCUDOS_CANSAN,                                  // 3A
            NOCHES_LARGAS, PULMONES_PEQUENOS, HIPO,                     // 3B
            MAREO_PORTALES, AGOBIO_NETHER,                              // 4A (Nether abierto)
            POCIONES_AGUADAS, RAYOS_METAL,                              // 4B
            COHETES_DEFECTUOSOS);                                       // 5

    /** En qué parte de la serie debería salir cada uno (las partes de ProgramaTeles.LISTA). */
    public static final Map<String, String> ACTO = Map.ofEntries(
            Map.entry(ASTILLAS, "1A"), Map.entry(DIETA_VARIADA, "1A"), Map.entry(ANIMALES_CHIVATOS, "1A"),
            Map.entry(BECARIO_ORDENA, "1B"), Map.entry(LLUVIA_ACIDA, "1B"), Map.entry(COMIDA_CADUCA, "1B"),
            Map.entry(MENAS_ESCURRIDIZAS, "2A"), Map.entry(MOCHILA_PESADA, "2A"), Map.entry(CUEVAS_OSCURAS, "2A"),
            Map.entry(TORMENTAS, "2B"), Map.entry(AGUA_HELADA, "2B"), Map.entry(DESLUMBRAMIENTO, "2B"),
            Map.entry(MENAS_GAS, "3A"), Map.entry(ESCUDOS_CANSAN, "3A"),
            Map.entry(NOCHES_LARGAS, "3B"), Map.entry(PULMONES_PEQUENOS, "3B"), Map.entry(HIPO, "3B"),
            Map.entry(MAREO_PORTALES, "4A"), Map.entry(AGOBIO_NETHER, "4A"),
            Map.entry(POCIONES_AGUADAS, "4B"), Map.entry(RAYOS_METAL, "4B"),
            Map.entry(COHETES_DEFECTUOSOS, "5"));

    /** No tienen sentido hasta que se abra el Nether. */
    public static final Set<String> NECESITA_NETHER = Set.of(MAREO_PORTALES, AGOBIO_NETHER);
    /** No tienen sentido hasta que se abra el End (élitras). */
    public static final Set<String> NECESITA_END = Set.of(COHETES_DEFECTUOSOS);

    /** Crea las teles (lo llama Eventos al cargar). */
    static void eventos() {
        // ----------------------------------------------------------------- 1A
        cambio(ASTILLAS, "¡Los árboles tienen astillas!",
                "A partir de ahora, romper un tronco sin un hacha en la mano te clavará astillas: medio corazón de daño por cada tronco "
                        + "(nunca te dejará por debajo de 1 corazón). Con cualquier hacha no pasa nada.",
                "Los árboles en huelga han contratado a una empresa de seguridad privada. El Centro de Desinformación ha intentado mediar, "
                        + "pero la empresa de seguridad está formada íntegramente por astillas y no atiende a razones.");

        cambio(DIETA_VARIADA, "¡El nutricionista ha llegado!",
                "A partir de ahora, si coméis el mismo alimento 3 veces seguidas, la tercera (y las siguientes) solo os llenará la mitad "
                        + "y os dará Náuseas durante 5 segundos. Basta con comer otra cosa entre medias.",
                "Por recortes, el Centro de Desinformación ha sustituido al médico de cabecera por un nutricionista en prácticas. "
                        + "No sabe mucho de nutrición, pero tiene opiniones muy firmes sobre comer siempre filete.");

        cambio(ANIMALES_CHIVATOS, "¡Los animales se chivan!",
                "A partir de ahora, si golpeas a una vaca, un cerdo, una oveja, una gallina, un conejo o una champiñaca, "
                        + "todos los animales de esos tipos que haya a menos de 12 bloques saldrán corriendo lejos de ti.",
                "Los animales de granja se han enterado de la huelga de los árboles y han creado un grupo de WhatsApp. "
                        + "Ahora, en cuanto le tocas un pelo a uno, se entera todo el vecindario. Y el vecindario corre.");

        // ----------------------------------------------------------------- 1B
        cambio(BECARIO_ORDENA, "¡El becario os ordena el inventario!",
                "A partir de ahora, cada 15-25 minutos el becario os \"ordenará\" el inventario: cambiará 2 huecos al azar de vuestra "
                        + "barra rápida por otros 2 de la mochila. No se pierde nada, pero puede que al ir a sacar la espada saquéis un bloque de tierra.",
                "El becario del Centro de Desinformación ha hecho un curso de organización doméstica de un fin de semana. "
                        + "Dice que vuestro inventario \"no le transmite paz\". Hemos intentado pararle, pero lo hace con muchísima ilusión.");

        cambio(LLUVIA_ACIDA, "¡La lluvia es ácida!",
                "A partir de ahora, si os pilla la lluvia sin nada en la cabeza perderéis medio corazón cada 10 segundos "
                        + "(nunca os dejará por debajo de 1 corazón). Con un casco (o una calabaza) no os pasa nada, aunque el casco se irá desgastando poco a poco.",
                "El nuevo proveedor de fuego del Centro de Desinformación ha estado echando sus residuos a las nubes. Nos asegura que es "
                        + "totalmente legal. También nos asegura que el paraguas no entra en el contrato.");

        cambio(COMIDA_CADUCA, "¡La comida cruda caduca!",
                "A partir de ahora, cada 5 minutos se os pudrirá 1 pieza de carne o pescado crudo del inventario y se convertirá en "
                        + "carne podrida. La comida cocinada y la que guardéis en cofres no se estropea.",
                "Seguimos sin saber quién dejó la nevera abierta. Mientras tanto, el Centro de Desinformación ha decidido que la carne cruda "
                        + "caduque en vuestros bolsillos. Los bolsillos no tienen frigorífico, y nosotros no tenemos presupuesto para uno.");

        // ----------------------------------------------------------------- 2A
        cambio(MENAS_ESCURRIDIZAS, "¡Las menas se escapan!",
                "A partir de ahora, al picar una mena hay un 15% de probabilidad de que se escape: en vez de romperse, saltará a un bloque "
                        + "de piedra cercano (a 3 bloques como mucho) y tendréis que ir a buscarla y picarla otra vez.",
                "Los minerales se han enterado de lo que les hacéis en los hornos y han empezado a huir. El Centro de Desinformación "
                        + "no puede culparlos. Bueno, sí puede, pero ha preferido no hacerlo.");

        cambio(MOCHILA_PESADA, "¡La mochila pesa!",
                "A partir de ahora, si lleváis más de 27 huecos ocupados de los 36 del inventario (sin contar la armadura ni la segunda mano), "
                        + "iréis un 15% más lentos. Usad cofres.",
                "El Centro de Desinformación ha contratado a una aerolínea de bajo coste para gestionar vuestros inventarios. "
                        + "A partir de cierto peso hay que pagar suplemento. Como no tenéis tarjeta, se os cobra en velocidad.");

        cambio(CUEVAS_OSCURAS, "¡Las profundidades están más oscuras!",
                "A partir de ahora, por debajo de la capa 0, si estáis en un sitio oscuro (nivel de luz 4 o menos) y no lleváis una luz en la mano "
                        + "(antorcha, farol, calabaza iluminada, piedra luminosa, linterna marina o luz de hongo), os dará Oscuridad. "
                        + "Se os quita en cuanto haya luz o saquéis una antorcha.",
                "Para ahorrar en la factura, el Centro de Desinformación ha desconectado la luz ambiental de las profundidades. "
                        + "Tinky Winky nos ha mandado una carta de agradecimiento. Escrita a oscuras.");

        // ----------------------------------------------------------------- 2B
        cambio(TORMENTAS, "¡Toda lluvia es tormenta!",
                "A partir de ahora, cada vez que se ponga a llover en el Overworld será tormenta eléctrica durante unos 5 minutos: "
                        + "rayos, cielo oscuro y monstruos que también pueden aparecer de día mientras dure.",
                "El departamento de meteorología del Centro de Desinformación ha quitado el botón de \"lluvia suave\" para simplificar "
                        + "el panel de control. Ahora solo quedan dos opciones: \"sol\" y \"fin del mundo\".");

        cambio(AGUA_HELADA, "¡El agua está helada!",
                "A partir de ahora, el agua está helada: si pasáis más de 20 segundos seguidos dentro, se os escarcha la pantalla y empezáis a perder "
                        + "medio corazón cada 2 segundos (nunca os dejará por debajo de 1 corazón). Al salir del agua, la cuenta vuelve a empezar. Llevar cualquier pieza de armadura de cuero "
                        + "os protege del frío, y en barca no pasa nada.",
                "El Centro de Desinformación ha cambiado la caldera del mundo por una de segunda mano. Según el vendedor, calienta "
                        + "perfectamente. El vendedor vive en Canarias.");

        cambio(DESLUMBRAMIENTO, "¡El sol deslumbra!",
                "A partir de ahora, si pasáis más de 1 minuto bajo tierra (por debajo de la capa 55 y donde no llegue nada de luz del sol) "
                        + "y salís a cielo abierto de día y sin lluvia, el sol os deslumbrará: Ceguera durante 4 segundos. Mirad bien antes de salir de la cueva.",
                "El Centro de Desinformación ha subido el brillo del sol al máximo para ahorrar en bombillas. A los que vivís en cuevas "
                        + "no se os ha consultado. Nunca se os consulta.");

        // ----------------------------------------------------------------- 3A
        cambio(MENAS_GAS, "¡Bolsas de gas en las menas!",
                "A partir de ahora, al picar una mena hay un 8% de probabilidad de liberar una nube de gas tóxico: durante unos 6 segundos, "
                        + "todo lo que esté a menos de 2,5 bloques recibirá Veneno I durante 5 segundos. El veneno no mata, pero deja tocado.",
                "Nuestros geólogos han descubierto que las menas no son macizas: están rellenas de los gases de la digestión de la Tierra. "
                        + "El Centro de Desinformación recomienda picar aguantando la respiración, lo cual no sirve absolutamente de nada.");

        cambio(ESCUDOS_CANSAN, "¡Los escudos cansan el brazo!",
                "A partir de ahora, cada golpe que paréis con el escudo tiene un 25% de probabilidad de dejaros el brazo dormido: "
                        + "el escudo se baja y no podréis usarlo durante 3 segundos, como cuando os lo desactiva un hacha.",
                "Los escudos del servidor venían del mismo proveedor que las camas: pesan el triple de lo que deberían y el asa es de cartón. "
                        + "Hemos pedido la hoja de reclamaciones. También es de cartón.");

        // ----------------------------------------------------------------- 3B
        cambio(NOCHES_LARGAS, "¡Las noches son más largas!",
                "A partir de ahora las noches del Overworld durarán un 50% más (unos 12 minutos en vez de 8). El día dura lo mismo.",
                "El Centro de Desinformación ha cambiado el reloj del mundo por uno de oferta. Atrasa, pero solo de noche, "
                        + "que es cuando nadie lo mira. Ya lo hemos devuelto, pero el reembolso tarda 30 días.");

        cambio(PULMONES_PEQUENOS, "¡Pulmones de oferta!",
                "A partir de ahora, bajo el agua el aire os durará la mitad (unos 7 segundos en vez de 15). "
                        + "La Respiración y las pociones de respiración acuática siguen funcionando.",
                "El Centro de Desinformación ha renegociado el contrato del aire del mundo. Por el mismo precio, ahora cada respiración "
                        + "trae la mitad de aire. El resto es embalaje.");

        cambio(HIPO, "¡Comer deprisa da hipo!",
                "A partir de ahora, si coméis 3 veces en menos de 30 segundos os dará hipo durante 1 minuto: cada 3-6 segundos "
                        + "daréis un saltito sin querer. Cuidado al borde de los precipicios.",
                "El nutricionista en prácticas ha publicado un estudio que demuestra que comer deprisa es malo. Para que se note, "
                        + "ha añadido el hipo al mundo. El estudio no ha pasado la revisión, pero el hipo sí.");

        // ----------------------------------------------------------------- 4A (Nether abierto)
        cambio(MAREO_PORTALES, "¡Viajar entre dimensiones marea!",
                "A partir de ahora, cada vez que cambiéis de dimensión (Overworld, Nether o End) tendréis jet lag: "
                        + "Náuseas y Lentitud durante 10 segundos al llegar.",
                "El Centro de Desinformación ha externalizado los portales a una aerolínea de bajo coste. Los asientos no se reclinan, "
                        + "no hay ventanilla y al llegar siempre se te ha olvidado algo.");

        cambio(AGOBIO_NETHER, "¡El Nether agobia!",
                "A partir de ahora, mientras estéis en el Nether tendréis 2 corazones menos de vida máxima (nunca os dejará con menos de 1). "
                        + "Al volver los recuperáis, pero vacíos. Quien tenga la pasiva Fondo de Roca se libra.",
                "Los técnicos del Centro de Desinformación han medido la temperatura del Nether y han concluido que hace calor. "
                        + "El informe ha costado 40.000 esmeraldas. Por el calor os falta el aire, y por el informe nos falta el presupuesto.");

        // ----------------------------------------------------------------- 4B
        cambio(POCIONES_AGUADAS, "¡Las pociones están aguadas!",
                "A partir de ahora, todos los efectos buenos que recibáis (pociones, manzanas doradas, estofados sospechosos...) "
                        + "durarán la mitad. Los efectos de los faros y de los conductos no cambian.",
                "El proveedor de pociones del Centro de Desinformación ha empezado a rebajarlas con agua para mantener el precio. "
                        + "Lo llama \"fórmula ligera\". Nosotros lo llamamos agua con colorante.");

        cambio(RAYOS_METAL, "¡El metal atrae los rayos!",
                "A partir de ahora, durante las tormentas, si estáis bajo la lluvia con 2 o más piezas de armadura de metal "
                        + "(hierro, cota de malla, oro o netherita) atraeréis rayos: más o menos una vez cada 30 segundos empezaréis a chisporrotear "
                        + "y, 1,5 segundos después, caerá un rayo donde estabais (2,5 corazones de daño, menos con armadura, si seguís a menos de 2 bloques). "
                        + "Si oís el chisporroteo, moveos.",
                "Los pararrayos que se comieron los creepers no han desaparecido: han acabado en vuestras armaduras. "
                        + "El Centro de Desinformación declina toda responsabilidad, pero recomienda el cuero.");

        // ----------------------------------------------------------------- 5
        cambio(COHETES_DEFECTUOSOS, "¡Cohetes de saldo!",
                "A partir de ahora, 1 de cada 8 cohetes que uséis para impulsaros con las élitras os explotará en la cara: "
                        + "2 corazones de daño (menos con armadura), os frena y el cohete se gasta igual.",
                "El Centro de Desinformación compró los cohetes en una tienda de un polígono que cerraba por liquidación. "
                        + "Venían con la mecha un poco corta y sin instrucciones. Sobre todo, sin instrucciones.");
    }

    /** Todas estas teles hacen lo mismo al salir: dejar la marca. El resto lo hace CambiosMundoEfectos mirando la marca. */
    private static void cambio(String id, String titulo, String descripcion, String excusa) {
        Eventos.amarillo(id, titulo, descripcion, excusa, server -> EstadoServidor.get(server).agregarCambio(id));
    }

    /** Ganchos de juego (lo llama Desinformados.onInitialize). */
    public static void registrar() {
        CambiosMundoEfectos.registrar();
    }
}

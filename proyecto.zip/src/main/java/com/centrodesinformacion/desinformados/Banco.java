package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.network.BancoAccionPayload;
import com.centrodesinformacion.desinformados.network.BancoPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Banco de Rumores: guarda los Rumores como saldo numérico y deja sacar cualquier moneda.
 * Así se cambian monedas (5 amarillas = 1 azul) metiendo y sacando.
 */
public class Banco {
    private static final Map<UUID, BlockPos> BANCO_ABIERTO = new HashMap<>();

    public static void registrar() {
        ServerPlayNetworking.registerGlobalReceiver(BancoAccionPayload.ID, (paquete, contexto) -> accion(contexto.player(), paquete));
    }

    public static void abrir(ServerPlayerEntity p, BlockPos pos) {
        BANCO_ABIERTO.put(p.getUuid(), pos.toImmutable());
        enviar(p, true);
    }

    private static void enviar(ServerPlayerEntity p, boolean abrir) {
        if (ServerPlayNetworking.canSend(p, BancoPayload.ID)) {
            ServerPlayNetworking.send(p, new BancoPayload(EstadoServidor.get(p.getServer()).getSaldo(p.getUuid()), abrir));
        }
    }

    /** Solo se puede operar estando cerca del banco que se abrió. */
    private static boolean cerca(ServerPlayerEntity p) {
        BlockPos pos = BANCO_ABIERTO.get(p.getUuid());
        return pos != null && p.getBlockPos().isWithinDistance(pos, 8)
                && p.getWorld().getBlockState(pos).getBlock() instanceof BancoBlock;
    }

    private static void accion(ServerPlayerEntity p, BancoAccionPayload paquete) {
        if (!cerca(p)) return;
        EstadoServidor estado = EstadoServidor.get(p.getServer());
        if (paquete.accion().equals("depositar")) {
            int total = 0;
            PlayerInventory inv = p.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.getItem() instanceof RumorItem r) {
                    total += r.getValor() * s.getCount();
                    inv.setStack(i, ItemStack.EMPTY);
                }
            }
            if (total > 0) {
                estado.setSaldo(p.getUuid(), estado.getSaldo(p.getUuid()) + total);
                p.sendMessage(Text.literal("Has depositado " + total + " Rumores").formatted(Formatting.GOLD), true);
                p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8f, 0.8f);
            }
        } else if (paquete.accion().startsWith("sacar:")) {
            Item moneda = moneda(paquete.accion().substring(6));
            int cantidad = Math.max(1, Math.min(64, paquete.cantidad()));
            if (moneda instanceof RumorItem r) {
                int coste = r.getValor() * cantidad;
                int saldo = estado.getSaldo(p.getUuid());
                if (saldo < coste) {
                    p.sendMessage(Text.literal("No tienes saldo suficiente (necesitas " + coste + ")").formatted(Formatting.RED), true);
                } else {
                    estado.setSaldo(p.getUuid(), saldo - coste);
                    ItemStack s = new ItemStack(moneda, cantidad);
                    if (!p.getInventory().insertStack(s)) p.dropItem(s, false);
                    p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_CHAIN_PLACE, SoundCategory.PLAYERS, 0.8f, 1.6f);
                }
            }
        }
        enviar(p, false);
    }

    private static Item moneda(String color) {
        return switch (color) {
            case "amarillo" -> ModItems.RUMOR_AMARILLO;
            case "azul" -> ModItems.RUMOR_AZUL;
            case "verde" -> ModItems.RUMOR_VERDE;
            case "rojo" -> ModItems.RUMOR_ROJO;
            case "gris" -> ModItems.RUMOR_GRIS;
            default -> null;
        };
    }
}

package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Lista de eventos preparados. Se lanzan con /desinfo lanzar <id>.
 *  - rojo: desafío puntual
 *  - amarillo: cambio de dificultad PERMANENTE (se guarda en el mundo)
 */
public class Eventos {
    public record Evento(String id, String color, String titulo, String descripcion, String excusa, Consumer<MinecraftServer> accion) {}

    public static final Map<String, Evento> TODOS = new LinkedHashMap<>();

    /** Ticks que tarda la tele en ponerse de color: el efecto empieza justo ahí. */
    /** Ticks hasta que la tele termina (se va o se rompe). Entonces llegan el mensaje y el evento. Igual que TvOverlay.DURACION. */
    public static final int RETRASO_TELE = 172;

    static {
        // ===================== AMARILLOS (cambios de dificultad) =====================
        // ===================== VERDES (anuncios con efecto) =====================
        verde("diamante", "¡Se desbloquea el diamante!",
                "El Centro de Desinformación autoriza el uso del diamante: ya se pueden craftear herramientas, armas y armaduras de diamante.",
                server -> {
                    EstadoServidor.get(server).agregarCambio(Crafteos.CAMBIO_DIAMANTE);
                    Crafteos.sincronizarTodos(server);
                });

        verde("receta_bloque_garatita", "¡Nueva receta: Bloque de Garatita!",
                "Ya se pueden juntar 9 Garatitas en un Bloque de Garatita (y deshacerlo otra vez).",
                server -> { EstadoServidor.get(server).agregarCambio("receta_bloque_garatita"); Crafteos.sincronizarTodos(server); });
        verde("receta_centro_estatica", "¡Nueva receta: Centro de Estática!",
                "Ya se puede craftear el Centro de Estática con 9 Fragmentos de Estática.",
                server -> { EstadoServidor.get(server).agregarCambio("receta_centro_estatica"); Crafteos.sincronizarTodos(server); });
        verde("receta_desinformacion_pura", "¡Nueva receta: Desinformación Pura!",
                "Ya se puede craftear la Desinformación Pura: lingotes de netherite en las esquinas, Fragmento de Estática arriba, bloques de diamante a los lados, Bloque de Garatita abajo y el Centro de Estática en medio.",
                server -> { EstadoServidor.get(server).agregarCambio("receta_desinformacion_pura"); Crafteos.sincronizarTodos(server); });

        // Formato: amarillo(id, título, qué cambia, comunicado sarcástico, acción)
        // En la tele y el chat sale como un solo texto: primero el comunicado y luego qué cambia.

        amarillo("arboles", "¡Los árboles han sido afectados!",
                "A partir de ahora plantar árboles será inútil: los brotes ya no crecerán nunca.",
                "Los árboles se han declarado en huelga indefinida. Exigen mejores condiciones y que dejéis de talarlos a puñetazos, cosa que nos parece razonable.",
                server -> EstadoServidor.get(server).agregarCambio("arboles"));

        amarillo("creepers_oscuros", "¡Llegan los Creepers Oscuros!",
                "Así que cuidado al bajar: aparecerán SOLO en cuevas y, si su explosión te alcanza, perderás un contenedor de corazón.",
                "No son creepers normales pintados con rotulador negro. Bueno, sí lo son, pero el rotulador estaba maldito y no pensamos devolverlo.",
                server -> desbloquearMob(server, ModEntidades.CREEPER_OSCURO));

        amarillo("furros", "¡Han llegado los Furros!",
                "Si te ven, te perseguirán para abrazarte, dejándote con Lentitud IV y quitándote medio corazón cada 2 segundos. Puedes pegarles para soltarte.",
                "El Centro de Desinformación organizó una convención en el sótano y se nos olvidó cerrar la puerta. Solo quieren cariño. Mucho cariño. Demasiado cariño. No hagáis contacto visual.",
                server -> desbloquearMob(server, ModEntidades.FURRO));

        amarillo("zombies_falsos", "¡Zombies adultos falsos!",
                "A partir de ahora, al derrotar a un zombie adulto se partirá en 2 zombies pequeños, y si llevaba armadura se la repartirán entre los dos.",
                "Tras una larga investigación, el Centro de Desinformación ha descubierto que los zombies adultos eran en realidad dos zombies bebé dentro de una gabardina. Lamentamos el engaño, del cual no somos responsables en absoluto.",
                server -> EstadoServidor.get(server).agregarCambio("zombies_falsos"));

        amarillo("esqueletos_doble_arco", "¡Esqueletos con doble arco!",
                "Ahora los esqueletos llevan un arco en cada mano y disparan dos flechas a la vez, algo abiertas para que cueste esquivarlas.",
                "Los esqueletos se quejaron de que un solo arco no les dejaba expresar todo su potencial artístico. El Centro de Desinformación, siempre comprometido con la cultura, les ha regalado otro. No sabemos cómo los sujetan sin músculos, y preferimos no preguntar.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("esqueletos_doble_arco");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("cubo_blanco", "¡Ha aparecido el Cubo Blanco!",
                "Es muy lento, pero si te toca te flasheará: tu pantalla se quedará completamente en blanco unos segundos y te dará Lentitud I.",
                "Le pedimos un mob nuevo al becario del Centro de Desinformación y solo le dio tiempo a hacer un cubo. Lo pintamos de blanco para que pareciera minimalista y moderno. No sabemos qué es ni qué quiere. No lo toquéis. Mejor dicho, que no os toque.",
                server -> desbloquearMob(server, ModEntidades.CUBO_BLANCO));

        amarillo("altky", "¡Llega Altky!",
                "Cuando te ve se pone a dibujar y de su hoja sale un mob dibujado (mal hecho). La mitad de las veces es un Furro dibujado; "
                        + "si no, un mob de la Libreta. Tarda 10 segundos entre dibujo y dibujo. Mátalo antes de que acabe la obra.",
                "Altky se apuntó a un curso de dibujo por internet. Solo vio la primera clase. Ahora todo lo que dibuja cobra vida "
                        + "y por alguna razón casi siempre dibuja furros. El Centro de Desinformación no va a preguntar.",
                server -> desbloquearMob(server, ModEntidades.ALTKY));

        amarillo("brandon_kevin", "¡Llegan Brandon y Kevin!",
                "Brandon (8 corazones, muy rápido) te ataca de lejos con rayos azules que te paralizan medio segundo. "
                        + "Cuando le pegas por primera vez llega Kevin (20 corazones, pega como un zombie), que se pone siempre delante de Brandon "
                        + "y se come los golpes que le des mientras esté cerca. Los rayos no le hacen nada a Kevin.",
                "Brandon dijo que tenía poderes eléctricos. Nadie le creyó, así que trajo a Kevin para que le cubriera la espalda. "
                        + "El Centro de Desinformación confirma que los rayos son reales y que Kevin no se va a mover de ahí.",
                server -> desbloquearMob(server, ModEntidades.BRANDON));

        amarillo("zombie_naranja", "¡Llega el Zombie Naranja!",
                "Solo recibe daño de proyectiles (flechas, tridentes...), tiene 15 corazones, pega un 25% más fuerte y es un poco más rápido que un zombie normal, aunque no tanto como uno pequeño. Espadas y hachas no le hacen nada.",
                "Un zombie se pasó tres semanas tomando el sol y se volvió naranja. Desde entonces dice que es inmune a los golpes porque \"tiene la piel curtida\". El Centro de Desinformación ha verificado esta información y la considera totalmente cierta.",
                server -> desbloquearMob(server, ModEntidades.ZOMBIE_NARANJA));

        amarillo("fuego_eterno", "¡El fuego ya no se apaga!",
                "A partir de ahora, si te prendes fuego no se apagará con el tiempo: tendrás que meterte en el agua (o esperar a que te pille la lluvia) para apagarlo.",
                "El Centro de Desinformación ha cambiado de proveedor de fuego. El nuevo es más barato y viene sin botón de apagado. Hemos enviado una queja formal, pero el proveedor tampoco puede responder porque sigue en llamas.",
                server -> EstadoServidor.get(server).agregarCambio("fuego_eterno"));

        amarillo("objetos_catapulta", "¡Soltar objetos es peligroso!",
                "A partir de ahora, al soltar un objeto saldrá disparado en la dirección en la que mires, con la fuerza de una flecha bien tensada. Cuidado al soltar cosas cerca de lava, del vacío o de un precipicio.",
                "Para ahorrar en envíos, el Centro de Desinformación ha sustituido el sistema de soltar objetos por catapultas de bolsillo. Ya no hace falta acercarse para dar cosas a tus compañeros: basta con apuntar y rezar.",
                server -> EstadoServidor.get(server).agregarCambio("objetos_catapulta"));

        amarillo("ovejas_sin_lana", "¡Las ovejas se han quedado sin lana!",
                "A partir de ahora todas las ovejas estarán esquiladas y la lana no les volverá a crecer, ni comiendo hierba. Tampoco la soltarán al morir.",
                "Tras una ola de calor provocada por el nuevo proveedor de fuego, las ovejas han decidido raparse por completo y han prometido no volver a dejarse crecer la lana jamás. El Centro de Desinformación respeta su decisión y su nuevo estilo.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("ovejas_sin_lana");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("aldeanos_caros", "¡Inflación en las aldeas!",
                "A partir de ahora todos los aldeanos cobrarán un 50% más por cada intercambio. Los descuentos por curarlos o por ser Héroe de la Aldea se siguen aplicando, pero sobre el precio nuevo.",
                "Los aldeanos han contratado a un asesor financiero del Centro de Desinformación, que les ha explicado que las esmeraldas valen la mitad que ayer por culpa de la inflación, la economía y, sobre todo, porque sí.",
                server -> EstadoServidor.get(server).agregarCambio("aldeanos_caros"));

        amarillo("garabatos", "¡Los Garabatos han cobrado vida!",
                "Son monigotes de palo dibujados en una hoja de papel, del tamaño de un jugador. Si te ven se acercarán y, si te tocan, te teletransportarán 10 bloques hacia arriba. Lo que pase después es cosa de la gravedad.",
                "Un becario del Centro de Desinformación se aburría tanto en una reunión que llenó su libreta de monigotes. Ahora los monigotes también se aburren y han decidido salir a jugar con vosotros. El becario ha sido ascendido.",
                server -> desbloquearMob(server, ModEntidades.GARABATO));

        amarillo("creepers_electrificados", "¡Creepers electrificados!",
                "A partir de ahora todos los creepers estarán electrificados, incluidos los Creepers Oscuros: su explosión será el doble de grande y mucho más dañina. Como consuelo, si matan a otro mob con la explosión puede soltar su cabeza.",
                "El Centro de Desinformación instaló pararrayos en todas las cuevas para proteger a los mobs. Por desgracia, los creepers se los comieron. Ahora brillan, chisporrotean y se niegan a devolvernos los pararrayos.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("creepers_electrificados");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("bebes_rapidos", "¡Los zombies pequeños van a tope!",
                "A partir de ahora los zombies pequeños serán un 50% más rápidos de lo que ya eran. Se aplica a todos: zombies, husks, ahogados y aldeanos zombie bebé.",
                "Alguien del Centro de Desinformación dejó una cafetera encendida cerca de una guardería de zombies. Ahora los bebés llevan tres días sin dormir y no piensan parar. Nadie sabe quién dejó la cafetera. Fue el becario.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("bebes_rapidos");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("ale_poderoso", "¡Ale se ha vuelto más poderoso!",
                "A partir de ahora Ale tendrá un 50% más de vida, fuerza y velocidad, será más grande y al morir soltará 4 Travensaños en lugar de 2.",
                "Ale ha empezado a ir al gimnasio por recomendación del Centro de Desinformación. Después de varias semanas haciendo press de banca con Travensaños, ha crecido, corre más y ahora va acompañado del doble de ellos. Le hemos pedido que pare. No ha parado.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("ale_poderoso");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("travensanos_furiosos", "¡Travensaños furiosos!",
                "A partir de ahora los Travensaños tendrán 8 corazones, serán un 40% más rápidos y, cuando se te sienten en el cuello, te quitarán corazón y medio cada segundo, atravesando la armadura.",
                "Los Travensaños se enteraron de que Ale los usaba como pesas en el gimnasio y no se lo han tomado nada bien. Como no pueden vengarse de él, se vengarán de vosotros. El Centro de Desinformación considera que es una reacción totalmente proporcionada.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("travensanos_furiosos");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("ale", "¡Ale anda suelto!",
                "Ale empezará a aparecer en lugares oscuros. Tiene 10 corazones, te perseguirá para pegarte y, al morir, soltará 2 Travensaños.",
                "Atención: este no es el verdadero Ale, sino un clon creado por la misma fuerza que dañó el reactor. Estos clones copian a personas reales para intensificar la desinformación en todo el que se cruzan. Según nuestros datos, el Ale original salió a comprar pan hace tres días y el clon aprovechó para ocupar su lugar. El Centro de Desinformación asegura que el pan no tiene nada que ver.",
                server -> EstadoServidor.get(server).agregarCambio("ale"));

        amarillo("travensanos", "¡Se ha descubierto una nueva especie: los Travensaños!",
                "Aparecerán en lugares oscuros. Si te ven, te perseguirán y se te sentarán en el cuello: te quitarán vida poco a poco y te invertirán los controles y la cámara hasta que los mates.",
                "Los científicos del Centro de Desinformación han descubierto una especie que llevaba siglos viviendo entre nosotros: los Travensaños. Viven en la playa todo el año y no entienden el concepto de espacio personal. Lo de sentarse en el cuello, aseguran, es una muestra de cariño.",
                server -> EstadoServidor.get(server).agregarCambio("travensanos"));

        amarillo("ulises", "¡Cuidado con Ulises!",
                "Ulises aparecerá en lugares oscuros. Si te ve, se te quedará mirando fijamente 8 segundos y lanzará un rayo rojo que te quitará la mitad de la vida que tengas. Escóndete para que te pierda de vista o pégale para desconcentrarlo.",
                "Otro clon de la fuerza que dañó el reactor. Estos clones copian a personas reales y amplifican lo que más desinforma de ellas. Del Ulises real copió la frase \"estoy bien\", y la amplificó hasta deambular por el mundo mirando fijamente a la gente y proyectando sobre ella que el amor no fue real. El Centro de Desinformación le recomendó terapia; el clon prefirió los rayos láser.",
                server -> EstadoServidor.get(server).agregarCambio("ulises"));

        amarillo("interferencia", "¡Tinky Winky ha entrado en la señal!",
                "Solo aparece en cuevas y sitios en oscuridad total, y es rápido. Si te toca, verás algo que no querrás ver, perderás 5 corazones durante 1 minuto y él desaparecerá. Tiene 4 corazones: mejor mátalo antes de que te alcance. Le dan miedo las antorchas: no se acerca a zonas iluminadas y huye de quien lleve una en la mano.",
                "Desde que el reactor se dañó, la tele del Centro de Desinformación capta canales que no existen. Uno de ellos es infantil. Bueno, lo era. Ahora uno de sus presentadores se ha salido de la pantalla y anda por las cuevas buscando a quien abrazar. No lo dejes.",
                server -> desbloquearMob(server, ModEntidades.INTERFERENCIA));

        amarillo("angel", "¡Cuidado con el Angel Manipulador!",
                "Aparecerá en lugares oscuros. Si te ve, te manipulará: tu cámara quedará fija en él, no podrás moverte, tu pantalla se pondrá azul y te arrastrará hacia él. Cuando te tenga cerca tendrás 2 segundos para matarlo antes de que explote. Tiene 10 corazones.",
                "Un nuevo clon de la fuerza que dañó el reactor, como los de Ale y Ulises: copias de personas reales que intensifican la desinformación. Este copió el don de convencimiento de Angel y lo amplificó hasta el punto de que nadie puede apartar la mirada de él. El Centro de Desinformación intentó contratarlo como portavoz, pero explotó en mitad de la entrevista.",
                server -> EstadoServidor.get(server).agregarCambio("angel"));

        amarillo("garabatos_altos", "¡Los Garabatos dibujan más alto!",
                "A partir de ahora, si un Garabato te toca te mandará 20 bloques hacia arriba en lugar de 10. Lleva cubos de agua.",
                "El becario que dibujaba los Garabatos ha descubierto las hojas tamaño A3. Ahora los monigotes tienen el doble de espacio para dibujarte, y lo aprovechan hacia arriba.",
                server -> EstadoServidor.get(server).agregarCambio("garabatos_altos"));

        amarillo("furros_manada", "¡Los Furros van en manada!",
                "A partir de ahora los Furros aparecerán en grupos de 3. Si ves uno, hay otros dos cerca esperando su abrazo.",
                "La convención del sótano ha abierto inscripciones grupales con descuento. Los Furros ya no salen solos: ahora vienen con amigos, y todos quieren abrazarte a la vez.",
                server -> EstadoServidor.get(server).agregarCambio("furros_manada"));

        amarillo("interferencias_clon", "¡Tinky Winky se multiplica!",
                "A partir de ahora, cada vez que golpees a Tinky Winky hay un 15% de probabilidad de que aparezca otro justo detrás de ti.",
                "Nuestros técnicos intentaron arreglar la señal dándole golpes a la tele, como se ha hecho toda la vida. Resulta que cada golpe sintoniza otra copia del canal infantil. Los técnicos siguen sin volver.",
                server -> EstadoServidor.get(server).agregarCambio("interferencias_clon"));

        amarillo("cubo_gigante", "¡El Cubo Blanco ha crecido!",
                "A partir de ahora el Cubo Blanco será el doble de grande y su flash te dejará la pantalla en blanco el doble de tiempo.",
                "Alguien dejó el Cubo Blanco en remojo toda la noche. Ahora ocupa el doble y nadie del Centro de Desinformación se atreve a sacarlo del agua. Ni a mirarlo.",
                server -> EstadoServidor.get(server).agregarCambio("cubo_gigante"));

        amarillo("ulises_rapido", "¡Ulises se ha vuelto impaciente!",
                "A partir de ahora Ulises cargará su rayo en 5 segundos en lugar de 8. Escóndete antes.",
                "El clon de Ulises ha descubierto que mirar fijamente 8 segundos es demasiado tiempo para proyectar. Ahora lo hace en 5. Dice que ha madurado.",
                server -> EstadoServidor.get(server).agregarCambio("ulises_rapido"));

        amarillo("altky_tableta", "¡Altky se compró una tableta!",
                "A partir de ahora Altky ya no dibuja mobs de papel: con su tableta saca mobs normales de verdad (zombies, esqueletos, creepers, arañas "
                        + "y también los del mod: Zombie Naranja, Cubo Blanco, Creeper Oscuro, Travensaños, Creeper de Fuego, Cubo Rojo, Esqueleto Ráfaga...). "
                        + "Los Furros siguen siendo sus favoritos (50 %).",
                "Altky ahorró tres meses para comprarse una tableta de dibujo. Dice que ahora sus dibujos tienen \"más resolución\". "
                        + "Lamentablemente, también tienen más dientes.",
                server -> EstadoServidor.get(server).agregarCambio("altky_tableta"));

        amarillo("brandon_mejorado", "¡Brandon ha mejorado a su equipo!",
                "A partir de ahora Brandon cura a Kevin con un rayo (2 corazones cada 3 segundos si está cerca), dispara sus rayos el doble de rápido "
                        + "y Kevin tiene el doble de vida (40 corazones).",
                "Brandon vio un tutorial de 'cómo ser el support de tu equipo' y ahora le pasa vida a Kevin. Kevin, por su parte, empezó a ir al gimnasio. "
                        + "El Centro de Desinformación no sabe cuál de los dos es peor noticia.",
                server -> EstadoServidor.get(server).agregarCambio("brandon_mejorado"));

        amarillo("creeper_invisible", "¡Los Creepers Oscuros se esconden!",
                "A partir de ahora los Creepers Oscuros serán invisibles hasta que estés a menos de 5 bloques de ellos. Escucha bien en las cuevas.",
                "El rotulador negro maldito se ha mezclado con tinta invisible. El Centro de Desinformación asegura que siguen ahí. Probablemente. Seguramente. Justo detrás de ti.",
                server -> EstadoServidor.get(server).agregarCambio("creeper_invisible"));

        amarillo("comida_podrida", "¡La comida cruda está podrida!",
                "A partir de ahora, comer carne o pescado crudo tiene un 30% de probabilidad de darte náuseas y hambre. Cocinad todo.",
                "El Centro de Desinformación dejó la nevera abierta todo el fin de semana. Hemos tirado lo que olía mal. Lo que no olía mal también, por si acaso. Lo que queda, os lo coméis vosotros.",
                server -> EstadoServidor.get(server).agregarCambio("comida_podrida"));

        amarillo("sed_cuevas", "¡Las cuevas dan sed!",
                "A partir de ahora, por debajo de la capa 0 el hambre bajará el doble de rápido. Bajad con comida.",
                "Nuestros geólogos han detectado que las cuevas profundas son más secas que el humor del becario. Allí abajo todo da hambre, incluso respirar.",
                server -> EstadoServidor.get(server).agregarCambio("sed_cuevas"));

        amarillo("camas_rotas", "¡Las camas ya no funcionan!",
                "A partir de ahora dormir ya no pasará la noche. Las camas solo servirán para guardar vuestro punto de reaparición.",
                "Las camas del servidor eran de un proveedor de muebles desinformado: venían sin colchón. Podéis tumbaros, pero la noche no se va a ningún sitio.",
                server -> EstadoServidor.get(server).agregarCambio("camas_rotas"));

        amarillo("leche_cortada", "¡La leche está cortada!",
                "A partir de ahora la leche ya no quitará los efectos. Ni el veneno, ni el hambre, ni nada. Os la bebéis por el sabor.",
                "Las vacas se enteraron de las condiciones laborales de los árboles y se han unido a la huelga. Siguen dando leche, pero por pura obligación y sin ganas de ayudar.",
                server -> EstadoServidor.get(server).agregarCambio("leche_cortada"));

        amarillo("regeneracion_lenta", "¡Os curáis más despacio!",
                "A partir de ahora la vida se regenerará a la mitad de velocidad al tener la barra de comida llena.",
                "El Centro de Desinformación ha recortado el presupuesto de sanidad. Las tiritas ahora son de segunda mano y los corazones tardan el doble en volver.",
                server -> EstadoServidor.get(server).agregarCambio("regeneracion_lenta"));

        amarillo("agua_escasa", "¡El agua escasea!",
                "A partir de ahora no se pueden crear fuentes infinitas de agua. Cada cubo cuenta.",
                "Para combatir la sequía, el Centro de Desinformación ha cerrado el grifo del mundo. Nadie sabía que el mundo tenía grifo. Nosotros tampoco.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("agua_escasa");
                    server.getGameRules().get(net.minecraft.world.GameRules.WATER_SOURCE_CONVERSION).set(false, server);
                });

        amarillo("cultivos_lentos", "¡Los cultivos crecen despacio!",
                "A partir de ahora el trigo, las zanahorias, las patatas y la remolacha crecerán a la mitad de velocidad.",
                "Los cultivos han visto la huelga de los árboles y han decidido hacer huelga de celo: siguen creciendo, pero exactamente lo mínimo exigible por contrato.",
                server -> EstadoServidor.get(server).agregarCambio("cultivos_lentos"));

        amarillo("hornos_glotones", "¡Los hornos tragan combustible!",
                "A partir de ahora el carbón y cualquier combustible durarán la mitad dentro de los hornos.",
                "Hemos actualizado el firmware de los hornos. Ahora son más inteligentes, más modernos y consumen el doble. Igual que todo lo moderno.",
                server -> EstadoServidor.get(server).agregarCambio("hornos_glotones"));

        amarillo("antorchas_apagan", "¡Las antorchas se apagan!",
                "A partir de ahora las antorchas que coloquéis se apagarán solas a los 10 minutos. Tinky Winky está encantado.",
                "Para ahorrar en la factura de la luz, el Centro de Desinformación ha puesto todas las antorchas en modo ahorro de energía. Se apagan solas. Igual que la motivación del becario.",
                server -> EstadoServidor.get(server).agregarCambio("antorchas_apagan"));

        amarillo("herramientas_fragiles", "¡Las herramientas son frágiles!",
                "A partir de ahora las herramientas, armas y armaduras se desgastarán el doble de rápido.",
                "Por recortes, todo el material nuevo viene con la etiqueta \"Hecho con mucho cariño y poco presupuesto\". El cariño no aguanta tanto como el hierro.",
                server -> EstadoServidor.get(server).agregarCambio("herramientas_fragiles"));

        amarillo("armadura_oxidada", "¡La armadura de hierro se oxida!",
                "A partir de ahora la armadura de hierro perderá durabilidad mientras os moje la lluvia o estéis dentro del agua.",
                "El Centro de Desinformación ha descubierto que el hierro se oxida con el agua. Llevamos años sin saberlo. Os pedimos disculpas por la información, no por el óxido.",
                server -> EstadoServidor.get(server).agregarCambio("armadura_oxidada"));

        amarillo("encantamientos_caros", "¡Encantar sale caro!",
                "A partir de ahora la mesa de encantamientos cobrará el doble de niveles por cada encantamiento.",
                "Los libros de magia han subido de precio por la inflación, igual que los aldeanos. Si encantar ya era caro, ahora es un lujo.",
                server -> EstadoServidor.get(server).agregarCambio("encantamientos_caros"));

        amarillo("esprintar_agota", "¡Correr cansa más!",
                "A partir de ahora esprintar gastará la barra de comida un 50% más rápido.",
                "Tras analizar vuestras costumbres, el Centro de Desinformación ha concluido que corréis demasiado. Ahora correr cansa más. Es por vuestra salud. Creemos.",
                server -> EstadoServidor.get(server).agregarCambio("esprintar_agota"));

        amarillo("suelos_resbaladizos", "¡Las cuevas resbalan!",
                "A partir de ahora el suelo de las cuevas será resbaladizo como el hielo. Cuidado con la lava.",
                "Un técnico del Centro de Desinformación encontró una oferta de cera para suelos y la aplicó en todas las cuevas. Ya no está con nosotros. Resbaló.",
                server -> EstadoServidor.get(server).agregarCambio("suelos_resbaladizos"));

        amarillo("caidas_duras", "¡Las caídas duelen más!",
                "A partir de ahora el daño por caída será un 50% mayor. Los Garabatos os lo agradecen.",
                "Después de mucho debate, la gravedad ha decidido tomarse su trabajo más en serio. Hemos intentado negociar con ella. No escucha.",
                server -> EstadoServidor.get(server).agregarCambio("caidas_duras"));

        amarillo("aranas_pequenas", "¡Las arañas han encogido!",
                "Desde hoy las arañas tienen el tamaño de un pez globo: caben por cualquier hueco y son más difíciles de golpear.",
                "Por recortes de presupuesto, el Centro de Desinformación ya no puede permitirse arañas de tamaño completo, así que las hemos lavado con agua caliente. Sentimos los inconvenientes. No los sentimos.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("aranas_pequenas");
                    Modificaciones.aplicarATodos(server);
                });
    }

    static {
        // ===================== NETHER Y ENDERMAN =====================
        amarillo("ghasts_triples", "¡Los ghasts lloran el triple!",
                "Ahora los ghasts disparan tres bolas de fuego a la vez, abiertas en abanico.",
                "Los ghasts empezaron terapia con el psicólogo del Centro de Desinformación. Resulta que tenían mucho que soltar. Literalmente.",
                server -> EstadoServidor.get(server).agregarCambio("ghasts_triples"));
        amarillo("blazes_dobles", "¡Blazes con doble ración!",
                "Cada bola de fuego que lanza un blaze sale con una gemela justo detrás.",
                "Los blazes se quejaron de que una bola de fuego no calentaba lo suficiente. El Centro de Desinformación, siempre atento al confort térmico, les ha duplicado la calefacción.",
                server -> EstadoServidor.get(server).agregarCambio("blazes_dobles"));
        amarillo("piglins_ladrones", "¡Los piglins son carteristas!",
                "Si un piglin te golpea, te roba hasta 3 objetos de oro del inventario (lingotes, pepitas, bloques...) y se los queda.",
                "La inflación ha llegado al Nether y los piglins ya no pueden pagar el alquiler. No justificamos el robo. Pero lo entendemos.",
                server -> EstadoServidor.get(server).agregarCambio("piglins_ladrones"));
        amarillo("hoglins_gimnasio", "¡Los hoglins van al gimnasio!",
                "Los hoglins tienen un 50% más de vida y sus embestidas te mandan mucho más lejos.",
                "Los hoglins se apuntaron al gimnasio del Centro de Desinformación con la cuota de 'piernas todos los días'. El entrenador dice que no hace falta, pero no le escuchan.",
                server -> EstadoServidor.get(server).agregarCambio("hoglins_gimnasio"));
        amarillo("magma_ardiente", "¡Los cubos de magma queman!",
                "Si un cubo de magma te golpea, te prende fuego durante 5 segundos.",
                "Alguien le dijo a los cubos de magma que eran 'tibios'. Se lo han tomado fatal y ahora se esfuerzan muchísimo en demostrar lo contrario.",
                server -> EstadoServidor.get(server).agregarCambio("magma_ardiente"));
        amarillo("wither_veneno", "¡Esqueletos wither con cafeína!",
                "Los esqueletos wither son un 25% más rápidos y su golpe da Wither II durante 8 segundos.",
                "Los esqueletos wither descubrieron la máquina de café del Centro de Desinformación. No tienen estómago, así que no sabemos dónde va el café. Pero funciona.",
                server -> EstadoServidor.get(server).agregarCambio("wither_veneno"));
        amarillo("zombificados_rencorosos", "¡Piglins zombificados rencorosos!",
                "Los piglins zombificados te atacan en cuanto te acercas a menos de 10 bloques, aunque no les hayas hecho nada.",
                "Los piglins zombificados por fin leyeron las reseñas que les dejasteis en internet. Todas. Y se acuerdan de vuestras caras.",
                server -> EstadoServidor.get(server).agregarCambio("zombificados_rencorosos"));
        amarillo("enderman_teletransporte", "¡Endermans con mala educación!",
                "Si un enderman te golpea, te teletransporta a un sitio al azar cercano (como una fruta coral).",
                "Los endermans han leído que el contacto visual es una falta de respeto. Ahora, si les miras y te pegan, te mandan a pensar lo que has hecho a otra parte.",
                server -> EstadoServidor.get(server).agregarCambio("enderman_teletransporte"));

        amarillo("nether_poblado", "¡El Nether tiene nuevos vecinos!",
                "Ahora en el Nether también aparecen Zombies Naranjas, Furros y Travensaños, y tres mobs nuevos: el Creeper de Fuego (al explotar te quema, qué sorpresa), el Cubo Rojo (te ciega como el Blanco... y te quema) y el Esqueleto Ráfaga (verde, dispara 5 flechas seguidas cada 5 segundos).",
                "Tras una inspección rutinaria, el Centro de Desinformación ha concluido que el Nether se veía muy sin vida. Hemos enviado a unos cuantos voluntarios. No eran voluntarios.",
                server -> {});

        // ===================== MORADOS (cosas importantes) =====================
        morado("nether", "¡Se abre el Nether!",
                "A partir de ahora los portales al Nether funcionan. Llevad agua... ah, no, que allí se evapora. Llevad valor.",
                server -> EstadoServidor.get(server).agregarCambio("nether_abierto"));
        morado("end", "¡Se abre el End!",
                "A partir de ahora el portal del End funciona. El dragón ha sido avisado. No le ha hecho gracia.",
                server -> EstadoServidor.get(server).agregarCambio("end_abierto"));

        // ===================== AMARILLO DE LA LIBRETA (solo con la libreta abierta) =====================
        amarillo("libreta_mejorada", "¡Los mobs de la Libreta han sido mejorados!",
                "En la Libreta: los zombies dibujados te borran la fuerza al golpearte (Debilidad 4 s); las flechas de los esqueletos dibujados dan Lentitud II 3 s; "
                        + "la explosión de los creepers dibujados te ciega 3 s y te mancha la pantalla de tinta; las arañas dibujadas te dejan pegado 4 s en una telaraña; "
                        + "y al matar un Garabato hay un 50 % de probabilidad de que el becario lo vuelva a dibujar.",
                "Los garabatos se sintieron celosos de que solo hayamos mejorado a los de la superficie, así que les hemos agregado cosas.",
                server -> EstadoServidor.get(server).agregarCambio("libreta_mejorada"));
    }

    // ---------- Grupos para /desinfo activar ----------
    public static final java.util.List<String> GRUPO_MOBS = java.util.List.of(
            "creepers_oscuros", "furros", "cubo_blanco", "zombie_naranja", "garabatos", "interferencia",
            "travensanos", "ale", "ulises", "angel", "brandon_kevin", "altky");
    public static final java.util.List<String> GRUPO_MUTACIONES = java.util.List.of(
            "aranas_pequenas", "zombies_falsos", "esqueletos_doble_arco", "creepers_electrificados", "bebes_rapidos",
            "ale_poderoso", "travensanos_furiosos", "garabatos_altos", "furros_manada", "interferencias_clon",
            "cubo_gigante", "ulises_rapido", "creeper_invisible", "libreta_mejorada", "brandon_mejorado", "altky_tableta",
            "ghasts_triples", "blazes_dobles", "piglins_ladrones", "hoglins_gimnasio", "magma_ardiente", "wither_veneno",
            "zombificados_rencorosos", "enderman_teletransporte");
    public static final java.util.List<String> GRUPO_MUNDO = java.util.List.of(
            "arboles", "fuego_eterno", "objetos_catapulta", "ovejas_sin_lana", "aldeanos_caros", "comida_podrida",
            "sed_cuevas", "camas_rotas", "leche_cortada", "regeneracion_lenta", "agua_escasa", "cultivos_lentos",
            "hornos_glotones", "antorchas_apagan", "herramientas_fragiles", "armadura_oxidada", "encantamientos_caros",
            "esprintar_agota", "suelos_resbaladizos", "caidas_duras");

    /** Activa un grupo entero de golpe, sin teles (para pruebas o para saltar a una fase avanzada). */
    public static int activarGrupo(MinecraftServer server, java.util.List<String> ids) {
        int n = 0;
        for (String id : ids) {
            Evento ev = TODOS.get(id);
            if (ev == null) continue;
            if (!puedeLanzarse(server, id)) continue; // los de la Libreta necesitan la libreta abierta
            ev.accion().accept(server);
            EstadoServidor.get(server).agregarCambio("evento:" + id);
            n++;
        }
        Modificaciones.aplicarATodos(server);
        return n;
    }

    /** Deshace todos los cambios de dificultad y vuelve a bloquear los mobs del mod. */
    public static void desactivarTodo(MinecraftServer server) {
        EstadoServidor estado = EstadoServidor.get(server);
        estado.getCambios().clear();
        estado.getMobsDesbloqueados().clear();
        estado.markDirty();
        server.getGameRules().get(net.minecraft.world.GameRules.WATER_SOURCE_CONVERSION).set(true, server);
        Modificaciones.aplicarATodos(server);
    }

    // ---------- Herramientas para crear eventos ----------

    private static void verde(String id, String titulo, String descripcion, Consumer<MinecraftServer> accion) {
        TODOS.put(id, new Evento(id, "verde", titulo, descripcion, "", accion));
    }

    private static void morado(String id, String titulo, String descripcion, Consumer<MinecraftServer> accion) {
        TODOS.put(id, new Evento(id, "morado", titulo, descripcion, "", accion));
    }

    private static void amarillo(String id, String titulo, String descripcion, String excusa, Consumer<MinecraftServer> accion) {
        TODOS.put(id, new Evento(id, "amarillo", titulo, descripcion, excusa, accion));
    }

    /** Los cambios de la Libreta solo se pueden ejecutar si la libreta está abierta. */
    public static boolean puedeLanzarse(MinecraftServer server, String id) {
        return !com.centrodesinformacion.desinformados.dimension.MutacionesLibreta.IDS.contains(id)
                || com.centrodesinformacion.desinformados.dimension.MutacionesLibreta.libretaAbierta(server);
    }

    public static void lanzar(MinecraftServer server, Evento evento) {
        mostrarTele(server, evento.color(), evento.titulo(), evento.descripcion(), evento.excusa());
        Tareas.programar(RETRASO_TELE, () -> evento.accion().accept(server));
        if (evento.color().equals("amarillo")) EstadoServidor.get(server).agregarCambio("evento:" + evento.id());
    }

    public static void mostrarTele(MinecraftServer server, String color, String titulo, String descripcion) {
        mostrarTele(server, color, titulo, descripcion, "");
    }

    public static void mostrarTele(MinecraftServer server, String color, String titulo, String descripcion, String excusa) {
        EventoTvPayload paquete = new EventoTvPayload(color, titulo,
                excusa.isEmpty() ? descripcion : excusa + " " + descripcion);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, paquete);
        }
        // Cuando la tele ya se fue (o se rompió), el detalle queda escrito en el chat
        Formatting fmt = switch (color) {
            case "verde" -> Formatting.GREEN;
            case "rojo" -> Formatting.RED;
            case "morado" -> Formatting.LIGHT_PURPLE;
            default -> Formatting.YELLOW;
        };
        String etiqueta = switch (color) {
            case "verde" -> "ANUNCIO";
            case "rojo" -> "DESAFÍO";
            case "morado" -> "IMPORTANTE";
            default -> "CAMBIO DE DIFICULTAD";
        };
        Tareas.programar(RETRASO_TELE, () -> {
            Text linea = Text.literal("━━━━━━━━━━━━━━━━━━━━━━━━").formatted(fmt);
            server.getPlayerManager().broadcast(linea, false);
            server.getPlayerManager().broadcast(Text.literal("[" + etiqueta + "] ").formatted(fmt, Formatting.BOLD)
                    .append(Text.literal(titulo).formatted(fmt)), false);
            String texto = excusa.isEmpty() ? descripcion : excusa + " " + descripcion;
            if (!texto.isEmpty()) {
                server.getPlayerManager().broadcast(Text.literal(texto).formatted(fmt), false);
            }
            server.getPlayerManager().broadcast(linea, false);
        });
    }

    public static void desbloquearMob(MinecraftServer server, EntityType<?> tipo) {
        EstadoServidor.get(server).desbloquearMob(Registries.ENTITY_TYPE.getId(tipo).toString());
    }

    /** Muestra 5, 4, 3, 2, 1 en la barra de acción al final de la cuenta. */
    private static void cuentaAtras(MinecraftServer server, int segundos) {
        for (int s = Math.min(5, segundos); s >= 1; s--) {
            int mostrar = s;
            Tareas.programar((segundos - s) * 20, () -> {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    p.sendMessage(Text.literal(String.valueOf(mostrar)).formatted(Formatting.RED, Formatting.BOLD), true);
                }
            });
        }
    }
}

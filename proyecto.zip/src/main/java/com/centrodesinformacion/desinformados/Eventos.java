package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Lista de eventos preparados. Se lanzan con /desinfo lanzar <id>.
 *  - rojo: desafío puntual
 *  - amarillo: cambio de dificultad PERMANENTE (se guarda en el mundo)
 */
public class Eventos {
    public record Evento(String id, String color, String titulo, String descripcion, Consumer<MinecraftServer> accion) {}

    public static final Map<String, Evento> TODOS = new LinkedHashMap<>();

    /** Ticks que tarda la tele en ponerse de color: el efecto empieza justo ahí. */
    private static final int RETRASO_TELE = 52;

    static {
        // ===================== AMARILLOS (cambios de dificultad) =====================
        amarillo("arboles", "¡Los árboles han sido afectados!",
                "Plantar árboles será inútil a partir de ahora.",
                server -> EstadoServidor.get(server).agregarCambio("arboles"));

        amarillo("creepers_oscuros", "¡Llegan los Creepers Oscuros!",
                "Si su explosión te alcanza, perderás un contenedor de corazón.",
                server -> desbloquearMob(server, ModEntidades.CREEPER_OSCURO));
    }

    // ---------- Herramientas para crear eventos ----------

    private static void amarillo(String id, String titulo, String descripcion, Consumer<MinecraftServer> accion) {
        TODOS.put(id, new Evento(id, "amarillo", titulo, descripcion, accion));
    }

    public static void lanzar(MinecraftServer server, Evento evento) {
        mostrarTele(server, evento.color(), evento.titulo(), evento.descripcion());
        Tareas.programar(RETRASO_TELE, () -> evento.accion().accept(server));
        if (evento.color().equals("amarillo")) EstadoServidor.get(server).agregarCambio("evento:" + evento.id());
    }

    public static void mostrarTele(MinecraftServer server, String color, String titulo, String descripcion) {
        EventoTvPayload paquete = new EventoTvPayload(color, titulo, descripcion);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, paquete);
        }
    }

    public static void desbloquearMob(MinecraftServer server, EntityType<?> tipo) {
        EstadoServidor.get(server).desbloquearMob(Registries.ENTITY_TYPE.getId(tipo).toString());
    }

    /** Muestra 5, 4, 3, 2, 1 en la barra de acción al final de la cuenta. */
    private static void cuentaAtras(MinecraftServer server, int segundos) {
        for (int s = Math.min(5, segundos); s >= 1; s--) {
            int mostrar = s;
            Tareas.programar((segundos - s) * 20, () -> {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    p.sendMessage(Text.literal(String.valueOf(mostrar)).formatted(Formatting.RED, Formatting.BOLD), true);
                }
            });
        }
    }
}

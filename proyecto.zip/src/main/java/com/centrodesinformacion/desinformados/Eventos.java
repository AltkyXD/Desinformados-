package com.centrodesinformacion.desinformados;

import com.centrodesinformacion.desinformados.entidad.ModEntidades;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Lista de eventos preparados. Se lanzan con /desinfo lanzar <id>.
 *  - rojo: desafío puntual
 *  - amarillo: cambio de dificultad PERMANENTE (se guarda en el mundo)
 */
public class Eventos {
    public record Evento(String id, String color, String titulo, String descripcion, String excusa, Consumer<MinecraftServer> accion) {}

    public static final Map<String, Evento> TODOS = new LinkedHashMap<>();

    /** Ticks que tarda la tele en ponerse de color: el efecto empieza justo ahí. */
    private static final int RETRASO_TELE = 52;

    static {
        // ===================== AMARILLOS (cambios de dificultad) =====================
        // Formato: amarillo(id, título, qué cambia, comunicado sarcástico, acción)
        // En la tele y el chat sale como un solo texto: primero el comunicado y luego qué cambia.

        amarillo("arboles", "¡Los árboles han sido afectados!",
                "A partir de ahora plantar árboles será inútil: los brotes ya no crecerán nunca.",
                "Los árboles se han declarado en huelga indefinida. Exigen mejores condiciones y que dejéis de talarlos a puñetazos, cosa que nos parece razonable.",
                server -> EstadoServidor.get(server).agregarCambio("arboles"));

        amarillo("creepers_oscuros", "¡Llegan los Creepers Oscuros!",
                "Así que cuidado al bajar: aparecerán SOLO en cuevas y, si su explosión te alcanza, perderás un contenedor de corazón.",
                "No son creepers normales pintados con rotulador negro. Bueno, sí lo son, pero el rotulador estaba maldito y no pensamos devolverlo.",
                server -> desbloquearMob(server, ModEntidades.CREEPER_OSCURO));

        amarillo("furros", "¡Han llegado los Furros!",
                "Si te ven, te perseguirán para abrazarte, dejándote con Lentitud IV y quitándote medio corazón cada 2 segundos. Puedes pegarles para soltarte.",
                "El Centro de Desinformación organizó una convención en el sótano y se nos olvidó cerrar la puerta. Solo quieren cariño. Mucho cariño. Demasiado cariño. No hagáis contacto visual.",
                server -> desbloquearMob(server, ModEntidades.FURRO));

        amarillo("zombies_falsos", "¡Zombies adultos falsos!",
                "A partir de ahora, al derrotar a un zombie adulto se partirá en 2 zombies pequeños, y si llevaba armadura se la repartirán entre los dos.",
                "Tras una larga investigación, el Centro de Desinformación ha descubierto que los zombies adultos eran en realidad dos zombies bebé dentro de una gabardina. Lamentamos el engaño, del cual no somos responsables en absoluto.",
                server -> EstadoServidor.get(server).agregarCambio("zombies_falsos"));

        amarillo("esqueletos_doble_arco", "¡Esqueletos con doble arco!",
                "Ahora los esqueletos llevan un arco en cada mano y disparan dos flechas a la vez, algo abiertas para que cueste esquivarlas.",
                "Los esqueletos se quejaron de que un solo arco no les dejaba expresar todo su potencial artístico. El Centro de Desinformación, siempre comprometido con la cultura, les ha regalado otro. No sabemos cómo los sujetan sin músculos, y preferimos no preguntar.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("esqueletos_doble_arco");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("cubo_blanco", "¡Ha aparecido el Cubo Blanco!",
                "Es muy lento, pero si te toca te flasheará: tu pantalla se quedará completamente en blanco unos segundos y te dará Lentitud I.",
                "Le pedimos un mob nuevo al becario del Centro de Desinformación y solo le dio tiempo a hacer un cubo. Lo pintamos de blanco para que pareciera minimalista y moderno. No sabemos qué es ni qué quiere. No lo toquéis. Mejor dicho, que no os toque.",
                server -> desbloquearMob(server, ModEntidades.CUBO_BLANCO));

        amarillo("zombie_naranja", "¡Llega el Zombie Naranja!",
                "Solo recibe daño de proyectiles (flechas, tridentes...), tiene 15 corazones, pega un 25% más fuerte y es un poco más rápido que un zombie normal, aunque no tanto como uno pequeño. Espadas y hachas no le hacen nada.",
                "Un zombie se pasó tres semanas tomando el sol y se volvió naranja. Desde entonces dice que es inmune a los golpes porque \"tiene la piel curtida\". El Centro de Desinformación ha verificado esta información y la considera totalmente cierta.",
                server -> desbloquearMob(server, ModEntidades.ZOMBIE_NARANJA));

        amarillo("fuego_eterno", "¡El fuego ya no se apaga!",
                "A partir de ahora, si te prendes fuego no se apagará con el tiempo: tendrás que meterte en el agua (o esperar a que te pille la lluvia) para apagarlo.",
                "El Centro de Desinformación ha cambiado de proveedor de fuego. El nuevo es más barato y viene sin botón de apagado. Hemos enviado una queja formal, pero el proveedor tampoco puede responder porque sigue en llamas.",
                server -> EstadoServidor.get(server).agregarCambio("fuego_eterno"));

        amarillo("objetos_catapulta", "¡Soltar objetos es peligroso!",
                "A partir de ahora, al soltar un objeto saldrá disparado en la dirección en la que mires, con la fuerza de una flecha bien tensada. Cuidado al soltar cosas cerca de lava, del vacío o de un precipicio.",
                "Para ahorrar en envíos, el Centro de Desinformación ha sustituido el sistema de soltar objetos por catapultas de bolsillo. Ya no hace falta acercarse para dar cosas a tus compañeros: basta con apuntar y rezar.",
                server -> EstadoServidor.get(server).agregarCambio("objetos_catapulta"));

        amarillo("ovejas_sin_lana", "¡Las ovejas se han quedado sin lana!",
                "A partir de ahora todas las ovejas estarán esquiladas y la lana no les volverá a crecer, ni comiendo hierba. Tampoco la soltarán al morir.",
                "Tras una ola de calor provocada por el nuevo proveedor de fuego, las ovejas han decidido raparse por completo y han prometido no volver a dejarse crecer la lana jamás. El Centro de Desinformación respeta su decisión y su nuevo estilo.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("ovejas_sin_lana");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("aldeanos_caros", "¡Inflación en las aldeas!",
                "A partir de ahora todos los aldeanos cobrarán un 50% más por cada intercambio. Los descuentos por curarlos o por ser Héroe de la Aldea se siguen aplicando, pero sobre el precio nuevo.",
                "Los aldeanos han contratado a un asesor financiero del Centro de Desinformación, que les ha explicado que las esmeraldas valen la mitad que ayer por culpa de la inflación, la economía y, sobre todo, porque sí.",
                server -> EstadoServidor.get(server).agregarCambio("aldeanos_caros"));

        amarillo("garabatos", "¡Los Garabatos han cobrado vida!",
                "Son monigotes de palo dibujados en una hoja de papel, del tamaño de un jugador. Si te ven se acercarán y, si te tocan, te teletransportarán 10 bloques hacia arriba. Lo que pase después es cosa de la gravedad.",
                "Un becario del Centro de Desinformación se aburría tanto en una reunión que llenó su libreta de monigotes. Ahora los monigotes también se aburren y han decidido salir a jugar con vosotros. El becario ha sido ascendido.",
                server -> desbloquearMob(server, ModEntidades.GARABATO));

        amarillo("creepers_electrificados", "¡Creepers electrificados!",
                "A partir de ahora todos los creepers estarán electrificados, incluidos los Creepers Oscuros: su explosión será el doble de grande y mucho más dañina. Como consuelo, si matan a otro mob con la explosión puede soltar su cabeza.",
                "El Centro de Desinformación instaló pararrayos en todas las cuevas para proteger a los mobs. Por desgracia, los creepers se los comieron. Ahora brillan, chisporrotean y se niegan a devolvernos los pararrayos.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("creepers_electrificados");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("bebes_rapidos", "¡Los zombies pequeños van a tope!",
                "A partir de ahora los zombies pequeños serán un 50% más rápidos de lo que ya eran. Se aplica a todos: zombies, husks, ahogados y aldeanos zombie bebé.",
                "Alguien del Centro de Desinformación dejó una cafetera encendida cerca de una guardería de zombies. Ahora los bebés llevan tres días sin dormir y no piensan parar. Nadie sabe quién dejó la cafetera. Fue el becario.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("bebes_rapidos");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("ale_poderoso", "¡Ale se ha vuelto más poderoso!",
                "A partir de ahora Ale tendrá un 50% más de vida, fuerza y velocidad, será más grande y al morir soltará 4 Travensaños en lugar de 2.",
                "Ale ha empezado a ir al gimnasio por recomendación del Centro de Desinformación. Después de varias semanas haciendo press de banca con Travensaños, ha crecido, corre más y ahora va acompañado del doble de ellos. Le hemos pedido que pare. No ha parado.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("ale_poderoso");
                    Modificaciones.aplicarATodos(server);
                });

        amarillo("travensanos_furiosos", "¡Travensaños furiosos!",
                "A partir de ahora, cuando un Travensaño se te siente en el cuello te quitará un corazón entero cada 1,5 segundos, en lugar de medio corazón cada 3. Es decir: el doble de rápido y el doble de daño.",
                "Los Travensaños se enteraron de que Ale los usaba como pesas en el gimnasio y no se lo han tomado nada bien. Como no pueden vengarse de él, se vengarán de vosotros. El Centro de Desinformación considera que es una reacción totalmente proporcionada.",
                server -> EstadoServidor.get(server).agregarCambio("travensanos_furiosos"));

        amarillo("ale", "¡Ale anda suelto!",
                "Ale empezará a aparecer en lugares oscuros. Tiene 10 corazones, te perseguirá para pegarte y, al morir, soltará 2 Travensaños.",
                "Ale salió a comprar pan hace tres días y todavía no ha encontrado el camino de vuelta. Desde entonces vaga por el mundo pegando a todo el que se cruza. El Centro de Desinformación asegura que el pan no tiene nada que ver.",
                server -> EstadoServidor.get(server).agregarCambio("ale"));

        amarillo("travensanos", "¡Se ha descubierto una nueva especie: los Travensaños!",
                "Aparecerán en lugares oscuros. Si te ven, te perseguirán y se te sentarán en el cuello: te quitarán vida poco a poco y te invertirán los controles y la cámara hasta que los mates.",
                "Los científicos del Centro de Desinformación han descubierto una especie que llevaba siglos viviendo entre nosotros: los Travensaños. Viven en la playa todo el año y no entienden el concepto de espacio personal. Lo de sentarse en el cuello, aseguran, es una muestra de cariño.",
                server -> EstadoServidor.get(server).agregarCambio("travensanos"));

        amarillo("ulises", "¡Cuidado con Ulises!",
                "Ulises aparecerá en lugares oscuros. Si te ve, se te quedará mirando fijamente 8 segundos y lanzará un rayo rojo que te quitará la mitad de la vida que tengas. Escóndete para que te pierda de vista o pégale para desconcentrarlo.",
                "Ulises lleva semanas diciendo que está bien. No está bien. Ahora deambula por el mundo mirando fijamente a la gente y proyectando sobre ella que el amor no fue real. El Centro de Desinformación le recomendó terapia; él prefirió los rayos láser.",
                server -> EstadoServidor.get(server).agregarCambio("ulises"));

        amarillo("interferencia", "¡Hay Interferencias en la señal!",
                "Aparecerán en lugares oscuros. Si una te toca, verás algo que no querrás ver, perderás 5 corazones durante 1 minuto y ella desaparecerá. Tiene 4 corazones: mejor mátala antes de que te alcance.",
                "Desde que el reactor se dañó, la señal del Centro de Desinformación capta cosas raras. Nuestros técnicos aseguran que son solo interferencias. Nuestros técnicos también han dejado de venir a trabajar.",
                server -> desbloquearMob(server, ModEntidades.INTERFERENCIA));

        amarillo("aranas_pequenas", "¡Las arañas han encogido!",
                "Desde hoy las arañas tienen el tamaño de un pez globo: caben por cualquier hueco y son más difíciles de golpear.",
                "Por recortes de presupuesto, el Centro de Desinformación ya no puede permitirse arañas de tamaño completo, así que las hemos lavado con agua caliente. Sentimos los inconvenientes. No los sentimos.",
                server -> {
                    EstadoServidor.get(server).agregarCambio("aranas_pequenas");
                    Modificaciones.aplicarATodos(server);
                });
    }

    // ---------- Herramientas para crear eventos ----------

    private static void amarillo(String id, String titulo, String descripcion, String excusa, Consumer<MinecraftServer> accion) {
        TODOS.put(id, new Evento(id, "amarillo", titulo, descripcion, excusa, accion));
    }

    public static void lanzar(MinecraftServer server, Evento evento) {
        mostrarTele(server, evento.color(), evento.titulo(), evento.descripcion(), evento.excusa());
        Tareas.programar(RETRASO_TELE, () -> evento.accion().accept(server));
        if (evento.color().equals("amarillo")) EstadoServidor.get(server).agregarCambio("evento:" + evento.id());
    }

    public static void mostrarTele(MinecraftServer server, String color, String titulo, String descripcion) {
        mostrarTele(server, color, titulo, descripcion, "");
    }

    public static void mostrarTele(MinecraftServer server, String color, String titulo, String descripcion, String excusa) {
        EventoTvPayload paquete = new EventoTvPayload(color, titulo,
                excusa.isEmpty() ? descripcion : excusa + " " + descripcion);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, paquete);
        }
        // Cuando la tele se pone de color, el detalle queda escrito en el chat
        Formatting fmt = switch (color) {
            case "verde" -> Formatting.GREEN;
            case "rojo" -> Formatting.RED;
            default -> Formatting.YELLOW;
        };
        String etiqueta = switch (color) {
            case "verde" -> "ANUNCIO";
            case "rojo" -> "DESAFÍO";
            default -> "CAMBIO DE DIFICULTAD";
        };
        Tareas.programar(RETRASO_TELE, () -> {
            Text linea = Text.literal("━━━━━━━━━━━━━━━━━━━━━━━━").formatted(fmt);
            server.getPlayerManager().broadcast(linea, false);
            server.getPlayerManager().broadcast(Text.literal("[" + etiqueta + "] ").formatted(fmt, Formatting.BOLD)
                    .append(Text.literal(titulo).formatted(fmt)), false);
            String texto = excusa.isEmpty() ? descripcion : excusa + " " + descripcion;
            if (!texto.isEmpty()) {
                server.getPlayerManager().broadcast(Text.literal(texto).formatted(fmt), false);
            }
            server.getPlayerManager().broadcast(linea, false);
        });
    }

    public static void desbloquearMob(MinecraftServer server, EntityType<?> tipo) {
        EstadoServidor.get(server).desbloquearMob(Registries.ENTITY_TYPE.getId(tipo).toString());
    }

    /** Muestra 5, 4, 3, 2, 1 en la barra de acción al final de la cuenta. */
    private static void cuentaAtras(MinecraftServer server, int segundos) {
        for (int s = Math.min(5, segundos); s >= 1; s--) {
            int mostrar = s;
            Tareas.programar((segundos - s) * 20, () -> {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    p.sendMessage(Text.literal(String.valueOf(mostrar)).formatted(Formatting.RED, Formatting.BOLD), true);
                }
            });
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.*;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Renderers de los mobs de estática: los modelos de siempre con textura de estática. */
public class EstaticaRenderers {
    static Identifier tex(String n) { return Desinformados.id("textures/entity/" + n + "_estatica.png"); }

    public static class Zombie extends ZombieEntityRenderer {
        public Zombie(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return tex("zombie"); }
    }

    public static class Esqueleto extends SkeletonEntityRenderer<net.minecraft.entity.mob.SkeletonEntity> {
        public Esqueleto(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SkeletonEntity e) { return tex("esqueleto"); }
    }

    public static class Arana extends SpiderEntityRenderer<SpiderEntity> {
        public Arana(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SpiderEntity e) { return tex("arana"); }
    }

    public static class Creeper extends CreeperEntityRenderer {
        public Creeper(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return tex("creeper"); }
    }

    // ---------- Mobs nuevos del Nether ----------
    public static class CreeperFuego extends CreeperEntityRenderer {
        public CreeperFuego(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return Desinformados.id("textures/entity/creeper_fuego.png"); }
    }

    public static class EsqueletoRafaga extends SkeletonEntityRenderer<net.minecraft.entity.mob.SkeletonEntity> {
        public EsqueletoRafaga(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SkeletonEntity e) { return Desinformados.id("textures/entity/esqueleto_rafaga.png"); }
    }

    public static class CuboRojo extends net.minecraft.client.render.entity.SlimeEntityRenderer {
        public CuboRojo(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SlimeEntity e) { return Desinformados.id("textures/entity/cubo_rojo.png"); }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.*;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Renderers de los mobs de estática: los modelos de siempre con textura de estática. */
public class EstaticaRenderers {
    static Identifier tex(String n) { return Desinformados.id("textures/entity/" + n + "_estatica.png"); }
    // Texturas creadas una vez (getTexture se llama en cada fotograma por cada mob)
    private static final Identifier ZOMBIE = tex("zombie"), ESQUELETO = tex("esqueleto"), ARANA = tex("arana"), CREEPER = tex("creeper");
    private static final Identifier CREEPER_FUEGO = Desinformados.id("textures/entity/creeper_fuego.png");
    private static final Identifier ESQUELETO_RAFAGA = Desinformados.id("textures/entity/esqueleto_rafaga.png");
    private static final Identifier CUBO_ROJO = Desinformados.id("textures/entity/cubo_rojo.png");

    public static class Zombie extends ZombieEntityRenderer {
        public Zombie(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return ZOMBIE; }
    }

    public static class Esqueleto extends SkeletonEntityRenderer<net.minecraft.entity.mob.SkeletonEntity> {
        public Esqueleto(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SkeletonEntity e) { return ESQUELETO; }
    }

    public static class Arana extends SpiderEntityRenderer<SpiderEntity> {
        public Arana(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SpiderEntity e) { return ARANA; }
    }

    public static class Creeper extends CreeperEntityRenderer {
        public Creeper(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return CREEPER; }
    }

    // ---------- Mobs nuevos del Nether ----------
    public static class CreeperFuego extends CreeperEntityRenderer {
        public CreeperFuego(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return CREEPER_FUEGO; }
    }

    public static class EsqueletoRafaga extends SkeletonEntityRenderer<net.minecraft.entity.mob.SkeletonEntity> {
        public EsqueletoRafaga(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SkeletonEntity e) { return ESQUELETO_RAFAGA; }
    }

    public static class CuboRojo extends net.minecraft.client.render.entity.SlimeEntityRenderer {
        public CuboRojo(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(net.minecraft.entity.mob.SlimeEntity e) { return CUBO_ROJO; }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.ModVariantes3;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.CreeperEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.util.Identifier;

/** Renderers de las variantes de los mobs del mod (parte 2 de 2): el renderer de su original con la textura nueva. */
public final class VarianteRenderers3 {
    private VarianteRenderers3() {}

    static Identifier tex(String id) { return Desinformados.id("textures/entity/" + id + ".png"); }

    // Texturas creadas una vez (getTexture se llama en cada fotograma por cada mob)
    private static final Identifier CREEPER_CENIZA = tex("creeper_ceniza");
    private static final Identifier ESQUELETO_FUEGO = tex("esqueleto_fuego");

    /** Como EstaticaRenderers.CreeperFuego, con la textura de ceniza. */
    public static class CreeperCenizaVariante3 extends CreeperEntityRenderer {
        public CreeperCenizaVariante3(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return CREEPER_CENIZA; }
    }

    /** Esqueleto normal con la textura de fuego. */
    public static class EsqueletoFuegoVariante3 extends SkeletonEntityRenderer<SkeletonEntity> {
        public EsqueletoFuegoVariante3(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SkeletonEntity e) { return ESQUELETO_FUEGO; }
    }

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityRendererRegistry.register(ModVariantes3.CREEPER_CENIZA, (EntityRendererFactory) CreeperCenizaVariante3::new);
        EntityRendererRegistry.register(ModVariantes3.ESQUELETO_FUEGO, (EntityRendererFactory) EsqueletoFuegoVariante3::new);
    }
}

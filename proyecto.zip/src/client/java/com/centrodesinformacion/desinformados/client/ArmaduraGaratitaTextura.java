package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.Optional;

/**
 * Armadura de Garatita con la FORMA de la de netherite: al cargar los recursos coge el diseño de la armadura de netherite
 * del propio juego (qué partes cubre, el casco abierto, los relieves y sombras) y lo pinta con el papel de libreta de la Garatita.
 * No copia ninguna textura de Minecraft dentro del mod: se genera en tu juego cada vez que cargan los recursos.
 */
public final class ArmaduraGaratitaTextura implements SimpleSynchronousResourceReloadListener {
    /** La armadura de Garatita usa esta textura (ModGaratita: capa "garatita_netherite"). */
    public static Identifier destino(int capa) {
        return Desinformados.id("textures/models/armor/garatita_netherite_layer_" + capa + ".png");
    }

    @Override
    public Identifier getFabricId() {
        return Desinformados.id("armadura_garatita_netherite");
    }

    @Override
    public void reload(ResourceManager recursos) {
        for (int capa = 1; capa <= 2; capa++) {
            NativeImage resultado = null;
            try (NativeImage papel = leer(recursos, Desinformados.id("textures/models/armor/garatita_layer_" + capa + ".png"))) {
                try (NativeImage forma = leer(recursos, Identifier.ofVanilla("textures/models/armor/netherite_layer_" + capa + ".png"))) {
                    resultado = combinar(forma, papel);
                } catch (Exception e) {
                    resultado = copiar(papel);                       // sin netherite (raro): la de papel de siempre
                }
            } catch (Exception e) {
                Desinformados.LOGGER.warn("No se pudo preparar la armadura de Garatita (capa {}): {}", capa, e.toString());
            }
            if (resultado != null)
                MinecraftClient.getInstance().getTextureManager().registerTexture(destino(capa), new NativeImageBackedTexture(resultado));
        }
    }

    private static NativeImage leer(ResourceManager recursos, Identifier id) throws Exception {
        Optional<Resource> r = recursos.getResource(id);
        if (r.isEmpty()) throw new java.io.FileNotFoundException(id.toString());
        try (InputStream in = r.get().getInputStream()) {
            return NativeImage.read(in);
        }
    }

    private static NativeImage copiar(NativeImage img) {
        NativeImage out = new NativeImage(img.getWidth(), img.getHeight(), true);
        out.copyFrom(img);
        return out;
    }

    // Colores en formato ABGR (el de NativeImage)
    private static int a(int c) { return c >>> 24; }
    private static int r(int c) { return c & 0xFF; }
    private static int g(int c) { return (c >> 8) & 0xFF; }
    private static int b(int c) { return (c >> 16) & 0xFF; }
    private static int abgr(int a, int r, int g, int b) { return (a << 24) | (b << 16) | (g << 8) | r; }

    /** La forma y el sombreado de 'forma' (netherite) con los colores de 'papel' (Garatita). */
    private static NativeImage combinar(NativeImage forma, NativeImage papel) {
        int w = forma.getWidth(), h = forma.getHeight();
        // brillo medio de la netherite, para saber qué es relieve claro y qué es sombra
        double suma = 0;
        int n = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = forma.getColor(x, y);
            if (a(c) > 0) { suma += luz(c); n++; }
        }
        double media = n > 0 ? suma / n : 1;
        NativeImage out = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = forma.getColor(x, y);
            if (a(c) == 0) { out.setColor(x, y, 0); continue; }
            int px = x * papel.getWidth() / w, py = y * papel.getHeight() / h;
            int p = papel.getColor(px, py);
            if (a(p) == 0) p = abgr(255, 244, 238, 220);            // donde la de papel no tenía nada: papel crema
            double sombra = Math.max(0.55, Math.min(1.3, luz(c) / media));
            out.setColor(x, y, abgr(a(c), tope(r(p) * sombra), tope(g(p) * sombra), tope(b(p) * sombra)));
        }
        return out;
    }

    private static double luz(int c) { return 0.299 * r(c) + 0.587 * g(c) + 0.114 * b(c); }
    private static int tope(double v) { return (int) Math.max(0, Math.min(255, Math.round(v))); }
}

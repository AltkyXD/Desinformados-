package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.entidad.agua.ModCocodrilo;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;

/** Renderer y capa de modelo del Cocodrilo. */
public final class CocodriloRenderers {
    private CocodriloRenderers() {}

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityModelLayerRegistry.registerModelLayer(CocodriloModel.CAPA, CocodriloModel::getTexturedModelData);
        EntityRendererRegistry.register(ModCocodrilo.COCODRILO, (EntityRendererFactory) CocodriloRenderer::new);
    }
}

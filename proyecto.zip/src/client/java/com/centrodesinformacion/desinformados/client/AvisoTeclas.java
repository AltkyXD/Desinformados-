package com.centrodesinformacion.desinformados.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Al entrar al mundo sale en el chat un recordatorio con las teclas del mod (Misiones, Pasivas y Enciclopedia).
 * Espera a que no haya ninguna pantalla abierta (carga, cinemática de la intro...) para que no se pierda.
 * Muestra la tecla que tenga asignada cada uno (por defecto U, I y O).
 */
public final class AvisoTeclas {
    private static final int ESPERA = 60;   // 3 s después de poder jugar
    private static boolean pendiente = false;
    private static int espera = 0;

    private AvisoTeclas() {}

    public static void registrar() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, cliente) -> {
            pendiente = true;
            espera = ESPERA;
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, cliente) -> pendiente = false);
        ClientTickEvents.END_CLIENT_TICK.register(AvisoTeclas::tick);
    }

    private static void tick(MinecraftClient cliente) {
        if (!pendiente || cliente.player == null || cliente.currentScreen != null) return;
        if (--espera > 0) return;
        pendiente = false;
        Text linea = Text.literal("━━━━━━━━━━━━━━━━━━━━━━━━").formatted(Formatting.DARK_AQUA);
        cliente.player.sendMessage(linea, false);
        cliente.player.sendMessage(Text.literal("Teclas del Centro de Desinformación").formatted(Formatting.AQUA, Formatting.BOLD), false);
        cliente.player.sendMessage(tecla(DesinformadosClient.TECLA_MISIONES, "Misiones (principales y secundarias)"), false);
        cliente.player.sendMessage(tecla(PasivasCliente.TECLA, "Pasivas"), false);
        cliente.player.sendMessage(tecla(DesinformadosClient.TECLA_ENCICLOPEDIA, "Enciclopedia (cambios, mobs, mutaciones y crafteos)"), false);
        cliente.player.sendMessage(linea, false);
    }

    private static MutableText tecla(KeyBinding k, String que) {
        return Text.literal(" [").formatted(Formatting.GRAY)
                .append(k.getBoundKeyLocalizedText().copy().formatted(Formatting.YELLOW, Formatting.BOLD))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(Text.literal(que).formatted(Formatting.WHITE));
    }
}

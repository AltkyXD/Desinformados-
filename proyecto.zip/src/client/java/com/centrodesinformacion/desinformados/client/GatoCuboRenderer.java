package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Cubo negro con la cara del gato del canal en el frente (sin pixelar) y un "uniforme" según su trabajo. */
public class GatoCuboRenderer extends EntityRenderer<GatoCuboEntity> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/gato_cubo.png");
    private static final Identifier BLANCO = Desinformados.id("textures/entity/blanco.png");
    private static final float H = 0.45f, ALTO = 0.9f;

    public GatoCuboRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.45f;
    }

    @Override
    public void render(GatoCuboEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        burbuja(e, delta, m, buffers);
        m.push();
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevHeadYaw, e.headYaw);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-cuerpo));
        float paso = e.limbAnimator.getPos(delta);
        float fuerza = Math.min(1f, e.limbAnimator.getSpeed(delta) * 1.5f);
        float tiempo = e.age + delta;
        m.translate(0, Math.abs(MathHelper.sin(paso * 0.7f)) * 0.18f * fuerza, 0);       // saltitos al andar
        float respira = 1f + MathHelper.sin(tiempo * 0.1f) * 0.02f;
        m.scale(1f / respira, respira, 1f / respira);
        if (e.getTipo() == GatoCuboEntity.GATITO) m.scale(0.55f, 0.55f, 0.55f);      // el hijo es pequeñito
        if (e.getTipo() == GatoCuboEntity.PLANO) m.scale(1f, 1f, 0.05f);             // el Gato 2D es plano
        int overlay = LivingEntityRenderer.getOverlay(e, 0f);
        MatrixStack.Entry pose = m.peek();

        // --- el cubo (estilo "Floppa"): cara delante, pelo por todos lados y orejas grandes ---
        VertexConsumer v = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURA));
        // frente (+Z): la cara del gato  (textura: cara 0-.5/0-.5 · pelo canela .5-1/0-.5 · pelo gris 0-.5/.5-1 · oreja .5-1/.5-1)
        cara(v, pose, H, ALTO, H, -H, ALTO, H, -H, 0, H, H, 0, H, 0f, 0f, 0.5f, 0.5f, 0, 0, 1, luz, overlay);
        cara(v, pose, -H, ALTO, -H, H, ALTO, -H, H, 0, -H, -H, 0, -H, 0f, 0.5f, 0.5f, 1f, 0, 0, -1, luz, overlay);   // espalda gris
        cara(v, pose, H, ALTO, -H, H, ALTO, H, H, 0, H, H, 0, -H, 0.5f, 0f, 1f, 0.5f, 1, 0, 0, luz, overlay);        // lados canela
        cara(v, pose, -H, ALTO, H, -H, ALTO, -H, -H, 0, -H, -H, 0, H, 0.5f, 0f, 1f, 0.5f, -1, 0, 0, luz, overlay);
        cara(v, pose, -H, ALTO, -H, -H, ALTO, H, H, ALTO, H, H, ALTO, -H, 0f, 0.5f, 0.5f, 1f, 0, 1, 0, luz, overlay); // arriba gris
        cara(v, pose, -H, 0, H, -H, 0, -H, H, 0, -H, H, 0, H, 0.5f, 0f, 1f, 0.5f, 0, -1, 0, luz, overlay);
        // orejas: dos láminas altas en las esquinas de arriba, un poco abiertas hacia fuera
        for (int lado = -1; lado <= 1; lado += 2) {
            m.push();
            m.translate(lado * 0.2f, ALTO - 0.02f, -0.06f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-lado * (9f + MathHelper.sin(tiempo * 0.12f + lado) * 2f)));
            MatrixStack.Entry po = m.peek();
            float w = 0.15f, h = 0.55f;
            float u0 = lado > 0 ? 1f : 0.5f, u1 = lado > 0 ? 0.5f : 1f; // la oreja derecha es la izquierda en espejo
            cara(v, po, -w, h, 0, w, h, 0, w, 0, 0, -w, 0, 0, u0, 0.5f, u1, 1f, 0, 0, 1, luz, overlay);
            m.pop();
        }
        pose = m.peek();

        // --- uniforme (detallado) ---
        VertexConsumer b = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        Uniformes.dibujar(e.getTipo(), b, m, luz, overlay);
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    /** Burbuja de "..." sobre la cabeza cuando estás cerca y puede hablar contigo. */
    private void burbuja(GatoCuboEntity e, float delta, MatrixStack m, VertexConsumerProvider buffers) {
        var jugador = net.minecraft.client.MinecraftClient.getInstance().player;
        if (jugador == null || jugador.squaredDistanceTo(e) > 25) return;
        if (e.age - e.ultimoClicCliente < GatoCuboEntity.ESPERA_DIALOGO) return;
        float t = e.age + delta;
        m.push();
        m.translate(0, 1.95f + MathHelper.sin(t * 0.12f) * 0.04f, 0);
        m.multiply(this.dispatcher.getRotation());
        float aparece = Math.min(1f, ((e.age + delta) % 100000) / 6f);
        m.scale(aparece, aparece, aparece);
        MatrixStack.Entry p = m.peek();
        VertexConsumer b = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        int ov = net.minecraft.client.render.OverlayTexture.DEFAULT_UV, luz = 0xF000F0;
        int blanco = 0xFFFFFFFF, negro = 0xFF1A1A1A;
        // cuerpo de la burbuja
        plano(b, p, -0.26f, 0.0f, 0.26f, 0.28f, 0f, blanco, luz, ov);
        plano(b, p, -0.22f, -0.03f, 0.22f, 0.0f, 0f, blanco, luz, ov);
        plano(b, p, -0.22f, 0.28f, 0.22f, 0.31f, 0f, blanco, luz, ov);
        // borde
        plano(b, p, -0.29f, 0.0f, -0.26f, 0.28f, 0f, negro, luz, ov);
        plano(b, p, 0.26f, 0.0f, 0.29f, 0.28f, 0f, negro, luz, ov);
        plano(b, p, -0.22f, 0.31f, 0.22f, 0.34f, 0f, negro, luz, ov);
        plano(b, p, -0.26f, 0.28f, -0.22f, 0.31f, 0f, negro, luz, ov);
        plano(b, p, 0.22f, 0.28f, 0.26f, 0.31f, 0f, negro, luz, ov);
        plano(b, p, -0.26f, -0.03f, -0.22f, 0.0f, 0f, negro, luz, ov);
        plano(b, p, 0.22f, -0.03f, 0.26f, 0.0f, 0f, negro, luz, ov);
        plano(b, p, -0.22f, -0.06f, -0.06f, -0.03f, 0f, negro, luz, ov);
        plano(b, p, 0.06f, -0.06f, 0.22f, -0.03f, 0f, negro, luz, ov);
        // piquito
        plano(b, p, -0.06f, -0.09f, 0.06f, -0.03f, 0f, blanco, luz, ov);
        plano(b, p, -0.09f, -0.09f, -0.06f, -0.03f, 0f, negro, luz, ov);
        plano(b, p, 0.06f, -0.09f, 0.09f, -0.03f, 0f, negro, luz, ov);
        plano(b, p, -0.06f, -0.13f, 0.0f, -0.09f, 0f, negro, luz, ov);
        // tres puntitos que "laten" uno detrás de otro
        for (int i = 0; i < 3; i++) {
            float salto = Math.max(0f, MathHelper.sin(t * 0.25f - i * 0.9f)) * 0.03f;
            float x = -0.15f + i * 0.12f;
            plano(b, p, x, 0.11f + salto, x + 0.06f, 0.17f + salto, 0.004f, negro, luz, ov);
            plano(b, p, x, 0.11f + salto, x + 0.06f, 0.17f + salto, -0.004f, negro, luz, ov);
        }
        m.pop();
    }

    private static void plano(VertexConsumer v, MatrixStack.Entry p, float x0, float y0, float x1, float y1, float z, int color, int luz, int ov) {
        vert(v, p, x0, y1, z, 0, 0, 0, 0, 1, color, luz, ov);
        vert(v, p, x1, y1, z, 1, 0, 0, 0, 1, color, luz, ov);
        vert(v, p, x1, y0, z, 1, 1, 0, 0, 1, color, luz, ov);
        vert(v, p, x0, y0, z, 0, 1, 0, 0, 1, color, luz, ov);
    }

    static void lazo(VertexConsumer b, MatrixStack.Entry pose, float f, int color, int luz, int overlay) {
        caja(b, pose, -0.16f, 0.03f, H, -0.03f, 0.13f, f + 0.03f, color, luz, overlay);
        caja(b, pose, 0.03f, 0.03f, H, 0.16f, 0.13f, f + 0.03f, color, luz, overlay);
        caja(b, pose, -0.03f, 0.05f, H, 0.03f, 0.11f, f + 0.04f, color, luz, overlay);
    }

    /** Un cuadrilátero con UV (u0,v0)-(u1,v1). Vértices: arriba-izq, arriba-der, abajo-der, abajo-izq (vistos desde fuera). */
    private static void cara(VertexConsumer v, MatrixStack.Entry p, float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4, float u0, float v0, float u1, float v1,
                             float nx, float ny, float nz, int luz, int overlay) {
        vert(v, p, x1, y1, z1, u0, v0, nx, ny, nz, 0xFFFFFFFF, luz, overlay);
        vert(v, p, x2, y2, z2, u1, v0, nx, ny, nz, 0xFFFFFFFF, luz, overlay);
        vert(v, p, x3, y3, z3, u1, v1, nx, ny, nz, 0xFFFFFFFF, luz, overlay);
        vert(v, p, x4, y4, z4, u0, v1, nx, ny, nz, 0xFFFFFFFF, luz, overlay);
    }

    static void caja(VertexConsumer v, MatrixStack.Entry p, float x0, float y0, float z0, float x1, float y1, float z1,
                             int color, int luz, int overlay) {
        float[][] caras = {
                {x0, y1, z1, x1, y1, z1, x1, y0, z1, x0, y0, z1, 0, 0, 1},
                {x1, y1, z0, x0, y1, z0, x0, y0, z0, x1, y0, z0, 0, 0, -1},
                {x1, y1, z1, x1, y1, z0, x1, y0, z0, x1, y0, z1, 1, 0, 0},
                {x0, y1, z0, x0, y1, z1, x0, y0, z1, x0, y0, z0, -1, 0, 0},
                {x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0},
                {x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0}};
        for (float[] c : caras) {
            vert(v, p, c[0], c[1], c[2], 0, 0, c[12], c[13], c[14], color, luz, overlay);
            vert(v, p, c[3], c[4], c[5], 1, 0, c[12], c[13], c[14], color, luz, overlay);
            vert(v, p, c[6], c[7], c[8], 1, 1, c[12], c[13], c[14], color, luz, overlay);
            vert(v, p, c[9], c[10], c[11], 0, 1, c[12], c[13], c[14], color, luz, overlay);
        }
    }

    private static void vert(VertexConsumer v, MatrixStack.Entry p, float x, float y, float z, float u, float tv,
                             float nx, float ny, float nz, int color, int luz, int overlay) {
        v.vertex(p, x, y, z).color((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, (color >>> 24) & 0xFF)
                .texture(u, tv).overlay(overlay).light(luz).normal(p, nx, ny, nz);
    }

    @Override
    public Identifier getTexture(GatoCuboEntity e) {
        return TEXTURA;
    }
}

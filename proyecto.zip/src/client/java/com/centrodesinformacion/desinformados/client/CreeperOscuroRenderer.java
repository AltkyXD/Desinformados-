package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.CreeperEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.util.Identifier;

public class CreeperOscuroRenderer extends CreeperEntityRenderer {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/creeper_oscuro.png");

    public CreeperOscuroRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
    }

    @Override
    public void render(CreeperEntity e, float yaw, float delta, net.minecraft.client.util.math.MatrixStack m,
                       net.minecraft.client.render.VertexConsumerProvider buffers, int luz) {
        var yo = net.minecraft.client.MinecraftClient.getInstance().player;
        if (e instanceof com.centrodesinformacion.desinformados.entidad.CreeperOscuroEntity c && c.isOculto()
                && yo != null && !yo.isSpectator() && yo.squaredDistanceTo(e) > 25) return; // invisible a más de 5 bloques
        super.render(e, yaw, delta, m, buffers, luz);
    }

    @Override
    public Identifier getTexture(CreeperEntity entidad) {
        return TEXTURA;
    }
}

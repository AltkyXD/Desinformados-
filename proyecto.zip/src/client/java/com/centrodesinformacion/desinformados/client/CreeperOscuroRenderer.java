package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.CreeperEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.util.Identifier;

public class CreeperOscuroRenderer extends CreeperEntityRenderer {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/creeper_oscuro.png");

    public CreeperOscuroRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
    }

    @Override
    public Identifier getTexture(CreeperEntity entidad) {
        return TEXTURA;
    }
}

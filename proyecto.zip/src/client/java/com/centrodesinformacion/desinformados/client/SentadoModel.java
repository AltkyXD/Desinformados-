package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.entidad.TravensanoEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.mob.MobEntity;

/** Modelo de jugador que se dibuja sentado a horcajadas cuando un Travensaño está en tu cuello. */
public class SentadoModel<T extends MobEntity> extends BipedEntityModel<T> {
    public SentadoModel(ModelPart raiz) {
        super(raiz);
    }

    @Override
    public void setAngles(T e, float paso, float fuerza, float edad, float yaw, float pitch) {
        super.setAngles(e, paso, fuerza, edad, yaw, pitch);
        if (e instanceof TravensanoEntity t && t.isSentado()) {
            // piernas abiertas hacia delante, por encima de tus hombros
            rightLeg.pitch = -1.4137167f;
            rightLeg.yaw = 0.45f;
            rightLeg.roll = 0.08f;
            leftLeg.pitch = -1.4137167f;
            leftLeg.yaw = -0.45f;
            leftLeg.roll = -0.08f;
            // brazos agarrándote la cabeza
            rightArm.pitch = -1.1f;
            rightArm.yaw = -0.25f;
            leftArm.pitch = -1.1f;
            leftArm.yaw = 0.25f;
        }
    }
}

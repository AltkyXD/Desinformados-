package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.agua.CocodriloEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo propio del Cocodrilo (textura 128x64, box UV). Medidas en píxeles (16 = 1 bloque), y hacia abajo, -z = delante:
 * <pre>
 * parte            padre   pivote (rel.)   cajas: uv -> origen (x,y,z) tamaño (w,h,d)
 * body             raíz    (0, 19, 0)      (0,0)   -> (-5,-3,-8) 10x6x16 ; crestas (0,22) -> (-3.5,-4,-7) y (2.5,-4,-7) 1x1x14
 * head             body    (0, 0, -8)      (52,0)  -> cráneo (-4,-4,-6) 8x4x7 ; ojos (116,0) 2x1x2 (el izquierdo en espejo) ;
 *                                          (82,0)  -> hocico (-3.5,-3,-15) 7x3x10 ; nariz (116,3) 4x1x2 ;
 *                                          (96,13) -> dientes de arriba (-2.5,0,-14.5) 5x1x8 (dentro de la mandíbula si está cerrada)
 * jaw              head    (0, 0, 0)       (52,13) -> mandíbula (-3,0,-15) 6x2x16 ; dientes de abajo (96,13) (-2.5,-1,-14.5) 5x1x8
 * tail1/2/3        cadena  (0,-1,8) (0,.5,8) (0,.5,8)  (0,37) 8x5x9 / (34,37) 6x4x9 / (64,37) 4x3x9 + crestas (30,22) 1x1x8
 * patas (4)        body    (+-5, 1, +-5)   (96,22) pata 3x3x3 + (108,22) pie 4x1x4 (las izquierdas en espejo)
 * </pre>
 * Largo total ~55 px (3,4 bloques); la mandíbula se abre con pitch positivo (bisagra en el pivote de la cabeza).
 */
public class CocodriloModel extends SinglePartEntityModel<CocodriloEntity> {
    public static final EntityModelLayer CAPA = new EntityModelLayer(Desinformados.id("cocodrilo"), "main");
    private static final float GRADOS = (float) Math.PI / 180f;

    private final ModelPart raiz;
    private final ModelPart cuerpo;
    private final ModelPart cabeza;
    private final ModelPart mandibula;
    private final ModelPart cola1;
    private final ModelPart cola2;
    private final ModelPart cola3;
    private final ModelPart pataDelDer;
    private final ModelPart pataDelIzq;
    private final ModelPart pataTrasDer;
    private final ModelPart pataTrasIzq;

    public CocodriloModel(ModelPart raiz) {
        this.raiz = raiz;
        this.cuerpo = raiz.getChild("body");
        this.cabeza = cuerpo.getChild("head");
        this.mandibula = cabeza.getChild("jaw");
        this.cola1 = cuerpo.getChild("tail1");
        this.cola2 = cola1.getChild("tail2");
        this.cola3 = cola2.getChild("tail3");
        this.pataDelDer = cuerpo.getChild("right_front_leg");
        this.pataDelIzq = cuerpo.getChild("left_front_leg");
        this.pataTrasDer = cuerpo.getChild("right_hind_leg");
        this.pataTrasIzq = cuerpo.getChild("left_hind_leg");
    }

    /** Generado desde la tabla de partes del script de la textura (mismas uv que el PNG). */
    public static TexturedModelData getTexturedModelData() {
        ModelData datos = new ModelData();
        ModelPartData raiz = datos.getRoot();
        ModelPartData cuerpo = raiz.addChild("body", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-5f, -3f, -8f, 10f, 6f, 16f)
                        .uv(0, 22).cuboid(-3.5f, -4f, -7f, 1f, 1f, 14f)
                        .uv(0, 22).cuboid(2.5f, -4f, -7f, 1f, 1f, 14f),
                ModelTransform.pivot(0f, 19f, 0f));
        ModelPartData cabeza = cuerpo.addChild("head", ModelPartBuilder.create()
                        .uv(52, 0).cuboid(-4f, -4f, -6f, 8f, 4f, 7f)
                        .uv(116, 0).cuboid(-4f, -5f, -5f, 2f, 1f, 2f)
                        .uv(116, 0).mirrored().cuboid(2f, -5f, -5f, 2f, 1f, 2f)
                        .uv(82, 0).mirrored(false).cuboid(-3.5f, -3f, -15f, 7f, 3f, 10f)
                        .uv(116, 3).cuboid(-2f, -4f, -15f, 4f, 1f, 2f)
                        .uv(96, 13).cuboid(-2.5f, 0f, -14.5f, 5f, 1f, 8f),
                ModelTransform.pivot(0f, 0f, -8f));
        cabeza.addChild("jaw", ModelPartBuilder.create()
                        .uv(52, 13).cuboid(-3f, 0f, -15f, 6f, 2f, 16f)
                        .uv(96, 13).cuboid(-2.5f, -1f, -14.5f, 5f, 1f, 8f),
                ModelTransform.pivot(0f, 0f, 0f));
        ModelPartData cola1 = cuerpo.addChild("tail1", ModelPartBuilder.create()
                        .uv(0, 37).cuboid(-4f, -2f, -1f, 8f, 5f, 9f)
                        .uv(30, 22).cuboid(-3f, -3f, 0f, 1f, 1f, 8f)
                        .uv(30, 22).cuboid(2f, -3f, 0f, 1f, 1f, 8f),
                ModelTransform.pivot(0f, -1f, 8f));
        ModelPartData cola2 = cola1.addChild("tail2", ModelPartBuilder.create()
                        .uv(34, 37).cuboid(-3f, -1.5f, -1f, 6f, 4f, 9f)
                        .uv(30, 22).cuboid(-2f, -2.5f, 0f, 1f, 1f, 8f)
                        .uv(30, 22).cuboid(1f, -2.5f, 0f, 1f, 1f, 8f),
                ModelTransform.pivot(0f, 0.5f, 8f));
        cola2.addChild("tail3", ModelPartBuilder.create()
                        .uv(64, 37).cuboid(-2f, -1f, -1f, 4f, 3f, 9f)
                        .uv(30, 22).cuboid(-0.5f, -2f, 0f, 1f, 1f, 8f),
                ModelTransform.pivot(0f, 0.5f, 8f));
        cuerpo.addChild("right_front_leg", ModelPartBuilder.create()
                        .uv(96, 22).cuboid(-2f, 0f, -1.5f, 3f, 3f, 3f)
                        .uv(108, 22).cuboid(-3f, 3f, -2.5f, 4f, 1f, 4f),
                ModelTransform.pivot(-5f, 1f, -5f));
        cuerpo.addChild("left_front_leg", ModelPartBuilder.create()
                        .uv(96, 22).mirrored().cuboid(-1f, 0f, -1.5f, 3f, 3f, 3f)
                        .uv(108, 22).cuboid(-1f, 3f, -2.5f, 4f, 1f, 4f),
                ModelTransform.pivot(5f, 1f, -5f));
        cuerpo.addChild("right_hind_leg", ModelPartBuilder.create()
                        .uv(96, 22).cuboid(-2f, 0f, -1.5f, 3f, 3f, 3f)
                        .uv(108, 22).cuboid(-3f, 3f, -2.5f, 4f, 1f, 4f),
                ModelTransform.pivot(-5f, 1f, 5f));
        cuerpo.addChild("left_hind_leg", ModelPartBuilder.create()
                        .uv(96, 22).mirrored().cuboid(-1f, 0f, -1.5f, 3f, 3f, 3f)
                        .uv(108, 22).cuboid(-1f, 3f, -2.5f, 4f, 1f, 4f),
                ModelTransform.pivot(5f, 1f, 5f));
        return TexturedModelData.of(datos, 128, 64);
    }

    @Override
    public ModelPart getPart() {
        return raiz;
    }

    @Override
    public void setAngles(CocodriloEntity e, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        float t = animationProgress;
        boolean agua = e.isTouchingWater();
        boolean agarra = e.estaAgarrando();
        float mov = Math.min(1f, limbDistance * 2f);

        // --- Cuerpo: nadando se inclina con el cabeceo (bucea de morro); con alguien en la boca, se revuelve
        cuerpo.pitch = agua ? MathHelper.clamp(headPitch, -50f, 50f) * GRADOS * 0.8f : 0f;
        cuerpo.yaw = 0f;
        cuerpo.roll = agua && agarra ? MathHelper.sin(t * 0.3f) * 0.6f : 0f;

        // --- Cabeza
        cabeza.yaw = MathHelper.clamp(headYaw, -35f, 35f) * GRADOS * 0.6f;
        cabeza.pitch = agua ? 0f : MathHelper.clamp(headPitch, -25f, 25f) * GRADOS * 0.5f;
        cabeza.roll = 0f;
        if (agarra) cabeza.yaw += MathHelper.sin(t * 0.7f) * 0.2f;      // sacude a la presa

        // --- Mandíbula (pitch positivo = abrir): del todo al morder (handSwingProgress), entreabierta
        //     mientras persigue, medio abierta con la presa dentro y, quieto en tierra, algún bostezo al sol
        float mordisco = MathHelper.sin(handSwingProgress * (float) Math.PI);
        float abierta;
        if (agarra) {
            abierta = 0.30f + 0.10f * MathHelper.sin(t * 0.4f);
        } else if (e.isAttacking()) {
            abierta = 0.15f + 0.12f * (0.5f + 0.5f * MathHelper.sin(t * 0.25f));
        } else if (!agua && mov < 0.1f) {
            float bostezo = MathHelper.sin((t + e.getId() * 37) * 0.021f);
            abierta = bostezo > 0.8f ? (bostezo - 0.8f) * 3.5f : 0f;
        } else {
            abierta = 0f;
        }
        mandibula.pitch = Math.max(abierta, mordisco * 0.9f);
        mandibula.yaw = 0f;
        mandibula.roll = 0f;

        // --- Cola: ondula de lado a lado (más deprisa y más fuerte al nadar), cada segmento con retraso
        float fase, amp;
        if (agua) {
            fase = t * (0.16f + 0.22f * mov);
            amp = 0.20f + 0.22f * mov;
        } else {
            fase = limbAngle * 0.6662f + t * 0.04f;
            amp = 0.05f + 0.22f * mov;
        }
        cola1.yaw = MathHelper.sin(fase) * amp;
        cola2.yaw = MathHelper.sin(fase - 1.0f) * amp * 1.3f;
        cola3.yaw = MathHelper.sin(fase - 2.0f) * amp * 1.6f;
        cola1.pitch = 0f;
        cola2.pitch = 0f;
        cola3.pitch = 0f;

        // --- Patas: en el agua, recogidas hacia atrás y abiertas, remando en diagonal; en tierra, paso de lagarto
        if (agua) {
            float remo = MathHelper.sin(t * (0.2f + 0.25f * mov));
            float fuerza = 0.25f + 0.35f * mov;
            pataDelDer.pitch = 0.9f + remo * fuerza;
            pataTrasIzq.pitch = 0.9f + remo * fuerza;
            pataDelIzq.pitch = 0.9f - remo * fuerza;
            pataTrasDer.pitch = 0.9f - remo * fuerza;
            pataDelDer.roll = 0.5f;
            pataTrasDer.roll = 0.5f;
            pataDelIzq.roll = -0.5f;
            pataTrasIzq.roll = -0.5f;
        } else {
            float paso = MathHelper.cos(limbAngle * 0.6662f) * 1.1f * limbDistance;
            pataDelDer.pitch = paso;
            pataTrasIzq.pitch = paso;
            pataDelIzq.pitch = -paso;
            pataTrasDer.pitch = -paso;
            pataDelDer.roll = 0.2f;
            pataTrasDer.roll = 0.2f;
            pataDelIzq.roll = -0.2f;
            pataTrasIzq.roll = -0.2f;
        }
        pataDelDer.yaw = 0f;
        pataDelIzq.yaw = 0f;
        pataTrasDer.yaw = 0f;
        pataTrasIzq.yaw = 0f;
    }
}

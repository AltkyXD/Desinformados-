package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.ModVariantes;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.BeeEntityRenderer;
import net.minecraft.client.render.entity.BlazeEntityRenderer;
import net.minecraft.client.render.entity.ChickenEntityRenderer;
import net.minecraft.client.render.entity.CowEntityRenderer;
import net.minecraft.client.render.entity.CreeperEntityRenderer;
import net.minecraft.client.render.entity.DrownedEntityRenderer;
import net.minecraft.client.render.entity.EndermanEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import net.minecraft.client.render.entity.SlimeEntityRenderer;
import net.minecraft.client.render.entity.SpiderEntityRenderer;
import net.minecraft.client.render.entity.WitchEntityRenderer;
import net.minecraft.client.render.entity.WitherSkeletonEntityRenderer;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.client.render.entity.feature.DrownedOverlayFeatureRenderer;
import net.minecraft.client.render.entity.feature.SpiderEyesFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.BlazeEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.WitchEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.util.Identifier;

/** Renderers de las 15 variantes de mobs: el modelo vanilla de su mob base con nuestra textura. */
public final class VarianteRenderers {
    private VarianteRenderers() {}

    static Identifier tex(String id) { return Desinformados.id("textures/entity/" + id + ".png"); }

    // Texturas creadas una vez (getTexture se llama en cada fotograma por cada mob)
    private static final Identifier ZOMBIE_PERIODISTA = tex("zombie_periodista");
    private static final Identifier ESQUELETO_FRANCOTIRADOR = tex("esqueleto_francotirador");
    private static final Identifier ARANA_TEJEDORA = tex("arana_tejedora");
    private static final Identifier CREEPER_SALTARIN = tex("creeper_saltarin");
    private static final Identifier ZOMBIE_LADRON = tex("zombie_ladron");
    private static final Identifier BRUJA_INFLUENCER = tex("bruja_influencer");
    private static final Identifier SLIME_VIRAL = tex("slime_viral");
    private static final Identifier VACA_LOCA = tex("vaca_loca");
    private static final Identifier POLLO_BOMBA = tex("pollo_bomba");
    private static final Identifier ZOMBIE_TANQUE = tex("zombie_tanque");
    private static final Identifier ENDERMAN_BROMISTA = tex("enderman_bromista");
    private static final Identifier ABEJA_ASESINA = tex("abeja_asesina");
    private static final Identifier BLAZE_HELADO = tex("blaze_helado");
    private static final Identifier ESQUELETO_WITHER_ARQUERO = tex("esqueleto_wither_arquero");
    private static final Identifier AHOGADO_PESCADOR = tex("ahogado_pescador");

    public static class ZombiePeriodista extends ZombieEntityRenderer {
        public ZombiePeriodista(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return CarasOriginales.con(ZOMBIE_PERIODISTA, CarasOriginales.ZOMBIE, CarasOriginales.Modo.MEZCLA, null); }
    }

    public static class EsqueletoFrancotirador extends SkeletonEntityRenderer<SkeletonEntity> {
        public EsqueletoFrancotirador(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SkeletonEntity e) { return ESQUELETO_FRANCOTIRADOR; }
    }

    /** Sin los ojos rojos brillantes de la araña vanilla: los suyos (rosas) van pintados en la textura. */
    public static class AranaTejedora extends SpiderEntityRenderer<SpiderEntity> {
        public AranaTejedora(EntityRendererFactory.Context c) {
            super(c);
            features.removeIf(f -> f instanceof SpiderEyesFeatureRenderer);
        }
        @Override public Identifier getTexture(SpiderEntity e) { return ARANA_TEJEDORA; }
    }

    public static class CreeperSaltarin extends CreeperEntityRenderer {
        public CreeperSaltarin(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return CarasOriginales.con(CREEPER_SALTARIN, CarasOriginales.CREEPER, CarasOriginales.Modo.ENTERA, CarasOriginales.LIMA); }
    }

    public static class ZombieLadron extends ZombieEntityRenderer {
        public ZombieLadron(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return CarasOriginales.con(ZOMBIE_LADRON, CarasOriginales.ZOMBIE, CarasOriginales.Modo.MEZCLA, null); }
    }

    public static class BrujaInfluencer extends WitchEntityRenderer {
        public BrujaInfluencer(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(WitchEntity e) { return BRUJA_INFLUENCER; }
    }

    public static class SlimeViral extends SlimeEntityRenderer {
        public SlimeViral(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SlimeEntity e) { return SLIME_VIRAL; }
    }

    public static class VacaLoca extends CowEntityRenderer {
        public VacaLoca(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CowEntity e) { return VACA_LOCA; }
    }

    public static class PolloBomba extends ChickenEntityRenderer {
        public PolloBomba(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ChickenEntity e) { return POLLO_BOMBA; }
    }

    /** x1,4 (la caja de la entidad también es x1,4: 0,84 x 2,7). */
    public static class ZombieTanque extends ZombieEntityRenderer {
        public ZombieTanque(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return CarasOriginales.con(ZOMBIE_TANQUE, CarasOriginales.ZOMBIE, CarasOriginales.Modo.MEZCLA, null); }
        @Override protected void scale(ZombieEntity e, MatrixStack matrices, float amount) {
            matrices.scale(1.4f, 1.4f, 1.4f);
        }
    }

    public static class EndermanBromista extends EndermanEntityRenderer {
        public EndermanBromista(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(EndermanEntity e) { return ENDERMAN_BROMISTA; }
    }

    public static class AbejaAsesina extends BeeEntityRenderer {
        public AbejaAsesina(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(BeeEntity e) { return ABEJA_ASESINA; }
    }

    public static class BlazeHelado extends BlazeEntityRenderer {
        public BlazeHelado(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(BlazeEntity e) { return BLAZE_HELADO; }
    }

    public static class EsqueletoWitherArquero extends WitherSkeletonEntityRenderer {
        public EsqueletoWitherArquero(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(WitherSkeletonEntity e) { return ESQUELETO_WITHER_ARQUERO; }
    }

    /** Sin la capa de algas del ahogado vanilla (taparía el chubasquero pintado en la textura). */
    public static class AhogadoPescador extends DrownedEntityRenderer {
        public AhogadoPescador(EntityRendererFactory.Context c) {
            super(c);
            features.removeIf(f -> f instanceof DrownedOverlayFeatureRenderer);
        }
        @Override public Identifier getTexture(ZombieEntity e) { return AHOGADO_PESCADOR; }
    }

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityRendererRegistry.register(ModVariantes.ZOMBIE_PERIODISTA, (EntityRendererFactory) ZombiePeriodista::new);
        EntityRendererRegistry.register(ModVariantes.ESQUELETO_FRANCOTIRADOR, (EntityRendererFactory) EsqueletoFrancotirador::new);
        EntityRendererRegistry.register(ModVariantes.ARANA_TEJEDORA, (EntityRendererFactory) AranaTejedora::new);
        EntityRendererRegistry.register(ModVariantes.CREEPER_SALTARIN, (EntityRendererFactory) CreeperSaltarin::new);
        EntityRendererRegistry.register(ModVariantes.ZOMBIE_LADRON, (EntityRendererFactory) ZombieLadron::new);
        EntityRendererRegistry.register(ModVariantes.BRUJA_INFLUENCER, (EntityRendererFactory) BrujaInfluencer::new);
        EntityRendererRegistry.register(ModVariantes.SLIME_VIRAL, (EntityRendererFactory) SlimeViral::new);
        EntityRendererRegistry.register(ModVariantes.VACA_LOCA, (EntityRendererFactory) VacaLoca::new);
        EntityRendererRegistry.register(ModVariantes.POLLO_BOMBA, (EntityRendererFactory) PolloBomba::new);
        EntityRendererRegistry.register(ModVariantes.ZOMBIE_TANQUE, (EntityRendererFactory) ZombieTanque::new);
        EntityRendererRegistry.register(ModVariantes.ENDERMAN_BROMISTA, (EntityRendererFactory) EndermanBromista::new);
        EntityRendererRegistry.register(ModVariantes.ABEJA_ASESINA, (EntityRendererFactory) AbejaAsesina::new);
        EntityRendererRegistry.register(ModVariantes.BLAZE_HELADO, (EntityRendererFactory) BlazeHelado::new);
        EntityRendererRegistry.register(ModVariantes.ESQUELETO_WITHER_ARQUERO, (EntityRendererFactory) EsqueletoWitherArquero::new);
        EntityRendererRegistry.register(ModVariantes.AHOGADO_PESCADOR, (EntityRendererFactory) AhogadoPescador::new);
    }
}

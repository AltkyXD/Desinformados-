package com.centrodesinformacion.desinformados.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.util.Random;

/**
 * Estática de tele barata: una sola textura de ruido (512x512) que se dibuja con un desplazamiento
 * al azar en cada frame. Antes se pintaban miles de cuadraditos por frame y daba lag.
 */
public final class Ruido {
    private static final int TAM = 512, MAX_REGION = 256;
    private static final Random R = new Random();
    private static Identifier textura;

    private static Identifier textura() {
        if (textura == null) {
            NativeImage img = new NativeImage(TAM, TAM, false);
            Random r = new Random(1234);
            for (int y = 0; y < TAM; y++) {
                for (int x = 0; x < TAM; x++) {
                    int g = r.nextInt(256);
                    img.setColor(x, y, 0xFF000000 | (g << 16) | (g << 8) | g);   // ABGR, gris
                }
            }
            textura = MinecraftClient.getInstance().getTextureManager().registerDynamicTexture("desinformados_ruido", new NativeImageBackedTexture(img));
        }
        return textura;
    }

    /** Pinta estática en el rectángulo (x0,y0)-(x1,y1); cada grano mide 'celda' píxeles; alfa 0-1. */
    public static void dibujar(DrawContext ctx, int x0, int y0, int x1, int y1, float alfa, int celda) {
        int w = x1 - x0, h = y1 - y0;
        if (w <= 0 || h <= 0 || alfa <= 0.01f) return;
        celda = Math.max(celda, (int) Math.ceil(Math.max(w, h) / (double) MAX_REGION));
        int rw = Math.max(1, w / celda), rh = Math.max(1, h / celda);
        float u = R.nextInt(TAM - rw), v = R.nextInt(TAM - rh);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        ctx.setShaderColor(1f, 1f, 1f, Math.min(1f, alfa));
        ctx.drawTexture(textura(), x0, y0, w, h, u, v, rw, rh, TAM, TAM);
        ctx.setShaderColor(1f, 1f, 1f, 1f);
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Manchas de tinta en los bordes de la pantalla. Se quedan mientras tocas tinta y se secan poco a poco al salir. */
public class ManchaOverlay {
    private static final Identifier TEXTURA = Desinformados.id("textures/misc/mancha_tinta.png");
    private static int restante = 0;

    public static void iniciar(int ticks) {
        restante = Math.max(restante, ticks);
    }

    public static void tick() {
        if (restante > 0) restante--;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (restante <= 0) return;
        float r = restante - contador.getTickDelta(false);
        float alfa = MathHelper.clamp(r / 60f, 0f, 1f); // se seca en los últimos 3 segundos
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        ctx.setShaderColor(1f, 1f, 1f, alfa);
        ctx.drawTexture(TEXTURA, 0, 0, 0f, 0f, w, h, w, h);
        ctx.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Ruleta;
import com.centrodesinformacion.desinformados.network.RuletaApuestaPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

/**
 * Pantalla de la ruleta: la rueda con sus 37 casillas a la izquierda y la apuesta a la derecha.
 * Al girar, la rueda y la bola dan vueltas en sentidos contrarios, frenan y la bola cae en el número que dijo el servidor.
 */
public class RuletaScreen extends Screen {
    public static int rumores = 0;
    private static final int ANCHO = 336, ALTO = 214;
    private static final float DURACION = 5000f;                 // ms que tarda la rueda en pararse
    private static final double CASILLA = Math.PI * 2 / Ruleta.ORDEN.length;

    private static int apuesta = 10;
    private static String color = "rojo";

    private ButtonWidget girar;
    private final ButtonWidget[] botonesColor = new ButtonWidget[3];
    private static final String[] COLORES = {"rojo", "negro", "verde"};

    // animación
    private double rueda = 0, bola = 0, ruedaIni, ruedaFin, bolaIni, bolaFin;
    private long inicio = 0;
    private boolean girando = false, terminado = false;
    private int numero = -1, premio = 0, apostado = 0, ultimaCasilla = -1;
    private String colorApostado = "";

    public RuletaScreen() {
        super(Text.literal("Ruleta"));
        bola = Math.random() * Math.PI * 2;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int x0() { return (width - ANCHO) / 2; }
    private int y0() { return (height - ALTO) / 2; }

    @Override
    protected void init() {
        int x = x0() + 192, y = y0() + 50, w = ANCHO - 192 - 12;
        int[] pasos = {-100, -10, 10, 100};
        String[] nombres = {"-100", "-10", "+10", "+100"};
        int bw = (w - 6) / 4;
        for (int i = 0; i < 4; i++) {
            int paso = pasos[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(nombres[i]), b -> cambiar(paso))
                    .dimensions(x + i * (bw + 2), y + 22, bw, 18).build());
        }
        int cw = (w - 4) / 3;
        for (int i = 0; i < 3; i++) {
            String c = COLORES[i];
            botonesColor[i] = addDrawableChild(ButtonWidget.builder(Text.literal(c), b -> { color = c; actualizarBotones(); })
                    .dimensions(x + i * (cw + 2), y + 64, cw, 20).build());
        }
        girar = addDrawableChild(ButtonWidget.builder(Text.literal("¡GIRAR!").formatted(Formatting.BOLD), b -> girar())
                .dimensions(x, y + 108, w, 22).build());
        actualizarBotones();
    }

    private void cambiar(int paso) {
        apuesta = Math.max(Ruleta.MINIMA, Math.min(Ruleta.MAXIMA, apuesta + paso));
        actualizarBotones();
    }

    private void actualizarBotones() {
        for (int i = 0; i < 3; i++) {
            String c = COLORES[i];
            Formatting f = c.equals("rojo") ? Formatting.RED : c.equals("verde") ? Formatting.GREEN : Formatting.WHITE;
            String txt = c.toUpperCase();
            botonesColor[i].setMessage(c.equals(color) ? Text.literal("▶" + txt + "◀").formatted(f, Formatting.BOLD) : Text.literal(txt).formatted(f));
            botonesColor[i].active = !girando;
        }
        if (girar != null) girar.active = !girando && rumores >= apuesta;
    }

    private void girar() {
        if (girando || rumores < apuesta) return;
        ClientPlayNetworking.send(new RuletaApuestaPayload(color, apuesta));
        girar.active = false;
    }

    /** El servidor dice qué número sale: arranca la animación para que la bola caiga justo ahí. */
    public void resultado(int n, int gana) {
        int idx = 0;
        for (int i = 0; i < Ruleta.ORDEN.length; i++) if (Ruleta.ORDEN[i] == n) idx = i;
        numero = n;
        premio = gana;
        apostado = apuesta;
        colorApostado = color;
        ruedaIni = rueda;
        ruedaFin = rueda + Math.PI * 2 * 3 + Math.random() * Math.PI;
        bolaIni = bola;
        double destino = ruedaFin + idx * CASILLA;                     // la bola acaba en la casilla del número
        long m = (long) Math.ceil((destino - (bolaIni - Math.PI * 10)) / (Math.PI * 2));
        bolaFin = destino - Math.PI * 2 * m;                            // 5 o 6 vueltas al revés
        inicio = System.currentTimeMillis();
        girando = true;
        terminado = false;
        actualizarBotones();
    }

    private static double frenar(double u) {
        return 1 - Math.pow(1 - u, 3);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int x = x0(), y = y0();
        // mesa de casino: marco dorado, madera y paño verde
        ctx.fill(x - 3, y - 3, x + ANCHO + 3, y + ALTO + 3, 0xFF2A1408);
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + ALTO + 2, 0xFFD6B046);
        ctx.fill(x, y, x + ANCHO, y + ALTO, 0xFF5C2E18);
        ctx.fill(x + 5, y + 5, x + ANCHO - 5, y + ALTO - 5, 0xFF1C5C34);
        ctx.fill(x + 186, y + 10, x + 187, y + ALTO - 10, 0xFFD6B046);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        avanzar();
        super.render(ctx, mx, my, delta);
        int x = x0(), y = y0();
        dibujarRueda(ctx, x + 96, y + ALTO / 2f, 86);
        // panel de la apuesta
        int px = x + 192, py = y + 50, w = ANCHO - 192 - 12;
        Text titulo = Text.literal("RULETA").formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, titulo, px + w / 2 - textRenderer.getWidth(titulo) / 2, y + 12, 0xFFF0D070, true);
        Text llevas = Text.literal("Llevas " + rumores + " Rumores");
        ctx.drawText(textRenderer, llevas, px + w / 2 - textRenderer.getWidth(llevas) / 2, y + 26, 0xFFFFF0B0, true);
        Text reglas = Text.literal("Rojo/Negro x1,9  ·  Verde x10");
        ctx.drawText(textRenderer, reglas, px + w / 2 - textRenderer.getWidth(reglas) / 2, y + 38, 0xFFB8D8C0, false);
        Text ap = Text.literal("Apuesta: " + apuesta).formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, ap, px + w / 2 - textRenderer.getWidth(ap) / 2, py + 8, 0xFFFFFFFF, true);
        ctx.drawText(textRenderer, Text.literal("Color:"), px, py + 52, 0xFFE0E0E0, false);
        int gana = color.equals("verde") ? apuesta * 10 : apuesta * 19 / 10;
        Text siGana = Text.literal("Si aciertas cobras " + gana);
        ctx.drawText(textRenderer, siGana, px + w / 2 - textRenderer.getWidth(siGana) / 2, py + 92, 0xFFB8D8C0, false);
        // resultado
        if (terminado && numero >= 0) {
            String c = Ruleta.color(numero);
            int col = c.equals("rojo") ? 0xFFFF5050 : c.equals("verde") ? 0xFF50E070 : 0xFFDDDDDD;
            Text salio = Text.literal("Salió el " + numero + " " + c.toUpperCase()).formatted(Formatting.BOLD);
            ctx.drawText(textRenderer, salio, px + w / 2 - textRenderer.getWidth(salio) / 2, py + 136, col, true);
            Text r = premio > 0 ? Text.literal("¡Ganas " + premio + " Rumores!").formatted(Formatting.GREEN)
                    : Text.literal("Pierdes " + apostado + " (" + colorApostado + ")").formatted(Formatting.GRAY);
            ctx.drawText(textRenderer, r, px + w / 2 - textRenderer.getWidth(r) / 2, py + 148, 0xFFFFFFFF, true);
        } else if (girando) {
            Text t = Text.literal("No va más...").formatted(Formatting.ITALIC);
            ctx.drawText(textRenderer, t, px + w / 2 - textRenderer.getWidth(t) / 2, py + 140, 0xFFF0D070, true);
        }
    }

    /** Llegó el saldo nuevo del servidor. */
    public void refrescar() {
        actualizarBotones();
    }

    private void avanzar() {
        if (!girando) return;
        double u = Math.min(1.0, (System.currentTimeMillis() - inicio) / DURACION);
        double e = frenar(u);
        rueda = ruedaIni + (ruedaFin - ruedaIni) * e;
        bola = bolaIni + (bolaFin - bolaIni) * e;
        // "clic" de la bola al pasar por las casillas cuando ya va despacio
        int casilla = (int) Math.floor(((bola - rueda) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) / CASILLA);
        if (casilla != ultimaCasilla && u > 0.45 && u < 1.0) {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), 1.8f, (float) (0.15 + 0.25 * u)));
        }
        ultimaCasilla = casilla;
        if (u >= 1.0) {
            girando = false;
            terminado = true;
            actualizarBotones();
        }
    }

    // ------------------------------------------------------------------ dibujo de la rueda

    private static void cuad(VertexConsumer vc, Matrix4f m, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int c) {
        vc.vertex(m, x1, y1, 0).color(c);
        vc.vertex(m, x2, y2, 0).color(c);
        vc.vertex(m, x3, y3, 0).color(c);
        vc.vertex(m, x4, y4, 0).color(c);
        // y por detrás, por si la cara queda girada
        vc.vertex(m, x4, y4, 0).color(c);
        vc.vertex(m, x3, y3, 0).color(c);
        vc.vertex(m, x2, y2, 0).color(c);
        vc.vertex(m, x1, y1, 0).color(c);
    }

    /** Sector de anillo entre los radios r0 y r1 y los ángulos a0 y a1 (0 = arriba, sentido horario). */
    private static void sector(VertexConsumer vc, Matrix4f m, float cx, float cy, float r0, float r1, double a0, double a1, int c) {
        int pasos = Math.max(1, (int) Math.ceil((a1 - a0) / 0.12));
        for (int i = 0; i < pasos; i++) {
            double b0 = a0 + (a1 - a0) * i / pasos, b1 = a0 + (a1 - a0) * (i + 1) / pasos;
            float s0 = (float) Math.sin(b0), c0 = (float) -Math.cos(b0), s1 = (float) Math.sin(b1), c1 = (float) -Math.cos(b1);
            cuad(vc, m, cx + s0 * r0, cy + c0 * r0, cx + s0 * r1, cy + c0 * r1, cx + s1 * r1, cy + c1 * r1, cx + s1 * r0, cy + c1 * r0, c);
        }
    }

    private void dibujarRueda(DrawContext ctx, float cx, float cy, float R) {
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        VertexConsumer vc = ctx.getVertexConsumers().getBuffer(RenderLayer.getGui());
        float rBorde = R, rPista = R - 9, rCasillaFuera = R - 14, rCasillaDentro = R - 38, rCono = R - 42;
        sector(vc, m, cx, cy, rPista, rBorde, 0, Math.PI * 2, 0xFF5A2A14);                  // aro de madera
        sector(vc, m, cx, cy, rPista - 1, rPista, 0, Math.PI * 2, 0xFFD6B046);
        sector(vc, m, cx, cy, rCasillaFuera, rPista - 1, 0, Math.PI * 2, 0xFF3A1A0C);       // pista de la bola
        sector(vc, m, cx, cy, rCasillaDentro - 1, rCasillaFuera, 0, Math.PI * 2, 0xFFD6B046); // separadores dorados (fondo)
        for (int i = 0; i < Ruleta.ORDEN.length; i++) {
            int n = Ruleta.ORDEN[i];
            int c = n == 0 ? 0xFF1E8C3C : Ruleta.ROJOS.contains(n) ? 0xFFC42222 : 0xFF18181C;
            double a = rueda + i * CASILLA;
            sector(vc, m, cx, cy, rCasillaDentro, rCasillaFuera - 1, a - CASILLA / 2 + 0.012, a + CASILLA / 2 - 0.012, c);
        }
        sector(vc, m, cx, cy, rCono, rCasillaDentro - 1, 0, Math.PI * 2, 0xFF6E3A1C);
        sector(vc, m, cx, cy, 0, rCono, 0, Math.PI * 2, 0xFF4E2812);                       // cono central
        for (int k = 0; k < 4; k++) {                                                       // radios dorados
            double a = rueda + k * Math.PI / 2;
            sector(vc, m, cx, cy, 4, rCono - 2, a - 0.035, a + 0.035, 0xFFD6B046);
        }
        sector(vc, m, cx, cy, 0, 6, 0, Math.PI * 2, 0xFFE8C460);
        // la bola: por la pista mientras gira rápido y cae a las casillas al frenar
        double u = girando ? Math.min(1.0, (System.currentTimeMillis() - inicio) / DURACION) : (terminado ? 1.0 : 0.0);
        float rBola;
        if (!girando && !terminado) rBola = (rPista + rCasillaFuera) / 2f;
        else if (u < 0.62) rBola = (rPista + rCasillaFuera) / 2f;
        else {
            double caer = Math.min(1.0, (u - 0.62) / 0.2);
            double rebote = u < 0.9 ? Math.abs(Math.sin(caer * Math.PI * 3)) * 3 * (1 - caer) : 0;
            rBola = (float) ((rPista + rCasillaFuera) / 2f + (((rCasillaFuera + rCasillaDentro) / 2f + 5) - (rPista + rCasillaFuera) / 2f) * caer + rebote);
        }
        double ab = terminado ? rueda + indice(numero) * CASILLA : bola;
        float bx = cx + (float) Math.sin(ab) * rBola, by = cy - (float) Math.cos(ab) * rBola;
        sector(vc, m, bx, by, 0, 3.2f, 0, Math.PI * 2, 0xFFF4F4F4);
        sector(vc, m, bx - 0.8f, by - 0.8f, 0, 1.2f, 0, Math.PI * 2, 0xFFFFFFFF);
        ctx.draw();
        // números de las casillas
        for (int i = 0; i < Ruleta.ORDEN.length; i++) {
            double a = rueda + i * CASILLA;
            String t = String.valueOf(Ruleta.ORDEN[i]);
            ctx.getMatrices().push();
            ctx.getMatrices().translate(cx, cy, 0);
            ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotation((float) a));
            ctx.getMatrices().translate(0, -(rCasillaFuera - 7), 0);
            ctx.getMatrices().scale(0.5f, 0.5f, 1f);
            ctx.drawText(textRenderer, t, -textRenderer.getWidth(t) / 2, -4, 0xFFFFFFFF, false);
            ctx.getMatrices().pop();
        }
        if (terminado && numero >= 0) {                     // marca el número ganador
            Text t = Text.literal(String.valueOf(numero)).formatted(Formatting.BOLD);
            ctx.getMatrices().push();
            ctx.getMatrices().translate(cx, cy, 0);
            ctx.getMatrices().scale(1.6f, 1.6f, 1f);
            ctx.drawText(textRenderer, t, -textRenderer.getWidth(t) / 2, -4, 0xFFFFFFFF, true);
            ctx.getMatrices().pop();
        }
    }

    private static int indice(int n) {
        for (int i = 0; i < Ruleta.ORDEN.length; i++) if (Ruleta.ORDEN[i] == n) return i;
        return 0;
    }
}

package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Mob plano como una hoja de papel (igual que el Garabato): un solo plano con el dibujo,
 * que se tambalea al andar, da saltitos y cae como una hoja al morir. Las crías son la mitad.
 */
public class PapelRenderer<T extends LivingEntity> extends EntityRenderer<T> {
    private final Identifier textura;
    private final float ancho, alto;
    private final boolean perfil;

    /** perfil = true: la hoja se pone de lado (animales vistos de perfil, con la cabeza dibujada a la IZQUIERDA). */
    public PapelRenderer(EntityRendererFactory.Context ctx, Identifier textura, float ancho, float alto, boolean perfil) {
        super(ctx);
        this.perfil = perfil;
        this.textura = textura;
        this.ancho = ancho;
        this.alto = alto;
        this.shadowRadius = ancho * 0.3f;
    }

    @Override
    public void render(T e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        m.push();
        if (e.isBaby()) m.scale(0.5f, 0.5f, 0.5f);
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevBodyYaw, e.bodyYaw);
        // De frente (como el Garabato) o de perfil, con la cabeza del dibujo apuntando hacia donde camina
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(perfil ? -90f - cuerpo : 180f - cuerpo));
        float paso = e.limbAnimator.getPos(delta);
        float fuerza = Math.min(1f, e.limbAnimator.getSpeed(delta));
        float tiempo = e.age + delta;
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.sin(paso * 0.6f) * 8f * fuerza + MathHelper.sin(tiempo * 0.08f) * 2f));
        m.translate(0, Math.abs(MathHelper.sin(paso * 0.6f)) * 0.08f * fuerza, 0);
        if (e.deathTime > 0) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(Math.min(90f, (e.deathTime + delta) * 6f)));

        int overlay = LivingEntityRenderer.getOverlay(e, 0f);
        VertexConsumer v = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(textura));
        MatrixStack.Entry pose = m.peek();
        float a = ancho / 2f;
        vertice(v, pose, -a, 0, 1, 1, luz, overlay);
        vertice(v, pose, a, 0, 0, 1, luz, overlay);
        vertice(v, pose, a, alto, 0, 0, luz, overlay);
        vertice(v, pose, -a, alto, 1, 0, luz, overlay);
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    private static void vertice(VertexConsumer v, MatrixStack.Entry pose, float x, float y, float u, float tv, int luz, int overlay) {
        v.vertex(pose, x, y, 0).color(255, 255, 255, 255).texture(u, tv).overlay(overlay).light(luz).normal(pose, 0, 0, 1);
    }

    @Override
    public Identifier getTexture(T e) {
        return textura;
    }
}

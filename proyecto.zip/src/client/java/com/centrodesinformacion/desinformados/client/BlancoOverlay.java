package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

/** Pantalla en blanco del Cubo Blanco: entra de golpe y se desvanece en el último segundo. */
public class BlancoOverlay {
    private static int restante = 0;
    private static int total = 1;

    public static void iniciar(int ticks) {
        restante = ticks;
        total = Math.max(1, ticks);
    }

    public static void tick() {
        if (restante > 0) restante--;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (restante <= 0) return;
        float r = restante - contador.getTickDelta(false);
        float alfa = MathHelper.clamp(r / 20f, 0f, 1f);                     // se va en el último segundo
        alfa *= MathHelper.clamp((total - r) / 2f + 0.6f, 0f, 1f);          // flash casi instantáneo al entrar
        ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), ((int) (255 * alfa) << 24) | 0xFFFFFF);
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.entidad.BrandonEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;

/** Modelo de jugador completo (con chaqueta, mangas y pantalón de la segunda capa). */
public class SkinModel<T extends LivingEntity> extends PlayerEntityModel<T> {
    public SkinModel(ModelPart raiz) {
        super(raiz, false);
    }

    @Override
    public void setAngles(T e, float paso, float fuerza, float edad, float yaw, float pitch) {
        super.setAngles(e, paso, fuerza, edad, yaw, pitch);
        if (e instanceof BrandonEntity b && b.isDisparando()) {
            // Brandon carga el rayo con los dos brazos hacia delante, temblando
            float temblor = (float) Math.sin(edad * 2.5f) * 0.05f;
            rightArm.pitch = -1.45f + pitch * 0.0174533f + temblor;
            leftArm.pitch = -1.45f + pitch * 0.0174533f - temblor;
            rightArm.yaw = -0.15f;
            leftArm.yaw = 0.15f;
            rightArm.roll = 0f;
            leftArm.roll = 0f;
            rightSleeve.copyTransform(rightArm);
            leftSleeve.copyTransform(leftArm);
        }
        if (e instanceof com.centrodesinformacion.desinformados.entidad.AltkyEntity a && a.isDibujando()) {
            // Altky dibuja: la mano izquierda sujeta la hoja/tableta y la derecha garabatea rápido
            leftArm.pitch = -1.1f;
            leftArm.yaw = 0.5f;
            leftArm.roll = 0f;
            rightArm.pitch = -1.0f + (float) Math.sin(edad * 1.7f) * 0.12f;
            rightArm.yaw = -0.25f + (float) Math.cos(edad * 2.3f) * 0.18f;
            rightArm.roll = 0f;
            head.pitch = 0.45f;
            hat.copyTransform(head);
            rightSleeve.copyTransform(rightArm);
            leftSleeve.copyTransform(leftArm);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.RayoEstaticaEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Rayo de estática: un cubito brillante que parpadea en grises y gira, con un halo. */
public class RayoEstaticaRenderer extends EntityRenderer<RayoEstaticaEntity> {
    private static final Identifier BLANCO = Desinformados.id("textures/entity/blanco.png");

    public RayoEstaticaRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(RayoEstaticaEntity e) {
        return BLANCO;
    }

    @Override
    public void render(RayoEstaticaEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        float t = e.age + delta;
        m.push();
        m.translate(0, 0.25, 0);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(t * 25f));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(t * 17f));
        VertexConsumer v = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        int g = 150 + (int) ((Math.sin(t * 3.1) * 0.5 + 0.5) * 105);
        int nucleo = 0xFF000000 | (g << 16) | (g << 8) | g;
        float r = 0.22f;
        GatoCuboRenderer.caja(v, m.peek(), -r, -r, -r, r, r, r, nucleo, 0xF000F0, OverlayTexture.DEFAULT_UV);
        int h = 60 + (int) ((Math.cos(t * 4.7) * 0.5 + 0.5) * 80);
        float rr = 0.32f;
        GatoCuboRenderer.caja(v, m.peek(), -rr, -0.06f, -rr, rr, 0.06f, rr, 0xFF000000 | (h << 16) | (h << 8) | h, 0xF000F0, OverlayTexture.DEFAULT_UV);
        GatoCuboRenderer.caja(v, m.peek(), -0.06f, -rr, -0.06f, 0.06f, rr, 0.06f, 0xFF000000 | (h << 16) | (h << 8) | h, 0xF000F0, OverlayTexture.DEFAULT_UV);
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModItems;
import com.centrodesinformacion.desinformados.network.BancoAccionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Pantalla del Banco de Rumores: saldo, depositar todo y sacar monedas (Shift = 10). */
public class BancoScreen extends Screen {
    public static int saldo = 0;
    private static final int ANCHO = 220, ALTO = 196;

    private record Moneda(String color, Item item, int valor, int texto) {}
    private static final Moneda[] MONEDAS = {
            new Moneda("amarillo", ModItems.RUMOR_AMARILLO, 1, 0xFFE8B428),
            new Moneda("azul", ModItems.RUMOR_AZUL, 5, 0xFF3878E6),
            new Moneda("verde", ModItems.RUMOR_VERDE, 10, 0xFF3CB450),
            new Moneda("rojo", ModItems.RUMOR_ROJO, 20, 0xFFDC3232),
            new Moneda("gris", ModItems.RUMOR_GRIS, 50, 0xFF96969E),
    };

    public BancoScreen() {
        super(Text.literal("Banco de Rumores"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        int x = (width - ANCHO) / 2, y = (height - ALTO) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Depositar todos mis Rumores"),
                b -> ClientPlayNetworking.send(new BancoAccionPayload("depositar", 0))).dimensions(x + 15, y + 52, ANCHO - 30, 20).build());
        for (int i = 0; i < MONEDAS.length; i++) {
            Moneda m = MONEDAS[i];
            addDrawableChild(ButtonWidget.builder(Text.literal("Sacar"),
                    b -> ClientPlayNetworking.send(new BancoAccionPayload("sacar:" + m.color(), hasShiftDown() ? 10 : 1)))
                    .dimensions(x + ANCHO - 70, y + 84 + i * 20, 55, 18).build());
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = (width - ANCHO) / 2, y = (height - ALTO) / 2;
        // Fondo de caja fuerte: verde oscuro con marco dorado
        ctx.fill(x - 3, y - 3, x + ANCHO + 3, y + ALTO + 3, 0xFF3A2A0A);
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + ALTO + 2, 0xFFC9A44C);
        ctx.fill(x, y, x + ANCHO, y + ALTO, 0xFF143A24);
        ctx.fill(x + 4, y + 4, x + ANCHO - 4, y + ALTO - 4, 0xFF1C4A2E);
        // Título y saldo
        Text titulo = Text.literal("BANCO DE RUMORES").formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, titulo, x + ANCHO / 2 - textRenderer.getWidth(titulo) / 2, y + 10, 0xFFE8C870, true);
        ctx.fill(x + 15, y + 24, x + ANCHO - 15, y + 46, 0xFF0C2416);
        Text s = Text.literal("Saldo: " + saldo + (saldo == 1 ? " Rumor" : " Rumores"));
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + ANCHO / 2f, y + 30, 0);
        ctx.getMatrices().scale(1.3f, 1.3f, 1f);
        ctx.drawText(textRenderer, s, -textRenderer.getWidth(s) / 2, 0, 0xFFFFE680, true);
        ctx.getMatrices().pop();
        // Lista de monedas
        for (int i = 0; i < MONEDAS.length; i++) {
            Moneda m = MONEDAS[i];
            int fy = y + 84 + i * 20;
            ctx.drawItem(new ItemStack(m.item()), x + 16, fy + 1);
            ctx.drawText(textRenderer, Text.translatable(m.item().getTranslationKey()), x + 36, fy + 2, m.texto(), true);
            ctx.drawText(textRenderer, Text.literal("vale " + m.valor()), x + 36, fy + 11, 0xFFB0C8B8, false);
        }
        Text ayuda = Text.literal("Shift + clic para sacar 10");
        ctx.drawText(textRenderer, ayuda, x + ANCHO / 2 - textRenderer.getWidth(ayuda) / 2, y + ALTO - 14, 0xFF8FB49C, false);
    }
}

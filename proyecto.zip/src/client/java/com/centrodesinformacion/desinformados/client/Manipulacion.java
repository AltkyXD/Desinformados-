package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Estado del jugador manipulado por el Angel: cámara fija, sin moverse y pantalla azul. */
public class Manipulacion {
    private static int entidad = -1;
    private static int restante = 0;
    private static float intensidad = 0, anterior = 0;

    public static void iniciar(int id, int ticks) {
        entidad = id;
        restante = ticks;
    }

    public static boolean activa() {
        return restante > 0;
    }

    public static void tick() {
        anterior = intensidad;
        intensidad = MathHelper.clamp(intensidad + (activa() ? 0.15f : -0.1f), 0f, 1f);
        if (restante <= 0) return;
        restante--;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        Entity e = mc.world.getEntityById(entidad);
        if (e == null) { restante = 0; return; }
        // Cámara fija en el Angel
        Vec3d d = e.getEyePos().subtract(p.getEyePos());
        float yaw = (float) (MathHelper.atan2(d.z, d.x) * MathHelper.DEGREES_PER_RADIAN) - 90f;
        float pitch = (float) (-MathHelper.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * MathHelper.DEGREES_PER_RADIAN);
        p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yaw - p.getYaw()) * 0.6f);
        p.setPitch(MathHelper.lerp(0.6f, p.getPitch(), pitch));
        p.setHeadYaw(p.getYaw());
    }

    /** Pantalla teñida de azul con los bordes más intensos. */
    public static void render(DrawContext ctx, RenderTickCounter contador) {
        float i = MathHelper.lerp(contador.getTickDelta(false), anterior, intensidad);
        if (i <= 0.01f) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        ctx.fill(0, 0, w, h, ((int) (90 * i) << 24) | 0x1E50FF);
        int pasos = 14, ancho = Math.max(2, Math.min(w, h) / 60);
        for (int k = 0; k < pasos; k++) {
            int c = ((int) (150 * i * (1f - k / (float) pasos)) << 24) | 0x0A2AC8;
            int o = k * ancho;
            ctx.fill(o, o, w - o, o + ancho, c);
            ctx.fill(o, h - o - ancho, w - o, h - o, c);
            ctx.fill(o, o + ancho, o + ancho, h - o - ancho, c);
            ctx.fill(w - o - ancho, o + ancho, w - o, h - o - ancho, c);
        }
    }
}

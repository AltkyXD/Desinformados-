package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.network.PasivaTogglePayload;
import com.centrodesinformacion.desinformados.pasivas.Pasivas;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Menú de pasivas (tecla K): cada pasiva con su icono, descripción y botón para activarla o desactivarla. */
public class PasivasScreen extends Screen {
    private static final int ANCHO = 330;
    private final List<ButtonWidget> botones = new ArrayList<>();
    private static final net.minecraft.item.ItemStack[] ICONOS = java.util.Arrays.stream(com.centrodesinformacion.desinformados.ModItems.PASIVAS)
            .map(net.minecraft.item.ItemStack::new).toArray(net.minecraft.item.ItemStack[]::new);

    public PasivasScreen() {
        super(Text.literal("Pasivas"));
    }

    /** Alto de cada fila: 46, o 38 si la pantalla es baja (escala de interfaz grande) para que quepan todas. */
    private int fila() { return 34 + Pasivas.TODAS.size() * 46 + 8 <= height - 6 ? 46 : 38; }
    private int alto() { return 34 + Pasivas.TODAS.size() * fila() + 8; }
    private int x0() { return (width - ANCHO) / 2; }
    private int y0() { return (height - alto()) / 2; }

    @Override public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        botones.clear();
        for (int i = 0; i < Pasivas.TODAS.size(); i++) {
            String id = Pasivas.TODAS.get(i).id();
            ButtonWidget b = ButtonWidget.builder(Text.literal(""), w -> ClientPlayNetworking.send(new PasivaTogglePayload(id)))
                    .dimensions(x0() + ANCHO - 84, y0() + 34 + i * fila() + 12, 76, 20).build();
            botones.add(addDrawableChild(b));
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (PasivasCliente.TECLA.matchesKey(key, scan)) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x99000000);
        int x = x0(), y = y0();
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + alto() + 2, 0xFF8A3CD6);
        ctx.fill(x, y, x + ANCHO, y + alto(), 0xF0141018);
        ctx.fill(x, y, x + ANCHO, y + 24, 0xFF22182C);
        for (int i = 0; i < Pasivas.TODAS.size(); i++) {
            String id = Pasivas.TODAS.get(i).id();
            boolean tiene = PasivasCliente.COMPRADAS.contains(id), activa = PasivasCliente.ACTIVAS.contains(id);
            int fy = y + 34 + i * fila();
            ctx.fill(x + 6, fy - 2, x + ANCHO - 6, fy + fila() - 6, !tiene ? 0x18FFFFFF : activa ? 0x3339FF5A : 0x22FFFFFF);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        for (int i = 0; i < botones.size(); i++) {
            String id = Pasivas.TODAS.get(i).id();
            boolean tiene = PasivasCliente.COMPRADAS.contains(id), activa = PasivasCliente.ACTIVAS.contains(id);
            ButtonWidget b = botones.get(i);
            b.visible = tiene;
            b.setMessage(Text.literal(activa ? "Activada" : "Desactivada").formatted(activa ? Formatting.GREEN : Formatting.GRAY));
        }
        super.render(ctx, mx, my, delta);
        int x = x0(), y = y0();
        ctx.drawText(textRenderer, Text.literal("✦ PASIVAS").formatted(Formatting.BOLD), x + 8, y + 8, 0xFFD9A8FF, true);
        String ayuda = "K para cerrar";
        ctx.drawText(textRenderer, ayuda, x + ANCHO - 8 - textRenderer.getWidth(ayuda), y + 8, 0xFF8A7A9A, false);
        for (int i = 0; i < Pasivas.TODAS.size(); i++) {
            Pasivas.Pasiva pa = Pasivas.TODAS.get(i);
            boolean tiene = PasivasCliente.COMPRADAS.contains(pa.id());
            int fy = y + 34 + i * fila();
            // el icono es el propio objeto de la pasiva (ya está cargado en el atlas: no da tirones)
            ctx.getMatrices().push();
            ctx.getMatrices().translate(x + 10, fy + 2, 0);
            ctx.getMatrices().scale(2f, 2f, 1f);
            ctx.drawItem(ICONOS[i], 0, 0);
            ctx.getMatrices().pop();
            if (!tiene) {                                   // apagado si no la tienes (por encima del objeto)
                ctx.getMatrices().push();
                ctx.getMatrices().translate(0, 0, 300);
                ctx.fill(x + 10, fy + 2, x + 42, fy + 34, 0xAA141018);
                ctx.getMatrices().pop();
            }
            ctx.drawText(textRenderer, Text.literal(pa.nombre()).formatted(Formatting.BOLD), x + 48, fy + 1, tiene ? 0xFFFFFFFF : 0xFF777777, true);
            List<OrderedText> lineas = textRenderer.wrapLines(Text.literal(pa.descripcion()), ANCHO - 48 - (tiene ? 92 : 14));
            for (int k = 0; k < Math.min(fila() >= 46 ? 3 : 2, lineas.size()); k++) {
                ctx.drawText(textRenderer, lineas.get(k), x + 48, fy + 12 + k * 9, tiene ? 0xFFB8B0C4 : 0xFF666666, false);
            }
            if (!tiene) {
                String precio = "No la tienes · " + pa.precio() + " Rumores";
                ctx.drawText(textRenderer, precio, x + ANCHO - 12 - textRenderer.getWidth(precio), fy + 1, 0xFFE0B030, false);
            }
        }
        if (PasivasCliente.COMPRADAS.isEmpty()) {
            String t = "Aún no tienes pasivas. Cómpralas al Mago de las Pasivas.";
            ctx.drawText(textRenderer, t, x + (ANCHO - textRenderer.getWidth(t)) / 2, y + alto() + 8, 0xFFD9A8FF, true);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public class ZombieNaranjaRenderer extends ZombieEntityRenderer {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/zombie_naranja.png");

    public ZombieNaranjaRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
    }

    @Override
    public Identifier getTexture(ZombieEntity entidad) {
        return TEXTURA;
    }
}

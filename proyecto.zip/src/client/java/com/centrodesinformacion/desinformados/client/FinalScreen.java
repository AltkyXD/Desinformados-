package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.FinalFinPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Cinemática final (al usar el Orbe de Estática):
 * 1. Estática y El Gato con señal débil: se despide y os da las gracias.
 * 2. "Adiós... y sigan desinformando de buena forma." La señal se rompe (como en la intro): 5 s de estática.
 * 3. Pantalla NEGRA: cae el título DESINFORMADOS y empieza la canción de los créditos (Ripple).
 * 4. Todo empieza a bajar: los créditos. Cuando se acaban, la canción baja de volumen hasta apagarse.
 * 5. Al acabar, el servidor te devuelve a tu hogar y el negro se desvanece.
 * No se puede saltar ni cerrar con ESC.
 */
public class FinalScreen extends Screen {
    private static final Identifier GATO = Desinformados.id("textures/gui/intro_gato.png");
    private static final Random R = new Random();

    private static final String[] GUION = {
            "¿Me escuchan? ...Esta vez la señal llega perfecta. Y es gracias a ustedes.",
            "La Desinformación se ha apagado. Gracias a ustedes, el mundo volvió a desinformarse de forma correcta.",
            "Creepers oscuros, furros, teles rojas, un reactor roto... y a pesar de todos los peligros, supieron arreglárselas.",
            "Y gracias por divertirse. De verdad. El Centro nunca había estado tan bien desinformado.",
            "Ya es hora de que vuelvan. Los mandaré de vuelta a su hogar... así que esto es un adiós.",
            "Adiós... y sigan desinformando de buena forma.",
    };

    private static final float LETRAS_POR_TICK = 1.2f;
    private static final int PAUSA = 45;
    private static final int ESTATICA_INICIO = 45;
    private static final int APARECE = 70;
    private static final int ESTATICA_FINAL = 100;

    // Fase negra (contada desde que la pantalla se pone en negro)
    private static final int TITULO = 40;          // 2 s: cae el título
    private static final int EMPIEZA_A_BAJAR = 170; // 8,5 s: todo empieza a bajar (créditos)
    private static final float VELOCIDAD = 1.0f;   // píxeles (de interfaz) por tick
    private static final int QUIETO_FINAL = 100;   // el último mensaje se queda 5 s en el centro
    private static final int APAGAR = 40;          // y se apaga en 2 s
    private static final int DESVANECER = 40;      // ya en casa: el negro se desvanece

    /** Créditos: {"#", título de sección} · {rol, nombre} · {"", ""} = hueco. */
    private static final String[][] CREDITOS = {
            {"#", "DESINFORMADOS"},
            {"Idea de la serie", "Altky"},
            {"Diseñador de personajes", "Altky"},
            {"Creador del mod", "Altky"},
            {"Voces", "Altky"},
            {"Ideas de mobs clones", "Angel"},
            {"Balance", "Angel"},
            {"", ""},
            {"#", "PERSONAL DEL CENTRO"},
            {"Señales verdes", "El Gato"},
            {"Responsable de lavar la ropa", "Conserje"},
            {"Barrido en zigzag (no es más eficiente)", "Conserje"},
            {"Atención al cliente (todos son el número 7)", "Recepcionista"},
            {"Exclusivas inventadas", "Periodista"},
            {"Pasivas mágicas sin devoluciones", "Mago de las Pasivas"},
            {"Corazones de segunda mano", "Enfermero de Corazones"},
            {"Minerales picados hace bastante", "Minero"},
            {"Catering (podrido)", "Chef Michelin"},
            {"Música a 20 Rumores", "DJ Miaumix"},
            {"Bailarina oficial (no ha parado)", "Gata Fiestera"},
            {"Decoración del Centro y miniaturas", "Gata Katemcita"},
            {"Comisiones a 67 dólares", "Gata Katemcita"},
            {"Investigación de la estática", "Gata Científica"},
            {"Ayudante de la Gata Científica (dice que es al revés)", "Gato Nerd"},
            {"Shipping no oficial del personal", "Gata Fujoshi"},
            {"Capítulos 1 al 14 de un fanfic", "Gata Fujoshi"},
            {"Poemas de amor por wifi", "Gato Romántico"},
            {"Billetes impresos con cariño", "Gato Millonario"},
            {"Sombrero de copa y compostura", "Gato Elegante"},
            {"Sospechas sin pruebas", "Detective Bigotes"},
            {"Protocolo de ignorar", "GATO-BOT 3000"},
            {"Huelga de árboles", "Gato Granjero"},
            {"Kyaaa~", "Gata Kawaii"},
            {"Preguntar si has comido", "Gata Mamá"},
            {"Seguir a mamá", "Gatito"},
            {"Miau", "Gato Gato"},
            {"Guau", "Gato Perro"},
            {"Efectos especiales (de lado no se ve)", "Gato 2D"},
            {"Becario", "(no ha enviado su nombre)"},
            {"", ""},
            {"#", "REPARTO DE MOBS"},
            {"Antagonista", "La Desinformación"},
            {"Rayos azules", "Brandon"},
            {"Tanque con sentimientos", "Kevin"},
            {"Dibujos con vida propia", "Altky (el mob, no el creador)"},
            {"Abrazos no solicitados", "Los Furros"},
            {"Robo de contenedores de corazón", "Creeper Oscuro"},
            {"Recibir golpes sin quejarse", "Muñeco de Prueba"},
            {"Garabatos", "La Libreta del Becario"},
            {"", ""},
            {"#", "AGRADECIMIENTOS"},
            {"Por no tocar el reactor", "Nadie"},
            {"Por mantener la señal", "Una antena de la tele"},
            {"Por los 7 segundos entre frase y frase", "La paciencia de los gatos"},
            {"Y a ti", "por desinformarte con nosotros"},
    };

    private final String[] jugadores;
    private final int[] inicioLinea = new int[GUION.length];
    private final int finDialogo, negro;
    private final List<Linea> lineas = new ArrayList<>();
    private int altoCreditos = 0;
    private int ticks = 0;
    private int finTicks = -1;            // cuándo el último mensaje llegó al centro
    private boolean avisado = false;
    private CancionFinal cancion;

    private record Linea(int y, String texto, int color, float escala, boolean negrita) {}

    public FinalScreen(String nombres) {
        super(Text.literal("Desinformados"));
        this.jugadores = nombres == null || nombres.isBlank() ? new String[0] : nombres.split(",");
        int t = APARECE + 5;
        for (int i = 0; i < GUION.length; i++) {
            inicioLinea[i] = t;
            int escribir = (int) (GUION[i].length() / LETRAS_POR_TICK);
            t += escribir + (i == GUION.length - 1 ? 30 : PAUSA);
        }
        finDialogo = t;
        negro = finDialogo + ESTATICA_FINAL;
    }

    /** Monta la lista de créditos (en píxeles de interfaz, desde arriba). */
    private void montarCreditos() {
        lineas.clear();
        int y = 0;
        if (jugadores.length > 0) {
            lineas.add(new Linea(y, "PROTAGONISTAS", 0xFF39FF5A, 1.6f, true));
            y += 26;
            for (String j : jugadores) { lineas.add(new Linea(y, j, 0xFFFFFFFF, 1.3f, true)); y += 18; }
            y += 30;
        }
        for (String[] c : CREDITOS) {
            if (c[0].equals("#")) {
                y += 10;
                lineas.add(new Linea(y, c[1], 0xFF39FF5A, 1.6f, true));
                y += 28;
            } else if (c[0].isEmpty()) {
                y += 24;
            } else {
                lineas.add(new Linea(y, c[0], 0xFF8A8A8A, 1f, false));
                lineas.add(new Linea(y + 11, c[1], 0xFFFFFFFF, 1.2f, true));
                y += 34;
            }
        }
        y += 60;
        lineas.add(new Linea(y, "Gracias por jugar", 0xFFFFFFFF, 2.2f, true));
        lineas.add(new Linea(y + 26, "Sigan desinformando de buena forma.", 0xFF39FF5A, 1.3f, false));
        altoCreditos = y + 26;
    }

    // ---- Ya en casa: el negro se queda en el HUD y se desvanece ----
    private static int salida = -1;
    private static int esperaSalida = 0;

    public static void registrar() {
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (salida < 0) return;
            if ((mc.world != null && mc.currentScreen == null && ++esperaSalida > 10) || esperaSalida > 200) salida++;
            if (salida > DESVANECER) salida = -1;
        });
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((ctx, contador) -> {
            if (salida < 0) return;
            float a = MathHelper.clamp(1f - (salida + (salida > 0 ? contador.getTickDelta(false) : 0f)) / DESVANECER, 0f, 1f);
            ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), ((int) (a * 255) << 24));
        });
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { }

    private static void sonar(SoundEvent s, float tono, float volumen) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(s, tono, volumen));
    }

    private int lineaActual() {
        for (int i = GUION.length - 1; i >= 0; i--) if (ticks >= inicioLinea[i]) return i;
        return -1;
    }

    /** Cuánto ha bajado todo (en píxeles de interfaz). */
    private float bajado(float dt) {
        float b = Math.max(0f, dt - EMPIEZA_A_BAJAR) * VELOCIDAD;
        float tope = height + altoCreditos - height / 2f + 10;      // hasta que "Gracias por jugar" queda en el centro
        return Math.min(b, tope);
    }

    @Override
    public void tick() {
        ticks++;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ticks == 1) {
            mc.getMusicTracker().stop();
            sonar(ModSounds.TV_ESTATICA, 1f, 1f);
        }
        if (ticks == ESTATICA_INICIO) sonar(ModSounds.TV_ESTATICA, 0.8f, 0.7f);
        for (int i = 0; i < GUION.length; i++) {
            int dt = ticks - inicioLinea[i];
            if (dt >= 0 && dt % 40 == 0 && dt < GUION[i].length() / LETRAS_POR_TICK) sonar(ModSounds.GATO_VOZ, 1f, 1f);
        }
        if (ticks >= finDialogo && ticks < negro) {                    // la señal se rompe
            int dt = ticks - finDialogo;
            if (dt % 30 == 0) sonar(ModSounds.TV_ESTATICA, 0.5f + R.nextFloat() * 0.6f, 1f);
            if (dt == 0) sonar(SoundEvents.BLOCK_LEVER_CLICK, 0.5f, 1f);
            if (R.nextInt(12) == 0) sonar(SoundEvents.BLOCK_REDSTONE_TORCH_BURNOUT, 0.8f + R.nextFloat(), 0.4f);
        }
        if (ticks == negro) {                                            // canción de los créditos
            mc.getMusicTracker().stop();
            cancion = new CancionFinal(ModSounds.FINAL_CREDITOS, 0.85f);
            mc.getSoundManager().play(cancion);
        }
        if (finTicks >= 0 && ticks == finTicks + QUIETO_FINAL && cancion != null) cancion.bajar();   // se acaban los créditos: baja el volumen
        if (ticks >= negro && lineas.isEmpty()) montarCreditos();
        if (ticks >= negro && finTicks < 0) {
            float dt = ticks - negro;
            float tope = height + altoCreditos - height / 2f + 10;
            if (dt > EMPIEZA_A_BAJAR && bajado(dt) >= tope) finTicks = ticks;
        }
        if (finTicks >= 0 && ticks >= finTicks + QUIETO_FINAL + APAGAR && !avisado) {
            avisado = true;
            salida = 0;
            esperaSalida = 0;
            if (ClientPlayNetworking.canSend(FinalFinPayload.ID)) ClientPlayNetworking.send(new FinalFinPayload(0));
            mc.setScreen(null);
        }
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float t = ticks + delta;
        int w = this.width, h = this.height;
        TextRenderer tr = this.textRenderer;

        if (t >= negro) {
            dibujarNegro(ctx, tr, t - negro, w, h);
            return;
        }
        ctx.fill(0, 0, w, h, 0xFF000000);
        if (t < ESTATICA_INICIO) {
            IntroScreen.estatica(ctx, w, h, 255);
            return;
        }
        if (t >= finDialogo) {                                           // 5 s de estática con glitches
            IntroScreen.estatica(ctx, w, h, 255);
            IntroScreen.desgarros(ctx, w, h, 1f);
            if (R.nextInt(6) == 0) ctx.fill(0, 0, w, h, R.nextBoolean() ? 0x30FF0000 : 0x3000FFFF);
            return;
        }

        int li = lineaActual();
        boolean ultima = li == GUION.length - 1;
        // esta vez la señal es buena... hasta el adiós
        float ruido = 0.1f + 0.04f * MathHelper.sin(t * 0.3f);
        if (t < APARECE) ruido = MathHelper.lerp((t - ESTATICA_INICIO) / (APARECE - ESTATICA_INICIO), 1f, ruido);
        float avance = ultima ? MathHelper.clamp((t - inicioLinea[li]) / (finDialogo - inicioLinea[li]), 0f, 1f) : 0f;
        if (ultima) ruido = MathHelper.lerp(avance * avance, ruido, 0.85f);
        boolean corte = R.nextInt(Math.max(2, (int) (40 * (1f - ruido)))) == 0 && ruido > 0.2f;

        boolean hablando = li >= 0 && (t - inicioLinea[li]) < GUION[li].length() / LETRAS_POR_TICK;
        float lado = Math.min(w, h) * 0.55f;
        float estirar = hablando ? 0.03f * Math.abs(MathHelper.sin(t * 0.9f)) : 0f;
        float temblor = ruido > 0.3f || corte ? (R.nextFloat() * 2 - 1) * ruido * 12f : 0f;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(w / 2f + temblor, h * 0.42f + (ultima && R.nextInt(8) == 0 ? R.nextFloat() * 10 - 5 : 0), 0);
        m.scale(lado / 256f * (1f - estirar * 0.5f), lado / 256f * (1f + estirar), 1f);
        if (!corte) ctx.drawTexture(GATO, -128, -128, 256, 256, 0, 0, 256, 256, 256, 256);
        m.pop();

        IntroScreen.estatica(ctx, w, h, (int) (ruido * 255));
        for (int y = 0; y < h; y += 3) ctx.fill(0, y, w, y + 1, 0x38000000);
        for (int i = 0; i < 3; i++) {
            if (R.nextFloat() < ruido) {
                int y = R.nextInt(h);
                ctx.fill(0, y, w, y + 1 + R.nextInt(3), 0x40FFFFFF);
            }
        }
        if (ultima) IntroScreen.desgarros(ctx, w, h, avance);
        IntroScreen.vineta(ctx, w, h);

        int barras = ruido > 0.6f ? 1 : ruido > 0.3f ? 2 : 3;
        for (int i = 0; i < 3; i++) {
            int x = 14 + i * 5, alto = 4 + i * 3;
            ctx.fill(x, 26 - alto, x + 3, 26, i < barras ? 0xFF39FF5A : 0x40FFFFFF);
        }
        ctx.drawText(tr, Text.literal(barras == 3 ? "SEÑAL PERFECTA" : "SEÑAL DÉBIL"), 32, 18, ((int) t / 10) % 2 == 0 ? 0xFF39FF5A : 0x8039FF5A, true);

        if (li >= 0) dibujarSubtitulo(ctx, tr, t, li, w, h, ruido);
    }

    private void dibujarSubtitulo(DrawContext ctx, TextRenderer tr, float t, int li, int w, int h, float ruido) {
        float dt = t - inicioLinea[li];
        int n = MathHelper.clamp((int) (dt * LETRAS_POR_TICK), 0, GUION[li].length());
        String texto = GUION[li].substring(0, n);
        if (ruido > 0.45f) {
            StringBuilder sb = new StringBuilder();
            for (char c : texto.toCharArray()) sb.append(c != ' ' && R.nextFloat() < (ruido - 0.4f) * 0.5f ? "#%&@/?".charAt(R.nextInt(6)) : c);
            texto = sb.toString();
        }
        int ancho = Math.min(w - 40, 340);
        int x = (w - ancho) / 2 + (ruido > 0.5f && R.nextInt(4) == 0 ? R.nextInt(5) - 2 : 0);
        int y = Math.min((int) (h * 0.42f + Math.min(w, h) * 0.275f) + 8, h - 52);
        ctx.fill(x - 1, y - 1, x + ancho + 1, y + 45, 0xFF39FF5A);
        ctx.fill(x, y, x + ancho, y + 44, 0xF0101010);
        ctx.drawText(tr, Text.literal("El Gato").formatted(Formatting.BOLD), x + 8, y + 6, 0xFF39FF5A, true);
        List<OrderedText> filas = tr.wrapLines(Text.literal(texto), ancho - 16);
        for (int i = 0; i < Math.min(2, filas.size()); i++) ctx.drawText(tr, filas.get(i), x + 8, y + 19 + i * 11, 0xFFEFEFEF, true);
    }

    // ------------------------------------------------------------------ fase negra: título y créditos

    private void dibujarNegro(DrawContext ctx, TextRenderer tr, float dt, int w, int h) {
        ctx.fill(0, 0, w, h, 0xFF000000);
        if (dt < 8) IntroScreen.estatica(ctx, w, h, (int) ((1f - dt / 8f) * 255));
        float b = bajado(dt);
        float alfa = 1f;
        if (finTicks >= 0) {                                             // al final todo se apaga
            float f = (ticks + (dt - (int) dt) - finTicks - QUIETO_FINAL) / APAGAR;
            alfa = MathHelper.clamp(1f - f, 0f, 1f);
        }
        if (alfa <= 0.02f) return;
        MatrixStack m = ctx.getMatrices();
        // título (cae como en la intro, pero blanco sobre negro) y luego sube con todo lo demás
        float tt = dt - TITULO;
        if (tt > 0 && b < h * 0.42f + 80) {
            m.push();
            m.translate(0, -b, 0);
            IntroScreen.dibujarTitulo(ctx, tr, tt, w, h, alfa, 0xF2F2F2, 0x9A9A9A);
            m.pop();
        }
        // créditos: empiezan justo por debajo de la pantalla
        float base = h + 20 - b;
        int a = Math.max(4, (int) (alfa * 255));
        for (Linea l : lineas) {
            float y = base + l.y();
            if (y < -30 || y > h + 30) continue;
            Text texto = l.negrita() ? Text.literal(l.texto()).formatted(Formatting.BOLD) : Text.literal(l.texto());
            m.push();
            m.translate(w / 2f, y, 0);
            m.scale(l.escala(), l.escala(), 1f);
            ctx.drawText(tr, texto, -tr.getWidth(texto) / 2, 0, (a << 24) | (l.color() & 0xFFFFFF), true);
            m.pop();
        }
        // un poquito de estática en los bordes, como una tele vieja
        if (R.nextInt(30) == 0) {
            int y = R.nextInt(h);
            ctx.fill(0, y, w, y + 1, 0x22FFFFFF);
        }
        IntroScreen.vineta(ctx, w, h);
    }
}

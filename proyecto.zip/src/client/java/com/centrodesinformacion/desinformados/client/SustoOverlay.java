package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/** Screamer: imagen a pantalla completa que tiembla, con el grito, y se desvanece al final. */
public class SustoOverlay {
    private static final Identifier IMAGEN = Desinformados.id("textures/gui/susto.png");
    private static final Random RANDOM = new Random();
    private static int restante = 0;

    public static void iniciar(int ticks) {
        restante = ticks;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ModSounds.SUSTO, 1f, 1.2f));
    }

    public static void tick() {
        if (restante > 0) restante--;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (restante <= 0) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float alfa = MathHelper.clamp((restante - contador.getTickDelta(false)) / 5f, 0f, 1f); // se esfuma en 0,25 s
        ctx.fill(0, 0, w, h, ((int) (255 * alfa) << 24));
        int temblor = 8;
        int dx = RANDOM.nextInt(temblor * 2 + 1) - temblor, dy = RANDOM.nextInt(temblor * 2 + 1) - temblor;
        int lado = (int) (Math.max(w, h) * 1.1f);
        ctx.setShaderColor(1f, 1f, 1f, alfa);
        ctx.drawTexture(IMAGEN, (w - lado) / 2 + dx, (h - lado) / 2 + dy, 0, 0, lado, lado, lado, lado);
        ctx.setShaderColor(1f, 1f, 1f, 1f);
    }
}

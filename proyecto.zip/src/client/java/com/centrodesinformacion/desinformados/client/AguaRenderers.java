package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.agua.CreeperAguaEntity;
import com.centrodesinformacion.desinformados.entidad.agua.ModAgua;
import com.centrodesinformacion.desinformados.entidad.agua.PulpoEntity;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.SquidEntityRenderer;
import net.minecraft.client.render.entity.model.CodEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.SquidEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Renderers de los mobs de agua: modelos vanilla (bacalao y calamar) con nuestras texturas. */
public final class AguaRenderers {
    private AguaRenderers() {}

    private static final Identifier CREEPER_AGUA = Desinformados.id("textures/entity/creeper_agua.png");
    private static final Identifier PULPO = Desinformados.id("textures/entity/pulpo.png");

    /**
     * Creeper de Agua: el modelo del bacalao x2 (textura 32x32). Se balancea al nadar como el bacalao, se tumba de lado
     * cuando está varado y, con la mecha encendida, se hincha y parpadea en blanco como un creeper.
     */
    public static class CreeperAgua extends MobEntityRenderer<CreeperAguaEntity, CodEntityModel<CreeperAguaEntity>> {
        public CreeperAgua(EntityRendererFactory.Context c) {
            super(c, new CodEntityModel<>(c.getPart(EntityModelLayers.COD)), 0.6f);
        }

        @Override
        public Identifier getTexture(CreeperAguaEntity e) {
            return CREEPER_AGUA;
        }

        @Override
        protected void setupTransforms(CreeperAguaEntity e, MatrixStack m, float animationProgress, float bodyYaw, float tickDelta, float scale) {
            super.setupTransforms(e, m, animationProgress, bodyYaw, tickDelta, scale);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(4.3f * MathHelper.sin(0.6f * animationProgress)));
            if (!e.isTouchingWater() && e.isOnGround()) {   // varado: tumbado de lado
                m.translate(0.2f, 0.2f, -0.2f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90f));
            }
        }

        /** x2, y con la mecha se hincha como el creeper vanilla. */
        @Override
        protected void scale(CreeperAguaEntity e, MatrixStack m, float tickDelta) {
            float g = e.progresoMecha(tickDelta);
            float h = 1f + MathHelper.sin(g * 100f) * g * 0.01f;
            g = MathHelper.clamp(g, 0f, 1f);
            g *= g;
            g *= g;
            float ancho = (1f + g * 0.4f) * h;
            float alto = (1f + g * 0.1f) / h;
            m.scale(2f * ancho, 2f * alto, 2f * ancho);
        }

        /** Parpadeo blanco de la mecha (como el creeper vanilla). */
        @Override
        protected float getAnimationCounter(CreeperAguaEntity e, float tickDelta) {
            float g = e.progresoMecha(tickDelta);
            return (int) (g * 10f) % 2 == 0 ? 0f : MathHelper.clamp(g, 0.5f, 1f);
        }
    }

    /** Pulpo: el modelo y las animaciones del calamar con nuestra textura 64x32. */
    public static class Pulpo extends SquidEntityRenderer<PulpoEntity> {
        public Pulpo(EntityRendererFactory.Context c) {
            super(c, new SquidEntityModel<>(c.getPart(EntityModelLayers.SQUID)));
        }

        @Override
        public Identifier getTexture(PulpoEntity e) {
            return PULPO;
        }
    }

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityRendererRegistry.register(ModAgua.CREEPER_AGUA, CreeperAgua::new);
        EntityRendererRegistry.register(ModAgua.PULPO, Pulpo::new);
    }
}

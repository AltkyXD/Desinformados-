package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.papel.AvionPapelEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo del Avión de Papel (textura 64x32, todo papel rayado). En píxeles, y hacia abajo, -z = morro.
 * Hecho con planos de grosor 0 (como las alas del murciélago):
 * <pre>
 *  alas: triángulo escalonado en 8 tramos de 2 px, del morro (z=-8) a la cola (z=+8), con media anchura de 1 a 8 px.
 *        Cada ala gira sobre la línea del centro (diedro en V) y aletea un poco.
 *  quilla: el doblez de debajo, un plano vertical que crece hacia atrás (1, 2 y 3 px de alto).
 * </pre>
 */
public class AvionPapelModel extends SinglePartEntityModel<AvionPapelEntity> {
    public static final EntityModelLayer CAPA = new EntityModelLayer(Desinformados.id("avion_papel"), "main");

    /** Tramos de 2 px del morro a la cola: {z inicio, media anchura}. */
    private static final float[][] TRAMOS = {{-8f, 1f}, {-6f, 2f}, {-4f, 3f}, {-2f, 4f}, {0f, 5f}, {2f, 6f}, {4f, 7f}, {6f, 8f}};

    private final ModelPart raiz;
    private final ModelPart alaIzq;
    private final ModelPart alaDer;

    public AvionPapelModel(ModelPart raiz) {
        this.raiz = raiz;
        ModelPart cuerpo = raiz.getChild("body");
        this.alaIzq = cuerpo.getChild("left_wing");
        this.alaDer = cuerpo.getChild("right_wing");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData datos = new ModelData();
        ModelPartData raiz = datos.getRoot();
        ModelPartData cuerpo = raiz.addChild("body", ModelPartBuilder.create()
                        // quilla (plano vertical bajo la línea del centro)
                        .uv(44, 0).cuboid(0f, 0f, -8f, 0f, 1f, 4f)
                        .uv(44, 0).cuboid(0f, 0f, -4f, 0f, 2f, 4f)
                        .uv(44, 0).cuboid(0f, 0f, 0f, 0f, 3f, 8f),
                ModelTransform.pivot(0f, 20f, 0f));
        ModelPartBuilder izq = ModelPartBuilder.create();
        ModelPartBuilder der = ModelPartBuilder.create();
        int v = 0;
        for (float[] t : TRAMOS) {
            izq.uv(0, v).cuboid(0f, 0f, t[0], t[1], 0f, 2f);
            der.uv(22, v).cuboid(-t[1], 0f, t[0], t[1], 0f, 2f);
            v += 3;
        }
        cuerpo.addChild("left_wing", izq, ModelTransform.pivot(0f, 0f, 0f));
        cuerpo.addChild("right_wing", der, ModelTransform.pivot(0f, 0f, 0f));
        return TexturedModelData.of(datos, 64, 32);
    }

    @Override
    public ModelPart getPart() {
        return raiz;
    }

    @Override
    public void setAngles(AvionPapelEntity e, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        // Diedro en V (puntas hacia arriba) con un ligero temblor del papel al viento
        float temblor = MathHelper.sin((animationProgress + e.getId() * 13) * 0.45f) * 0.06f;
        alaIzq.roll = -0.28f + temblor;
        alaDer.roll = 0.28f - temblor;
    }
}

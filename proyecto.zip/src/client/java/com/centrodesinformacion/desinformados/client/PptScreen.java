package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.PiedraPapelTijera;
import com.centrodesinformacion.desinformados.network.PptAccionPayload;
import com.centrodesinformacion.desinformados.network.PptPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Mesa de Piedra, Papel o Tijera: arriba los dos asientos (nombre, apuesta propuesta y si está de acuerdo);
 * abajo, según la fase, la apuesta y "De acuerdo", o los tres botones para elegir. El servidor lo decide todo.
 */
public class PptScreen extends Screen {
    /** Lo último que mandó el servidor. */
    public static PptPayload estado = new PptPayload(0, "", "", 10, 10, false, false, -1, -1, false, -1, -1, 0, 0, 0, "", false);
    private static final String[] ICONOS = {"✊", "✋", "✌"};
    private static final int ANCHO = 300, ALTO = 210;

    private final ButtonWidget[] pasos = new ButtonWidget[4];
    private final ButtonWidget[] jugadas = new ButtonWidget[3];
    private ButtonWidget igualar, acuerdo, salir;
    private int faseVista = -1;

    public PptScreen() {
        super(Text.literal("Piedra, Papel o Tijera"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int x0() { return (width - ANCHO) / 2; }
    private int y0() { return (height - ALTO) / 2; }

    private int miPropuesta() { return estado.yo() == 0 ? estado.propuesta0() : estado.propuesta1(); }
    private int suPropuesta() { return estado.yo() == 0 ? estado.propuesta1() : estado.propuesta0(); }

    @Override
    protected void init() {
        int x = x0(), y = y0();
        int[] valores = {-100, -10, 10, 100};
        String[] nombres = {"-100", "-10", "+10", "+100"};
        for (int i = 0; i < 4; i++) {
            int paso = valores[i];
            int bx = i < 2 ? x + 14 + i * 36 : x + ANCHO - 14 - (4 - i) * 36;
            pasos[i] = addDrawableChild(ButtonWidget.builder(Text.literal(nombres[i]), b -> cambiar(paso)).dimensions(bx, y + 132, 34, 20).build());
        }
        igualar = addDrawableChild(ButtonWidget.builder(Text.literal("Igualar"),
                b -> ClientPlayNetworking.send(new PptAccionPayload("apuesta", suPropuesta()))).dimensions(x + ANCHO / 2 - 102, y + 158, 100, 20).build());
        acuerdo = addDrawableChild(ButtonWidget.builder(Text.literal("De acuerdo"),
                b -> ClientPlayNetworking.send(new PptAccionPayload("acuerdo", 0))).dimensions(x + ANCHO / 2 + 2, y + 158, 100, 20).build());
        int bw = 84, bx = x + ANCHO / 2 - (bw * 3 + 8) / 2;
        for (int i = 0; i < 3; i++) {
            int jugada = i;
            jugadas[i] = addDrawableChild(ButtonWidget.builder(Text.literal(ICONOS[i] + " " + PiedraPapelTijera.JUGADAS[i]),
                    b -> ClientPlayNetworking.send(new PptAccionPayload("elegir", jugada))).dimensions(bx + i * (bw + 4), y + 140, bw, 24).build());
        }
        salir = addDrawableChild(ButtonWidget.builder(Text.literal("Levantarse"), b -> {
            ClientPlayNetworking.send(new PptAccionPayload("salir", 0));
            close();
        }).dimensions(x + 8, y + ALTO - 26, 76, 18).build());
        actualizar();
    }

    private void cambiar(int paso) {
        int v = Math.max(PiedraPapelTijera.MINIMA, Math.min(PiedraPapelTijera.MAXIMA, miPropuesta() + paso));
        ClientPlayNetworking.send(new PptAccionPayload("apuesta", v));
    }

    /** Llegó un estado nuevo del servidor. */
    public void refrescar() {
        if (estado.fase() != faseVista && client != null) {
            if (estado.fase() == PiedraPapelTijera.ELIGIENDO)
                client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 1.4f, 0.8f));
            faseVista = estado.fase();
        }
        actualizar();
    }

    private void actualizar() {
        boolean sentado = estado.yo() >= 0;
        int fase = estado.fase();
        boolean apostando = sentado && (fase == PiedraPapelTijera.ESPERANDO || fase == PiedraPapelTijera.ACORDANDO);
        for (ButtonWidget b : pasos) b.visible = apostando;
        igualar.visible = apostando && fase == PiedraPapelTijera.ACORDANDO;
        igualar.active = miPropuesta() != suPropuesta();
        acuerdo.visible = apostando && fase == PiedraPapelTijera.ACORDANDO;
        boolean miOk = estado.yo() == 0 ? estado.ok0() : estado.ok1();
        acuerdo.setMessage(miOk ? Text.literal("✔ De acuerdo").formatted(Formatting.GREEN) : Text.literal("De acuerdo"));
        acuerdo.active = estado.rumores() >= miPropuesta() || miOk;
        boolean eligiendo = sentado && fase == PiedraPapelTijera.ELIGIENDO;
        for (int i = 0; i < 3; i++) {
            jugadas[i].visible = eligiendo;
            jugadas[i].active = estado.miEleccion() < 0;
        }
        salir.visible = sentado && fase != PiedraPapelTijera.ELIGIENDO;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int x = x0(), y = y0();
        ctx.fill(x - 3, y - 3, x + ANCHO + 3, y + ALTO + 3, 0xFF14102A);
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + ALTO + 2, 0xFFD6B046);
        ctx.fill(x, y, x + ANCHO, y + ALTO, 0xFF5C2E18);
        ctx.fill(x + 5, y + 5, x + ANCHO - 5, y + ALTO - 5, 0xFF22346E);
        // los dos asientos
        int ancho = (ANCHO - 30) / 2;
        for (int i = 0; i < 2; i++) {
            int ax = x + 10 + i * (ancho + 10);
            boolean mio = estado.yo() == i;
            ctx.fill(ax, y + 34, ax + ancho, y + 92, mio ? 0x55F0D070 : 0x33000000);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = x0(), y = y0(), cx = x + ANCHO / 2;
        centrado(ctx, Text.literal("PIEDRA, PAPEL O TIJERA").formatted(Formatting.BOLD), cx, y + 10, 0xFFF0D070);
        centrado(ctx, Text.literal(estado.yo() >= 0 ? "Llevas " + estado.rumores() + " Rumores" : "Solo miras: la mesa está ocupada"), cx, y + 22, 0xFFB8C8F0);

        int ancho = (ANCHO - 30) / 2;
        String[] nombres = {estado.nombre0(), estado.nombre1()};
        int[] propuestas = {estado.propuesta0(), estado.propuesta1()};
        boolean[] oks = {estado.ok0(), estado.ok1()};
        int[] ultimas = {estado.ultima0(), estado.ultima1()};
        int fase = estado.fase();
        for (int i = 0; i < 2; i++) {
            int ax = x + 10 + i * (ancho + 10), acx = ax + ancho / 2;
            boolean hay = !nombres[i].isEmpty();
            centrado(ctx, Text.literal(hay ? nombres[i] : "Esperando rival...").formatted(hay ? Formatting.BOLD : Formatting.ITALIC), acx, y + 40,
                    hay ? 0xFFFFFFFF : 0xFF9090B0);
            if (!hay) continue;
            if (fase == PiedraPapelTijera.ESPERANDO || fase == PiedraPapelTijera.ACORDANDO) {
                centrado(ctx, Text.literal("Apuesta: " + propuestas[i]), acx, y + 56, 0xFFF0D070);
                centrado(ctx, Text.literal(oks[i] ? "✔ De acuerdo" : "Pensándolo..."), acx, y + 70, oks[i] ? 0xFF60E080 : 0xFF9090B0);
            } else if (fase == PiedraPapelTijera.ELIGIENDO) {
                boolean eligio = i == estado.yo() ? estado.miEleccion() >= 0 : estado.rivalEligio();
                String txt = i == estado.yo() && estado.miEleccion() >= 0
                        ? ICONOS[estado.miEleccion()] + " " + PiedraPapelTijera.JUGADAS[estado.miEleccion()]
                        : eligio ? "✔ Ya eligió" : "Eligiendo...";
                centrado(ctx, Text.literal(txt), acx, y + 60, eligio ? 0xFF60E080 : 0xFF9090B0);
                if (ultimas[i] >= 0) centrado(ctx, Text.literal("Antes: " + PiedraPapelTijera.JUGADAS[ultimas[i]]), acx, y + 74, 0xFF9090B0);
            } else if (ultimas[i] >= 0) {
                ctx.getMatrices().push();
                ctx.getMatrices().translate(acx, y + 62, 0);
                ctx.getMatrices().scale(2f, 2f, 1f);
                String ic = ICONOS[ultimas[i]];
                ctx.drawText(textRenderer, Text.literal(ic), -textRenderer.getWidth(ic) / 2, -4, 0xFFFFFFFF, true);
                ctx.getMatrices().pop();
                centrado(ctx, Text.literal(PiedraPapelTijera.JUGADAS[ultimas[i]]), acx, y + 78, 0xFFE0E0E0);
            } else if (fase == PiedraPapelTijera.RESULTADO) {
                centrado(ctx, Text.literal("No eligió"), acx, y + 62, 0xFF9090B0);
            }
        }
        if (fase == PiedraPapelTijera.ELIGIENDO || fase == PiedraPapelTijera.RESULTADO) centrado(ctx, Text.literal("VS").formatted(Formatting.BOLD), cx, y + 60, 0xFFF0D070);

        // centro: bote, cuenta atrás y mensajes
        if (fase == PiedraPapelTijera.ELIGIENDO) {
            centrado(ctx, Text.literal("Bote: " + estado.bote() + " Rumores · quedan " + estado.segundos() + " s").formatted(Formatting.BOLD), cx, y + 100, 0xFFF0D070);
            if (estado.yo() >= 0 && estado.miEleccion() < 0) centrado(ctx, Text.literal("Elige en secreto:"), cx, y + 124, 0xFFE0E0E0);
            else if (estado.yo() >= 0) centrado(ctx, Text.literal("Esperando a tu rival..."), cx, y + 124, 0xFFB8C8F0);
        } else if (estado.yo() >= 0 && (fase == PiedraPapelTijera.ESPERANDO || fase == PiedraPapelTijera.ACORDANDO)) {
            centrado(ctx, Text.literal("Tu apuesta: " + miPropuesta()).formatted(Formatting.BOLD), cx, y + 138, 0xFFFFFFFF);
            if (fase == PiedraPapelTijera.ESPERANDO) centrado(ctx, Text.literal("Esperando a que se siente otro jugador...").formatted(Formatting.ITALIC), cx, y + 162, 0xFFB8C8F0);
        }
        if (!estado.mensaje().isEmpty()) centrado(ctx, Text.literal(estado.mensaje()), cx, y + 108 + (fase == PiedraPapelTijera.ELIGIENDO ? 70 : 0), 0xFFFFE680);
        else if (fase == PiedraPapelTijera.ACORDANDO && miPropuesta() != suPropuesta())
            centrado(ctx, Text.literal("Tenéis que apostar lo mismo para empezar"), cx, y + 108, 0xFFB8C8F0);
    }

    private void centrado(DrawContext ctx, Text t, int cx, int y, int color) {
        ctx.drawText(textRenderer, t, cx - textRenderer.getWidth(t) / 2, y, color, true);
    }
}

package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/** Cuadro de diálogo de los Gatos Cubo encima de la barra de objetos, con efecto de máquina de escribir. */
public class DialogoHud {
    private static String nombre = "", texto = "";
    private static int color = 0xFFFFFF;
    private static int ticks = -1, total = 0;
    private static final float LETRAS_POR_TICK = 1.6f;

    public static void mostrar(String n, int c, String t) {
        nombre = n; color = c; texto = t;
        ticks = 0;
        total = (int) (t.length() / LETRAS_POR_TICK) + 70;   // lo que tarda en escribirse + 3,5 s para leerlo
    }

    public static void tick() {
        if (ticks >= 0 && ++ticks > total) ticks = -1;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (ticks < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int letras = Math.min(texto.length(), (int) (t * LETRAS_POR_TICK));
        float alfa = MathHelper.clamp((total - t) / 10f, 0f, 1f) * MathHelper.clamp(t / 4f, 0f, 1f);
        if (alfa <= 0.02f) return;
        int a = (int) (alfa * 255) << 24;
        int ancho = Math.min(ctx.getScaledWindowWidth() - 40, 300);
        List<OrderedText> lineas = tr.wrapLines(Text.literal(texto.substring(0, letras)), ancho - 12);
        int totalLineas = Math.max(1, tr.wrapLines(Text.literal(texto), ancho - 12).size()); // el cuadro no crece mientras escribe
        int alto = 16 + totalLineas * 10;
        int x = (ctx.getScaledWindowWidth() - ancho) / 2;
        int y = ctx.getScaledWindowHeight() - 64 - alto;
        if (mc.player != null && !mc.player.isCreative()) y -= 10; // deja sitio a corazones y comida
        ctx.fill(x - 1, y - 1, x + ancho + 1, y + alto + 1, (int) (alfa * 0xCC) << 24 | 0x000000);
        ctx.fill(x, y, x + ancho, y + alto, (int) (alfa * 0xB0) << 24 | 0x15151C);
        ctx.fill(x, y, x + 3, y + alto, a | (color & 0xFFFFFF));                       // franja del color del gato
        ctx.drawText(tr, Text.literal(nombre), x + 8, y + 4, a | (color & 0xFFFFFF), true);
        for (int i = 0; i < lineas.size(); i++) ctx.drawText(tr, lineas.get(i), x + 8, y + 14 + i * 10, a | 0xE8E8E8, false);
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.agua.CocodriloEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

/** El Cocodrilo con su modelo propio (CocodriloModel) y su textura de 128x64. */
public class CocodriloRenderer extends MobEntityRenderer<CocodriloEntity, CocodriloModel> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/cocodrilo.png");

    public CocodriloRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new CocodriloModel(ctx.getPart(CocodriloModel.CAPA)), 0.9f);
    }

    @Override
    public Identifier getTexture(CocodriloEntity entidad) {
        return TEXTURA;
    }
}

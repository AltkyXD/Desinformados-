package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;

/**
 * Trajes de los Gatos Cubo, hechos con cajitas de colores.
 * El cubo ocupa x,z = -0.45..0.45, y = 0..0.9; el frente (la cara) está en z = +0.45.
 */
final class Uniformes {
    private static final float H = 0.45f, A = 0.9f, F = H + 0.004f;
    private static VertexConsumer v;
    private static MatrixStack m;
    private static int luz, ov;

    private static void c(float x0, float y0, float z0, float x1, float y1, float z1, int color) {
        GatoCuboRenderer.caja(v, m.peek(), x0, y0, z0, x1, y1, z1, color, luz, ov);
    }
    private static void brillo(float x0, float y0, float z0, float x1, float y1, float z1, int color) {
        GatoCuboRenderer.caja(v, m.peek(), x0, y0, z0, x1, y1, z1, color, 0xF000F0, ov);
    }
    /** Pieza pegada al frente (grosor g). */
    private static void fr(float x0, float y0, float x1, float y1, float g, int color) { c(x0, y0, H, x1, y1, F + g, color); }

    static void dibujar(int tipo, VertexConsumer vc, MatrixStack ms, int l, int o) {
        v = vc; m = ms; luz = l; ov = o;
        switch (tipo) {
            case GatoCuboEntity.RECEPCIONISTA -> recepcionista();
            case GatoCuboEntity.PERIODISTA -> periodista();
            case GatoCuboEntity.CONSERJE -> conserje();
            case GatoCuboEntity.VEND_PASIVAS -> mago();
            case GatoCuboEntity.VEND_CORAZONES -> enfermero();
            case GatoCuboEntity.VEND_MINERALES -> minero();
            case GatoCuboEntity.ANIME -> anime();
            case GatoCuboEntity.NERD -> nerd();
            case GatoCuboEntity.ROBOT -> robot();
            case GatoCuboEntity.GRANJERO -> granjero();
            case GatoCuboEntity.GATO_GATO -> gatoGato();
            case GatoCuboEntity.ROMANTICO -> romantico();
            case GatoCuboEntity.MILLONARIO -> millonario();
            case GatoCuboEntity.ELEGANTE -> elegante();
            case GatoCuboEntity.CHEF -> chef();
            case GatoCuboEntity.DETECTIVE -> detective();
            case GatoCuboEntity.DJ -> dj();
            case GatoCuboEntity.CIENTIFICA -> cientifica();
            case GatoCuboEntity.FUJOSHI -> fujoshi();
            case GatoCuboEntity.MADRE -> madre();
            case GatoCuboEntity.GATITO -> gatito();
            case GatoCuboEntity.FIESTERA -> fiestera();
            case GatoCuboEntity.PERRO -> perro();
            default -> {} // El Gato (principal): sin nada, tal cual
        }
    }

    private static void cuello(int camisa) {
        // cuello de camisa: dos solapas en pico
        for (int i = 0; i < 4; i++) {
            float d = i * 0.035f;
            fr(-0.26f + d, 0.0f + d * 0.6f, -0.05f, 0.03f + d * 0.6f, 0.006f, camisa);
            fr(0.05f, 0.0f + d * 0.6f, 0.26f - d, 0.03f + d * 0.6f, 0.006f, camisa);
        }
    }

    // ---------------------------------------------------------------- recepcionista
    private static void recepcionista() {
        int negro = 0xFF1C1C1E, gris = 0xFF4A4A50, espuma = 0xFF2E2E33;
        // diadema por encima de la cabeza
        c(-0.49f, A - 0.05f, -0.035f, 0.49f, A + 0.03f, 0.035f, negro);
        c(-0.47f, A + 0.03f, -0.03f, 0.47f, A + 0.06f, 0.03f, gris);
        c(-0.49f, 0.55f, -0.035f, -0.455f, A - 0.05f, 0.035f, negro);
        c(0.455f, 0.55f, -0.035f, 0.49f, A - 0.05f, 0.035f, negro);
        // auriculares (copa + almohadilla + aro)
        for (int lado = -1; lado <= 1; lado += 2) {
            float x = lado * 0.47f;
            c(Math.min(x, x + lado * 0.07f), 0.38f, -0.11f, Math.max(x, x + lado * 0.07f), 0.6f, 0.11f, negro);
            c(Math.min(x + lado * 0.07f, x + lado * 0.085f), 0.42f, -0.07f, Math.max(x + lado * 0.07f, x + lado * 0.085f), 0.56f, 0.07f, gris);
            c(Math.min(x, x - lado * 0.02f), 0.4f, -0.09f, Math.max(x, x - lado * 0.02f), 0.58f, 0.09f, espuma);
        }
        // micrófono: brazo desde el auricular derecho hasta la boca, con espuma
        c(0.47f, 0.42f, 0.08f, 0.5f, 0.445f, 0.52f, negro);
        c(0.14f, 0.42f, 0.49f, 0.5f, 0.445f, 0.52f, negro);
        c(0.06f, 0.4f, 0.47f, 0.16f, 0.47f, 0.55f, espuma);
        // camisa, lazo rojo y credencial
        cuello(0xFFF5F5F5);
        GatoCuboRenderer.lazo(v, m.peek(), F, 0xFFC0392B, luz, ov);
        fr(-0.06f, 0.0f, 0.06f, 0.02f, 0.006f, 0xFFF5F5F5);
        fr(-0.4f, 0.1f, -0.22f, 0.26f, 0.008f, 0xFFF8F8F8);          // credencial
        fr(-0.4f, 0.22f, -0.22f, 0.26f, 0.011f, 0xFF2E6FD8);          // franja azul
        fr(-0.38f, 0.17f, -0.3f, 0.2f, 0.011f, 0xFFB8B8B8);           // "foto"
        fr(-0.29f, 0.185f, -0.24f, 0.195f, 0.011f, 0xFF404040);
        fr(-0.38f, 0.13f, -0.24f, 0.14f, 0.011f, 0xFF404040);
        fr(-0.32f, 0.26f, -0.3f, 0.32f, 0.008f, 0xFF2E6FD8);          // cordón
    }

    // ---------------------------------------------------------------- periodista
    private static void periodista() {
        int ala = 0xFF4E3220, copa = 0xFF6B4528, oscuro = 0xFF3A2416, cinta = 0xFF151515;
        c(-0.56f, A, -0.56f, 0.56f, A + 0.025f, 0.56f, ala);
        c(-0.6f, A - 0.01f, 0.4f, 0.6f, A + 0.015f, 0.62f, ala);               // ala delantera algo caída
        c(-0.33f, A + 0.025f, -0.31f, 0.33f, A + 0.24f, 0.31f, copa);
        c(-0.29f, A + 0.24f, -0.26f, 0.29f, A + 0.31f, 0.26f, copa);
        c(-0.04f, A + 0.3f, -0.22f, 0.04f, A + 0.315f, 0.22f, oscuro);        // hendidura de arriba
        c(-0.335f, A + 0.03f, -0.315f, 0.335f, A + 0.09f, 0.315f, cinta);
        // tarjeta de PRENSA en la cinta
        c(0.07f, A + 0.05f, 0.31f, 0.25f, A + 0.2f, 0.325f, 0xFFF6F2E2);
        c(0.09f, A + 0.15f, 0.325f, 0.23f, A + 0.17f, 0.33f, 0xFF151515);
        c(0.09f, A + 0.11f, 0.325f, 0.2f, A + 0.125f, 0.33f, 0xFF151515);
        c(0.09f, A + 0.075f, 0.325f, 0.23f, A + 0.085f, 0.33f, 0xFFC0392B);
        // lápiz detrás de la "oreja" derecha
        c(0.45f, 0.62f, -0.26f, 0.485f, 0.655f, 0.2f, 0xFFF2C230);
        c(0.45f, 0.62f, -0.31f, 0.485f, 0.655f, -0.26f, 0xFFE89AAE);
        c(0.45f, 0.62f, -0.27f, 0.485f, 0.655f, -0.255f, 0xFFB0B0B0);
        c(0.455f, 0.625f, 0.2f, 0.48f, 0.65f, 0.25f, 0xFFE0C090);
        c(0.46f, 0.63f, 0.25f, 0.475f, 0.645f, 0.275f, 0xFF303030);
        // camisa con corbata floja
        cuello(0xFFF0EEE6);
        fr(-0.045f, 0.16f, 0.045f, 0.22f, 0.02f, 0xFF7A1F2B);           // nudo
        fr(-0.05f, 0.0f, 0.05f, 0.16f, 0.014f, 0xFF7A1F2B);
        for (int i = 0; i < 3; i++) fr(-0.05f, 0.03f + i * 0.05f, 0.05f, 0.045f + i * 0.05f, 0.016f, 0xFFD9B24A);
        // libreta de notas asomando
        fr(0.24f, 0.0f, 0.4f, 0.2f, 0.01f, 0xFFF7F3E6);
        for (int i = 0; i < 4; i++) fr(0.26f, 0.04f + i * 0.04f, 0.38f, 0.048f + i * 0.04f, 0.013f, 0xFF8FB0E0);
        fr(0.24f, 0.19f, 0.4f, 0.21f, 0.014f, 0xFF9A9A9A);
    }

    // ---------------------------------------------------------------- conserje
    private static void conserje() {
        int azul = 0xFF2456A6, azulOsc = 0xFF173F80, amarillo = 0xFFF2C230, vaquero = 0xFF3B5E8C;
        c(-0.41f, A, -0.43f, 0.41f, A + 0.15f, 0.41f, azul);
        c(-0.36f, A + 0.15f, -0.38f, 0.36f, A + 0.19f, 0.36f, azul);
        c(-0.035f, A + 0.19f, -0.035f, 0.035f, A + 0.215f, 0.035f, azulOsc);    // botón
        c(-0.32f, A, 0.41f, 0.32f, A + 0.03f, 0.7f, azulOsc);                    // visera
        c(-0.33f, A - 0.005f, 0.68f, 0.33f, A + 0.03f, 0.72f, azulOsc);
        c(-0.1f, A + 0.04f, 0.41f, 0.1f, A + 0.13f, 0.42f, amarillo);           // logo
        c(-0.05f, A + 0.065f, 0.42f, 0.05f, A + 0.105f, 0.425f, azul);
        // peto vaquero con tirantes, bolsillo y botones
        fr(-0.3f, 0.0f, 0.3f, 0.24f, 0.012f, vaquero);
        fr(-0.3f, 0.24f, -0.21f, 0.5f, 0.012f, vaquero);
        fr(0.21f, 0.24f, 0.3f, 0.5f, 0.012f, vaquero);
        fr(-0.27f, 0.42f, -0.24f, 0.45f, 0.02f, amarillo);
        fr(0.24f, 0.42f, 0.27f, 0.45f, 0.02f, amarillo);
        fr(-0.12f, 0.05f, 0.12f, 0.17f, 0.017f, 0xFF2F4C72);
        fr(-0.12f, 0.155f, 0.12f, 0.17f, 0.02f, 0xFFE0C060);                   // costura
        fr(-0.02f, 0.06f, 0.02f, 0.15f, 0.02f, 0xFFC03030);                    // destornillador asomando
        // escoba apoyada en el costado
        m.push();
        m.translate(0.52f, 0.0f, 0.12f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(8f));
        c(-0.02f, 0.14f, -0.02f, 0.02f, 1.25f, 0.02f, 0xFF7A5230);
        c(-0.11f, 0.0f, -0.05f, 0.11f, 0.16f, 0.05f, 0xFFD8B860);
        c(-0.12f, 0.12f, -0.055f, 0.12f, 0.16f, 0.055f, 0xFFB03030);
        for (int i = -2; i <= 2; i++) c(i * 0.04f - 0.008f, -0.01f, -0.055f, i * 0.04f + 0.008f, 0.12f, 0.055f, 0xFFC4A04A);
        m.pop();
    }

    // ---------------------------------------------------------------- mago de las pasivas
    private static void mago() {
        int morado = 0xFF5C24A0, moradoOsc = 0xFF3E1670, oro = 0xFFE0B830, estrella = 0xFFFFE680;
        c(-0.52f, A, -0.52f, 0.52f, A + 0.03f, 0.52f, moradoOsc);              // ala
        float[] anchos = {0.34f, 0.29f, 0.24f, 0.19f, 0.14f, 0.1f, 0.06f};
        for (int i = 0; i < anchos.length; i++) {
            float a = anchos[i], y0 = A + 0.03f + i * 0.11f, dz = -i * i * 0.008f;   // el cono se dobla hacia atrás
            c(-a, y0, -a + dz, a, y0 + 0.11f, a + dz, i % 2 == 0 ? morado : 0xFF6A2BB0);
        }
        c(-0.345f, A + 0.03f, -0.345f, 0.345f, A + 0.08f, 0.345f, oro);         // cinta dorada
        c(-0.06f, A + 0.035f, 0.34f, 0.06f, A + 0.075f, 0.355f, 0xFFB08A20);   // hebilla
        // estrellas y luna en el sombrero
        brillo(0.08f, A + 0.16f, 0.29f, 0.14f, A + 0.22f, 0.3f, estrella);
        brillo(0.1f, A + 0.14f, 0.29f, 0.12f, A + 0.24f, 0.3f, estrella);
        brillo(-0.13f, A + 0.33f, 0.2f, -0.08f, A + 0.38f, 0.21f, estrella);
        brillo(-0.14f, A + 0.18f, 0.29f, -0.12f, A + 0.27f, 0.3f, 0xFFF0F0FF);   // luna
        brillo(-0.12f, A + 0.17f, 0.29f, -0.09f, A + 0.19f, 0.3f, 0xFFF0F0FF);
        brillo(-0.12f, A + 0.26f, 0.29f, -0.09f, A + 0.28f, 0.3f, 0xFFF0F0FF);
        // barba de mago y bigote (tapando la boca del gato)
        int barba = 0xFFEDEDED, barbaS = 0xFFCFCFCF;
        fr(-0.26f, 0.1f, 0.26f, 0.22f, 0.04f, barba);
        fr(-0.2f, 0.04f, 0.2f, 0.12f, 0.05f, barba);
        fr(-0.12f, 0.0f, 0.12f, 0.06f, 0.055f, barbaS);
        fr(-0.22f, 0.21f, -0.02f, 0.26f, 0.06f, barba);                          // bigote
        fr(0.02f, 0.21f, 0.22f, 0.26f, 0.06f, barba);
        fr(-0.26f, 0.19f, -0.2f, 0.24f, 0.065f, barbaS);
        fr(0.2f, 0.19f, 0.26f, 0.24f, 0.065f, barbaS);
        // capa por detrás con broches dorados
        c(-0.47f, 0.03f, -0.475f, 0.47f, 0.86f, -0.455f, morado);
        c(-0.47f, 0.03f, -0.48f, 0.47f, 0.1f, -0.47f, oro);
        c(-0.48f, 0.74f, -0.1f, -0.455f, 0.82f, 0.0f, oro);
        c(0.455f, 0.74f, -0.1f, 0.48f, 0.82f, 0.0f, oro);
    }

    // ---------------------------------------------------------------- enfermero
    private static void enfermero() {
        int blanco = 0xFFF8F8F8, gris = 0xFFDADADA, rojo = 0xFFD62828;
        c(-0.28f, A, -0.19f, 0.28f, A + 0.06f, 0.19f, blanco);                 // cofia: banda
        c(-0.24f, A + 0.06f, -0.12f, 0.24f, A + 0.21f, 0.15f, blanco);          // parte doblada
        c(-0.24f, A + 0.06f, -0.19f, 0.24f, A + 0.16f, -0.12f, gris);
        c(-0.03f, A + 0.07f, 0.15f, 0.03f, A + 0.19f, 0.162f, rojo);           // cruz roja
        c(-0.075f, A + 0.1f, 0.15f, 0.075f, A + 0.16f, 0.162f, rojo);
        // bata blanca con solapas, camisa azul y bolsillo con bolígrafos
        fr(-0.45f, 0.0f, -0.16f, 0.34f, 0.01f, blanco);
        fr(0.16f, 0.0f, 0.45f, 0.34f, 0.01f, blanco);
        for (int i = 0; i < 4; i++) {
            fr(-0.18f - i * 0.02f, 0.0f + i * 0.08f, -0.14f - i * 0.02f, 0.08f + i * 0.08f, 0.012f, gris);
            fr(0.14f + i * 0.02f, 0.0f + i * 0.08f, 0.18f + i * 0.02f, 0.08f + i * 0.08f, 0.012f, gris);
        }
        fr(-0.16f, 0.0f, 0.16f, 0.12f, 0.006f, 0xFF9EC8F0);
        fr(-0.4f, 0.05f, -0.24f, 0.16f, 0.014f, gris);                          // bolsillo
        fr(-0.38f, 0.14f, -0.36f, 0.22f, 0.02f, 0xFF2E6FD8);
        fr(-0.33f, 0.14f, -0.31f, 0.23f, 0.02f, rojo);
        // estetoscopio
        int tubo = 0xFF2C2C30, plata = 0xFFC8CCD2;
        fr(-0.3f, 0.32f, 0.3f, 0.345f, 0.02f, tubo);
        fr(-0.3f, 0.12f, -0.275f, 0.345f, 0.02f, tubo);
        fr(0.275f, 0.18f, 0.3f, 0.345f, 0.02f, tubo);
        fr(0.24f, 0.08f, 0.34f, 0.18f, 0.035f, plata);
        fr(0.27f, 0.11f, 0.31f, 0.15f, 0.04f, 0xFF60646A);
        fr(-0.32f, 0.08f, -0.26f, 0.13f, 0.025f, plata);
    }

    // ---------------------------------------------------------------- minero
    private static void minero() {
        int amarillo = 0xFFF2C230, amarilloOsc = 0xFFC99A18, naranja = 0xFFE8742A, reflejo = 0xFFE6E6E6;
        c(-0.53f, A, -0.53f, 0.53f, A + 0.025f, 0.53f, amarilloOsc);            // ala
        c(-0.44f, A + 0.025f, -0.44f, 0.44f, A + 0.15f, 0.44f, amarillo);
        c(-0.34f, A + 0.15f, -0.34f, 0.34f, A + 0.21f, 0.34f, amarillo);
        c(-0.045f, A + 0.15f, -0.42f, 0.045f, A + 0.235f, 0.42f, amarilloOsc);  // cresta
        c(-0.445f, A + 0.03f, -0.445f, 0.445f, A + 0.06f, 0.445f, 0xFF262626);  // cinta de la lámpara
        c(-0.1f, A + 0.025f, 0.44f, 0.1f, A + 0.15f, 0.5f, 0xFF6E6E6E);         // lámpara
        brillo(-0.075f, A + 0.045f, 0.5f, 0.075f, A + 0.13f, 0.51f, 0xFFFFFBD0);
        c(-0.11f, A + 0.03f, -0.52f, 0.11f, A + 0.14f, -0.445f, 0xFF3A3A3A);    // batería
        c(-0.05f, A + 0.14f, -0.5f, 0.05f, A + 0.16f, -0.47f, 0xFFC03030);
        // peto naranja con tiras reflectantes
        fr(-0.32f, 0.0f, 0.32f, 0.14f, 0.012f, naranja);
        fr(-0.32f, 0.14f, -0.21f, 0.46f, 0.012f, naranja);
        fr(0.21f, 0.14f, 0.32f, 0.46f, 0.012f, naranja);
        fr(-0.32f, 0.3f, -0.21f, 0.335f, 0.016f, reflejo);
        fr(0.21f, 0.3f, 0.32f, 0.335f, 0.016f, reflejo);
        fr(-0.32f, 0.06f, 0.32f, 0.09f, 0.016f, reflejo);
        // manchas de tierra en la cara
        fr(0.18f, 0.32f, 0.26f, 0.36f, 0.003f, 0x99503A24);
        fr(-0.3f, 0.5f, -0.24f, 0.53f, 0.003f, 0x99503A24);
        // pico apoyado en el costado izquierdo
        m.push();
        m.translate(-0.52f, 0.05f, 0.05f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-14f));
        c(-0.022f, 0.0f, -0.022f, 0.022f, 0.85f, 0.022f, 0xFF7A5230);
        c(-0.25f, 0.8f, -0.03f, 0.25f, 0.87f, 0.03f, 0xFF8A8F96);
        c(-0.3f, 0.78f, -0.025f, -0.24f, 0.84f, 0.025f, 0xFF5E636A);
        c(0.24f, 0.78f, -0.025f, 0.3f, 0.84f, 0.025f, 0xFF5E636A);
        m.pop();
    }

    // Posiciones de la cara (en el frente): ojos en x = +0.23 y x = -0.18, a y = 0.66; nariz y = 0.33; boca y ~ 0.18
    private static final float OJO_IZQ = 0.23f, OJO_DER = -0.18f, OJO_Y = 0.66f;

    private static void marco(float cx, float cy, float r, float g, float grosor, int color) {
        fr(cx - r, cy + r - grosor, cx + r, cy + r, g, color);
        fr(cx - r, cy - r, cx + r, cy - r + grosor, g, color);
        fr(cx - r, cy - r, cx - r + grosor, cy + r, g, color);
        fr(cx + r - grosor, cy - r, cx + r, cy + r, g, color);
    }

    private static void corazon(float cx, float cy, float t, float z, int color) {
        brillo(cx - 2 * t, cy, z, cx, cy + t, z + 0.01f, color);
        brillo(cx, cy, z, cx + 2 * t, cy + t, z + 0.01f, color);
        brillo(cx - 2 * t, cy - t, z, cx + 2 * t, cy, z + 0.01f, color);
        brillo(cx - t, cy - 2 * t, z, cx + t, cy - t, z + 0.01f, color);
    }

    // ---------------------------------------------------------------- gata kawaii
    private static void anime() {
        int rosa = 0xFFFF7FBF, rosaOsc = 0xFFE0559E, marino = 0xFF1E2A5A;
        c(-0.24f, A - 0.02f, -0.07f, -0.04f, A + 0.17f, 0.07f, rosa);          // lazo gigante
        c(0.04f, A - 0.02f, -0.07f, 0.24f, A + 0.17f, 0.07f, rosa);
        c(-0.26f, A + 0.02f, -0.06f, -0.22f, A + 0.13f, 0.06f, rosaOsc);
        c(0.22f, A + 0.02f, -0.06f, 0.26f, A + 0.13f, 0.06f, rosaOsc);
        c(-0.05f, A + 0.02f, -0.08f, 0.05f, A + 0.13f, 0.08f, rosaOsc);
        brillo(0.28f, 0.41f, H, 0.38f, 0.45f, F + 0.002f, 0xFFFF9AC8);          // coloretes
        brillo(-0.33f, 0.41f, H, -0.23f, 0.45f, F + 0.002f, 0xFFFF9AC8);
        for (float x : new float[]{OJO_IZQ - 0.06f, OJO_DER - 0.06f}) {           // brillitos en los ojos
            brillo(x, 0.7f, H, x + 0.035f, 0.735f, F + 0.004f, 0xFFFFFFFF);
            brillo(x + 0.08f, 0.62f, H, x + 0.1f, 0.64f, F + 0.004f, 0xFFFFFFFF);
        }
        fr(-0.45f, 0.0f, 0.45f, 0.08f, 0.008f, marino);                          // cuello de marinera
        fr(-0.45f, 0.055f, 0.45f, 0.065f, 0.01f, 0xFFFFFFFF);
        fr(-0.09f, 0.0f, 0.09f, 0.06f, 0.016f, 0xFFD62828);                      // pañuelo rojo
        fr(-0.06f, 0.06f, 0.06f, 0.1f, 0.016f, 0xFFD62828);
        fr(-0.03f, 0.1f, 0.03f, 0.13f, 0.016f, 0xFFB01E1E);
        femenina(0, true);
    }

    // ---------------------------------------------------------------- gato nerd
    private static void nerd() {
        int negro = 0xFF111111;
        marco(OJO_IZQ, OJO_Y, 0.15f, 0.025f, 0.035f, negro);                    // gafas gordas
        marco(OJO_DER, OJO_Y, 0.15f, 0.025f, 0.035f, negro);
        fr(OJO_DER + 0.15f, OJO_Y, OJO_IZQ - 0.15f, OJO_Y + 0.035f, 0.025f, negro);
        fr(0.0f, OJO_Y - 0.01f, 0.05f, OJO_Y + 0.045f, 0.03f, 0xFFF2F2F2);   // celo en el puente
        c(0.44f, OJO_Y + 0.08f, -0.25f, 0.47f, OJO_Y + 0.11f, H + 0.03f, negro);  // patillas
        c(-0.47f, OJO_Y + 0.08f, -0.25f, -0.44f, OJO_Y + 0.11f, H + 0.03f, negro);
        cuello(0xFFF2F2F2);
        GatoCuboRenderer.lazo(v, m.peek(), F, 0xFF2E9E44, luz, ov);              // pajarita verde
        fr(0.2f, 0.03f, 0.38f, 0.2f, 0.01f, 0xFFF8F8F8);                         // protector de bolsillo
        fr(0.22f, 0.17f, 0.24f, 0.26f, 0.02f, 0xFF2E6FD8);
        fr(0.26f, 0.17f, 0.28f, 0.25f, 0.02f, 0xFFD62828);
        fr(0.3f, 0.17f, 0.32f, 0.27f, 0.02f, 0xFF111111);
        fr(0.34f, 0.17f, 0.36f, 0.24f, 0.02f, 0xFFF2C230);
    }

    // ---------------------------------------------------------------- GATO-BOT 3000
    private static void robot() {
        int metal = 0xFF9AA3AD, metalOsc = 0xFF6B737C;
        c(-0.46f, A - 0.06f, -0.46f, 0.46f, A + 0.005f, 0.46f, metal);          // chapa de arriba
        for (int i = -1; i <= 1; i += 2) for (int j = -1; j <= 1; j += 2)
            c(i * 0.4f - 0.03f, A, j * 0.4f - 0.03f, i * 0.4f + 0.03f, A + 0.02f, j * 0.4f + 0.03f, metalOsc); // remaches
        c(-0.015f, A, -0.015f, 0.015f, A + 0.3f, 0.015f, metalOsc);               // antena
        brillo(-0.045f, A + 0.3f, -0.045f, 0.045f, A + 0.37f, 0.045f, 0xFFFF3030);
        for (int lado = -1; lado <= 1; lado += 2) {                               // tornillos del cuello
            float x = lado * 0.465f;
            c(Math.min(x, x + lado * 0.05f), 0.35f, -0.06f, Math.max(x, x + lado * 0.05f), 0.45f, 0.06f, metal);
            c(Math.min(x + lado * 0.05f, x + lado * 0.06f), 0.38f, -0.03f, Math.max(x + lado * 0.05f, x + lado * 0.06f), 0.42f, 0.03f, metalOsc);
        }
        fr(-0.32f, 0.0f, 0.32f, 0.16f, 0.01f, metal);                              // panel con lucecitas
        fr(-0.3f, 0.02f, 0.3f, 0.14f, 0.012f, metalOsc);
        int[] luces = {0xFF30FF60, 0xFFFF3030, 0xFFFFD030, 0xFF30A0FF};
        for (int i = 0; i < 4; i++) brillo(-0.26f + i * 0.14f, 0.06f, H, -0.2f + i * 0.14f, 0.1f, F + 0.016f, luces[i]);
    }

    // ---------------------------------------------------------------- gato granjero
    private static void granjero() {
        int paja = 0xFFE6C35C, pajaOsc = 0xFFC9A440, rojo = 0xFFC0392B;
        c(-0.56f, A, -0.56f, 0.56f, A + 0.03f, 0.56f, paja);                      // sombrero de paja
        c(-0.3f, A + 0.03f, -0.3f, 0.3f, A + 0.22f, 0.3f, pajaOsc);
        c(-0.305f, A + 0.04f, -0.305f, 0.305f, A + 0.08f, 0.305f, rojo);
        for (int i = -4; i <= 4; i += 2) c(i * 0.06f, A + 0.031f, 0.3f, i * 0.06f + 0.02f, A + 0.032f, 0.56f, pajaOsc); // trenzado
        c(0.04f, 0.16f, H, 0.4f, 0.18f, F + 0.025f, 0xFFF0DC90);                  // espiga en la boca
        c(0.38f, 0.14f, H, 0.47f, 0.22f, F + 0.03f, 0xFFD9A52A);
        fr(-0.45f, 0.0f, 0.45f, 0.07f, 0.01f, rojo);                              // pañuelo de cuello
        for (int i = -3; i <= 3; i++) fr(i * 0.12f - 0.01f, 0.025f, i * 0.12f + 0.01f, 0.045f, 0.012f, 0xFFF5F5F5);
        fr(-0.1f, 0.07f, 0.1f, 0.12f, 0.012f, rojo);
    }

    // ---------------------------------------------------------------- gato gato (solo collar con cascabel)
    private static void gatoGato() {
        c(-0.465f, 0.04f, -0.465f, 0.465f, 0.09f, 0.465f, 0xFFD12C2C);
        fr(-0.05f, 0.0f, 0.05f, 0.09f, 0.04f, 0xFFF2C230);
        fr(-0.04f, 0.02f, 0.04f, 0.03f, 0.045f, 0xFF6B5010);
    }

    // ---------------------------------------------------------------- gato romántico
    private static void romantico() {
        c(-0.3f, A, -0.32f, 0.36f, A + 0.08f, 0.3f, 0xFF8E1B2E);                // boina ladeada
        c(0.06f, A + 0.08f, -0.04f, 0.1f, A + 0.12f, 0.0f, 0xFF8E1B2E);
        c(-0.22f, 0.165f, H, 0.12f, 0.185f, F + 0.03f, 0xFF2E8B3A);              // rosa en la boca
        c(-0.04f, 0.18f, H, 0.04f, 0.23f, F + 0.032f, 0xFF3FA84C);               // hoja
        c(-0.33f, 0.12f, H, -0.2f, 0.24f, F + 0.05f, 0xFFD6203A);
        c(-0.31f, 0.14f, F + 0.05f, -0.22f, 0.22f, F + 0.06f, 0xFFA8122A);
        corazon(0.0f, A + 0.45f, 0.04f, 0.0f, 0xFFFF4D6D);                         // corazón flotando
    }

    // ---------------------------------------------------------------- gato millonario
    private static void millonario() {
        int oro = 0xFFE0B830, verde = 0xFF3BAA4A, verdeOsc = 0xFF2A7A34;
        marco(OJO_IZQ, OJO_Y, 0.13f, 0.03f, 0.025f, oro);                         // monóculo
        fr(OJO_IZQ + 0.11f, 0.32f, OJO_IZQ + 0.125f, OJO_Y - 0.13f, 0.02f, oro);  // cadenita
        fr(-0.36f, 0.05f, 0.36f, 0.08f, 0.012f, oro);                             // collar de oro
        fr(-0.06f, 0.0f, 0.06f, 0.1f, 0.02f, oro);
        fr(-0.02f, 0.02f, 0.02f, 0.08f, 0.025f, 0xFF8A6A10);                      // "$"
        for (int k = 0; k < 3; k++) {                                              // fajos de billetes falsos
            c(0.46f, 0.08f + k * 0.035f, -0.14f + k * 0.01f, 0.64f, 0.11f + k * 0.035f, 0.14f + k * 0.01f, k % 2 == 0 ? verde : 0xFFE88AD0);
            c(0.53f, 0.08f + k * 0.035f, -0.145f + k * 0.01f, 0.57f, 0.112f + k * 0.035f, 0.145f + k * 0.01f, 0xFFF5F5F5);
        }
        c(-0.64f, 0.08f, -0.12f, -0.46f, 0.12f, 0.12f, verdeOsc);
        c(-0.58f, 0.12f, -0.1f, -0.48f, 0.15f, 0.1f, verde);
    }

    // ---------------------------------------------------------------- gato elegante
    private static void elegante() {
        int negro = 0xFF121212;
        c(-0.42f, A, -0.42f, 0.42f, A + 0.03f, 0.42f, negro);                     // sombrero de copa
        c(-0.27f, A + 0.03f, -0.27f, 0.27f, A + 0.45f, 0.27f, negro);
        c(-0.275f, A + 0.05f, -0.275f, 0.275f, A + 0.11f, 0.275f, 0xFF7A1F2B);
        c(-0.25f, A + 0.43f, -0.25f, 0.25f, A + 0.451f, 0.25f, 0xFF2A2A2A);
        cuello(0xFFF8F8F8);
        GatoCuboRenderer.lazo(v, m.peek(), F, negro, luz, ov);                    // pajarita negra
        fr(0.24f, 0.16f, 0.34f, 0.2f, 0.012f, 0xFFF8F8F8);                         // pañuelo de bolsillo
        fr(0.26f, 0.2f, 0.32f, 0.23f, 0.012f, 0xFFF8F8F8);
        c(0.5f, 0.0f, 0.12f, 0.53f, 0.74f, 0.15f, negro);                          // bastón
        c(0.48f, 0.72f, 0.1f, 0.58f, 0.77f, 0.17f, 0xFFE0B830);
    }

    // ---------------------------------------------------------------- chef
    private static void chef() {
        int blanco = 0xFFFAFAFA, sombra = 0xFFE2E2E2;
        c(-0.3f, A, -0.3f, 0.3f, A + 0.1f, 0.3f, blanco);                         // gorro de chef
        c(-0.37f, A + 0.1f, -0.37f, 0.37f, A + 0.34f, 0.37f, blanco);
        c(-0.31f, A + 0.34f, -0.31f, 0.31f, A + 0.42f, 0.31f, sombra);
        for (int i = -1; i <= 1; i++) c(i * 0.18f - 0.02f, A + 0.1f, 0.37f, i * 0.18f + 0.02f, A + 0.34f, 0.375f, sombra); // pliegues
        fr(-0.22f, 0.26f, 0.22f, 0.3f, 0.02f, 0xFF151515);                        // bigote rizado
        fr(-0.27f, 0.29f, -0.21f, 0.34f, 0.02f, 0xFF151515);
        fr(0.21f, 0.29f, 0.27f, 0.34f, 0.02f, 0xFF151515);
        fr(-0.35f, 0.0f, 0.35f, 0.07f, 0.01f, 0xFFD62828);                        // pañuelo rojo
        fr(-0.06f, 0.06f, 0.06f, 0.11f, 0.014f, 0xFFB01E1E);
        c(0.47f, 0.22f, -0.015f, 0.5f, 0.8f, 0.015f, 0xFFC8CCD2);                // cucharón
        c(0.44f, 0.12f, -0.06f, 0.56f, 0.22f, 0.06f, 0xFFA8ACB2);
    }

    // ---------------------------------------------------------------- detective
    private static void detective() {
        int cafe = 0xFF8A6A42, cafeOsc = 0xFF5E4528;
        c(-0.35f, A, -0.35f, 0.35f, A + 0.2f, 0.35f, cafe);                        // gorro de cazador (cuadros)
        for (int i = -3; i <= 3; i++) {
            c(i * 0.1f - 0.008f, A + 0.001f, -0.355f, i * 0.1f + 0.008f, A + 0.2f, 0.355f, cafeOsc);
            c(-0.355f, A + 0.05f + Math.abs(i) * 0.0f, i * 0.1f - 0.008f, 0.355f, A + 0.2f, i * 0.1f + 0.008f, cafeOsc);
        }
        c(-0.26f, A, 0.35f, 0.26f, A + 0.03f, 0.55f, cafe);                        // viseras delante y detrás
        c(-0.26f, A, -0.55f, 0.26f, A + 0.03f, -0.35f, cafe);
        c(-0.06f, A + 0.2f, -0.06f, 0.06f, A + 0.25f, 0.06f, cafeOsc);             // lazo de las orejeras
        c(-0.2f, 0.155f, H, 0.04f, 0.185f, F + 0.03f, 0xFF4A2E18);                // pipa
        c(-0.28f, 0.12f, H, -0.18f, 0.24f, F + 0.06f, 0xFF4A2E18);
        c(-0.27f, 0.22f, F + 0.01f, -0.19f, 0.24f, F + 0.05f, 0xFF1A1A1A);
        // lupa en el costado
        c(0.47f, 0.12f, -0.02f, 0.5f, 0.42f, 0.02f, 0xFF3A2416);
        float y0 = 0.42f, y1 = 0.72f, z0 = -0.15f, z1 = 0.15f, x = 0.47f;
        c(x, y0, z0, x + 0.03f, y0 + 0.03f, z1, 0xFFB8B8B8);
        c(x, y1 - 0.03f, z0, x + 0.03f, y1, z1, 0xFFB8B8B8);
        c(x, y0, z0, x + 0.03f, y1, z0 + 0.03f, 0xFFB8B8B8);
        c(x, y0, z1 - 0.03f, x + 0.03f, y1, z1, 0xFFB8B8B8);
        brillo(x + 0.01f, y0 + 0.03f, z0 + 0.03f, x + 0.02f, y1 - 0.03f, z1 - 0.03f, 0xFFBFE6FF);
    }

    // ---------------------------------------------------------------- DJ Miaumix
    private static void dj() {
        int negro = 0xFF141416, gris = 0xFF3A3A40, verde = 0xFF39FF5A, oro = 0xFFE0B830;
        // gorra al revés
        c(-0.4f, A, -0.4f, 0.4f, A + 0.12f, 0.36f, negro);
        c(-0.22f, A, -0.62f, 0.22f, A + 0.03f, -0.36f, negro);
        brillo(-0.06f, A + 0.03f, -0.405f, 0.06f, A + 0.09f, -0.4f, verde);
        // auriculares grandes con luces verdes
        c(-0.49f, A + 0.1f, -0.05f, 0.49f, A + 0.16f, 0.05f, gris);
        for (int lado = -1; lado <= 1; lado += 2) {
            float x0 = lado < 0 ? -0.6f : 0.45f, x1 = lado < 0 ? -0.45f : 0.6f;
            c(x0, 0.4f, -0.16f, x1, 0.68f, 0.16f, negro);
            c(lado < 0 ? -0.5f : 0.45f, 0.62f, -0.04f, lado < 0 ? -0.45f : 0.5f, A + 0.12f, 0.04f, gris);
            brillo(lado < 0 ? -0.605f : 0.6f, 0.47f, -0.08f, lado < 0 ? -0.6f : 0.605f, 0.61f, 0.08f, verde);
        }
        // gafas de sol
        fr(OJO_DER - 0.15f, OJO_Y - 0.09f, OJO_DER + 0.13f, OJO_Y + 0.09f, 0.02f, negro);
        fr(OJO_IZQ - 0.13f, OJO_Y - 0.09f, OJO_IZQ + 0.15f, OJO_Y + 0.09f, 0.02f, negro);
        fr(OJO_DER + 0.13f, OJO_Y + 0.02f, OJO_IZQ - 0.13f, OJO_Y + 0.06f, 0.02f, negro);
        brillo(OJO_DER - 0.11f, OJO_Y + 0.03f, F + 0.02f, OJO_DER - 0.05f, OJO_Y + 0.06f, F + 0.024f, 0xFF7FD8FF);
        brillo(OJO_IZQ - 0.09f, OJO_Y + 0.03f, F + 0.02f, OJO_IZQ - 0.03f, OJO_Y + 0.06f, F + 0.024f, 0xFF7FD8FF);
        // cadena de oro con un disco de vinilo
        fr(-0.34f, 0.08f, 0.34f, 0.11f, 0.012f, oro);
        fr(-0.09f, 0.0f, 0.09f, 0.12f, 0.02f, negro);
        brillo(-0.03f, 0.04f, F + 0.02f, 0.03f, 0.08f, F + 0.026f, verde);
    }

    // ---------------------------------------------------------------- gata científica
    private static void cientifica() {
        int blanco = 0xFFF4F6F8, sombra = 0xFFD5DADF;
        // moño de pelo castaño oscuro y pestañas/labios
        c(-0.47f, A - 0.02f, -0.47f, 0.47f, A + 0.04f, 0.47f, 0xFF3B2A20);
        c(-0.14f, A + 0.04f, -0.36f, 0.14f, A + 0.24f, -0.08f, 0xFF3B2A20);
        c(-0.16f, A + 0.1f, -0.38f, 0.16f, A + 0.14f, -0.06f, 0xFF5A4030);
        c(0.12f, A + 0.12f, -0.24f, 0.14f, A + 0.32f, -0.2f, 0xFFF2C230);   // lápiz en el moño
        femenina(0xFFC9506E, true);
        // bata blanca con solapas y bolsillo
        fr(-0.45f, 0.0f, -0.18f, 0.24f, 0.012f, blanco);
        fr(0.18f, 0.0f, 0.45f, 0.24f, 0.012f, blanco);
        fr(-0.22f, 0.0f, -0.16f, 0.24f, 0.016f, sombra);
        fr(0.16f, 0.0f, 0.22f, 0.24f, 0.016f, sombra);
        fr(0.26f, 0.05f, 0.4f, 0.15f, 0.018f, sombra);
        // tubo de ensayo verde brillante en el bolsillo
        c(0.3f, 0.12f, H, 0.34f, 0.3f, F + 0.035f, 0xFFDDEEFF);
        brillo(0.305f, 0.12f, F + 0.036f, 0.335f, 0.22f, F + 0.038f, 0xFF39FF5A);
        // gafas de laboratorio subidas en la frente
        int marco = 0xFF2F6FA8;
        c(-0.47f, 0.78f, -0.03f, 0.47f, 0.82f, 0.03f, marco);
        for (float x : new float[]{-0.18f, 0.18f}) {
            fr(x - 0.13f, 0.76f, x + 0.13f, 0.88f, 0.03f, marco);
            brillo(x - 0.1f, 0.78f, F + 0.031f, x + 0.1f, 0.86f, F + 0.034f, 0xFFBDE8FF);
        }
    }

    // ---------------------------------------------------------------- gata fujoshi
    private static void fujoshi() {
        int cafe = 0xFF6B4226, cafeOsc = 0xFF4E2F1A, negro = 0xFF101012;
        melena(cafe, cafeOsc, 0.12f, 0.1f);                     // cabellera café despeinada hacia abajo
        // gafas grandes y redondas, opacas, con brillo
        float r = 0.165f;
        for (float x : new float[]{OJO_IZQ, OJO_DER}) {
            disco(x, OJO_Y - 0.02f, r, F + 0.03f, 0xFFEDEDED);
            disco(x - 0.06f, OJO_Y + 0.04f, 0.04f, F + 0.034f, 0xFFFFFFFF);
            aro(x, OJO_Y - 0.02f, r, 0.018f, 0.04f, negro);
        }
        fr(OJO_DER + r, OJO_Y + 0.0f, OJO_IZQ - r, OJO_Y + 0.03f, 0.04f, negro);       // puente
        femenina(0xFFD9607E, false);
        // libreta en la mano con lápiz
        c(0.46f, 0.06f, 0.06f, 0.5f, 0.36f, 0.34f, 0xFFF0E6D0);
        c(0.5f, 0.06f, 0.06f, 0.52f, 0.36f, 0.34f, 0xFF7A3B6A);
        c(0.5f, 0.3f, 0.36f, 0.53f, 0.33f, 0.52f, 0xFFF2C230);
    }

    // ---------------------------------------------------------------- gata mamá
    private static void madre() {
        int delantal = 0xFFF7D8E4, borde = 0xFFE07AA8, perla = 0xFFF4F0E8;
        femenina(0xFFD2486A, true);
        fr(-0.3f, 0.0f, 0.3f, 0.26f, 0.012f, delantal);                  // delantal
        fr(-0.3f, 0.24f, 0.3f, 0.27f, 0.014f, borde);
        fr(-0.12f, 0.06f, 0.12f, 0.16f, 0.016f, borde);                 // bolsillo con corazón
        corazon(0f, 0.12f, 0.018f, F + 0.017f, 0xFFFF5A8A);
        for (int i = -4; i <= 4; i++) {                                    // collar de perlas
            float x = i * 0.07f, y = 0.3f - Math.abs(i) * 0.012f;
            fr(x - 0.022f, y - 0.022f, x + 0.022f, y + 0.022f, 0.02f, perla);
        }
        c(-0.2f, A, -0.12f, 0.2f, A + 0.06f, 0.12f, 0xFFF2C6D8);         // pañuelo en la cabeza
        c(0.18f, A - 0.02f, -0.06f, 0.3f, A + 0.08f, 0.06f, borde);
    }

    // ---------------------------------------------------------------- gatito (va con su mamá)
    private static void gatito() {
        fr(-0.2f, 0.0f, 0.2f, 0.18f, 0.012f, 0xFFBFE3FF);                // babero azul
        fr(-0.2f, 0.16f, 0.2f, 0.19f, 0.014f, 0xFF6FB6F2);
        fr(-0.07f, 0.24f, 0.07f, 0.32f, 0.03f, 0xFFFF9AC8);              // chupete
        fr(-0.03f, 0.26f, 0.03f, 0.3f, 0.05f, 0xFFF2F2F2);
    }

    // ---------------------------------------------------------------- gata fiestera
    private static void fiestera() {
        melena(0xFFFF5FB8, 0xFFC93C8E, 0.2f, 0.04f);            // melena rosa chicle
        femenina(0xFFFF2E6E, true);
        // gorrito de fiesta de rayas (encima del pelo)
        int[] colores = {0xFFFF4FA0, 0xFFFFE04A, 0xFF4FD0FF};
        for (int i = 0; i < 6; i++) {
            float r = 0.2f - i * 0.03f;
            c(-r, A + 0.06f + i * 0.06f, -r, r, A + 0.06f + (i + 1) * 0.06f, r, colores[i % 3]);
        }
        brillo(-0.03f, A + 0.42f, -0.03f, 0.03f, A + 0.48f, 0.03f, 0xFFFFFFFF);
        // gafas de corazón
        corazon(OJO_IZQ, OJO_Y - 0.02f, 0.05f, F + 0.02f, 0xFFFF3B8A);
        corazon(OJO_DER, OJO_Y - 0.02f, 0.05f, F + 0.02f, 0xFFFF3B8A);
        // collar de pulseras luminosas
        int[] neon = {0xFF39FF5A, 0xFFFF4FD0, 0xFF4FD0FF, 0xFFFFE04A};
        for (int i = 0; i < 4; i++) brillo(-0.4f + i * 0.2f, 0.04f, F, -0.22f + i * 0.2f, 0.08f, F + 0.012f, neon[i]);
    }

    // ---------------------------------------------------------------- gato perro
    private static void perro() {
        int oreja = 0xFF6B4A2E, collar = 0xFFD62828;
        // orejas caídas de perro a los lados
        c(-0.55f, 0.35f, -0.12f, -0.45f, 0.82f, 0.12f, oreja);
        c(0.45f, 0.35f, -0.12f, 0.55f, 0.82f, 0.12f, oreja);
        // lengua fuera
        fr(-0.06f, 0.08f, 0.06f, 0.2f, 0.03f, 0xFFFF6F8F);
        fr(-0.01f, 0.1f, 0.01f, 0.2f, 0.035f, 0xFFD94A6A);
        // collar rojo con placa dorada
        fr(-0.45f, 0.0f, 0.45f, 0.06f, 0.014f, collar);
        fr(-0.05f, -0.06f, 0.05f, 0.03f, 0.022f, 0xFFE0B830);
        // hueso en la boca... no, en el lado
        c(0.46f, 0.1f, -0.15f, 0.5f, 0.14f, 0.15f, 0xFFF4F0E2);
        c(0.46f, 0.08f, -0.2f, 0.5f, 0.16f, -0.13f, 0xFFF4F0E2);
        c(0.46f, 0.08f, 0.13f, 0.5f, 0.16f, 0.2f, 0xFFF4F0E2);
    }

    // ---------------------------------------------------------------- detalles "de chica"
    /** Pestañas en la esquina de fuera de cada ojo y labios pintados. */
    private static void femenina(int labios, boolean pestanas) {
        int negro = 0xFF121212;
        if (pestanas) {
            for (int lado = -1; lado <= 1; lado += 2) {
                float x = lado > 0 ? OJO_IZQ : OJO_DER;
                float fuera = x + lado * 0.11f;
                fr(Math.min(fuera, fuera + lado * 0.06f), OJO_Y + 0.07f, Math.max(fuera, fuera + lado * 0.06f), OJO_Y + 0.095f, 0.01f, negro);
                fr(Math.min(fuera, fuera + lado * 0.05f), OJO_Y + 0.11f, Math.max(fuera, fuera + lado * 0.05f), OJO_Y + 0.13f, 0.01f, negro);
                fr(Math.min(fuera - lado * 0.04f, fuera), OJO_Y + 0.12f, Math.max(fuera - lado * 0.04f, fuera), OJO_Y + 0.15f, 0.01f, negro);
            }
        }
        if (labios != 0) {
            fr(-0.07f, 0.16f, 0.07f, 0.19f, 0.008f, labios);
            fr(-0.04f, 0.19f, 0.04f, 0.205f, 0.008f, labios);
        }
    }

    /** Aro circular (gafas redondas) hecho con cuadraditos, en el frente. */
    private static void aro(float cx, float cy, float r, float grosor, float g, int color) {
        int n = 28;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            float x = cx + (float) Math.cos(a) * r, y = cy + (float) Math.sin(a) * r;
            fr(x - grosor, y - grosor, x + grosor, y + grosor, g, color);
        }
    }

    /** Disco relleno (cristal) hecho con franjas horizontales. */
    private static void disco(float cx, float cy, float r, float z, int color) {
        int n = 12;
        for (int i = 0; i < n; i++) {
            float y0 = cy - r + i * (2 * r / n), y1 = y0 + 2 * r / n;
            float ym = (y0 + y1) / 2 - cy;
            float w = (float) Math.sqrt(Math.max(0, r * r - ym * ym));
            brillo(cx - w, y0, z, cx + w, y1, z + 0.003f, color);
        }
    }

    /** Melena: casquete arriba, pelo cayendo por detrás y por los lados, y flequillo desordenado delante. */
    private static void melena(int color, int sombra, float hasta, float flequillo) {
        c(-0.47f, A - 0.02f, -0.47f, 0.47f, A + 0.06f, 0.47f, color);                       // casquete
        float[] largos = {0.0f, 0.05f, -0.03f, 0.06f, 0.0f, 0.04f, -0.02f, 0.05f, 0.01f};      // puntas desiguales
        for (int i = 0; i < largos.length; i++) {                                              // detrás
            float x0 = -0.48f + i * 0.107f;
            c(x0, hasta + largos[i], -0.49f, x0 + 0.107f, A + 0.06f, -0.45f, i % 2 == 0 ? color : sombra);
        }
        for (int lado = -1; lado <= 1; lado += 2) {                                            // lados
            for (int i = 0; i < 6; i++) {
                float z0 = -0.47f + i * 0.13f;
                float bajo = hasta + largos[(i + 3) % largos.length] + (i > 3 ? 0.08f : 0f);
                float x0 = lado < 0 ? -0.49f : 0.45f, x1 = lado < 0 ? -0.45f : 0.49f;
                c(x0, bajo, z0, x1, A + 0.06f, Math.min(z0 + 0.13f, 0.47f), i % 2 == 0 ? color : sombra);
            }
            // mechones que caen por delante, pegados a los bordes de la cara
            float fx0 = lado < 0 ? -0.47f : 0.39f, fx1 = lado < 0 ? -0.39f : 0.47f;
            fr(fx0, hasta + 0.1f, fx1, A + 0.06f, 0.02f, sombra);
        }
        float[] puntas = {0.06f, 0.11f, 0.03f, 0.13f, 0.07f, 0.12f, 0.04f, 0.1f, 0.05f};      // flequillo despeinado
        for (int i = 0; i < puntas.length; i++) {
            float x0 = -0.45f + i * 0.1f;
            fr(x0, A - flequillo - puntas[i] * 0.6f, x0 + 0.1f, A + 0.06f, 0.025f + (i % 3) * 0.006f, i % 2 == 0 ? color : sombra);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Blackjack;
import com.centrodesinformacion.desinformados.network.BlackjackAccionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Mesa de Blackjack: arriba las cartas de la banca, abajo las tuyas. Antes de repartir eliges la apuesta;
 * durante la mano: Pedir, Plantarse o Doblar. Todo lo decide el servidor; aquí solo se dibuja.
 */
public class BlackjackScreen extends Screen {
    // lo último que mandó el servidor
    public static int rumores = 0, apuestaMano = 0, fase = Blackjack.SIN_MANO, pago = 0;
    public static List<Integer> jugador = List.of(), banca = List.of();
    public static String mensaje = "";
    /** Apuesta elegida para la próxima mano (se recuerda entre partidas). */
    private static int apuesta = 10;

    private static final int ANCHO = 320, ALTO = 236;
    private static final int CARTA_W = 26, CARTA_H = 36;

    private final ButtonWidget[] botonesApuesta = new ButtonWidget[4];
    private ButtonWidget repartir, pedir, plantarse, doblar;
    private int cartasVistas = 0;

    // ---- Destapar la banca poco a poco al acabar la mano (antes salía todo de golpe y no se entendía)
    private static final int TICKS_CARTA = 16;          // 0,8 s por carta
    /** Cuántas cartas de la banca se ven ahora mismo (las demás aún no han salido; la 2.ª, boca abajo). */
    private int bancaMostradas = Integer.MAX_VALUE;
    private int espera = 0;
    private int faseVista = Blackjack.SIN_MANO;

    private boolean destapando() { return bancaMostradas < banca.size(); }

    /** Lo que se dibuja de la banca: las ya destapadas y, si aún no se ha destapado la 2.ª, su reverso. */
    private List<Integer> bancaVisible() {
        if (!destapando()) return banca;
        List<Integer> l = new java.util.ArrayList<>(banca.subList(0, Math.max(0, bancaMostradas)));
        if (bancaMostradas < 2 && banca.size() >= 2) l.add(Blackjack.OCULTA);
        return l;
    }

    public BlackjackScreen() {
        super(Text.literal("Blackjack"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int x0() { return (width - ANCHO) / 2; }
    private int y0() { return (height - ALTO) / 2; }

    @Override
    protected void init() {
        int x = x0(), y = y0() + ALTO - 30;
        int[] pasos = {-100, -10, 10, 100};
        String[] nombres = {"-100", "-10", "+10", "+100"};
        for (int i = 0; i < 4; i++) {
            int paso = pasos[i];
            int bx = i < 2 ? x + 12 + i * 34 : x + ANCHO - 12 - (4 - i) * 34;
            botonesApuesta[i] = addDrawableChild(ButtonWidget.builder(Text.literal(nombres[i]), b -> cambiar(paso))
                    .dimensions(bx, y, 32, 20).build());
        }
        repartir = addDrawableChild(ButtonWidget.builder(Text.literal("¡REPARTIR!").formatted(Formatting.BOLD),
                b -> ClientPlayNetworking.send(new BlackjackAccionPayload("repartir", apuesta))).dimensions(x + ANCHO / 2 - 50, y - 24, 100, 20).build());
        int bw = 82, bx = x + ANCHO / 2 - (bw * 3 + 8) / 2;
        pedir = addDrawableChild(ButtonWidget.builder(Text.literal("Pedir"),
                b -> ClientPlayNetworking.send(new BlackjackAccionPayload("pedir", 0))).dimensions(bx, y, bw, 20).build());
        plantarse = addDrawableChild(ButtonWidget.builder(Text.literal("Plantarse"),
                b -> ClientPlayNetworking.send(new BlackjackAccionPayload("plantarse", 0))).dimensions(bx + bw + 4, y, bw, 20).build());
        doblar = addDrawableChild(ButtonWidget.builder(Text.literal("Doblar"),
                b -> ClientPlayNetworking.send(new BlackjackAccionPayload("doblar", 0))).dimensions(bx + (bw + 4) * 2, y, bw, 20).build());
        cartasVistas = jugador.size() + banca.size();
        faseVista = fase;
        actualizarBotones();
    }

    private void cambiar(int paso) {
        apuesta = Math.max(Blackjack.MINIMA, Math.min(Blackjack.MAXIMA, apuesta + paso));
        actualizarBotones();
    }

    /** Llegó un estado nuevo del servidor. */
    public void refrescar() {
        // La mano acaba de terminar: la banca enseña su carta tapada y luego pide las suyas, de una en una
        if (fase == Blackjack.TERMINADA && faseVista != Blackjack.TERMINADA) {
            bancaMostradas = Math.min(1, banca.size());
            espera = TICKS_CARTA;
        } else if (fase != Blackjack.TERMINADA) {
            bancaMostradas = Integer.MAX_VALUE;
        }
        faseVista = fase;
        int ahora = jugador.size() + banca.size();
        if (ahora > cartasVistas && client != null)
            client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ITEM_BOOK_PAGE_TURN, 1.2f, 0.8f));
        cartasVistas = ahora;
        actualizarBotones();
    }

    @Override
    public void tick() {
        super.tick();
        if (!destapando() || --espera > 0) return;
        bancaMostradas++;
        espera = TICKS_CARTA;
        if (client != null) client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ITEM_BOOK_PAGE_TURN, 1.2f, 0.8f));
        if (!destapando()) actualizarBotones();                         // ya está todo: aparece el resultado y "otra mano"
    }

    private void actualizarBotones() {
        boolean jugando = fase == Blackjack.JUGANDO || destapando();
        for (ButtonWidget b : botonesApuesta) b.visible = !jugando;
        repartir.visible = !jugando;
        repartir.active = rumores >= apuesta;
        repartir.setMessage(Text.literal(fase == Blackjack.TERMINADA ? "¡OTRA MANO!" : "¡REPARTIR!").formatted(Formatting.BOLD));
        pedir.visible = plantarse.visible = doblar.visible = jugando;
        if (destapando()) pedir.visible = plantarse.visible = doblar.visible = false;   // solo se mira cómo juega la banca
        doblar.active = fase == Blackjack.JUGANDO && jugador.size() == 2 && rumores >= apuestaMano;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int x = x0(), y = y0();
        // mesa de casino: marco dorado, madera y paño verde con su media luna
        ctx.fill(x - 3, y - 3, x + ANCHO + 3, y + ALTO + 3, 0xFF2A1408);
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + ALTO + 2, 0xFFD6B046);
        ctx.fill(x, y, x + ANCHO, y + ALTO, 0xFF5C2E18);
        ctx.fill(x + 5, y + 5, x + ANCHO - 5, y + ALTO - 5, 0xFF1C5C34);
        ctx.fill(x + 20, y + 98, x + ANCHO - 20, y + 99, 0x66D6B046);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = x0(), y = y0(), cx = x + ANCHO / 2;
        centrado(ctx, Text.literal("BLACKJACK").formatted(Formatting.BOLD), cx, y + 9, 0xFFF0D070);
        int llevas = destapando() ? rumores - pago : rumores;          // el premio no se ve hasta que la banca acaba
        centrado(ctx, Text.literal("Llevas " + llevas + " Rumores · Ganar x2 · Blackjack x2,5"), cx, y + 21, 0xFFB8D8C0);

        // banca
        List<Integer> bv = bancaVisible();
        int vb = Blackjack.valor(bv);
        boolean oculta = bv.contains(Blackjack.OCULTA);
        String tb = bv.isEmpty() ? "Banca" : "Banca: " + vb + (oculta ? " + ?" : "") + (vb > 21 ? " (se pasó)" : "");
        ctx.drawText(textRenderer, Text.literal(tb), x + 14, y + 36, vb > 21 ? 0xFF60E080 : 0xFFE0E0E0, true);
        if (destapando() && bancaMostradas >= 2) {
            Text pide = Text.literal(vb < 17 ? "La banca pide carta (hasta 17)..." : "La banca se planta").formatted(Formatting.ITALIC);
            ctx.drawText(textRenderer, pide, x + ANCHO - 14 - textRenderer.getWidth(pide), y + 36, 0xFFF0D070, true);
        }
        dibujarMano(ctx, bv, cx, y + 48);

        // jugador
        int vj = Blackjack.valor(jugador);
        String tj = jugador.isEmpty() ? "Tú" : "Tú: " + vj + (vj > 21 ? " (te pasaste)" : "");
        ctx.drawText(textRenderer, Text.literal(tj), x + 14, y + 104, vj > 21 ? 0xFFFF6060 : 0xFFE0E0E0, true);
        if (apuestaMano > 0 && fase != Blackjack.SIN_MANO) {
            Text ap = Text.literal("Apostado: " + apuestaMano);
            ctx.drawText(textRenderer, ap, x + ANCHO - 14 - textRenderer.getWidth(ap), y + 104, 0xFFF0D070, true);
        }
        dibujarMano(ctx, jugador, cx, y + 116);

        // abajo: apuesta o resultado
        int yb = y + ALTO - 30;
        if (destapando()) {
            centrado(ctx, Text.literal(bancaMostradas < 2 ? "La banca destapa su carta..." : "Turno de la banca...").formatted(Formatting.ITALIC),
                    cx, yb - 44, 0xFFB8D8C0);
        } else if (fase != Blackjack.JUGANDO) {
            centrado(ctx, Text.literal("Apuesta: " + apuesta).formatted(Formatting.BOLD), cx, yb + 6, 0xFFFFFFFF);
            if (fase == Blackjack.TERMINADA && !mensaje.isEmpty()) {
                int col = pago > apuestaMano ? 0xFF60E080 : pago == apuestaMano ? 0xFFF0E070 : 0xFFB0B0B0;
                centrado(ctx, Text.literal(mensaje), cx, yb - 44, col);
            } else if (jugador.isEmpty()) {
                centrado(ctx, Text.literal("Elige la apuesta y reparte").formatted(Formatting.ITALIC), cx, yb - 44, 0xFFB8D8C0);
            }
        }
    }

    private void centrado(DrawContext ctx, Text t, int cx, int y, int color) {
        ctx.drawText(textRenderer, t, cx - textRenderer.getWidth(t) / 2, y, color, true);
    }

    /** Las cartas centradas en cx, un poco solapadas si son muchas. */
    private void dibujarMano(DrawContext ctx, List<Integer> cartas, int cx, int y) {
        int n = cartas.size();
        if (n == 0) return;
        int paso = n <= 6 ? CARTA_W + 4 : Math.max(12, (ANCHO - 40 - CARTA_W) / (n - 1));
        int total = paso * (n - 1) + CARTA_W;
        int x = cx - total / 2;
        for (int i = 0; i < n; i++) dibujarCarta(ctx, cartas.get(i), x + i * paso, y);
    }

    private void dibujarCarta(DrawContext ctx, int c, int x, int y) {
        ctx.fill(x + 1, y + 1, x + CARTA_W + 1, y + CARTA_H + 1, 0x66000000);          // sombra
        if (c == Blackjack.OCULTA) {                                                    // reverso
            ctx.fill(x, y, x + CARTA_W, y + CARTA_H, 0xFFF0ECE2);
            ctx.fill(x + 2, y + 2, x + CARTA_W - 2, y + CARTA_H - 2, 0xFF9A1E2C);
            for (int i = 0; i < CARTA_H - 6; i += 4) ctx.fill(x + 4, y + 3 + i, x + CARTA_W - 4, y + 4 + i, 0x55F0ECE2);
            return;
        }
        ctx.fill(x, y, x + CARTA_W, y + CARTA_H, 0xFFF0ECE2);
        ctx.fill(x, y, x + CARTA_W, y + 1, 0xFFFFFFFF);
        int col = Blackjack.roja(c) ? 0xFFC82828 : 0xFF1E1E1E;
        String r = Blackjack.rango(c), p = Blackjack.palo(c);
        ctx.drawText(textRenderer, Text.literal(r), x + 3, y + 3, col, false);
        ctx.drawText(textRenderer, Text.literal(p), x + 3, y + 12, col, false);
        // palo grande en el centro
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + CARTA_W / 2f + 2, y + CARTA_H / 2f + 2, 0);
        ctx.getMatrices().scale(1.6f, 1.6f, 1f);
        ctx.drawText(textRenderer, Text.literal(p), -textRenderer.getWidth(p) / 2, -4, col, false);
        ctx.getMatrices().pop();
    }

    /** Por si se abre la pantalla desde fuera (no hace falta, pero así no queda nada a medias). */
    public static void abrir() {
        MinecraftClient.getInstance().setScreen(new BlackjackScreen());
    }
}

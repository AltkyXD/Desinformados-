package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Mob con skin de jugador 64x64 completa (Brandon, Kevin). Opcional: capa que brilla en la oscuridad. */
public class SkinRenderer<T extends MobEntity> extends BipedEntityRenderer<T, SkinModel<T>> {
    private final Identifier textura;

    public SkinRenderer(EntityRendererFactory.Context contexto, Identifier textura, Identifier brillo) {
        super(contexto, new SkinModel<>(contexto.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.textura = textura;
        if (brillo != null) {
            RenderLayer capa = RenderLayer.getEyes(brillo);
            addFeature(new EyesFeatureRenderer<T, SkinModel<T>>(this) {
                @Override
                public RenderLayer getEyesTexture() {
                    return capa;
                }
            });
        }
    }

    @Override
    public Identifier getTexture(T entidad) {
        return textura;
    }
}

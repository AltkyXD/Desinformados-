package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Notificación en la esquina de arriba a la derecha (con el marco de los logros): "¡Misión completada! Recibiste: 10 Rumores". */
public class NotificacionToast implements Toast {
    private static final Identifier FONDO = Identifier.ofVanilla("toast/advancement");
    private static final long DURACION = 5000L;
    private final Text titulo, texto;
    private final ItemStack icono;

    public NotificacionToast(String titulo, String texto, String icono) {
        this.titulo = Text.literal(titulo);
        this.texto = Text.literal(texto);
        Identifier id = Identifier.tryParse(icono);
        this.icono = id != null && Registries.ITEM.containsId(id) ? new ItemStack(Registries.ITEM.get(id)) : ItemStack.EMPTY;
    }

    @Override
    public Visibility draw(DrawContext ctx, ToastManager manager, long tiempo) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawGuiTexture(FONDO, 0, 0, getWidth(), getHeight());
        if (!icono.isEmpty()) ctx.drawItemWithoutEntity(icono, 8, 8);
        ctx.drawText(tr, titulo, 30, 7, 0xFFFFE04A, false);
        // si el texto no cabe en una línea, se corta con "..."
        String t = texto.getString();
        int max = getWidth() - 36;
        if (tr.getWidth(t) > max) t = tr.trimToWidth(t, max - tr.getWidth("...")) + "...";
        ctx.drawText(tr, t, 30, 18, 0xFFFFFFFF, false);
        return tiempo >= DURACION * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.papel.ModPapel;
import com.centrodesinformacion.desinformados.entidad.papel.TravensanoPapelEntity;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;

/** Renderers de los mobs de papel de la Libreta (parte 2). */
public final class PapelRenderers {
    private PapelRenderers() {}

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityRendererRegistry.register(ModPapel.TRAVENSANO_PAPEL, TravensanoPapelRenderer::new);
        EntityRendererRegistry.register(ModPapel.FANTASMA_PAPEL, ctx -> new PapelRenderer<>(ctx,
                Desinformados.id("textures/entity/dibujo/fantasma_papel.png"), 1.0f, 1.5f, false));
        EntityRendererRegistry.register(ModPapel.AVION_PAPEL, AvionPapelRenderer::new);
    }

    /** La hoja del Travensaño; sentado en un cuello, más pequeña (para no tapar). */
    static class TravensanoPapelRenderer extends PapelRenderer<TravensanoPapelEntity> {
        TravensanoPapelRenderer(EntityRendererFactory.Context ctx) {
            super(ctx, Desinformados.id("textures/entity/dibujo/travensano_papel.png"), 0.9f, 1.8f, false);
        }

        @Override
        public void render(TravensanoPapelEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
            if (!e.isSentado()) {
                super.render(e, yaw, delta, m, buffers, luz);
                return;
            }
            m.push();
            m.scale(0.55f, 0.55f, 0.55f);
            super.render(e, yaw, delta, m, buffers, luz);
            m.pop();
        }
    }
}

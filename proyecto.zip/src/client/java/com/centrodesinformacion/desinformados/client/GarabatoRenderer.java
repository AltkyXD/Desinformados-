package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.GarabatoEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Una hoja de papel plana (1 x 2 bloques) con el monigote dibujado. Se tambalea al caminar. */
public class GarabatoRenderer extends EntityRenderer<GarabatoEntity> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/garabato.png");

    public GarabatoRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
        this.shadowRadius = 0.3f;
    }

    @Override
    public void render(GarabatoEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        m.push();
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevBodyYaw, e.bodyYaw);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - cuerpo));
        float paso = e.limbAnimator.getPos(delta);
        float fuerza = Math.min(1f, e.limbAnimator.getSpeed(delta));
        float tiempo = e.age + delta;
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.sin(paso * 0.6f) * 9f * fuerza + MathHelper.sin(tiempo * 0.08f) * 2f));
        m.translate(0, Math.abs(MathHelper.sin(paso * 0.6f)) * 0.08f * fuerza, 0);
        if (e.deathTime > 0) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(Math.min(90f, (e.deathTime + delta) * 6f))); // cae como una hoja
        }

        int overlay = LivingEntityRenderer.getOverlay(e, 0f);
        VertexConsumer v = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURA));
        MatrixStack.Entry pose = m.peek();
        float a = 0.5f, alto = 2.0f;
        vertice(v, pose, -a, 0, 0, 1, 1, luz, overlay);
        vertice(v, pose, a, 0, 0, 0, 1, luz, overlay);
        vertice(v, pose, a, alto, 0, 0, 0, luz, overlay);
        vertice(v, pose, -a, alto, 0, 1, 0, luz, overlay);
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    private static void vertice(VertexConsumer v, MatrixStack.Entry pose, float x, float y, float z, float u, float tv, int luz, int overlay) {
        v.vertex(pose, x, y, z).color(255, 255, 255, 255).texture(u, tv).overlay(overlay).light(luz).normal(pose, 0, 0, 1);
    }

    @Override
    public Identifier getTexture(GarabatoEntity e) {
        return TEXTURA;
    }
}

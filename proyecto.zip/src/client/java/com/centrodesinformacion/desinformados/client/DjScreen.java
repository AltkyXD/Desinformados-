package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.DjPayload;
import com.centrodesinformacion.desinformados.network.DjPedidoPayload;
import com.centrodesinformacion.desinformados.tienda.Dj;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Menú de DJ Miaumix: pide una canción por 20 Rumores. */
public class DjScreen extends Screen {
    private static int entidad, dinero, sonando = -1, quedan;
    private static long recibido;
    private static final int ANCHO = 280, ALTO = 150;
    private final List<ButtonWidget> botones = new ArrayList<>();

    public DjScreen() {
        super(Text.literal("DJ Miaumix"));
    }

    public static void actualizar(DjPayload p) {
        entidad = p.entidad();
        dinero = p.dinero();
        sonando = p.sonando();
        quedan = p.quedan();
        recibido = System.currentTimeMillis();
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        botones.clear();
        int x = (width - ANCHO) / 2, y = (height - ALTO) / 2;
        for (int i = 0; i < Dj.NOMBRES.length; i++) {
            final int indice = i;
            ButtonWidget b = ButtonWidget.builder(Text.literal("Pedir"), w -> ClientPlayNetworking.send(new DjPedidoPayload(entidad, indice)))
                    .dimensions(x + ANCHO - 62, y + 48 + i * 26, 50, 20).build();
            botones.add(addDrawableChild(b));
        }
    }

    private int segundosRestantes() {
        return Math.max(0, quedan - (int) ((System.currentTimeMillis() - recibido) / 1000));
    }

    private boolean libre() {
        return sonando < 0 || segundosRestantes() <= 0;
    }

    /** Fondo: oscurece el juego y dibuja el panel (los botones van encima). */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        int x = (width - ANCHO) / 2, y = (height - ALTO) / 2;
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + ALTO + 2, 0xFF39FF5A);   // borde verde neón
        ctx.fill(x, y, x + ANCHO, y + ALTO, 0xF0121216);
        ctx.fill(x, y, x + ANCHO, y + 22, 0xFF1E1E26);
        for (int i = 0; i < Dj.NOMBRES.length; i++) {
            int fy = y + 48 + i * 26;
            boolean esta = !libre() && i == sonando;
            ctx.fill(x + 6, fy - 2, x + ANCHO - 6, fy + 22, esta ? 0x5539FF5A : 0x22FFFFFF);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        boolean libre = libre();
        for (ButtonWidget b : botones) b.active = libre;
        super.render(ctx, mx, my, delta);
        int x = (width - ANCHO) / 2, y = (height - ALTO) / 2;
        ctx.drawText(textRenderer, Text.literal("♪ DJ MIAUMIX ♪").formatted(Formatting.BOLD), x + 8, y + 7, 0xFF39FF5A, true);
        String plata = "Tus Rumores: " + dinero;
        ctx.drawText(textRenderer, plata, x + ANCHO - 8 - textRenderer.getWidth(plata), y + 7, 0xFFFFD84A, true);
        ctx.drawText(textRenderer, "Pide una canción (" + Dj.PRECIO + " Rumores cada una)", x + 8, y + 30, 0xFFAAAAAA, false);
        for (int i = 0; i < Dj.NOMBRES.length; i++) {
            int fy = y + 48 + i * 26;
            boolean esta = !libre && i == sonando;
            ctx.drawText(textRenderer, (esta ? "▶ " : "♫ ") + Dj.NOMBRES[i], x + 12, fy + 2, esta ? 0xFF39FF5A : 0xFFFFFFFF, true);
            int seg = Dj.DURACION[i] / 20;
            ctx.drawText(textRenderer, String.format("%d:%02d  ·  %d Rumores", seg / 60, seg % 60, Dj.PRECIO), x + 12, fy + 12, 0xFF9A9AA5, false);
        }
        if (!libre) {
            int s = segundosRestantes();
            String t = String.format("Sonando: %s (quedan %d:%02d)", Dj.NOMBRES[sonando], s / 60, s % 60);
            ctx.drawText(textRenderer, t, x + (ANCHO - textRenderer.getWidth(t)) / 2, y + ALTO - 14, 0xFFFF7FD0, true);
        }
    }
}

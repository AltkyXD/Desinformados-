package com.centrodesinformacion.desinformados.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;

/** Copia local de las misiones que manda el servidor. */
public class MisionesCliente {
    /** valor/meta = -1 si la misión no tiene barra de progreso (o ya está hecha). */
    public record Info(String titulo, String descripcion, String recompensa, boolean hecha, boolean grupo, boolean superada,
                       int hechos, int valor, int meta) {}

    public static final List<Info> PRINCIPALES = new ArrayList<>();
    public static final List<Info> SECUNDARIAS = new ArrayList<>();
    public static boolean fuera = false;
    public static int total = 0, necesarios = 0, ocultas = 0;

    public static void actualizar(String json) {
        try {
            JsonObject raiz = JsonParser.parseString(json).getAsJsonObject();
            fuera = raiz.has("fuera") && raiz.get("fuera").getAsBoolean();
            total = entero(raiz, "total", 0);
            necesarios = entero(raiz, "necesarios", 0);
            ocultas = entero(raiz, "ocultas", 0);
            PRINCIPALES.clear();
            SECUNDARIAS.clear();
            leer(raiz.getAsJsonArray("principales"), PRINCIPALES);
            leer(raiz.getAsJsonArray("secundarias"), SECUNDARIAS);
        } catch (Exception ignored) {
        }
    }

    private static int entero(JsonObject o, String k, int def) {
        return o.has(k) ? o.get(k).getAsInt() : def;
    }

    private static boolean bool(JsonObject o, String k) {
        return o.has(k) && o.get(k).getAsBoolean();
    }

    private static void leer(JsonArray arr, List<Info> lista) {
        if (arr == null) return;
        for (JsonElement el : arr) {
            JsonObject o = el.getAsJsonObject();
            lista.add(new Info(o.get("titulo").getAsString(), o.get("descripcion").getAsString(),
                    o.has("recompensa") ? o.get("recompensa").getAsString() : "", bool(o, "hecha"), bool(o, "grupo"), bool(o, "superada"),
                    entero(o, "hechos", 0), entero(o, "valor", -1), entero(o, "meta", -1)));
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;

/** Copia local de las misiones que manda el servidor. */
public class MisionesCliente {
    public record Info(String tipo, String titulo, String descripcion, boolean hecha, int grupo, int total) {}

    public static final List<Info> LISTA = new ArrayList<>();

    public static void actualizar(String json) {
        LISTA.clear();
        try {
            JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                LISTA.add(new Info(o.get("tipo").getAsString(), o.get("titulo").getAsString(), o.get("descripcion").getAsString(),
                        o.get("hecha").getAsBoolean(), o.get("grupo").getAsInt(), o.get("total").getAsInt()));
            }
        } catch (Exception ignored) {
        }
    }
}

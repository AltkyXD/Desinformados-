package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.JefePayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/** Barra de vida del jefe final (La Desinformación): en vez de un color, la barra está hecha de estática. */
public final class JefeHud {
    private static final Random R = new Random();
    private static boolean visible = false;
    private static int fase = 0;
    private static float progreso = 0, mostrado = 0;
    private static long ultima = 0;

    public static void recibir(JefePayload p) {
        visible = p.visible();
        fase = p.fase();
        progreso = p.progreso();
        ultima = System.currentTimeMillis();
        if (!visible) mostrado = 0;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (!visible || System.currentTimeMillis() - ultima > 3000) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        mostrado = MathHelper.lerp(0.15f, mostrado, progreso);                     // la barra baja suavecito
        int w = ctx.getScaledWindowWidth();
        int ancho = Math.min(260, w - 40), x = (w - ancho) / 2, y = 16, alto = 9;

        // título con glitch (desplazamientos rojo/cian de vez en cuando)
        String nombre = "LA DESINFORMACIÓN";
        int tx = w / 2 - mc.textRenderer.getWidth(nombre) / 2, ty = 4;
        if (R.nextFloat() < 0.15f) {
            ctx.drawText(mc.textRenderer, nombre, tx - 1, ty, 0xAAFF2A2A, false);
            ctx.drawText(mc.textRenderer, nombre, tx + 1, ty, 0xAA2AFFFF, false);
        }
        ctx.drawText(mc.textRenderer, Text.literal(nombre).formatted(Formatting.BOLD), tx, ty, 0xFFEFEFEF, true);
        String f = "FASE " + fase;
        ctx.drawText(mc.textRenderer, f, x + ancho - mc.textRenderer.getWidth(f), ty, 0xFF9A9A9A, true);

        // marco y fondo
        ctx.fill(x - 2, y - 2, x + ancho + 2, y + alto + 2, 0xFF000000);
        ctx.fill(x - 1, y - 1, x + ancho + 1, y + alto + 1, 0xFF6A6A6A);
        ctx.fill(x, y, x + ancho, y + alto, 0xFF141414);
        // relleno de estática
        int lleno = Math.round(ancho * MathHelper.clamp(mostrado, 0f, 1f));
        if (lleno > 0) {
            Ruido.dibujar(ctx, x, y, x + lleno, y + alto, 1f, 1);
            ctx.fill(x, y, x + lleno, y + 1, 0x66FFFFFF);                             // brillo arriba
            if (R.nextFloat() < 0.08f) ctx.fill(x, y + R.nextInt(alto), x + lleno, y + R.nextInt(alto) + 1, 0x88FFFFFF);   // rayita de interferencia
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Dibuja los corazones de alma en su propia fila, encima de la vida y la armadura. */
public class AlmasHud {
    private static final Identifier CONTENEDOR = Identifier.ofVanilla("hud/heart/container");
    private static final Identifier LLENO = Desinformados.id("hud/alma_full");
    private static final Identifier MEDIO = Desinformados.id("hud/alma_half");

    private static float puntos = 0;

    public static void actualizar(float nuevosPuntos) {
        puntos = nuevosPuntos;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (puntos <= 0 || p == null || mc.options.hudHidden
                || mc.interactionManager == null || !mc.interactionManager.hasStatusBars()) return;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        // Misma cuenta que usa Minecraft para colocar la vida y la armadura
        float vidaMax = Math.max((float) p.getAttributeValue(EntityAttributes.GENERIC_MAX_HEALTH), p.getHealth());
        int dorados = MathHelper.ceil(p.getAbsorptionAmount());
        int lineas = MathHelper.ceil((vidaMax + dorados) / 2f / 10f);
        int altoLinea = Math.max(10 - (lineas - 2), 3);
        int y = h - 39 - (lineas - 1) * altoLinea - 10;
        if (p.getArmor() > 0) y -= 10;
        int x0 = w / 2 - 91;

        int mitades = MathHelper.ceil(puntos);
        int corazones = MathHelper.ceil(mitades / 2f);
        for (int i = 0; i < corazones; i++) {
            int x = x0 + i * 8;
            ctx.drawGuiTexture(CONTENEDOR, x, y, 9, 9);
            boolean medio = (i * 2 + 1) == mitades;
            ctx.drawGuiTexture(medio ? MEDIO : LLENO, x, y, 9, 9);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

/** Mientras queden ticks, adelante/atrás e izquierda/derecha van al revés. */
public class ControlesInvertidos {
    private static int restante = 0;

    public static void iniciar(int ticks) { restante = ticks; }
    public static void tick() { if (restante > 0) restante--; }
    public static boolean activos() { return restante > 0; }
}

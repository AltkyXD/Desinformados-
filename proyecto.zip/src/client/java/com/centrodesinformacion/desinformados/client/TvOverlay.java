package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Animación de la tele: aparece con rebote, se enciende, estática,
 * flash y la pantalla se pone del color del evento. Dura ~8,5 segundos.
 */
public class TvOverlay {
    private static final int DURACION = 170;
    private static final int FIN_ENCENDIDO = 12;
    private static final int FIN_ESTATICA = 45;
    private static final int FIN_FLASH = 52;
    private static final Random RANDOM = new Random();

    // Rotura de la tele roja
    private static final int GRIETAS = DURACION - 45;   // empieza a agrietarse
    private static final int ROTURA = DURACION - 33;    // estalla en pedazos
    private record Fragmento(float x, float y, int w, int h, float vx, float vy, float rot, float vr, int color) {}
    private static final List<Fragmento> FRAGMENTOS = new ArrayList<>();
    private static final List<float[]> GRIETAS_LINEAS = new ArrayList<>(); // cada una: x1,y1,x2,y2,orden

    private static EventoTvPayload evento = null;
    private static int ticks = 0;

    public static void iniciar(EventoTvPayload paquete) {
        evento = paquete;
        ticks = 0;
        sonar(ModSounds.TV_ESTATICA);
        if (rompible()) prepararRotura();
    }

    private static boolean rompible() {
        return evento != null && "rojo".equals(evento.color());
    }

    private static void prepararRotura() {
        FRAGMENTOS.clear();
        GRIETAS_LINEAS.clear();
        // Grietas desde un punto de impacto en la pantalla
        float ix = -40 + RANDOM.nextFloat() * 60, iy = -25 + RANDOM.nextFloat() * 50;
        for (int r = 0; r < 7; r++) {
            float ang = (float) (r / 7.0 * Math.PI * 2 + RANDOM.nextFloat() * 0.6);
            float x = ix, y = iy;
            for (int seg = 0; seg < 5; seg++) {
                ang += (RANDOM.nextFloat() - 0.5f) * 0.9f;
                float largo = 8 + RANDOM.nextFloat() * 12;
                float nx = MathHelper.clamp(x + MathHelper.cos(ang) * largo, -84, 84);
                float ny = MathHelper.clamp(y + MathHelper.sin(ang) * largo, -60, 60);
                GRIETAS_LINEAS.add(new float[]{x, y, nx, ny, seg});
                x = nx; y = ny;
            }
        }
        // Pedazos: la tele se divide en trozos que salen volando desde el impacto
        int t = 12;
        for (int fx = -84; fx < 84; fx += t) {
            for (int fy = -60; fy < 60; fy += t) {
                float cxp = fx + t / 2f, cyp = fy + t / 2f;
                float dx = cxp - ix, dy = cyp - iy;
                float dist = Math.max(4f, MathHelper.sqrt(dx * dx + dy * dy));
                float fuerza = 2.5f + RANDOM.nextFloat() * 3f;
                float vx = dx / dist * fuerza + (RANDOM.nextFloat() - 0.5f) * 2f;
                float vy = dy / dist * fuerza - 2.5f - RANDOM.nextFloat() * 2.5f;
                int tam = t - 2 - RANDOM.nextInt(4);
                FRAGMENTOS.add(new Fragmento(cxp, cyp, tam, tam - RANDOM.nextInt(3), vx, vy,
                        RANDOM.nextFloat() * 360, (RANDOM.nextFloat() - 0.5f) * 40f, colorFragmento(cxp, cyp)));
            }
        }
    }

    private static int colorFragmento(float x, float y) {
        if (x > -68 && x < 44 && y > -44 && y < 44) {
            int c = colorDe("rojo");
            return RANDOM.nextInt(4) == 0 ? 0xFFFFFFFF : c;        // cristal con algún brillo
        }
        if (x > -72 && x < 48 && y > -48 && y < 48) return 0xFF1A1A1A; // marco
        if (x > 52 && y < 4) return 0xFF212121;                        // perillas
        return RANDOM.nextBoolean() ? 0xFF6D4C41 : 0xFF3E2723;         // madera
    }

    public static void tick() {
        if (evento == null) return;
        ticks++;
        if (ticks == FIN_ESTATICA) {
            sonar(switch (evento.color()) {
                case "verde" -> ModSounds.EVENTO_VERDE;
                case "rojo", "calavera" -> ModSounds.EVENTO_ROJO;
                default -> ModSounds.EVENTO_AMARILLO;
            });
        }
        if (rompible() && ticks == ROTURA) {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(net.minecraft.sound.SoundEvents.BLOCK_GLASS_BREAK, 0.8f, 1.2f));
        }
        if (ticks >= DURACION) evento = null;
    }

    private static void sonar(SoundEvent sonido) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sonido, 1.0f));
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (evento == null) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        // Oscurecer el fondo
        float opacidad = MathHelper.clamp(Math.min(t / 10f, (DURACION - t) / 15f), 0f, 1f);
        ctx.fill(0, 0, w, h, ((int) (opacidad * 150)) << 24);

        // Escala: entra con rebote, sale encogiéndose
        float escala;
        if (t < FIN_ENCENDIDO) escala = rebote(t / FIN_ENCENDIDO);
        else if (!rompible() && t > DURACION - 15) escala = MathHelper.clamp((DURACION - t) / 15f, 0f, 1f);
        else escala = 1f;
        if (escala < 0.02f) return;

        int cx = w / 2;
        int cy = h / 2 - 25;
        MatrixStack m = ctx.getMatrices();
        if (rompible() && t >= ROTURA) {
            dibujarFragmentos(ctx, m, cx, cy, t - ROTURA);
            return;
        }
        m.push();
        m.translate(cx, cy, 0);
        // Sacudida al aparecer: fuerte al principio y se va calmando
        if (t < FIN_ESTATICA) {
            float fuerza = 6f * (1f - t / FIN_ESTATICA);
            m.translate((RANDOM.nextFloat() * 2 - 1) * fuerza, (RANDOM.nextFloat() * 2 - 1) * fuerza, 0);
            m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees((RANDOM.nextFloat() * 2 - 1) * fuerza * 0.8f));
        }
        if ("rojo".equals(evento.color()) && t > FIN_FLASH && t < FIN_FLASH + 25) {
            m.translate(RANDOM.nextFloat() * 4 - 2, RANDOM.nextFloat() * 4 - 2, 0); // temblor en desafíos
        }
        if (rompible() && t >= GRIETAS) {
            float f = 1f + (t - GRIETAS) / 3f;
            m.translate((RANDOM.nextFloat() * 2 - 1) * f, (RANDOM.nextFloat() * 2 - 1) * f, 0);
        }
        m.scale(escala, escala, 1f);
        dibujarTele(ctx, tr, t);
        if (rompible() && t >= GRIETAS) dibujarGrietas(ctx, (t - GRIETAS) / (ROTURA - GRIETAS));
        m.pop();

        // Descripción debajo de la tele
        if (t > FIN_FLASH + 5 && t < (rompible() ? GRIETAS : DURACION - 15) && !evento.descripcion().isEmpty()) {
            List<OrderedText> lineas = tr.wrapLines(Text.literal(evento.descripcion()), Math.min(300, w - 40));
            int y = cy + 78;
            for (OrderedText linea : lineas) {
                ctx.drawCenteredTextWithShadow(tr, linea, cx, y, 0xFFFFFF);
                y += 11;
            }
        }
    }

    private static void dibujarTele(DrawContext ctx, TextRenderer tr, float t) {
        if (t >= FIN_FLASH) {
            int base = colorDe(evento.color()) & 0xFFFFFF;
            float pulso = 0.6f + 0.4f * MathHelper.sin(t * 0.25f);
            for (int i = 1; i <= 6; i++) {
                int alfa = (int) ((60 - i * 9) * pulso);
                int g = 84 + i * 3;
                ctx.fill(-g, -60 - i * 3, g, 60 + i * 3, (alfa << 24) | base);
            }
        }
        // Antenas
        for (int i = 0; i < 10; i++) {
            ctx.fill(-6 - i * 3, -64 - i * 3, -3 - i * 3, -61 - i * 3, 0xFF2B2B2B);
            ctx.fill(3 + i * 3, -64 - i * 3, 6 + i * 3, -61 - i * 3, 0xFF2B2B2B);
        }
        ctx.fill(-8, -64, 8, -58, 0xFF2B2B2B);
        // Patas
        ctx.fill(-62, 58, -50, 70, 0xFF3E2723);
        ctx.fill(50, 58, 62, 70, 0xFF3E2723);
        // Carcasa de madera
        ctx.fill(-84, -60, 84, 60, 0xFF3E2723);
        ctx.fill(-80, -56, 80, 56, 0xFF6D4C41);
        // Marco de la pantalla
        ctx.fill(-72, -48, 48, 48, 0xFF1A1A1A);
        // Perillas y altavoz
        ctx.fill(56, -40, 72, -24, 0xFF212121);
        ctx.fill(62, -38, 66, -30, 0xFFBDBDBD);
        ctx.fill(56, -16, 72, 0, 0xFF212121);
        ctx.fill(62, -14, 66, -6, 0xFFBDBDBD);
        for (int i = 0; i < 5; i++) ctx.fill(56, 10 + i * 7, 72, 13 + i * 7, 0xFF4E342E);

        int x1 = -68, y1 = -44, x2 = 44, y2 = 44;
        if (t < FIN_ENCENDIDO) {
            // Encendido: línea blanca en negro
            ctx.fill(x1, y1, x2, y2, 0xFF000000);
            int alto = (int) (1 + (t / FIN_ENCENDIDO) * 4);
            ctx.fill(x1, -alto, x2, alto, 0xFFFFFFFF);
        } else if (t < FIN_ESTATICA) {
            // Estática
            for (int x = x1; x < x2; x += 4) {
                for (int y = y1; y < y2; y += 4) {
                    int g = RANDOM.nextInt(256);
                    ctx.fill(x, y, Math.min(x + 4, x2), Math.min(y + 4, y2), 0xFF000000 | (g << 16) | (g << 8) | g);
                }
            }
        } else if (t < FIN_FLASH) {
            ctx.fill(x1, y1, x2, y2, 0xFFFFFFFF);
        } else {
            // Pantalla de color con el mensaje
            ctx.fill(x1, y1, x2, y2, colorDe(evento.color()));
            ctx.fill(x1 + 10, y1 + 8, x2 - 10, y2 - 8, 0x22FFFFFF);
            ctx.fill(x1 + 22, y1 + 18, x2 - 22, y2 - 18, 0x18FFFFFF);
            for (int y = y1; y < y2; y += 3) ctx.fill(x1, y, x2, y + 1, 0x22000000); // líneas de tele vieja
            boolean claro = "amarillo".equals(evento.color());
            int colorTexto = claro ? 0xFF1A1A1A : 0xFFFFFFFF;
            int centro = (x1 + x2) / 2;
            texto(ctx, tr, Text.literal(etiquetaDe(evento.color())).formatted(Formatting.BOLD).asOrderedText(),
                    centro, y1 + 8, colorTexto, !claro);
            if ("calavera".equals(evento.color())) {
                dibujarCalavera(ctx, centro, (y1 + y2) / 2 + 6, 5, t);
            } else {
                List<OrderedText> lineas = tr.wrapLines(Text.literal(evento.titulo()), x2 - x1 - 12);
                int y = (y1 + y2) / 2 - (lineas.size() * 10) / 2 + 4;
                for (OrderedText linea : lineas) {
                    texto(ctx, tr, linea, centro, y, colorTexto, !claro);
                    y += 10;
                }
            }
        }
        // Brillo del cristal
        ctx.fill(x1 + 4, y1 + 4, x1 + 20, y1 + 6, 0x33FFFFFF);
    }

    /** Grietas que crecen desde el punto de impacto (progreso 0 a 1). */
    private static void dibujarGrietas(DrawContext ctx, float progreso) {
        float hasta = progreso * 5f;
        for (float[] l : GRIETAS_LINEAS) {
            float orden = l[4];
            if (orden > hasta) continue;
            float parte = MathHelper.clamp(hasta - orden, 0f, 1f);
            float x2 = MathHelper.lerp(parte, l[0], l[2]), y2 = MathHelper.lerp(parte, l[1], l[3]);
            float largo = MathHelper.sqrt((x2 - l[0]) * (x2 - l[0]) + (y2 - l[1]) * (y2 - l[1]));
            int pasos = Math.max(1, (int) largo);
            for (int i = 0; i <= pasos; i++) {
                int x = (int) MathHelper.lerp(i / (float) pasos, l[0], x2);
                int y = (int) MathHelper.lerp(i / (float) pasos, l[1], y2);
                ctx.fill(x - 1, y - 1, x + 1, y + 1, 0xFF0A0A0A);
                ctx.fill(x + 1, y - 1, x + 2, y, 0x88FFFFFF);
            }
        }
    }

    /** Pedazos volando con gravedad y giro, desvaneciéndose. */
    private static void dibujarFragmentos(DrawContext ctx, MatrixStack m, int cx, int cy, float dt) {
        float gravedad = 0.45f;
        float alfaTotal = MathHelper.clamp(1f - (dt - 20f) / 13f, 0f, 1f);
        for (Fragmento f : FRAGMENTOS) {
            float x = f.x() + f.vx() * dt;
            float y = f.y() + f.vy() * dt + 0.5f * gravedad * dt * dt;
            int a = (int) (((f.color() >>> 24) & 0xFF) * alfaTotal);
            if (a <= 0) continue;
            m.push();
            m.translate(cx + x, cy + y, 0);
            m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(f.rot() + f.vr() * dt));
            ctx.fill(-f.w() / 2, -f.h() / 2, f.w() / 2, f.h() / 2, (a << 24) | (f.color() & 0xFFFFFF));
            m.pop();
        }
    }

    private static final String[] CALAVERA = {
            "..XXXXX..",
            ".XXXXXXX.",
            "XXXXXXXXX",
            "XX..X..XX",
            "XX..X..XX",
            "XXXX.XXXX",
            ".XXX.XXX.",
            "..XXXXX..",
            "..X.X.X..",
    };

    /** Calavera pixel art centrada en (cx, cy). Late como un corazón. */
    static void dibujarCalavera(DrawContext ctx, int cx, int cy, int px, float t) {
        float latido = 1f + 0.08f * Math.max(0f, MathHelper.sin(t * 0.4f));
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0);
        m.scale(latido, latido, 1f);
        int ox = -CALAVERA[0].length() * px / 2, oy = -CALAVERA.length * px / 2;
        for (int y = 0; y < CALAVERA.length; y++) {
            for (int x = 0; x < CALAVERA[y].length(); x++) {
                if (CALAVERA[y].charAt(x) == 'X') {
                    ctx.fill(ox + x * px, oy + y * px, ox + (x + 1) * px, oy + (y + 1) * px, 0xFFEDE6D6);
                }
            }
        }
        m.pop();
    }

    private static void texto(DrawContext ctx, TextRenderer tr, OrderedText txt, int cx, int y, int color, boolean sombra) {
        ctx.drawText(tr, txt, cx - tr.getWidth(txt) / 2, y, color, sombra);
    }

    private static int colorDe(String color) {
        return switch (color) {
            case "verde" -> 0xFF39FF5A;
            case "rojo" -> 0xFFFF2A2A;
            case "calavera" -> 0xFF7A0000;
            default -> 0xFFFFE333;
        };
    }

    private static String etiquetaDe(String color) {
        return switch (color) {
            case "verde" -> "¡BUENAS NOTICIAS!";
            case "rojo" -> "¡DESAFÍO!";
            case "calavera" -> "¡ÚLTIMA VIDA!";
            default -> "¡DIFICULTAD!";
        };
    }

    private static float rebote(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        return 1f + c3 * (float) Math.pow(x - 1, 3) + c1 * (float) Math.pow(x - 1, 2);
    }
}

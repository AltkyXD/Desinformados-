package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.List;
import java.util.Random;

/**
 * Animación de la tele: aparece con rebote, se enciende, estática,
 * flash y la pantalla se pone del color del evento. Dura ~8,5 segundos.
 */
public class TvOverlay {
    private static final int DURACION = 170;
    private static final int FIN_ENCENDIDO = 12;
    private static final int FIN_ESTATICA = 45;
    private static final int FIN_FLASH = 52;
    private static final Random RANDOM = new Random();

    private static EventoTvPayload evento = null;
    private static int ticks = 0;

    public static void iniciar(EventoTvPayload paquete) {
        evento = paquete;
        ticks = 0;
        sonar(ModSounds.TV_ESTATICA);
    }

    public static void tick() {
        if (evento == null) return;
        ticks++;
        if (ticks == FIN_ESTATICA) {
            sonar(switch (evento.color()) {
                case "verde" -> ModSounds.EVENTO_VERDE;
                case "rojo" -> ModSounds.EVENTO_ROJO;
                default -> ModSounds.EVENTO_AMARILLO;
            });
        }
        if (ticks >= DURACION) evento = null;
    }

    private static void sonar(SoundEvent sonido) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sonido, 1.0f));
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (evento == null) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        // Oscurecer el fondo
        float opacidad = MathHelper.clamp(Math.min(t / 10f, (DURACION - t) / 15f), 0f, 1f);
        ctx.fill(0, 0, w, h, ((int) (opacidad * 150)) << 24);

        // Escala: entra con rebote, sale encogiéndose
        float escala;
        if (t < FIN_ENCENDIDO) escala = rebote(t / FIN_ENCENDIDO);
        else if (t > DURACION - 15) escala = MathHelper.clamp((DURACION - t) / 15f, 0f, 1f);
        else escala = 1f;
        if (escala < 0.02f) return;

        int cx = w / 2;
        int cy = h / 2 - 25;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0);
        if ("rojo".equals(evento.color()) && t > FIN_FLASH && t < FIN_FLASH + 25) {
            m.translate(RANDOM.nextFloat() * 4 - 2, RANDOM.nextFloat() * 4 - 2, 0); // temblor en desafíos
        }
        m.scale(escala, escala, 1f);
        dibujarTele(ctx, tr, t);
        m.pop();

        // Descripción debajo de la tele
        if (t > FIN_FLASH + 5 && t < DURACION - 15 && !evento.descripcion().isEmpty()) {
            List<OrderedText> lineas = tr.wrapLines(Text.literal(evento.descripcion()), Math.min(300, w - 40));
            int y = cy + 78;
            for (OrderedText linea : lineas) {
                ctx.drawCenteredTextWithShadow(tr, linea, cx, y, 0xFFFFFF);
                y += 11;
            }
        }
    }

    private static void dibujarTele(DrawContext ctx, TextRenderer tr, float t) {
        // Antenas
        for (int i = 0; i < 10; i++) {
            ctx.fill(-6 - i * 3, -64 - i * 3, -3 - i * 3, -61 - i * 3, 0xFF2B2B2B);
            ctx.fill(3 + i * 3, -64 - i * 3, 6 + i * 3, -61 - i * 3, 0xFF2B2B2B);
        }
        ctx.fill(-8, -64, 8, -58, 0xFF2B2B2B);
        // Patas
        ctx.fill(-62, 58, -50, 70, 0xFF3E2723);
        ctx.fill(50, 58, 62, 70, 0xFF3E2723);
        // Carcasa de madera
        ctx.fill(-84, -60, 84, 60, 0xFF3E2723);
        ctx.fill(-80, -56, 80, 56, 0xFF6D4C41);
        // Marco de la pantalla
        ctx.fill(-72, -48, 48, 48, 0xFF1A1A1A);
        // Perillas y altavoz
        ctx.fill(56, -40, 72, -24, 0xFF212121);
        ctx.fill(62, -38, 66, -30, 0xFFBDBDBD);
        ctx.fill(56, -16, 72, 0, 0xFF212121);
        ctx.fill(62, -14, 66, -6, 0xFFBDBDBD);
        for (int i = 0; i < 5; i++) ctx.fill(56, 10 + i * 7, 72, 13 + i * 7, 0xFF4E342E);

        int x1 = -68, y1 = -44, x2 = 44, y2 = 44;
        if (t < FIN_ENCENDIDO) {
            // Encendido: línea blanca en negro
            ctx.fill(x1, y1, x2, y2, 0xFF000000);
            int alto = (int) (1 + (t / FIN_ENCENDIDO) * 4);
            ctx.fill(x1, -alto, x2, alto, 0xFFFFFFFF);
        } else if (t < FIN_ESTATICA) {
            // Estática
            for (int x = x1; x < x2; x += 4) {
                for (int y = y1; y < y2; y += 4) {
                    int g = RANDOM.nextInt(256);
                    ctx.fill(x, y, Math.min(x + 4, x2), Math.min(y + 4, y2), 0xFF000000 | (g << 16) | (g << 8) | g);
                }
            }
        } else if (t < FIN_FLASH) {
            ctx.fill(x1, y1, x2, y2, 0xFFFFFFFF);
        } else {
            // Pantalla de color con el mensaje
            ctx.fill(x1, y1, x2, y2, colorDe(evento.color()));
            for (int y = y1; y < y2; y += 3) ctx.fill(x1, y, x2, y + 1, 0x22000000); // líneas de tele vieja
            boolean claro = "amarillo".equals(evento.color());
            int colorTexto = claro ? 0xFF1A1A1A : 0xFFFFFFFF;
            int centro = (x1 + x2) / 2;
            texto(ctx, tr, Text.literal(etiquetaDe(evento.color())).formatted(Formatting.BOLD).asOrderedText(),
                    centro, y1 + 8, colorTexto, !claro);
            List<OrderedText> lineas = tr.wrapLines(Text.literal(evento.titulo()), x2 - x1 - 12);
            int y = (y1 + y2) / 2 - (lineas.size() * 10) / 2 + 4;
            for (OrderedText linea : lineas) {
                texto(ctx, tr, linea, centro, y, colorTexto, !claro);
                y += 10;
            }
        }
        // Brillo del cristal
        ctx.fill(x1 + 4, y1 + 4, x1 + 20, y1 + 6, 0x33FFFFFF);
    }

    private static void texto(DrawContext ctx, TextRenderer tr, OrderedText txt, int cx, int y, int color, boolean sombra) {
        ctx.drawText(tr, txt, cx - tr.getWidth(txt) / 2, y, color, sombra);
    }

    private static int colorDe(String color) {
        return switch (color) {
            case "verde" -> 0xFF43A047;
            case "rojo" -> 0xFFD32F2F;
            default -> 0xFFFBC02D;
        };
    }

    private static String etiquetaDe(String color) {
        return switch (color) {
            case "verde" -> "¡BUENAS NOTICIAS!";
            case "rojo" -> "¡DESAFÍO!";
            default -> "¡DIFICULTAD!";
        };
    }

    private static float rebote(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        return 1f + c3 * (float) Math.pow(x - 1, 3) + c1 * (float) Math.pow(x - 1, 2);
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Animación de la tele: aparece con rebote, se enciende, estática,
 * flash y la pantalla se pone del color del evento. Dura ~8,5 segundos.
 */
public class TvOverlay {
    /** ~8,6 s en total. Al terminar (tele ya fuera o hecha pedazos) llega el mensaje al chat. Igual que Eventos.RETRASO_TELE. */
    private static final int DURACION = 172;
    private static final int FIN_ENCENDIDO = 12;
    private static final int FIN_ESTATICA = 90;   // estática más larga: el color tarda más en salir
    private static final int FIN_FLASH = 97;
    private static final Random RANDOM = new Random();

    // Rotura de la tele roja
    private static final int GRIETAS = DURACION - 45;   // empieza a agrietarse
    private static final int ROTURA = DURACION - 33;    // estalla en pedazos
    private record Fragmento(float x, float y, int w, int h, float vx, float vy, float rot, float vr, int color) {}
    private static final List<Fragmento> FRAGMENTOS = new ArrayList<>();
    private static final List<float[]> GRIETAS_LINEAS = new ArrayList<>(); // cada una: x1,y1,x2,y2,orden

    private static EventoTvPayload evento = null;
    private static int ticks = 0;

    public static void iniciar(EventoTvPayload paquete) {
        evento = paquete;
        ticks = 0;
        sonar(ModSounds.TV_ESTATICA);
        if (rompible()) prepararRotura();
    }

    private static boolean rompible() {
        return evento != null && "rojo".equals(evento.color());
    }

    private static void prepararRotura() {
        FRAGMENTOS.clear();
        GRIETAS_LINEAS.clear();
        // Grietas desde un punto de impacto en la pantalla
        float ix = -40 + RANDOM.nextFloat() * 60, iy = -25 + RANDOM.nextFloat() * 50;
        for (int r = 0; r < 7; r++) {
            float ang = (float) (r / 7.0 * Math.PI * 2 + RANDOM.nextFloat() * 0.6);
            float x = ix, y = iy;
            for (int seg = 0; seg < 5; seg++) {
                ang += (RANDOM.nextFloat() - 0.5f) * 0.9f;
                float largo = 8 + RANDOM.nextFloat() * 12;
                float nx = MathHelper.clamp(x + MathHelper.cos(ang) * largo, -84, 84);
                float ny = MathHelper.clamp(y + MathHelper.sin(ang) * largo, -60, 60);
                GRIETAS_LINEAS.add(new float[]{x, y, nx, ny, seg});
                x = nx; y = ny;
            }
        }
        // Pedazos: la tele se divide en trozos que salen volando desde el impacto
        int t = 12;
        for (int fx = -84; fx < 84; fx += t) {
            for (int fy = -60; fy < 60; fy += t) {
                float cxp = fx + t / 2f, cyp = fy + t / 2f;
                float dx = cxp - ix, dy = cyp - iy;
                float dist = Math.max(4f, MathHelper.sqrt(dx * dx + dy * dy));
                float fuerza = 2.5f + RANDOM.nextFloat() * 3f;
                float vx = dx / dist * fuerza + (RANDOM.nextFloat() - 0.5f) * 2f;
                float vy = dy / dist * fuerza - 2.5f - RANDOM.nextFloat() * 2.5f;
                int tam = t - 2 - RANDOM.nextInt(4);
                FRAGMENTOS.add(new Fragmento(cxp, cyp, tam, tam - RANDOM.nextInt(3), vx, vy,
                        RANDOM.nextFloat() * 360, (RANDOM.nextFloat() - 0.5f) * 40f, colorFragmento(cxp, cyp)));
            }
        }
    }

    private static int colorFragmento(float x, float y) {
        if (x > -68 && x < 44 && y > -44 && y < 44) {
            int c = colorDe("rojo");
            return RANDOM.nextInt(4) == 0 ? 0xFFFFFFFF : c;        // cristal con algún brillo
        }
        if (x > -72 && x < 48 && y > -48 && y < 48) return 0xFF141414;  // goma
        if (x > -76 && x < 52 && y > -52 && y < 52) return RANDOM.nextBoolean() ? CROMO : CROMO_CLARO; // marco cromado
        if (x > 52 && y < 4) return RANDOM.nextBoolean() ? 0xFF3A3A3A : LATON;   // perillas y placa
        if (x > 52) return 0xFF2A1A10;                                            // altavoz
        return RANDOM.nextInt(3) == 0 ? MADERA_OSCURA : MADERA;                   // madera
    }

    public static void tick() {
        if (evento == null) return;
        ticks++;
        if (ticks == FIN_ESTATICA) {
            sonar(switch (evento.color()) {
                case "verde" -> ModSounds.EVENTO_VERDE;
                case "rojo", "calavera" -> ModSounds.EVENTO_ROJO;
                default -> ModSounds.EVENTO_AMARILLO;
            });
        }
        if (rompible() && ticks == ROTURA) {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(net.minecraft.sound.SoundEvents.BLOCK_GLASS_BREAK, 0.8f, 1.2f));
        }
        if (ticks >= DURACION) evento = null;
    }

    private static void sonar(SoundEvent sonido) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sonido, 1.0f));
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (evento == null) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();


        // Escala: entra con rebote, sale encogiéndose
        float escala;
        if (t < FIN_ENCENDIDO) escala = rebote(t / FIN_ENCENDIDO);
        else if (!rompible() && t > DURACION - 15) escala = MathHelper.clamp((DURACION - t) / 15f, 0f, 1f);
        else escala = 1f;
        if (escala < 0.02f) return;

        int cx = w / 2;
        int cy = h / 2 - 25;
        MatrixStack m = ctx.getMatrices();
        if (rompible() && t >= ROTURA) {
            dibujarFragmentos(ctx, m, cx, cy, t - ROTURA);
            return;
        }
        m.push();
        m.translate(cx, cy, 0);
        // Sacudida al aparecer: fuerte al principio y se va calmando
        if (t < FIN_ESTATICA) {
            float fuerza = 6f * (1f - t / FIN_ESTATICA);
            m.translate((RANDOM.nextFloat() * 2 - 1) * fuerza, (RANDOM.nextFloat() * 2 - 1) * fuerza, 0);
            m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees((RANDOM.nextFloat() * 2 - 1) * fuerza * 0.8f));
        }
        if ("rojo".equals(evento.color()) && t > FIN_FLASH && t < FIN_FLASH + 25) {
            m.translate(RANDOM.nextFloat() * 4 - 2, RANDOM.nextFloat() * 4 - 2, 0); // temblor en desafíos
        }
        if (rompible() && t >= GRIETAS) {
            float f = 1f + (t - GRIETAS) / 3f;
            m.translate((RANDOM.nextFloat() * 2 - 1) * f, (RANDOM.nextFloat() * 2 - 1) * f, 0);
        }
        m.scale(escala, escala, 1f);
        dibujarTele(ctx, tr, t);
        if (rompible() && t >= GRIETAS) dibujarGrietas(ctx, (t - GRIETAS) / (ROTURA - GRIETAS));
        m.pop();
    }

    private static void dibujarTele(DrawContext ctx, TextRenderer tr, float t) {
        if (t >= FIN_FLASH) {
            int base = colorDe(evento.color()) & 0xFFFFFF;
            float pulso = 0.6f + 0.4f * MathHelper.sin(t * 0.25f);
            for (int i = 1; i <= 6; i++) {
                int alfa = (int) ((60 - i * 9) * pulso);
                int g = 84 + i * 3;
                ctx.fill(-g, -60 - i * 3, g, 60 + i * 3, (alfa << 24) | base);
            }
        }
        dibujarCarcasa(ctx, tr, t);

        int x1 = -68, y1 = -44, x2 = 44, y2 = 44;
        if (t < FIN_ENCENDIDO) {
            // Encendido: línea blanca en negro
            ctx.fill(x1, y1, x2, y2, 0xFF000000);
            int alto = (int) (1 + (t / FIN_ENCENDIDO) * 4);
            ctx.fill(x1, -alto, x2, alto, 0xFFFFFFFF);
        } else if (t < FIN_ESTATICA) {
            // Estática
            for (int x = x1; x < x2; x += 4) {
                for (int y = y1; y < y2; y += 4) {
                    int g = RANDOM.nextInt(256);
                    ctx.fill(x, y, Math.min(x + 4, x2), Math.min(y + 4, y2), 0xFF000000 | (g << 16) | (g << 8) | g);
                }
            }
        } else if (t < FIN_FLASH) {
            ctx.fill(x1, y1, x2, y2, 0xFFFFFFFF);
        } else {
            // Pantalla de color con el mensaje
            ctx.fill(x1, y1, x2, y2, colorDe(evento.color()));
            ctx.fill(x1 + 10, y1 + 8, x2 - 10, y2 - 8, 0x22FFFFFF);
            ctx.fill(x1 + 22, y1 + 18, x2 - 22, y2 - 18, 0x18FFFFFF);
            for (int y = y1; y < y2; y += 3) ctx.fill(x1, y, x2, y + 1, 0x22000000); // líneas de tele vieja
            // La tele solo muestra el color; el texto va al chat (la calavera sí se dibuja)
            if ("calavera".equals(evento.color())) {
                dibujarCalavera(ctx, (x1 + x2) / 2, (y1 + y2) / 2, 5, t);
            }
        }
        dibujarCristalCRT(ctx, x1, y1, x2, y2);
    }

    // =====================================================================
    //                       TELE RETRO DETALLADA
    // =====================================================================

    private static final int MADERA_OSCURA = 0xFF3B2213;
    private static final int MADERA = 0xFF7B4A2A;
    private static final int MADERA_CLARA = 0xFF9A6236;
    private static final int CROMO = 0xFF9E9E9E;
    private static final int CROMO_CLARO = 0xFFE0E0E0;
    private static final int CROMO_OSCURO = 0xFF5A5A5A;
    private static final int GOMA = 0xFF141414;
    private static final int LATON = 0xFFC9A44C;

    /** Rectángulo con esquinas redondeadas (escalonadas, estilo pixel). */
    private static void redondeado(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        for (int k = 0; k < r; k++) {
            int entra = r - (int) Math.round(Math.sqrt(r * r - (r - k - 0.5) * (r - k - 0.5)));
            ctx.fill(x1 + entra, y1 + k, x2 - entra, y1 + k + 1, color);
            ctx.fill(x1 + entra, y2 - k - 1, x2 - entra, y2 - k, color);
        }
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
    }

    private static void circulo(DrawContext ctx, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.round(Math.sqrt(r * r - dy * dy));
            ctx.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    private static void linea(DrawContext ctx, float x1, float y1, float x2, float y2, int grosor, int color) {
        int pasos = (int) Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        for (int i = 0; i <= pasos; i++) {
            int x = (int) MathHelper.lerp(i / (float) Math.max(1, pasos), x1, x2);
            int y = (int) MathHelper.lerp(i / (float) Math.max(1, pasos), y1, y2);
            ctx.fill(x, y, x + grosor, y + grosor, color);
        }
    }

    private static void dibujarCarcasa(DrawContext ctx, TextRenderer tr, float t) {
        // --- Antenas de conejo ---
        float vaiven = MathHelper.sin(t * 0.15f) * 1.5f;
        linea(ctx, -5, -64, -40 + vaiven, -106, 3, CROMO_OSCURO);
        linea(ctx, -5, -65, -40 + vaiven, -107, 1, CROMO_CLARO);
        linea(ctx, 3, -64, 36 - vaiven, -110, 3, CROMO_OSCURO);
        linea(ctx, 3, -65, 36 - vaiven, -111, 1, CROMO_CLARO);
        circulo(ctx, (int) (-40 + vaiven), -107, 3, CROMO);
        ctx.fill((int) (-41 + vaiven), -109, (int) (-39 + vaiven), -108, CROMO_CLARO);
        circulo(ctx, (int) (37 - vaiven), -111, 3, CROMO);
        ctx.fill((int) (36 - vaiven), -113, (int) (38 - vaiven), -112, CROMO_CLARO);
        // base de la antena (cúpula)
        redondeado(ctx, -14, -70, 14, -58, 5, 0xFF2A2A2A);
        ctx.fill(-10, -68, 6, -67, 0x55FFFFFF);

        // --- Patas inclinadas con remate de latón ---
        for (int lado = -1; lado <= 1; lado += 2) {
            for (int k = 0; k < 14; k++) {
                int x = lado * (58 + k / 2);
                ctx.fill(x - 4, 58 + k, x + 4, 59 + k, k < 2 ? MADERA_OSCURA : 0xFF2E1A0E);
            }
            ctx.fill(lado * 65 - 5, 72, lado * 65 + 5, 75, LATON);
        }

        // --- Mueble de madera ---
        redondeado(ctx, -86, -62, 86, 62, 10, 0xFF1E1008);       // contorno
        redondeado(ctx, -84, -60, 84, 60, 9, MADERA_OSCURA);
        redondeado(ctx, -81, -57, 81, 57, 7, MADERA);
        // vetas de la madera (fijas, no parpadean)
        for (int y = -54; y < 55; y += 3) {
            int desfase = (int) (Math.sin(y * 0.7) * 12);
            for (int x = -78 + Math.abs(desfase % 9); x < 78; x += 23 + (y & 7)) {
                int largo = 8 + ((x * 31 + y * 17) & 7);
                ctx.fill(x, y, Math.min(x + largo, 78), y + 1, (y & 4) == 0 ? 0x26000000 : 0x14FFFFFF);
            }
        }
        // bisel: luz arriba, sombra abajo
        ctx.fill(-76, -57, 76, -56, 0x40FFFFFF);
        ctx.fill(-76, 56, 76, 57, 0x50000000);

        // --- Marco cromado de la pantalla ---
        redondeado(ctx, -75, -51, 51, 51, 8, CROMO_OSCURO);
        redondeado(ctx, -74, -50, 50, 50, 8, CROMO);
        ctx.fill(-68, -50, 44, -49, CROMO_CLARO);                  // brillo superior
        ctx.fill(-74, -42, -73, 42, CROMO_CLARO);                  // brillo izquierdo
        redondeado(ctx, -71, -47, 47, 47, 7, GOMA);                // junta de goma

        // --- Panel de control ---
        redondeado(ctx, 53, -51, 79, 51, 4, 0xFF2E1A0E);
        redondeado(ctx, 54, -50, 78, 50, 4, 0xFF4A2B17);
        // placa de marca
        ctx.fill(55, -48, 77, -40, 0xFF7A6230);
        ctx.fill(55, -48, 77, -47, 0xFFE8C870);
        ctx.fill(56, -47, 76, -41, LATON);
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(66, -45.5f, 0);
        m.scale(0.42f, 0.42f, 1f);
        Text marca = Text.literal("DESINFO").formatted(Formatting.BOLD);
        ctx.drawText(tr, marca, -tr.getWidth(marca) / 2, -4, 0xFF3B2213, false);
        m.pop();
        // perillas con marcas alrededor
        dibujarPerilla(ctx, 66, -27, t * 2f);
        dibujarPerilla(ctx, 66, -8, -t * 0.7f + 40f);
        // piloto de encendido
        circulo(ctx, 59, 3, 1, 0xFFFF3030);
        ctx.fill(57, 1, 62, 6, 0x33FF0000);
        // rejilla del altavoz
        redondeado(ctx, 55, 8, 77, 48, 3, 0xFF1C110A);
        for (int y = 10; y < 46; y += 3) {
            ctx.fill(57, y, 75, y + 1, 0xFF6B4527);
            ctx.fill(57, y + 1, 75, y + 2, 0xFF2A1A10);
        }
    }

    private static void dibujarPerilla(DrawContext ctx, int cx, int cy, float angulo) {
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(-225 + i * 270 / 7.0);
            int px = cx + (int) Math.round(Math.cos(a) * 10), py = cy + (int) Math.round(Math.sin(a) * 10);
            ctx.fill(px, py, px + 1, py + 1, 0xFFE0C080);
        }
        circulo(ctx, cx, cy + 1, 7, 0xFF0A0A0A);                   // sombra
        circulo(ctx, cx, cy, 7, 0xFF1C1C1C);
        circulo(ctx, cx, cy, 6, 0xFF3A3A3A);
        circulo(ctx, cx - 1, cy - 1, 3, 0xFF555555);               // brillo
        double a = Math.toRadians(angulo);
        linea(ctx, cx, cy, cx + (float) Math.cos(a) * 5, cy + (float) Math.sin(a) * 5, 1, 0xFFE8E8E8);
    }

    /** Efecto de tubo CRT: líneas de barrido, bordes oscuros, esquinas curvas y reflejo. */
    private static void dibujarCristalCRT(DrawContext ctx, int x1, int y1, int x2, int y2) {
        for (int y = y1; y < y2; y += 2) ctx.fill(x1, y, x2, y + 1, 0x1A000000);
        for (int i = 0; i < 7; i++) {
            int a = (7 - i) * 9;
            int c = a << 24;
            ctx.fill(x1 + i, y1 + i, x2 - i, y1 + i + 1, c);
            ctx.fill(x1 + i, y2 - i - 1, x2 - i, y2 - i, c);
            ctx.fill(x1 + i, y1 + i + 1, x1 + i + 1, y2 - i - 1, c);
            ctx.fill(x2 - i - 1, y1 + i + 1, x2 - i, y2 - i - 1, c);
        }
        // esquinas redondeadas del tubo
        int r = 7;
        for (int k = 0; k < r; k++) {
            int entra = r - (int) Math.round(Math.sqrt(r * r - (r - k - 0.5) * (r - k - 0.5)));
            ctx.fill(x1, y1 + k, x1 + entra, y1 + k + 1, GOMA);
            ctx.fill(x2 - entra, y1 + k, x2, y1 + k + 1, GOMA);
            ctx.fill(x1, y2 - k - 1, x1 + entra, y2 - k, GOMA);
            ctx.fill(x2 - entra, y2 - k - 1, x2, y2 - k, GOMA);
        }
        // reflejo curvo del cristal
        for (int k = 0; k < 18; k++) {
            ctx.fill(x1 + 6 + k, y1 + 5, x1 + 8 + k, y1 + 7, (0x30 - k) << 24 | 0xFFFFFF);
        }
        for (int k = 0; k < 10; k++) {
            ctx.fill(x1 + 5, y1 + 7 + k, x1 + 7, y1 + 9 + k, (0x28 - k * 2) << 24 | 0xFFFFFF);
        }
        ctx.fill(x2 - 22, y2 - 8, x2 - 10, y2 - 7, 0x18FFFFFF);
    }

    /** Grietas que crecen desde el punto de impacto (progreso 0 a 1). */
    private static void dibujarGrietas(DrawContext ctx, float progreso) {
        float hasta = progreso * 5f;
        for (float[] l : GRIETAS_LINEAS) {
            float orden = l[4];
            if (orden > hasta) continue;
            float parte = MathHelper.clamp(hasta - orden, 0f, 1f);
            float x2 = MathHelper.lerp(parte, l[0], l[2]), y2 = MathHelper.lerp(parte, l[1], l[3]);
            float largo = MathHelper.sqrt((x2 - l[0]) * (x2 - l[0]) + (y2 - l[1]) * (y2 - l[1]));
            int pasos = Math.max(1, (int) largo);
            for (int i = 0; i <= pasos; i++) {
                int x = (int) MathHelper.lerp(i / (float) pasos, l[0], x2);
                int y = (int) MathHelper.lerp(i / (float) pasos, l[1], y2);
                ctx.fill(x - 1, y - 1, x + 1, y + 1, 0xFF0A0A0A);
                ctx.fill(x + 1, y - 1, x + 2, y, 0x88FFFFFF);
            }
        }
    }

    /** Pedazos volando con gravedad y giro, desvaneciéndose. */
    private static void dibujarFragmentos(DrawContext ctx, MatrixStack m, int cx, int cy, float dt) {
        float gravedad = 0.45f;
        float alfaTotal = MathHelper.clamp(1f - (dt - 20f) / 13f, 0f, 1f);
        for (Fragmento f : FRAGMENTOS) {
            float x = f.x() + f.vx() * dt;
            float y = f.y() + f.vy() * dt + 0.5f * gravedad * dt * dt;
            int a = (int) (((f.color() >>> 24) & 0xFF) * alfaTotal);
            if (a <= 0) continue;
            m.push();
            m.translate(cx + x, cy + y, 0);
            m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(f.rot() + f.vr() * dt));
            ctx.fill(-f.w() / 2, -f.h() / 2, f.w() / 2, f.h() / 2, (a << 24) | (f.color() & 0xFFFFFF));
            m.pop();
        }
    }

    private static final String[] CALAVERA = {
            "..XXXXX..",
            ".XXXXXXX.",
            "XXXXXXXXX",
            "XX..X..XX",
            "XX..X..XX",
            "XXXX.XXXX",
            ".XXX.XXX.",
            "..XXXXX..",
            "..X.X.X..",
    };

    /** Calavera pixel art centrada en (cx, cy). Late como un corazón. */
    static void dibujarCalavera(DrawContext ctx, int cx, int cy, int px, float t) {
        float latido = 1f + 0.08f * Math.max(0f, MathHelper.sin(t * 0.4f));
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0);
        m.scale(latido, latido, 1f);
        int ox = -CALAVERA[0].length() * px / 2, oy = -CALAVERA.length * px / 2;
        for (int y = 0; y < CALAVERA.length; y++) {
            for (int x = 0; x < CALAVERA[y].length(); x++) {
                if (CALAVERA[y].charAt(x) == 'X') {
                    ctx.fill(ox + x * px, oy + y * px, ox + (x + 1) * px, oy + (y + 1) * px, 0xFFEDE6D6);
                }
            }
        }
        m.pop();
    }

    private static void texto(DrawContext ctx, TextRenderer tr, OrderedText txt, int cx, int y, int color, boolean sombra) {
        ctx.drawText(tr, txt, cx - tr.getWidth(txt) / 2, y, color, sombra);
    }

    private static int colorDe(String color) {
        return switch (color) {
            case "verde" -> 0xFF39FF5A;
            case "rojo" -> 0xFFFF2A2A;
            case "calavera" -> 0xFF7A0000;
            default -> 0xFFFFE333;
        };
    }

    private static String etiquetaDe(String color) {
        return switch (color) {
            case "verde" -> "¡BUENAS NOTICIAS!";
            case "rojo" -> "¡DESAFÍO!";
            case "calavera" -> "¡ÚLTIMA VIDA!";
            default -> "¡DIFICULTAD!";
        };
    }

    private static float rebote(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        return 1f + c3 * (float) Math.pow(x - 1, 3) + c1 * (float) Math.pow(x - 1, 2);
    }
}

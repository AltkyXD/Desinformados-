package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.GarabatoEntity;
import com.centrodesinformacion.desinformados.entidad.ModVariantes2;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Renderers de las variantes de los mobs del mod (parte 1 de 2): el renderer del original con otra textura (y escala en los grandes). */
public final class VarianteRenderers2 {
    private VarianteRenderers2() {}

    static Identifier tex(String id) { return Desinformados.id("textures/entity/" + id + ".png"); }

    // Texturas creadas una vez (getTexture se llama en cada fotograma por cada mob)
    private static final Identifier CREEPER_BULO = tex("creeper_bulo");
    private static final Identifier FURRO_GIGANTE = tex("furro_gigante");
    private static final Identifier CUBO_NEGRO = tex("cubo_negro");
    private static final Identifier ZOMBIE_LIMON = tex("zombie_limon");
    private static final Identifier GARABATO_ELASTICO = tex("garabato_elastico");
    private static final Identifier RUIDO_BLANCO = tex("ruido_blanco");
    private static final Identifier TRAVENSANO_PESADO = tex("travensano_pesado");
    private static final Identifier CUBO_PURPURA = tex("cubo_purpura");

    /** Como el Creeper Oscuro (también se oculta con "creeper_invisible"). */
    public static class CreeperBulo extends CreeperOscuroRenderer {
        public CreeperBulo(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(CreeperEntity e) { return CREEPER_BULO; }
    }

    /** x1,5 (la caja de la entidad también es x1,5: 0,9 x 2,925). */
    public static class FurroGigante extends FurroRenderer {
        public FurroGigante(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return FURRO_GIGANTE; }
        @Override protected void scale(ZombieEntity e, MatrixStack matrices, float amount) {
            matrices.scale(1.5f, 1.5f, 1.5f);
        }
    }

    public static class CuboNegro extends CuboBlancoRenderer {
        public CuboNegro(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SlimeEntity e) { return CUBO_NEGRO; }
    }

    public static class ZombieLimon extends ZombieNaranjaRenderer {
        public ZombieLimon(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(ZombieEntity e) { return ZOMBIE_LIMON; }
    }

    /** La hoja de papel del Garabato (GarabatoRenderer dibuja con getTexture). */
    public static class GarabatoElastico extends GarabatoRenderer {
        public GarabatoElastico(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(GarabatoEntity e) { return GARABATO_ELASTICO; }
    }

    /** Como el Cubo Rojo (EstaticaRenderers.CuboRojo). */
    public static class CuboPurpura extends EstaticaRenderers.CuboRojo {
        public CuboPurpura(EntityRendererFactory.Context c) { super(c); }
        @Override public Identifier getTexture(SlimeEntity e) { return CUBO_PURPURA; }
    }

    /** Lo llama DesinformadosClient.onInitializeClient. */
    public static void registrar() {
        EntityRendererRegistry.register(ModVariantes2.CREEPER_BULO, (EntityRendererFactory) CreeperBulo::new);
        EntityRendererRegistry.register(ModVariantes2.FURRO_GIGANTE, (EntityRendererFactory) FurroGigante::new);
        EntityRendererRegistry.register(ModVariantes2.CUBO_NEGRO, (EntityRendererFactory) CuboNegro::new);
        EntityRendererRegistry.register(ModVariantes2.ZOMBIE_LIMON, (EntityRendererFactory) ZombieLimon::new);
        EntityRendererRegistry.register(ModVariantes2.GARABATO_ELASTICO, (EntityRendererFactory) GarabatoElastico::new);
        EntityRendererRegistry.register(ModVariantes2.RUIDO_BLANCO, ctx -> new HumanoideRenderer<>(ctx, RUIDO_BLANCO));
        EntityRendererRegistry.register(ModVariantes2.TRAVENSANO_PESADO, ctx -> new HumanoideRenderer<>(ctx, TRAVENSANO_PESADO));
        EntityRendererRegistry.register(ModVariantes2.CUBO_PURPURA, (EntityRendererFactory) CuboPurpura::new);
    }
}

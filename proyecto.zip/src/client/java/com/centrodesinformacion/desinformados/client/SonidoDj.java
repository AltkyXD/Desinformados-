package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/**
 * Música del DJ: suena en la posición del DJ, pero solo se oye mientras el jugador esté en el mismo piso.
 * Si sube o baja de piso el volumen se va a 0 (en medio segundo) y la canción sigue avanzando en silencio;
 * al volver se oye otra vez justo por donde va.
 */
public class SonidoDj extends MovingSoundInstance {
    private static final float PASO = 0.1f;   // 10 ticks para entrar/salir del todo
    private final float maximo;
    private final double minY, maxY;
    private final ClientWorld mundo;
    private float nivel;
    /** Ticks que ya llevaba sonando cuando llegó (0 = desde el principio). */
    private final int desde;

    public SonidoDj(SoundEvent sonido, double x, double y, double z, float volumen, double minY, double maxY) {
        this(sonido, x, y, z, volumen, minY, maxY, 0);
    }

    public SonidoDj(SoundEvent sonido, double x, double y, double z, float volumen, double minY, double maxY, int desde) {
        super(sonido, SoundCategory.RECORDS, SoundInstance.createRandom());
        this.x = x;
        this.y = y;
        this.z = z;
        this.maximo = volumen;
        this.minY = minY;
        this.maxY = maxY;
        this.desde = Math.max(0, desde);
        this.pitch = 1f;
        this.repeat = false;
        this.relative = false;
        this.attenuationType = AttenuationType.LINEAR;
        this.mundo = MinecraftClient.getInstance().world;
        this.nivel = enSuPiso() ? 1f : 0f;
        this.volume = maximo * nivel;
    }

    private boolean enSuPiso() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        return p != null && p.getY() >= minY && p.getY() < maxY;
    }

    /**
     * Si llega a mitad de la canción, se salta lo que ya ha sonado: se lee el ogg y se descarta hasta ese segundo
     * (los sonidos del DJ son "stream" en sounds.json, que es lo que hace falta para esto).
     */
    @Override
    public java.util.concurrent.CompletableFuture<net.minecraft.client.sound.AudioStream> getAudioStream(
            net.minecraft.client.sound.SoundLoader loader, net.minecraft.util.Identifier id, boolean repeatInstantly) {
        var futuro = loader.loadStreamed(id, repeatInstantly);
        if (desde <= 0) return futuro;
        return futuro.thenApply(stream -> {
            try {
                javax.sound.sampled.AudioFormat f = stream.getFormat();
                int marco = Math.max(1, f.getFrameSize());
                long saltar = (long) (desde / 20.0 * f.getSampleRate()) * marco;
                while (saltar > 0) {
                    java.nio.ByteBuffer b = stream.read((int) Math.min(saltar, 65536));
                    if (b == null || !b.hasRemaining()) break;
                    saltar -= b.remaining();
                }
            } catch (java.io.IOException e) {
                // si falla, suena desde el principio
            }
            return stream;
        });
    }

    /** Aunque empiece en silencio (estás en otro piso) tiene que arrancar, para que al llegar ya esté sonando. */
    @Override
    public boolean shouldAlwaysPlay() {
        return true;
    }

    @Override
    public void tick() {
        if (MinecraftClient.getInstance().world != mundo) {   // cambió de dimensión o salió del mundo
            setDone();
            return;
        }
        float meta = enSuPiso() ? 1f : 0f;
        if (nivel < meta) nivel = Math.min(meta, nivel + PASO);
        else if (nivel > meta) nivel = Math.max(meta, nivel - PASO);
        volume = maximo * nivel;
    }
}

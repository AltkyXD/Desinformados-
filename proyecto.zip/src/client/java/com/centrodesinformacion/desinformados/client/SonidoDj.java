package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/**
 * Música del DJ: suena en la posición del DJ, pero solo se oye mientras el jugador esté en el mismo piso.
 * Si sube o baja de piso el volumen se va a 0 (en medio segundo) y la canción sigue avanzando en silencio;
 * al volver se oye otra vez justo por donde va.
 */
public class SonidoDj extends MovingSoundInstance {
    private static final float PASO = 0.1f;   // 10 ticks para entrar/salir del todo
    private final float maximo;
    private final double minY, maxY;
    private final ClientWorld mundo;
    private float nivel;

    public SonidoDj(SoundEvent sonido, double x, double y, double z, float volumen, double minY, double maxY) {
        super(sonido, SoundCategory.RECORDS, SoundInstance.createRandom());
        this.x = x;
        this.y = y;
        this.z = z;
        this.maximo = volumen;
        this.minY = minY;
        this.maxY = maxY;
        this.pitch = 1f;
        this.repeat = false;
        this.relative = false;
        this.attenuationType = AttenuationType.LINEAR;
        this.mundo = MinecraftClient.getInstance().world;
        this.nivel = enSuPiso() ? 1f : 0f;
        this.volume = maximo * nivel;
    }

    private boolean enSuPiso() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        return p != null && p.getY() >= minY && p.getY() < maxY;
    }

    /** Aunque empiece en silencio (estás en otro piso) tiene que arrancar, para que al llegar ya esté sonando. */
    @Override
    public boolean shouldAlwaysPlay() {
        return true;
    }

    @Override
    public void tick() {
        if (MinecraftClient.getInstance().world != mundo) {   // cambió de dimensión o salió del mundo
            setDone();
            return;
        }
        float meta = enSuPiso() ? 1f : 0f;
        if (nivel < meta) nivel = Math.min(meta, nivel + PASO);
        else if (nivel > meta) nivel = Math.max(meta, nivel - PASO);
        volume = maximo * nivel;
    }
}

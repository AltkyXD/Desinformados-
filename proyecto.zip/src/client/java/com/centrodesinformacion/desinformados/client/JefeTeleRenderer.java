package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModBloques;
import com.centrodesinformacion.desinformados.dimension.TelePortalBlock;
import com.centrodesinformacion.desinformados.entidad.JefeTeleEntity;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Desinformación (jefe final): la misma tele de 5x5 del mundo (con su estática animada), tentáculos de estática
 * que la levantan, ojos realistas en la pantalla y parpadeos de "apagado".
 * Espacio del modelo: la pantalla mira a +Z; la tele va de x -2.5..2.5, z -0.5..0.5.
 */
public class JefeTeleRenderer extends EntityRenderer<JefeTeleEntity> {
    private static final Identifier BLANCO = Desinformados.id("textures/entity/blanco.png");
    private static final Identifier OJO = Desinformados.id("textures/entity/jefe_ojo.png");
    private static final int LUZ_MAX = 0xF000F0;

    public JefeTeleRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 2.5f;
    }

    @Override
    public Identifier getTexture(JefeTeleEntity e) {
        return BLANCO;
    }

    private static float suave(float x) {
        x = MathHelper.clamp(x, 0f, 1f);
        return x * x * (3 - 2 * x);
    }

    /** Número pseudoaleatorio estable 0..1 (para la estática y los parpadeos). */
    private static float azar(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65535f;
    }

    @Override
    public void render(JefeTeleEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        float t = e.age + delta;
        int fase = e.getFase(), trans = e.getTransicion();
        float total = fase == 1 ? JefeTeleEntity.TRANSICION_1 : JefeTeleEntity.TRANSICION_2;
        float prog = trans > 0 ? MathHelper.clamp(1f - (trans - delta) / total, 0f, 1f) : 1f;

        // --- cuánto la levantan los tentáculos
        float alto;
        if (fase == 0) alto = 0f;
        else if (fase == 1) alto = trans > 0 ? 2f * suave((prog - 0.35f) / 0.65f) : 2f;
        else alto = trans > 0 ? 2f + 2f * suave((prog - 0.3f) / 0.7f) : 4f;
        if (fase > 0 && trans == 0) alto += MathHelper.sin(t * 0.08f) * 0.15f;           // flota un poco
        boolean glitch = fase == 2 && trans > 0 && prog < 0.8f;

        m.push();
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevBodyYaw, e.bodyYaw);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-cuerpo));
        if (e.deathTime > 0) {                                                           // al morir: se encoge con glitch
            float d = (e.deathTime + delta) / 20f;
            m.translate((azar(e.age, 1) - 0.5f) * 0.4f * d, 0, (azar(e.age, 2) - 0.5f) * 0.4f * d);
            m.scale(1f + d * 0.2f, Math.max(0.02f, 1f - d), 1f + d * 0.2f);
        }
        if (glitch && azar((int) (t / 2), 7) < 0.35f)                                    // tirones de glitch
            m.translate((azar((int) t, 3) - 0.5f) * 0.6f, 0, (azar((int) t, 4) - 0.5f) * 0.3f);
        int overlay = LivingEntityRenderer.getOverlay(e, 0f);

        // --- tentáculos de estática
        int cuantos = fase == 0 ? 0 : fase == 1 ? 4 : 8;
        if (fase == 2 && trans > 0 && prog < 0.45f) cuantos = 4;                         // los viejos se glitchean antes de que salgan los nuevos
        float crece = fase == 1 && trans > 0 ? suave(prog / 0.4f) : 1f;
        float creceNuevos = fase == 2 && trans > 0 ? suave((prog - 0.45f) / 0.35f) : 1f;
        VertexConsumer b = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        for (int i = 0; i < cuantos; i++) tentaculo(b, m, i, cuantos, alto, t, i >= 4 ? crece * creceNuevos : crece, glitch, overlay);

        // --- la tele de 5x5 (los mismos bloques que la del mundo, con su estática animada)
        m.push();
        m.translate(-2.5f, alto, -0.5f);
        BlockState base = ModBloques.TELE_PORTAL.getDefaultState().with(TelePortalBlock.FACING, Direction.SOUTH).with(TelePortalBlock.ROTA, false);
        int luzTele = LightmapTextureManager.pack(Math.max(10, LightmapTextureManager.getBlockLightCoordinates(luz)), LightmapTextureManager.getSkyLightCoordinates(luz));
        var bloques = MinecraftClient.getInstance().getBlockRenderManager();
        for (int px = 0; px < 5; px++) for (int py = 0; py < 5; py++) {
            m.push();
            m.translate(px, py, 0);
            bloques.renderBlockAsEntity(base.with(TelePortalBlock.PX, px).with(TelePortalBlock.PY, py), m, buffers, luzTele, overlay);
            m.pop();
        }
        m.pop();

        // cristal de la pantalla (dentro del marco plateado), delante en z = 0.5
        float sx0 = -2.2f, sx1 = 1.36f, sy0 = alto + 1.2f, sy1 = alto + 4.62f, sz = 0.5f + 0.012f;
        // --- se apaga: fase 0 constantemente; luego solo a ratos (y mucho en el glitch)
        float umbral = fase == 0 ? 0.32f + e.getGolpes() * 0.1f : glitch ? 0.4f : 0.04f;
        boolean apagada = azar((int) (t / 3), 11) < umbral && e.deathTime == 0;
        MatrixStack.Entry p = m.peek();
        if (apagada) {
            VertexConsumer negro = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
            quad(negro, p, sx0, sy0, sx1, sy1, sz, 0f, 0f, 1f, 1f, 0xFF050505, LUZ_MAX, overlay);
            if (azar((int) t, 12) < 0.5f)                                                // la rayita blanca de tele apagándose
                quad(negro, p, sx0 + 0.6f, (sy0 + sy1) / 2 - 0.03f, sx1 - 0.6f, (sy0 + sy1) / 2 + 0.03f, sz + 0.002f, 0f, 0f, 1f, 1f, 0xFFEFEFEF, LUZ_MAX, overlay);
        }

        // --- ojos realistas (desde la fase 1)
        float ojos = fase == 0 ? 0f : fase == 1 && trans > 0 ? suave((prog - 0.5f) / 0.3f) : 1f;
        if (ojos > 0.01f && !apagada) {
            float parpadeo = (e.age % 90) < 4 ? 0.12f : 1f;                              // parpadea de vez en cuando
            float abre = ojos * parpadeo;
            float cx = (sx0 + sx1) / 2, cy = alto + 3.05f, ancho = 1.45f, altoOjo = ancho * 158f / 243f;
            VertexConsumer o = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(OJO));
            for (int lado = -1; lado <= 1; lado += 2) {
                float x = cx + lado * 0.85f;
                float j = glitch && azar((int) t, 20 + lado) < 0.3f ? (azar((int) t, 30 + lado) - 0.5f) * 0.3f : 0f;
                quad(o, p, x - ancho / 2 + j, cy - altoOjo / 2 * abre, x + ancho / 2 + j, cy + altoOjo / 2 * abre, sz + 0.004f,
                        lado < 0 ? 1f : 0f, 0f, lado < 0 ? 0f : 1f, 1f, 0xFFFFFFFF, LUZ_MAX, overlay);
            }
        }
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    /** Un tentáculo de estática: cadena de cubos que baja en curva desde la tele hasta el suelo y se ondula. */
    private static void tentaculo(VertexConsumer b, MatrixStack m, int i, int total, float alto, float t, float crece, boolean glitch, int overlay) {
        if (crece <= 0.01f) return;
        // dónde se agarra a la tele (por debajo) y dónde apoya en el suelo (en círculo alrededor)
        float[] agarreX = {-2.0f, -0.7f, 0.7f, 2.0f, -1.4f, 0f, 1.4f, 0f};
        float[] agarreZ = {0.25f, -0.25f, 0.25f, -0.25f, -0.35f, 0.35f, -0.35f, 0f};
        float ax = agarreX[i % 8], az = agarreZ[i % 8];
        double ang = (i + 0.5) / total * Math.PI * 2 + (i >= 4 ? 0.4 : 0);
        float radio = total > 4 ? 4.6f : 3.6f;
        float fx = (float) Math.cos(ang) * radio, fz = (float) Math.sin(ang) * radio;
        float cx = ax * 1.6f + fx * 0.35f, cy = alto * 0.55f + 0.6f, cz = az + fz * 0.3f;   // punto de control (codo)
        int segmentos = 16;
        int hasta = Math.max(1, Math.round(segmentos * crece));
        for (int s = 0; s < hasta; s++) {
            float u = s / (float) (segmentos - 1);
            float a = (1 - u) * (1 - u), bb = 2 * (1 - u) * u, c = u * u;
            float x = a * ax + bb * cx + c * fx;
            float y = a * alto + bb * cy + c * 0.15f;
            float z = a * az + bb * cz + c * fz;
            // ondulación
            float onda = MathHelper.sin(t * 0.18f + u * 7f + i * 1.7f) * 0.28f * (1f - u * 0.6f);
            x += onda * (float) -Math.sin(ang);
            z += onda * (float) Math.cos(ang);
            y += MathHelper.cos(t * 0.13f + u * 5f + i) * 0.12f * (1 - u);
            if (glitch && azar((int) t * 31 + s, i) < 0.15f) { x += (azar((int) t, s) - 0.5f) * 0.8f; y += (azar(s, (int) t) - 0.5f) * 0.5f; }
            float r = 0.42f - u * 0.2f;
            // color de estática: gris que cambia a cada rato
            int g = 55 + (int) (azar((int) (t / 2) + s * 17, i * 5) * 190);
            int color = 0xFF000000 | (g << 16) | (g << 8) | g;
            if (glitch && azar((int) t + s, i + 99) < 0.12f) color = azar(s, i) < 0.5f ? 0xFFFF3030 : 0xFF30FFFF;
            GatoCuboRenderer.caja(b, m.peek(), x - r, y - r, z - r, x + r, y + r, z + r, color, LUZ_MAX, overlay);
        }
    }

    private static void quad(VertexConsumer v, MatrixStack.Entry p, float x0, float y0, float x1, float y1, float z,
                             float u0, float v0, float u1, float v1, int color, int luz, int overlay) {
        int a = (color >>> 24) & 255, r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        punto(v, p, x0, y1, z, u0, v0, r, g, b, a, luz, overlay);
        punto(v, p, x0, y0, z, u0, v1, r, g, b, a, luz, overlay);
        punto(v, p, x1, y0, z, u1, v1, r, g, b, a, luz, overlay);
        punto(v, p, x1, y1, z, u1, v0, r, g, b, a, luz, overlay);
    }

    private static void punto(VertexConsumer v, MatrixStack.Entry p, float x, float y, float z, float u, float tv,
                              int r, int g, int b, int a, int luz, int overlay) {
        v.vertex(p, x, y, z).color(r, g, b, a).texture(u, tv).overlay(overlay).light(luz).normal(p, 0, 0, 1);
    }

    @Override
    protected int getBlockLight(JefeTeleEntity e, net.minecraft.util.math.BlockPos pos) {
        return 15;
    }

    @Override
    public boolean shouldRender(JefeTeleEntity e, net.minecraft.client.render.Frustum frustum, double x, double y, double z) {
        return true;   // es enorme: que no desaparezca al mirarla de cerca
    }

}

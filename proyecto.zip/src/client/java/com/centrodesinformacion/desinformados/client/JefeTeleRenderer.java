package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.JefeTeleEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * La Desinformación (jefe final): un televisor antiguo de 5x5x5 con relieve (mueble de madera, tubo por detrás,
 * marco plateado, perillas, altavoz, patas y antena), pantalla de estática, tentáculos de estática
 * que la levantan, ojos realistas en la pantalla y parpadeos de "apagado".
 * Espacio del modelo: la pantalla mira a +Z; la tele va de x -2.5..2.5, z -2.5..2.5, y 0..5 (más la antena).
 */
public class JefeTeleRenderer extends EntityRenderer<JefeTeleEntity> {
    private static final Identifier BLANCO = Desinformados.id("textures/entity/blanco.png");
    private static final Identifier OJO = Desinformados.id("textures/entity/jefe_ojo.png");
    private static final int LUZ_MAX = 0xF000F0;
    private static final java.util.Random R = new java.util.Random();
    // hueco de la pantalla en el frente
    private static final float PANT_X0 = -2.15f, PANT_X1 = 1.05f, PANT_Y0 = 1.0f, PANT_Y1 = 4.65f;
    // Tablas fijas (antes se creaban en cada fotograma)
    private static final float[] PATAS_X = {-2.2f, 1.7f}, PATAS_Z = {-1.5f, 1.6f};
    private static final float[] AGARRE_X = {-2.0f, -0.7f, 0.7f, 2.0f, -1.4f, 0f, 1.4f, 0f};
    private static final float[] AGARRE_Z = {1.2f, -1.2f, 1.2f, -1.2f, -1.8f, 1.8f, -1.8f, 0f};
    private static final int MADERA = 0xFF7A4A28, MADERA_OSC = 0xFF55321A, PLASTICO = 0xFF2B2B2E, PLASTICO_OSC = 0xFF18181A,
            PLATA = 0xFFC2C6CC, PLATA_OSC = 0xFF8A8E95, LATON = 0xFFC9A44A, PERILLA = 0xFF353535, PERILLA_CLARA = 0xFF6E6E6E, REJILLA = 0xFF140D08;

    public JefeTeleRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 3f;
    }

    @Override
    public Identifier getTexture(JefeTeleEntity e) {
        return BLANCO;
    }

    private static float suave(float x) {
        x = MathHelper.clamp(x, 0f, 1f);
        return x * x * (3 - 2 * x);
    }

    /** Número pseudoaleatorio estable 0..1 (para la estática y los parpadeos). */
    private static float azar(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65535f;
    }

    @Override
    public void render(JefeTeleEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        float t = e.age + delta;
        int fase = e.getFase(), trans = e.getTransicion();
        float total = fase == 1 ? JefeTeleEntity.TRANSICION_1 : JefeTeleEntity.TRANSICION_2;
        float prog = trans > 0 ? MathHelper.clamp(1f - (trans - delta) / total, 0f, 1f) : 1f;

        // --- cuánto la levantan los tentáculos
        float alto;
        if (fase == 0) alto = 0f;
        else if (fase == 1) alto = trans > 0 ? 2f * suave((prog - 0.35f) / 0.65f) : 2f;
        else alto = trans > 0 ? 2f + 2f * suave((prog - 0.3f) / 0.7f) : 4f;
        if (fase > 0 && trans == 0) alto += MathHelper.sin(t * 0.08f) * 0.15f;           // flota un poco
        boolean glitch = fase == 2 && trans > 0 && prog < 0.8f;

        m.push();
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevBodyYaw, e.bodyYaw);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-cuerpo));
        if (e.deathTime > 0) {                                                           // al morir: se encoge con glitch
            float d = (e.deathTime + delta) / 20f;
            m.translate((azar(e.age, 1) - 0.5f) * 0.4f * d, 0, (azar(e.age, 2) - 0.5f) * 0.4f * d);
            m.scale(1f + d * 0.2f, Math.max(0.02f, 1f - d), 1f + d * 0.2f);
        }
        if (glitch && azar((int) (t / 2), 7) < 0.35f)                                    // tirones de glitch
            m.translate((azar((int) t, 3) - 0.5f) * 0.6f, 0, (azar((int) t, 4) - 0.5f) * 0.3f);
        int overlay = LivingEntityRenderer.getOverlay(e, 0f);

        // --- tentáculos de estática
        int cuantos = fase == 0 ? 0 : fase == 1 ? 4 : 8;
        if (fase == 2 && trans > 0 && prog < 0.45f) cuantos = 4;                         // los viejos se glitchean antes de que salgan los nuevos
        float crece = fase == 1 && trans > 0 ? suave(prog / 0.4f) : 1f;
        float creceNuevos = fase == 2 && trans > 0 ? suave((prog - 0.45f) / 0.35f) : 1f;
        VertexConsumer b = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        for (int i = 0; i < cuantos; i++) tentaculo(b, m, i, cuantos, alto, t, i >= 4 ? crece * creceNuevos : crece, glitch, overlay);

        // --- la tele: un televisor antiguo de 5x5x5 con relieve (mueble de madera, tubo detrás, marco, perillas, antena)
        int luzTele = LightmapTextureManager.pack(Math.max(10, LightmapTextureManager.getBlockLightCoordinates(luz)), LightmapTextureManager.getSkyLightCoordinates(luz));
        televisor(buffers, m, alto, luzTele, overlay, t);

        // cristal de la pantalla (dentro del marco plateado), delante en z = 2.3
        float sx0 = PANT_X0, sx1 = PANT_X1, sy0 = alto + PANT_Y0, sy1 = alto + PANT_Y1, sz = 2.36f;
        // --- se apaga: fase 0 constantemente; luego solo a ratos (y mucho en el glitch)
        float umbral = fase == 0 ? 0.32f + e.getGolpes() * 0.1f : glitch ? 0.4f : 0.04f;
        boolean apagada = azar((int) (t / 3), 11) < umbral && e.deathTime == 0;
        MatrixStack.Entry p = m.peek();
        if (apagada) {
            VertexConsumer negro = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
            quad(negro, p, sx0, sy0, sx1, sy1, sz, 0f, 0f, 1f, 1f, 0xFF050505, LUZ_MAX, overlay);
            if (azar((int) t, 12) < 0.5f)                                                // la rayita blanca de tele apagándose
                quad(negro, p, sx0 + 0.6f, (sy0 + sy1) / 2 - 0.03f, sx1 - 0.6f, (sy0 + sy1) / 2 + 0.03f, sz + 0.002f, 0f, 0f, 1f, 1f, 0xFFEFEFEF, LUZ_MAX, overlay);
        }

        // --- ojos realistas (desde la fase 1)
        float ojos = fase == 0 ? 0f : fase == 1 && trans > 0 ? suave((prog - 0.5f) / 0.3f) : 1f;
        if (ojos > 0.01f && !apagada) {
            float parpadeo = (e.age % 90) < 4 ? 0.12f : 1f;                              // parpadea de vez en cuando
            float abre = ojos * parpadeo;
            float cx = (sx0 + sx1) / 2, cy = alto + 2.95f, ancho = 1.4f, altoOjo = ancho * 158f / 243f;
            VertexConsumer o = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(OJO));
            for (int lado = -1; lado <= 1; lado += 2) {
                float x = cx + lado * 0.82f;
                float j = glitch && azar((int) t, 20 + lado) < 0.3f ? (azar((int) t, 30 + lado) - 0.5f) * 0.3f : 0f;
                quad(o, p, x - ancho / 2 + j, cy - altoOjo / 2 * abre, x + ancho / 2 + j, cy + altoOjo / 2 * abre, sz + 0.004f,
                        lado < 0 ? 1f : 0f, 0f, lado < 0 ? 0f : 1f, 1f, 0xFFFFFFFF, LUZ_MAX, overlay);
            }
        }
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    private static void caja(VertexConsumer b, MatrixStack m, float x0, float y0, float z0, float x1, float y1, float z1, int color, int luz, int ov) {
        GatoCuboRenderer.caja(b, m.peek(), x0, y0, z0, x1, y1, z1, color, luz, ov);
    }

    /** El televisor de 5x5x5 con relieve. */
    private static void televisor(VertexConsumerProvider buffers, MatrixStack m, float a, int luz, int ov, float t) {
        VertexConsumer b = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(BLANCO));
        // patas
        for (float px : PATAS_X) for (float pz : PATAS_Z)
            caja(b, m, px, a, pz, px + 0.5f, a + 0.35f, pz + 0.5f, PLASTICO_OSC, luz, ov);
        // mueble de madera (con un reborde arriba)
        caja(b, m, -2.5f, a + 0.35f, -0.9f, 2.5f, a + 4.9f, 2.3f, MADERA, luz, ov);
        caja(b, m, -2.56f, a + 4.9f, -0.96f, 2.56f, a + 5.05f, 2.38f, MADERA_OSC, luz, ov);
        caja(b, m, -2.56f, a + 0.3f, -0.96f, 2.56f, a + 0.42f, 2.38f, MADERA_OSC, luz, ov);
        for (int i = 0; i < 3; i++) {                                                   // vetas en los lados
            float y = a + 1.3f + i * 1.25f;
            caja(b, m, -2.53f, y, -0.6f, -2.5f, y + 0.06f, 2.0f, MADERA_OSC, luz, ov);
            caja(b, m, 2.5f, y, -0.6f, 2.53f, y + 0.06f, 2.0f, MADERA_OSC, luz, ov);
        }
        // el tubo de la tele por detrás (se va estrechando) con rejillas de ventilación
        caja(b, m, -2.2f, a + 0.6f, -1.8f, 2.2f, a + 4.75f, -0.9f, PLASTICO, luz, ov);
        caja(b, m, -1.6f, a + 1.1f, -2.5f, 1.6f, a + 4.25f, -1.8f, PLASTICO, luz, ov);
        for (int i = 0; i < 6; i++) {
            float y = a + 1.5f + i * 0.42f;
            caja(b, m, -1.2f, y, -2.53f, 1.2f, y + 0.12f, -2.5f, PLASTICO_OSC, luz, ov);
        }
        // frente: placa de madera alrededor del hueco de la pantalla
        float x0 = PANT_X0, x1 = PANT_X1, y0 = a + PANT_Y0, y1 = a + PANT_Y1;
        caja(b, m, -2.5f, y1, 2.3f, 2.5f, a + 4.9f, 2.5f, MADERA, luz, ov);
        caja(b, m, -2.5f, a + 0.42f, 2.3f, 2.5f, y0, 2.5f, MADERA, luz, ov);
        caja(b, m, -2.5f, y0, 2.3f, x0, y1, 2.5f, MADERA, luz, ov);
        caja(b, m, x1, y0, 2.3f, 2.5f, y1, 2.5f, MADERA, luz, ov);
        // marco plateado (sobresale)
        float g = 0.14f;
        caja(b, m, x0 - g, y1, 2.45f, x1 + g, y1 + g, 2.6f, PLATA, luz, ov);
        caja(b, m, x0 - g, y0 - g, 2.45f, x1 + g, y0, 2.6f, PLATA, luz, ov);
        caja(b, m, x0 - g, y0, 2.45f, x0, y1, 2.6f, PLATA, luz, ov);
        caja(b, m, x1, y0, 2.45f, x1 + g, y1, 2.6f, PLATA, luz, ov);
        caja(b, m, x0, y1 - 0.05f, 2.3f, x1, y1, 2.47f, PLATA_OSC, luz, ov);       // borde interior (da profundidad al hueco)
        caja(b, m, x0, y0, 2.3f, x1, y0 + 0.05f, 2.47f, PLATA_OSC, luz, ov);
        caja(b, m, x0, y0, 2.3f, x0 + 0.05f, y1, 2.47f, PLATA_OSC, luz, ov);
        caja(b, m, x1 - 0.05f, y0, 2.3f, x1, y1, 2.47f, PLATA_OSC, luz, ov);
        // panel de control a la derecha: placa, dos perillas y el altavoz
        caja(b, m, 1.25f, a + 1.15f, 2.5f, 2.35f, a + 4.5f, 2.53f, 0xFF241811, luz, ov);
        caja(b, m, 1.38f, a + 4.05f, 2.53f, 2.22f, a + 4.35f, 2.56f, LATON, luz, ov);
        for (float py : new float[]{a + 3.35f, a + 2.55f}) {
            caja(b, m, 1.55f, py - 0.25f, 2.53f, 2.05f, py + 0.25f, 2.8f, PERILLA, luz, ov);
            caja(b, m, 1.65f, py - 0.15f, 2.8f, 1.95f, py + 0.15f, 2.86f, PERILLA_CLARA, luz, ov);
            caja(b, m, 1.78f, py + 0.02f, 2.86f, 1.82f, py + 0.15f, 2.88f, 0xFFE8E8E8, luz, ov);   // la rayita de la perilla
        }
        for (int i = 0; i < 5; i++) {
            float y = a + 1.3f + i * 0.17f;
            caja(b, m, 1.38f, y, 2.53f, 2.22f, y + 0.08f, 2.55f, REJILLA, luz, ov);
        }
        // placa de latón debajo de la pantalla
        float cx = (x0 + x1) / 2;
        caja(b, m, cx - 0.6f, a + 0.55f, 2.5f, cx + 0.6f, a + 0.82f, 2.55f, LATON, luz, ov);
        for (int i = 0; i < 6; i++) caja(b, m, cx - 0.45f + i * 0.18f, a + 0.65f, 2.55f, cx - 0.39f + i * 0.18f, a + 0.71f, 2.56f, 0xFF5A4410, luz, ov);
        // antena de "orejas de conejo"
        caja(b, m, -0.45f, a + 5.05f, -0.3f, 0.45f, a + 5.3f, 0.3f, PLASTICO_OSC, luz, ov);
        for (int lado = -1; lado <= 1; lado += 2) {
            float mueve = MathHelper.sin(t * 0.05f + lado) * 0.08f;
            for (int k = 0; k < 9; k++) {
                float u = k / 9f;
                float ax = lado * (0.15f + u * 1.2f + mueve * u), ay = a + 5.3f + u * 1.9f, az = -u * 0.3f;
                caja(b, m, ax - 0.05f, ay, az - 0.05f, ax + 0.05f, ay + 0.24f, az + 0.05f, 0xFFB4B4B4, luz, ov);
            }
            float tx = lado * (1.35f + mueve), ty = a + 7.2f;
            caja(b, m, tx - 0.09f, ty, -0.39f, tx + 0.09f, ty + 0.18f, -0.21f, PLASTICO_OSC, luz, ov);
        }
        // la pantalla: estática de verdad (la textura de ruido con un trozo al azar en cada fotograma)
        VertexConsumer st = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(Ruido.textura()));
        float tam = 0.14f, u0 = R.nextFloat() * (1f - tam), v0 = R.nextFloat() * (1f - tam);
        quad(st, m.peek(), x0, y0, x1, y1, 2.33f, u0, v0, u0 + tam, v0 + tam * (y1 - y0) / (x1 - x0), 0xFFE6E6E6, LUZ_MAX, ov);
    }

    /** Un tentáculo de estática: cadena de cubos que baja en curva desde la tele hasta el suelo y se ondula. */
    private static void tentaculo(VertexConsumer b, MatrixStack m, int i, int total, float alto, float t, float crece, boolean glitch, int overlay) {
        if (crece <= 0.01f) return;
        // dónde se agarra a la tele (por debajo) y dónde apoya en el suelo (en círculo alrededor)
        float[] agarreX = AGARRE_X;
        float[] agarreZ = AGARRE_Z;
        float ax = agarreX[i % 8], az = agarreZ[i % 8];
        double ang = (i + 0.5) / total * Math.PI * 2 + (i >= 4 ? 0.4 : 0);
        float radio = total > 4 ? 5.4f : 4.4f;
        float fx = (float) Math.cos(ang) * radio, fz = (float) Math.sin(ang) * radio;
        float cx = ax * 1.6f + fx * 0.35f, cy = alto * 0.55f + 0.6f, cz = az + fz * 0.3f;   // punto de control (codo)
        int segmentos = 16;
        int hasta = Math.max(1, Math.round(segmentos * crece));
        for (int s = 0; s < hasta; s++) {
            float u = s / (float) (segmentos - 1);
            float a = (1 - u) * (1 - u), bb = 2 * (1 - u) * u, c = u * u;
            float x = a * ax + bb * cx + c * fx;
            float y = a * alto + bb * cy + c * 0.15f;
            float z = a * az + bb * cz + c * fz;
            // ondulación
            float onda = MathHelper.sin(t * 0.18f + u * 7f + i * 1.7f) * 0.28f * (1f - u * 0.6f);
            x += onda * (float) -Math.sin(ang);
            z += onda * (float) Math.cos(ang);
            y += MathHelper.cos(t * 0.13f + u * 5f + i) * 0.12f * (1 - u);
            if (glitch && azar((int) t * 31 + s, i) < 0.15f) { x += (azar((int) t, s) - 0.5f) * 0.8f; y += (azar(s, (int) t) - 0.5f) * 0.5f; }
            float r = 0.42f - u * 0.2f;
            // color de estática: gris que cambia a cada rato
            int g = 55 + (int) (azar((int) (t / 2) + s * 17, i * 5) * 190);
            int color = 0xFF000000 | (g << 16) | (g << 8) | g;
            if (glitch && azar((int) t + s, i + 99) < 0.12f) color = azar(s, i) < 0.5f ? 0xFFFF3030 : 0xFF30FFFF;
            GatoCuboRenderer.caja(b, m.peek(), x - r, y - r, z - r, x + r, y + r, z + r, color, LUZ_MAX, overlay);
        }
    }

    private static void quad(VertexConsumer v, MatrixStack.Entry p, float x0, float y0, float x1, float y1, float z,
                             float u0, float v0, float u1, float v1, int color, int luz, int overlay) {
        int a = (color >>> 24) & 255, r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        punto(v, p, x0, y1, z, u0, v0, r, g, b, a, luz, overlay);
        punto(v, p, x0, y0, z, u0, v1, r, g, b, a, luz, overlay);
        punto(v, p, x1, y0, z, u1, v1, r, g, b, a, luz, overlay);
        punto(v, p, x1, y1, z, u1, v0, r, g, b, a, luz, overlay);
    }

    private static void punto(VertexConsumer v, MatrixStack.Entry p, float x, float y, float z, float u, float tv,
                              int r, int g, int b, int a, int luz, int overlay) {
        v.vertex(p, x, y, z).color(r, g, b, a).texture(u, tv).overlay(overlay).light(luz).normal(p, 0, 0, 1);
    }

    @Override
    protected int getBlockLight(JefeTeleEntity e, net.minecraft.util.math.BlockPos pos) {
        return 15;
    }

    @Override
    public boolean shouldRender(JefeTeleEntity e, net.minecraft.client.render.Frustum frustum, double x, double y, double z) {
        return true;   // es enorme: que no desaparezca al mirarla de cerca
    }

}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SlimeEntityRenderer;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.util.Identifier;

public class CuboBlancoRenderer extends SlimeEntityRenderer {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/cubo_blanco.png");

    public CuboBlancoRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
    }

    @Override
    public Identifier getTexture(SlimeEntity entidad) {
        return TEXTURA;
    }
}

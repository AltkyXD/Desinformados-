package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.entidad.GatoCuboEntity;
import com.centrodesinformacion.desinformados.network.TiendaCompraPayload;
import com.centrodesinformacion.desinformados.tienda.Tienda;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Tienda de un Gato Cubo: lista de ofertas con precio en Rumores y botón de comprar (el de minerales, también vender). */
public class TiendaScreen extends Screen {
    public static int entidad, tipo, dinero;
    private static final int ANCHO = 260;
    /** Pestaña "Vender" (solo en el puesto de minerales). */
    private boolean vendiendo = false;

    public TiendaScreen() {
        super(Text.literal("Tienda"));
    }

    private boolean conPestanas() { return Tienda.compra(tipo); }
    /** Primera fila de ofertas (más abajo si hay pestañas). */
    private int inicioFilas(int y) { return y + (conPestanas() ? 64 : 46); }

    public static void actualizar(int e, int t, int d) {
        entidad = e; tipo = t; dinero = d;
    }

    private List<Tienda.Oferta> ofertas() { return Tienda.ofertas(tipo); }
    private int alto() { return Math.max(110, (conPestanas() ? 82 : 64) + ofertas().size() * 22); }

    @Override public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        int x = (width - ANCHO) / 2, y = (height - alto()) / 2;
        if (conPestanas()) {
            ButtonWidget comprar = ButtonWidget.builder(Text.literal("Comprar"), b -> { vendiendo = false; clearAndInit(); })
                    .dimensions(x + ANCHO / 2 - 82, y + 38, 80, 18).build();
            ButtonWidget vender = ButtonWidget.builder(Text.literal("Vender"), b -> { vendiendo = true; clearAndInit(); })
                    .dimensions(x + ANCHO / 2 + 2, y + 38, 80, 18).build();
            comprar.active = vendiendo;      // la pestaña en la que estás sale "apretada"
            vender.active = !vendiendo;
            addDrawableChild(comprar);
            addDrawableChild(vender);
        }
        List<Tienda.Oferta> lista = ofertas();
        int fy0 = inicioFilas(y);
        for (int i = 0; i < lista.size(); i++) {
            final int indice = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(vendiendo ? "Vender" : "Comprar"),
                    b -> ClientPlayNetworking.send(new TiendaCompraPayload(entidad, vendiendo ? -indice - 1 : indice)))
                    .dimensions(x + ANCHO - 68, fy0 + i * 22, 56, 18).build());
        }
    }

    private String titulo() {
        return switch (tipo) {
            case GatoCuboEntity.VEND_PASIVAS -> "PASIVAS MÁGICAS";
            case GatoCuboEntity.VEND_CORAZONES -> "CORAZONES Y TÓTEMS";
            default -> "MINERALES DEL CUBO";
        };
    }

    private int colorMarco() {
        return switch (tipo) {
            case GatoCuboEntity.VEND_PASIVAS -> 0xFF8A3CD6;
            case GatoCuboEntity.VEND_CORAZONES -> 0xFFD63C3C;
            default -> 0xFFE0B030;
        };
    }

    /** Fondo: oscurece el juego y dibuja el panel (los botones van encima). */
    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int alto = alto();
        int x = (width - ANCHO) / 2, y = (height - alto) / 2;
        ctx.fill(x - 3, y - 3, x + ANCHO + 3, y + alto + 3, 0xFF101010);
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + alto + 2, colorMarco());
        ctx.fill(x, y, x + ANCHO, y + alto, 0xFF1A1A22);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int alto = alto();
        int x = (width - ANCHO) / 2, y = (height - alto) / 2;
        Text t = Text.literal(titulo()).formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, t, x + ANCHO / 2 - textRenderer.getWidth(t) / 2, y + 8, colorMarco(), true);
        Text d = Text.literal("Tienes " + dinero + " Rumores (Banco + bolsillo)");
        ctx.drawText(textRenderer, d, x + ANCHO / 2 - textRenderer.getWidth(d) / 2, y + 24, 0xFFFFE680, true);
        List<Tienda.Oferta> lista = ofertas();
        if (lista.isEmpty()) {
            Text p = Text.literal("Próximamente... el mago sigue horneando las pasivas.").formatted(Formatting.ITALIC);
            ctx.drawText(textRenderer, p, x + ANCHO / 2 - textRenderer.getWidth(p) / 2, y + 60, 0xFFB0A0D0, false);
            return;
        }
        int fy0 = inicioFilas(y);
        for (int i = 0; i < lista.size(); i++) {
            Tienda.Oferta o = lista.get(i);
            int fy = fy0 + i * 22;
            ctx.drawItem(o.stack(), x + 10, fy + 1);
            ctx.drawItemInSlot(textRenderer, o.stack(), x + 10, fy + 1);
            ctx.drawText(textRenderer, o.item().getName(), x + 32, fy + 1, 0xFFFFFFFF, true);
            if (vendiendo) {
                int lleva = client != null && client.player != null ? Tienda.cuantosLleva(client.player.getInventory(), o.item()) : 0;
                int pago = Tienda.ganancia(o, lleva);
                String linea = lleva == 0 ? "No llevas · x" + o.cantidad() + " = " + Tienda.ganancia(o, o.cantidad()) + " Rumores"
                        : "Vender " + lleva + " → " + pago + " Rumores";
                ctx.drawText(textRenderer, Text.literal(linea), x + 32, fy + 10, pago > 0 ? 0xFF7CE07C : 0xFF909090, false);
            } else {
                boolean alcanza = dinero >= o.precio();
                ctx.drawText(textRenderer, Text.literal(o.precio() + " Rumores"), x + 32, fy + 10, alcanza ? 0xFF7CE07C : 0xFFE06060, false);
            }
        }
    }
}

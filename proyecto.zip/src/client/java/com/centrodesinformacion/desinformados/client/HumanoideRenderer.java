package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Mob con forma de jugador y skin de jugador 64x64 (Ale, Travensaño). */
public class HumanoideRenderer<T extends MobEntity> extends BipedEntityRenderer<T, BipedEntityModel<T>> {
    private final Identifier textura;

    public HumanoideRenderer(EntityRendererFactory.Context contexto, Identifier textura) {
        super(contexto, new SentadoModel<>(contexto.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.textura = textura;
    }

    @Override
    public Identifier getTexture(T entidad) {
        return textura;
    }
}

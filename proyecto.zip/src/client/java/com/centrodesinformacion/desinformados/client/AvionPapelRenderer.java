package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.papel.AvionPapelEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Avión de Papel: su modelo propio, cabeceando al subir y al bajar en picado (como el phantom). */
public class AvionPapelRenderer extends MobEntityRenderer<AvionPapelEntity, AvionPapelModel> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/dibujo/avion_papel.png");

    public AvionPapelRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new AvionPapelModel(ctx.getPart(AvionPapelModel.CAPA)), 0.3f);
    }

    @Override
    public Identifier getTexture(AvionPapelEntity e) {
        return TEXTURA;
    }

    @Override
    protected void setupTransforms(AvionPapelEntity e, MatrixStack m, float animationProgress, float bodyYaw, float tickDelta, float scale) {
        super.setupTransforms(e, m, animationProgress, bodyYaw, tickDelta, scale);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(e.getPitch()));
    }
}

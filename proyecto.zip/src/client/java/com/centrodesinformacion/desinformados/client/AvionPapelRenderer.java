package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.papel.AvionPapelEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Avión de Papel: dos alas triangulares lisas (en V) y la quilla de debajo, dibujadas directamente.
 * Textura 64x32: la mitad izquierda es el avión visto desde arriba (morro arriba en el centro), la derecha la quilla.
 * Mira hacia donde vuela y cabecea al bajar en picado y al subir (como el phantom).
 */
public class AvionPapelRenderer extends EntityRenderer<AvionPapelEntity> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/dibujo/avion_papel.png");
    private static final float MEDIO_LARGO = 0.6f, MEDIA_ENVERGADURA = 0.55f, DIEDRO = 0.14f, QUILLA = 0.16f;

    public AvionPapelRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.25f;
    }

    @Override
    public Identifier getTexture(AvionPapelEntity e) {
        return TEXTURA;
    }

    @Override
    public void render(AvionPapelEntity e, float yaw, float delta, MatrixStack m, VertexConsumerProvider buffers, int luz) {
        m.push();
        m.translate(0, 0.22, 0);
        float cuerpo = MathHelper.lerpAngleDegrees(delta, e.prevBodyYaw, e.bodyYaw);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-cuerpo));                     // el morro (+Z) hacia donde mira
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MathHelper.lerp(delta, e.prevPitch, e.getPitch())));
        if (e.deathTime > 0) {                                                           // al morir cae dando vueltas
            float d = e.deathTime + delta;
            m.translate(0, -d * 0.02f, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(d * 18f));
        }
        float t = e.age + delta;
        float temblor = MathHelper.sin(t * 0.7f + e.getId()) * 0.025f;                 // el papel tiembla con el aire
        int ov = LivingEntityRenderer.getOverlay(e, 0f);
        VertexConsumer v = buffers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURA));
        MatrixStack.Entry p = m.peek();
        float L = MEDIO_LARGO, S = MEDIA_ENVERGADURA;
        // ala izquierda (x+) y derecha (x-): morro, morro, punta de la cola, centro de la cola
        quad(v, p, 0, 0, L, 0.25f, 0f, 0, 0, L, 0.25f, 0f, S, DIEDRO + temblor, -L, 0f, 1f, 0, 0, -L, 0.25f, 1f, 0, 1, 0, luz, ov);
        quad(v, p, 0, 0, L, 0.25f, 0f, 0, 0, L, 0.25f, 0f, -S, DIEDRO - temblor, -L, 0.5f, 1f, 0, 0, -L, 0.25f, 1f, 0, 1, 0, luz, ov);
        // quilla: el doblez de debajo, triangular
        quad(v, p, 0, 0, L, 0.5f, 0f, 0, 0, L, 0.5f, 0f, 0, -QUILLA, -L, 1f, 1f, 0, 0, -L, 1f, 0f, 1, 0, 0, luz, ov);
        m.pop();
        super.render(e, yaw, delta, m, buffers, luz);
    }

    private static void quad(VertexConsumer v, MatrixStack.Entry p,
                             float x1, float y1, float z1, float u1, float v1,
                             float x2, float y2, float z2, float u2, float v2,
                             float x3, float y3, float z3, float u3, float v3,
                             float x4, float y4, float z4, float u4, float v4,
                             float nx, float ny, float nz, int luz, int ov) {
        punto(v, p, x1, y1, z1, u1, v1, nx, ny, nz, luz, ov);
        punto(v, p, x2, y2, z2, u2, v2, nx, ny, nz, luz, ov);
        punto(v, p, x3, y3, z3, u3, v3, nx, ny, nz, luz, ov);
        punto(v, p, x4, y4, z4, u4, v4, nx, ny, nz, luz, ov);
    }

    private static void punto(VertexConsumer v, MatrixStack.Entry p, float x, float y, float z, float u, float tv,
                              float nx, float ny, float nz, int luz, int ov) {
        v.vertex(p, x, y, z).color(255, 255, 255, 255).texture(u, tv).overlay(ov).light(luz).normal(p, nx, ny, nz);
    }
}

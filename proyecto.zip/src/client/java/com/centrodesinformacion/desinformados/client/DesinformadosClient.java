package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;

public class DesinformadosClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EventoTvPayload.ID, (paquete, contexto) -> TvOverlay.iniciar(paquete));
        ClientPlayNetworking.registerGlobalReceiver(AlmasPayload.ID, (paquete, contexto) -> AlmasHud.actualizar(paquete.puntos()));
        EntityRendererRegistry.register(ModEntidades.CREEPER_OSCURO, CreeperOscuroRenderer::new);
        HudRenderCallback.EVENT.register(AlmasHud::render);
        HudRenderCallback.EVENT.register(TvOverlay::render);
        ClientTickEvents.END_CLIENT_TICK.register(cliente -> TvOverlay.tick());
    }
}

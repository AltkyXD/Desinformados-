package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;

public class DesinformadosClient implements ClientModInitializer {
    public static final net.minecraft.client.option.KeyBinding TECLA_MISIONES =
            net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.option.KeyBinding(
                    "key.desinformados.misiones", net.minecraft.client.util.InputUtil.Type.KEYSYM,
                    org.lwjgl.glfw.GLFW.GLFW_KEY_L, "category.desinformados"));

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void registrarFurro() {
        EntityRendererRegistry.register(ModEntidades.FURRO, (net.minecraft.client.render.entity.EntityRendererFactory) FurroRenderer::new);
        EntityRendererRegistry.register(ModEntidades.ZOMBIE_NARANJA, (net.minecraft.client.render.entity.EntityRendererFactory) ZombieNaranjaRenderer::new);
        EntityRendererRegistry.register(ModEntidades.ZOMBIE_ESTATICA, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.Zombie::new);
        EntityRendererRegistry.register(ModEntidades.ESQUELETO_ESTATICA, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.Esqueleto::new);
        EntityRendererRegistry.register(ModEntidades.ARANA_ESTATICA, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.Arana::new);
        EntityRendererRegistry.register(ModEntidades.CREEPER_ESTATICA, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.Creeper::new);
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(com.centrodesinformacion.desinformados.ModBloques.TELE_PORTAL,
                net.minecraft.client.render.RenderLayer.getCutout());
        EntityRendererRegistry.register(ModEntidades.ZOMBIE_DIBUJO, ctx -> new PapelRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/dibujo/zombie.png"), 1.0f, 2.0f, false));
        EntityRendererRegistry.register(ModEntidades.ESQUELETO_DIBUJO, ctx -> new PapelRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/dibujo/esqueleto.png"), 1.0f, 2.0f, false));
        EntityRendererRegistry.register(ModEntidades.CREEPER_DIBUJO, ctx -> new PapelRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/dibujo/creeper.png"), 1.0f, 1.75f, false));
        EntityRendererRegistry.register(ModEntidades.ARANA_DIBUJO, ctx -> new PapelRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/dibujo/arana.png"), 1.5f, 1.0f, true));
        EntityRendererRegistry.register(ModEntidades.CUBO_BLANCO, (net.minecraft.client.render.entity.EntityRendererFactory) CuboBlancoRenderer::new);
        EntityRendererRegistry.register(ModEntidades.CREEPER_FUEGO, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.CreeperFuego::new);
        EntityRendererRegistry.register(ModEntidades.ESQUELETO_RAFAGA, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.EsqueletoRafaga::new);
        EntityRendererRegistry.register(ModEntidades.CUBO_ROJO, (net.minecraft.client.render.entity.EntityRendererFactory) EstaticaRenderers.CuboRojo::new);
    }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EventoTvPayload.ID, (paquete, contexto) -> TvOverlay.iniciar(paquete));
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.IntroPayload.ID,
                (paquete, contexto) -> contexto.client().setScreen(new IntroScreen()));
        ClientPlayNetworking.registerGlobalReceiver(AlmasPayload.ID, (paquete, contexto) -> AlmasHud.actualizar(paquete.puntos()));
        EntityRendererRegistry.register(ModEntidades.CREEPER_OSCURO, CreeperOscuroRenderer::new);
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlocks(net.minecraft.client.render.RenderLayer.getCutout(),
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_AZUL,
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_MORADA,
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_GRIS);
        EntityRendererRegistry.register(ModEntidades.GARABATO, GarabatoRenderer::new);
        EntityRendererRegistry.register(ModEntidades.ALE,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/ale.png")));
        EntityRendererRegistry.register(ModEntidades.ULISES,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/ulises.png")));
        EntityRendererRegistry.register(ModEntidades.INTERFERENCIA,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/interferencia.png")));
        EntityRendererRegistry.register(ModEntidades.ANGEL,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/angel.png")));
        EntityRendererRegistry.register(ModEntidades.TRAVENSANO,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/travensano.png")));
        registrarFurro();
        EntityRendererRegistry.register(ModEntidades.GATO_CUBO, GatoCuboRenderer::new);
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                com.centrodesinformacion.desinformados.ModBloques.REJILLA_METAL, net.minecraft.client.render.RenderLayer.getCutout());
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                com.centrodesinformacion.desinformados.ModBloques.MESA_DJ, net.minecraft.client.render.RenderLayer.getCutout());
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlocks(
                net.minecraft.client.render.RenderLayer.getCutout(), com.centrodesinformacion.desinformados.ModBloques.DECO_CUTOUT);
        // Pista de baile: el color sale del estado del bloque; en el inventario va cambiando sola
        net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry.BLOCK.register(
                (estado, mundo, pos, tinte) -> com.centrodesinformacion.desinformados.muebles.PistaBaileBlock.COLORES[
                        estado.get(com.centrodesinformacion.desinformados.muebles.PistaBaileBlock.COLOR)],
                com.centrodesinformacion.desinformados.ModBloques.PISTA_BAILE);
        net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry.ITEM.register(
                (stack, tinte) -> 0xFF000000 | com.centrodesinformacion.desinformados.muebles.PistaBaileBlock.COLORES[
                        (int) ((System.currentTimeMillis() / 500) % 16)],
                com.centrodesinformacion.desinformados.ModBloques.PISTA_BAILE);
        EntityRendererRegistry.register(ModEntidades.BRANDON, ctx -> new SkinRenderer<>(ctx,
                com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/brandon.png"),
                com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/brandon_brillo.png")));
        EntityRendererRegistry.register(ModEntidades.ALTKY, ctx -> new SkinRenderer<>(ctx,
                com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/altky.png"), null));
        EntityRendererRegistry.register(ModEntidades.FURRO_DIBUJO, ctx -> new PapelRenderer<>(ctx,
                com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/dibujo/furro.png"), 1.0f, 2.0f, false));
        EntityRendererRegistry.register(ModEntidades.KEVIN, ctx -> new SkinRenderer<>(ctx,
                com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/kevin.png"), null));
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.DialogoPayload.ID,
                (paquete, contexto) -> DialogoHud.mostrar(paquete.nombre(), paquete.color(), paquete.texto()));
        HudRenderCallback.EVENT.register(DialogoHud::render);
        // varios huevos para el mismo mob: cada uno con sus colores
        net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry.ITEM.register(
                (stack, capa) -> 0xFF000000 | ((net.minecraft.item.SpawnEggItem) stack.getItem()).getColor(capa),
                com.centrodesinformacion.desinformados.ModItems.HUEVOS_GATO);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.TiendaPayload.ID, (paquete, contexto) -> {
            TiendaScreen.actualizar(paquete.entidad(), paquete.tipo(), paquete.dinero());
            if (paquete.abrir()) contexto.client().setScreen(new TiendaScreen());
        });
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BordePayload.ID,
                (paquete, contexto) -> BordeRojo.cambiar(paquete.activo()));
        HudRenderCallback.EVENT.register(BordeRojo::render);
        HudRenderCallback.EVENT.register(AlmasHud::render);
        HudRenderCallback.EVENT.register(TvOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.MuertePayload.ID,
                (paquete, contexto) -> MuerteOverlay.iniciar(paquete.nombre()));
        HudRenderCallback.EVENT.register(MuerteOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BlancoPayload.ID,
                (paquete, contexto) -> BlancoOverlay.iniciar(paquete.ticks()));
        HudRenderCallback.EVENT.register(BlancoOverlay::render);
        // Libreta: tinta, hojas de papel y manchas en la pantalla
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.ManchaPayload.ID,
                (paquete, contexto) -> ManchaOverlay.iniciar(paquete.ticks()));
        HudRenderCallback.EVENT.register(ManchaOverlay::render);
        net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry.INSTANCE.register(
                com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA,
                com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA_FLUYENDO,
                new net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler(
                        com.centrodesinformacion.desinformados.Desinformados.id("block/tinta_quieta"),
                        com.centrodesinformacion.desinformados.Desinformados.id("block/tinta_fluyendo")));
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putFluids(net.minecraft.client.render.RenderLayer.getTranslucent(),
                com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA,
                com.centrodesinformacion.desinformados.dimension.ModFluidos.TINTA_FLUYENDO);
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(com.centrodesinformacion.desinformados.ModBloques.HOJAS_PAPEL,
                net.minecraft.client.render.RenderLayer.getCutoutMipped());
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.CambiosPayload.ID, (paquete, contexto) -> {
            com.centrodesinformacion.desinformados.CambiosActivos.CLIENTE.clear();
            for (String c : paquete.lista().split(",")) if (!c.isEmpty()) com.centrodesinformacion.desinformados.CambiosActivos.CLIENTE.add(c);
        });
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.ManipuladoPayload.ID,
                (paquete, contexto) -> Manipulacion.iniciar(paquete.entidad(), paquete.ticks()));
        HudRenderCallback.EVENT.register(Manipulacion::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BancoPayload.ID, (paquete, contexto) -> {
            BancoScreen.saldo = paquete.saldo();
            if (paquete.abrir()) contexto.client().setScreen(new BancoScreen());
        });
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.MisionesPayload.ID,
                (paquete, contexto) -> MisionesCliente.actualizar(paquete.json()));
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.SustoPayload.ID,
                (paquete, contexto) -> SustoOverlay.iniciar(paquete.ticks()));
        HudRenderCallback.EVENT.register(SustoOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.InvertidoPayload.ID,
                (paquete, contexto) -> ControlesInvertidos.iniciar(paquete.ticks()));
        ClientTickEvents.END_CLIENT_TICK.register(cliente -> {
            TvOverlay.tick();
            BordeRojo.tick();
            MuerteOverlay.tick();
            BlancoOverlay.tick();
            ManchaOverlay.tick();
            DialogoHud.tick();
            Manipulacion.tick();
            while (TECLA_MISIONES.wasPressed()) {
                if (cliente.currentScreen == null) cliente.setScreen(new MisionesScreen());
            }
            SustoOverlay.tick();
            ControlesInvertidos.tick();
        });
    }
}

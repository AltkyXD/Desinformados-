package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class DesinformadosClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EventoTvPayload.ID, (paquete, contexto) -> TvOverlay.iniciar(paquete));
        HudRenderCallback.EVENT.register(TvOverlay::render);
        ClientTickEvents.END_CLIENT_TICK.register(cliente -> TvOverlay.tick());
    }
}

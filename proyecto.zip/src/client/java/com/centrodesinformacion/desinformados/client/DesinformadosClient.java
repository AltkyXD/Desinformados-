package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.AlmasPayload;
import com.centrodesinformacion.desinformados.network.EventoTvPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import com.centrodesinformacion.desinformados.entidad.ModEntidades;

public class DesinformadosClient implements ClientModInitializer {
    public static final net.minecraft.client.option.KeyBinding TECLA_MISIONES =
            net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.option.KeyBinding(
                    "key.desinformados.misiones", net.minecraft.client.util.InputUtil.Type.KEYSYM,
                    org.lwjgl.glfw.GLFW.GLFW_KEY_L, "category.desinformados"));

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void registrarFurro() {
        EntityRendererRegistry.register(ModEntidades.FURRO, (net.minecraft.client.render.entity.EntityRendererFactory) FurroRenderer::new);
        EntityRendererRegistry.register(ModEntidades.ZOMBIE_NARANJA, (net.minecraft.client.render.entity.EntityRendererFactory) ZombieNaranjaRenderer::new);
        EntityRendererRegistry.register(ModEntidades.CUBO_BLANCO, (net.minecraft.client.render.entity.EntityRendererFactory) CuboBlancoRenderer::new);
    }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EventoTvPayload.ID, (paquete, contexto) -> TvOverlay.iniciar(paquete));
        ClientPlayNetworking.registerGlobalReceiver(AlmasPayload.ID, (paquete, contexto) -> AlmasHud.actualizar(paquete.puntos()));
        EntityRendererRegistry.register(ModEntidades.CREEPER_OSCURO, CreeperOscuroRenderer::new);
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlocks(net.minecraft.client.render.RenderLayer.getCutout(),
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_AZUL,
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_MORADA,
                com.centrodesinformacion.desinformados.ModBloques.TRAGAMONEDAS_GRIS);
        EntityRendererRegistry.register(ModEntidades.GARABATO, GarabatoRenderer::new);
        EntityRendererRegistry.register(ModEntidades.ALE,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/ale.png")));
        EntityRendererRegistry.register(ModEntidades.ULISES,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/ulises.png")));
        EntityRendererRegistry.register(ModEntidades.INTERFERENCIA,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/interferencia.png")));
        EntityRendererRegistry.register(ModEntidades.ANGEL,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/angel.png")));
        EntityRendererRegistry.register(ModEntidades.TRAVENSANO,
                ctx -> new HumanoideRenderer<>(ctx, com.centrodesinformacion.desinformados.Desinformados.id("textures/entity/travensano.png")));
        registrarFurro();
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BordePayload.ID,
                (paquete, contexto) -> BordeRojo.cambiar(paquete.activo()));
        HudRenderCallback.EVENT.register(BordeRojo::render);
        HudRenderCallback.EVENT.register(AlmasHud::render);
        HudRenderCallback.EVENT.register(TvOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.MuertePayload.ID,
                (paquete, contexto) -> MuerteOverlay.iniciar(paquete.nombre()));
        HudRenderCallback.EVENT.register(MuerteOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BlancoPayload.ID,
                (paquete, contexto) -> BlancoOverlay.iniciar(paquete.ticks()));
        HudRenderCallback.EVENT.register(BlancoOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.ManipuladoPayload.ID,
                (paquete, contexto) -> Manipulacion.iniciar(paquete.entidad(), paquete.ticks()));
        HudRenderCallback.EVENT.register(Manipulacion::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.BancoPayload.ID, (paquete, contexto) -> {
            BancoScreen.saldo = paquete.saldo();
            if (paquete.abrir()) contexto.client().setScreen(new BancoScreen());
        });
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.MisionesPayload.ID,
                (paquete, contexto) -> MisionesCliente.actualizar(paquete.json()));
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.SustoPayload.ID,
                (paquete, contexto) -> SustoOverlay.iniciar(paquete.ticks()));
        HudRenderCallback.EVENT.register(SustoOverlay::render);
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.InvertidoPayload.ID,
                (paquete, contexto) -> ControlesInvertidos.iniciar(paquete.ticks()));
        ClientTickEvents.END_CLIENT_TICK.register(cliente -> {
            TvOverlay.tick();
            BordeRojo.tick();
            MuerteOverlay.tick();
            BlancoOverlay.tick();
            Manipulacion.tick();
            while (TECLA_MISIONES.wasPressed()) {
                if (cliente.currentScreen == null) cliente.setScreen(new MisionesScreen());
            }
            SustoOverlay.tick();
            ControlesInvertidos.tick();
        });
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.agua.PulpoEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo propio del Pulpo (textura 64x64, box UV). Mismo marco que el calamar vanilla (para usar sus giros al nadar):
 * <pre>
 * manto      (0,0)   10x12x10, pivote (0,8,0), caja (-5,-6,-5)  — cabeza bulbosa
 * coronilla  (0,22)   8x3x8,   encima del manto
 * ojos       (40,0)   2x2x1,   a los lados del frente (-z)
 * 8 brazos de 3 tramos (se curvan): (0,34) 3x6x3, (12,34) 2x6x2, (20,34) 1x5x1, en círculo de radio 3,5 bajo el manto
 * </pre>
 */
public class PulpoModel extends SinglePartEntityModel<PulpoEntity> {
    public static final EntityModelLayer CAPA = new EntityModelLayer(Desinformados.id("pulpo"), "main");

    private final ModelPart raiz;
    private final ModelPart manto;
    private final ModelPart[][] brazos = new ModelPart[8][3];

    public PulpoModel(ModelPart raiz) {
        this.raiz = raiz;
        this.manto = raiz.getChild("body");
        for (int i = 0; i < 8; i++) {
            brazos[i][0] = raiz.getChild("tentacle" + i);
            brazos[i][1] = brazos[i][0].getChild("mid");
            brazos[i][2] = brazos[i][1].getChild("tip");
        }
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData datos = new ModelData();
        ModelPartData raiz = datos.getRoot();
        ModelPartData cuerpo = raiz.addChild("body", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-5f, -6f, -5f, 10f, 12f, 10f)
                        .uv(0, 22).cuboid(-4f, -9f, -4f, 8f, 3f, 8f),
                ModelTransform.pivot(0f, 8f, 0f));
        cuerpo.addChild("eyes", ModelPartBuilder.create()
                        .uv(40, 0).cuboid(-4.5f, 1f, -5.6f, 2f, 2f, 1f)
                        .uv(40, 0).mirrored().cuboid(2.5f, 1f, -5.6f, 2f, 2f, 1f),
                ModelTransform.NONE);
        for (int i = 0; i < 8; i++) {
            double d = i * Math.PI * 2.0 / 8;
            float x = (float) Math.cos(d) * 3.5f, z = (float) Math.sin(d) * 3.5f;
            float yaw = (float) (i * Math.PI * -2.0 / 8 + Math.PI / 2);
            ModelPartData base = raiz.addChild("tentacle" + i, ModelPartBuilder.create()
                    .uv(0, 34).cuboid(-1.5f, 0f, -1.5f, 3f, 6f, 3f), ModelTransform.of(x, 13.5f, z, 0f, yaw, 0f));
            ModelPartData medio = base.addChild("mid", ModelPartBuilder.create()
                    .uv(12, 34).cuboid(-1f, 0f, -1f, 2f, 6f, 2f), ModelTransform.pivot(0f, 5.5f, 0f));
            medio.addChild("tip", ModelPartBuilder.create()
                    .uv(20, 34).cuboid(-0.5f, 0f, -0.5f, 1f, 5f, 1f), ModelTransform.pivot(0f, 5.5f, 0f));
        }
        return TexturedModelData.of(datos, 64, 64);
    }

    @Override
    public ModelPart getPart() {
        return raiz;
    }

    /** animationProgress = ángulo de los tentáculos del calamar (se abren al impulsarse); además cada brazo se ondula. */
    @Override
    public void setAngles(PulpoEntity e, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        float t = e.age;
        for (int i = 0; i < 8; i++) {
            float onda = MathHelper.sin(t * 0.12f + i * 0.9f);
            brazos[i][0].pitch = animationProgress * 0.9f + 0.15f;
            brazos[i][1].pitch = animationProgress * 0.5f + onda * 0.25f + 0.2f;
            brazos[i][2].pitch = animationProgress * 0.4f + MathHelper.sin(t * 0.12f + i * 0.9f - 1.2f) * 0.35f + 0.35f;   // las puntas se enroscan
        }
        manto.yScale = 1f + MathHelper.sin(t * 0.08f) * 0.03f;                         // "respira"
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.IntroFinPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.List;
import java.util.Random;

/**
 * Cinemática de bienvenida (sin mods extra):
 * 1. Clic en la tele: estática en toda la pantalla.
 * 2. La foto de El Gato en medio, con señal débil, explica la situación.
 * 3. "Te transportaré al Centro en 5... 4... 3..." y la señal se rompe: 5 s de estática.
 * 4. Pantalla en blanco + canción. A los 3 s aparece el título DESINFORMADOS animado.
 *    La canción baja de volumen desde los 17 s hasta el silencio a los 24 s.
 * 5. A los 24 s se esfuma el título y el blanco se desvanece: ya estás en el Centro.
 * No se puede saltar ni cerrar con ESC.
 */
public class IntroScreen extends Screen {
    private static final Identifier GATO = Desinformados.id("textures/gui/intro_gato.png");
    private static final Random R = new Random();

    /** Lo que dice El Gato. La última es la cuenta atrás, cuando la señal se rompe. */
    private static final String[] GUION = {
            "¿Me escuchan? ...Bien. Logré tener señal con ustedes.",
            "Soy El Gato, del Centro de Desinformación. Escuchen: el mundo está en peligro.",
            "El Reactor de la Desinformación ha sido dañado... y una tele apareció.",
            "Está generando desinformaciones que afectan al mundo de formas muy raras.",
            "Estoy tratando de investigarla. Así fue como logré contactarlos.",
            "No puedo mantener la señal mucho tiempo... y necesito que me ayuden.",
            "Vale, no tenemos mucho tiempo. Te transportaré al Centro de Desinformación en 5... 4... 3...",
    };

    private static final float LETRAS_POR_TICK = 1.2f;
    private static final int PAUSA = 40;

    private static final int ESTATICA_INICIO = 45;   // estática sola al darle clic
    private static final int APARECE = 70;           // el gato termina de aparecer
    private static final int ESTATICA_FINAL = 100;   // 5 s de estática cuando se rompe la señal

    // Fase blanca (contada desde que la pantalla se pone en blanco)
    private static final int TITULO = 60;            // 3 s: sale el título
    private static final int FIN_CANCION = 480;      // 24 s: se acaba todo
    private static final int ESFUMAR_TITULO = 20;    // el título se esfuma en 1 s
    private static final int DESVANECER = 35;        // el blanco se desvanece en ~1,75 s

    private final int[] inicioLinea = new int[GUION.length];
    private final int finDialogo, blanco, finTotal;
    private int ticks = 0;
    private boolean avisado = false;

    public IntroScreen() {
        super(Text.literal("Desinformados"));
        int t = APARECE + 5;
        for (int i = 0; i < GUION.length; i++) {
            inicioLinea[i] = t;
            int escribir = (int) (GUION[i].length() / LETRAS_POR_TICK);
            t += escribir + (i == GUION.length - 1 ? 10 : PAUSA);
        }
        finDialogo = t;
        blanco = finDialogo + ESTATICA_FINAL;
        finTotal = blanco + FIN_CANCION + DESVANECER;
    }

    // ---- Ya en el Centro: el blanco se queda en el HUD y se desvanece ----
    private static int salida = -1;
    private static int esperaSalida = 0;

    public static void registrar() {
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (salida < 0) return;
            boolean llegado = mc.world != null && mc.currentScreen == null
                    && mc.world.getRegistryKey() != com.centrodesinformacion.desinformados.intro.Intro.CUARTO;
            if (llegado || ++esperaSalida > 200) salida++;      // empieza a desvanecerse cuando ya cargó el Centro
            if (salida > DESVANECER) salida = -1;
        });
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((ctx, contador) -> {
            if (salida < 0) return;
            float a = MathHelper.clamp(1f - (salida + (salida > 0 ? contador.getTickDelta(false) : 0f)) / DESVANECER, 0f, 1f);
            ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), ((int) (a * 255) << 24) | 0xFFFFFF);
        });
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { }

    private static void sonar(SoundEvent s, float tono, float volumen) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(s, tono, volumen));
    }

    private int lineaActual() {
        for (int i = GUION.length - 1; i >= 0; i--) if (ticks >= inicioLinea[i]) return i;
        return -1;
    }

    @Override
    public void tick() {
        ticks++;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ticks == 1) {
            mc.getMusicTracker().stop();
            sonar(ModSounds.TV_ESTATICA, 1f, 1f);
        }
        if (ticks == ESTATICA_INICIO) sonar(ModSounds.TV_ESTATICA, 0.8f, 0.7f);
        for (int i = 0; i < GUION.length; i++) {
            int dt = ticks - inicioLinea[i];
            if (dt >= 0 && dt % 40 == 0 && dt < GUION[i].length() / LETRAS_POR_TICK) sonar(ModSounds.GATO_VOZ, 1f, 1f);
        }
        // La señal se rompe: 5 s de estática con chasquidos
        if (ticks >= finDialogo && ticks < blanco) {
            int dt = ticks - finDialogo;
            if (dt % 30 == 0) sonar(ModSounds.TV_ESTATICA, 0.5f + R.nextFloat() * 0.6f, 1f);
            if (dt == 0) sonar(SoundEvents.BLOCK_LEVER_CLICK, 0.5f, 1f);
            if (R.nextInt(12) == 0) sonar(SoundEvents.BLOCK_REDSTONE_TORCH_BURNOUT, 0.8f + R.nextFloat(), 0.4f);
        }
        if (ticks == blanco) {
            mc.getMusicTracker().stop();
            sonar(ModSounds.INTRO_CANCION, 1f, 0.6f);
        }
        // Al terminar la canción (24 s) y con todo en blanco, el servidor te lleva al Centro.
        // El blanco sigue en el HUD y se desvanece cuando ya estás allí.
        if (ticks >= blanco + FIN_CANCION && !avisado) {
            avisado = true;
            salida = 0;
            esperaSalida = 0;
            if (ClientPlayNetworking.canSend(IntroFinPayload.ID)) ClientPlayNetworking.send(new IntroFinPayload(0));
            mc.setScreen(null);
        }
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float t = ticks + delta;
        int w = this.width, h = this.height;
        TextRenderer tr = this.textRenderer;

        if (t >= blanco) {
            dibujarBlanco(ctx, tr, t - blanco, w, h);
            return;
        }
        ctx.fill(0, 0, w, h, 0xFF000000);
        if (t < ESTATICA_INICIO) {
            estatica(ctx, w, h, 255);
            return;
        }
        if (t >= finDialogo) {
            // 5 s de estática con glitches
            estatica(ctx, w, h, 255);
            desgarros(ctx, w, h, 1f);
            if (R.nextInt(6) == 0) ctx.fill(0, 0, w, h, R.nextBoolean() ? 0x30FF0000 : 0x3000FFFF);
            return;
        }

        int li = lineaActual();
        boolean ultima = li == GUION.length - 1;
        // Qué tan mala está la señal: al aparecer, un poco al hablar, y cada vez peor en la cuenta atrás
        float ruido = 0.18f + 0.06f * MathHelper.sin(t * 0.3f);
        if (t < APARECE) ruido = MathHelper.lerp((t - ESTATICA_INICIO) / (APARECE - ESTATICA_INICIO), 1f, ruido);
        float avance = ultima ? MathHelper.clamp((t - inicioLinea[li]) / (finDialogo - inicioLinea[li]), 0f, 1f) : 0f;
        if (ultima) ruido = MathHelper.lerp(avance * avance, ruido, 0.85f);
        boolean corte = R.nextInt(Math.max(2, (int) (40 * (1f - ruido)))) == 0;

        // Foto de El Gato en medio
        boolean hablando = li >= 0 && (t - inicioLinea[li]) < GUION[li].length() / LETRAS_POR_TICK;
        float lado = Math.min(w, h) * 0.55f;
        float estirar = hablando ? 0.03f * Math.abs(MathHelper.sin(t * 0.9f)) : 0f;
        float temblor = ruido > 0.3f || corte ? (R.nextFloat() * 2 - 1) * ruido * 12f : 0f;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(w / 2f + temblor, h * 0.42f + (ultima && R.nextInt(8) == 0 ? R.nextFloat() * 10 - 5 : 0), 0);
        m.scale(lado / 256f * (1f - estirar * 0.5f), lado / 256f * (1f + estirar), 1f);
        if (!corte) ctx.drawTexture(GATO, -128, -128, 256, 256, 0, 0, 256, 256, 256, 256);
        m.pop();

        estatica(ctx, w, h, (int) (ruido * 255));
        for (int y = 0; y < h; y += 3) ctx.fill(0, y, w, y + 1, 0x38000000);
        for (int i = 0; i < 3; i++) {
            if (R.nextFloat() < ruido) {
                int y = R.nextInt(h);
                ctx.fill(0, y, w, y + 1 + R.nextInt(3), 0x40FFFFFF);
            }
        }
        if (ultima) desgarros(ctx, w, h, avance);
        vineta(ctx, w, h);

        int barras = ruido > 0.6f ? 1 : ruido > 0.3f ? 2 : 3;
        for (int i = 0; i < 3; i++) {
            int x = 14 + i * 5, alto = 4 + i * 3;
            ctx.fill(x, 26 - alto, x + 3, 26, i < barras ? 0xFF39FF5A : 0x40FFFFFF);
        }
        ctx.drawText(tr, Text.literal("SEÑAL DÉBIL"), 32, 18, ((int) t / 10) % 2 == 0 ? 0xFF39FF5A : 0x8039FF5A, true);

        if (li >= 0) dibujarSubtitulo(ctx, tr, t, li, w, h, ruido);
    }

    private void dibujarSubtitulo(DrawContext ctx, TextRenderer tr, float t, int li, int w, int h, float ruido) {
        float dt = t - inicioLinea[li];
        int n = MathHelper.clamp((int) (dt * LETRAS_POR_TICK), 0, GUION[li].length());
        String texto = GUION[li].substring(0, n);
        if (ruido > 0.45f) {
            StringBuilder sb = new StringBuilder();
            for (char c : texto.toCharArray()) sb.append(c != ' ' && R.nextFloat() < (ruido - 0.4f) * 0.5f ? "#%&@/?".charAt(R.nextInt(6)) : c);
            texto = sb.toString();
        }
        int ancho = Math.min(w - 40, 340);
        int x = (w - ancho) / 2 + (ruido > 0.5f && R.nextInt(4) == 0 ? R.nextInt(5) - 2 : 0);
        int y = Math.min((int) (h * 0.42f + Math.min(w, h) * 0.275f) + 8, h - 52);
        ctx.fill(x - 1, y - 1, x + ancho + 1, y + 45, 0xFF39FF5A);
        ctx.fill(x, y, x + ancho, y + 44, 0xF0101010);
        ctx.drawText(tr, Text.literal("El Gato").formatted(Formatting.BOLD), x + 8, y + 6, 0xFF39FF5A, true);
        List<OrderedText> lineas = tr.wrapLines(Text.literal(texto), ancho - 16);
        for (int i = 0; i < Math.min(2, lineas.size()); i++) {
            ctx.drawText(tr, lineas.get(i), x + 8, y + 19 + i * 11, 0xFFEFEFEF, true);
        }
    }

    // ------------------------------------------------------------------ fase blanca: canción y título

    private void dibujarBlanco(DrawContext ctx, TextRenderer tr, float dt, int w, int h) {
        // Blanco total mientras suena la canción
        ctx.fill(0, 0, w, h, 0xFFFFFFFF);
        // Últimos restos de estática al empezar el blanco
        if (dt < 8) estatica(ctx, w, h, (int) ((1f - dt / 8f) * 255));

        float tt = dt - TITULO;
        if (tt < 0) return;
        float alfa = dt < FIN_CANCION - ESFUMAR_TITULO ? 1f
                : MathHelper.clamp(1f - (dt - (FIN_CANCION - ESFUMAR_TITULO)) / ESFUMAR_TITULO, 0f, 1f);
        if (alfa <= 0.02f) return;
        dibujarTitulo(ctx, tr, tt, w, h, alfa);
    }

    /** "DESINFORMADOS" con la fuente de Minecraft: las letras caen una a una con rebote y luego flotan. */
    private static void dibujarTitulo(DrawContext ctx, TextRenderer tr, float tt, int w, int h, float alfa) {
        String titulo = "DESINFORMADOS";
        float escala = Math.min(w * 0.7f / tr.getWidth(titulo), 7f);
        float esfumar = 1f + (1f - alfa) * 0.15f;                 // al esfumarse crece un poquito
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(w / 2f, h * 0.42f, 0);
        m.scale(escala * esfumar, escala * esfumar, 1f);
        int x = -tr.getWidth(titulo) / 2;
        int a = Math.max(4, (int) (alfa * 255));
        boolean glitch = R.nextInt(25) == 0;
        for (int i = 0; i < titulo.length(); i++) {
            String letra = String.valueOf(titulo.charAt(i));
            int ancho = tr.getWidth(letra);
            float lt = tt - i * 3f;                                // cada letra entra 3 ticks después que la anterior
            if (lt > 0) {
                float caida = MathHelper.clamp(lt / 14f, 0f, 1f);
                float y = -18f * (1f - rebote(caida));             // cae desde arriba y rebota
                if (caida >= 1f) y = MathHelper.sin((tt * 0.12f) + i * 0.55f) * 0.8f;   // flota suave
                float rot = (1f - caida) * (i % 2 == 0 ? -25f : 25f);
                int aLetra = Math.max(4, (int) (a * MathHelper.clamp(lt / 5f, 0f, 1f)));
                m.push();
                m.translate(x + ancho / 2f, y, 0);
                m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(rot));
                float jx = glitch ? R.nextFloat() * 2f - 1f : 0f;
                // separación de colores (rojo / cian) y la letra principal en negro
                ctx.drawText(tr, letra, (int) (-ancho / 2f + 0.7f + jx), -4, (Math.max(4, aLetra * 2 / 3) << 24) | 0xFF3030, false);
                ctx.drawText(tr, letra, (int) (-ancho / 2f - 0.7f - jx), -4, (Math.max(4, aLetra * 2 / 3) << 24) | 0x20C8FF, false);
                ctx.drawText(tr, letra, (int) (-ancho / 2f), -4, (aLetra << 24) | 0x151515, false);
                m.pop();
            }
            x += ancho;
        }
        m.pop();

        // Subtítulo, cuando ya cayeron todas las letras
        float sub = tt - (titulo.length() * 3f + 25f);
        if (sub > 0) {
            int as = Math.max(4, (int) (alfa * MathHelper.clamp(sub / 20f, 0f, 1f) * 255));
            Text texto = Text.literal("Una serie del Centro de Desinformación");
            m.push();
            m.translate(w / 2f, h * 0.42f + 7 * escala, 0);
            m.scale(1.3f, 1.3f, 1f);
            ctx.drawText(tr, texto, -tr.getWidth(texto) / 2, 0, (as << 24) | 0x555555, false);
            m.pop();
        }
    }

    private static float rebote(float x) {
        float n = 7.5625f, d = 2.75f;
        if (x < 1f / d) return n * x * x;
        if (x < 2f / d) { x -= 1.5f / d; return n * x * x + 0.75f; }
        if (x < 2.5f / d) { x -= 2.25f / d; return n * x * x + 0.9375f; }
        x -= 2.625f / d;
        return n * x * x + 0.984375f;
    }

    // ------------------------------------------------------------------ utilidades

    private static void estatica(DrawContext ctx, int w, int h, int alfa) {
        Ruido.dibujar(ctx, 0, 0, w, h, alfa / 255f, 4);
    }

    private static void desgarros(DrawContext ctx, int w, int h, float fuerza) {
        int n = (int) (2 + fuerza * 8);
        for (int i = 0; i < n; i++) {
            if (R.nextFloat() > 0.3f + fuerza * 0.5f) continue;
            int y = R.nextInt(h);
            int alto = 1 + R.nextInt(2 + (int) (fuerza * 10));
            int color = switch (R.nextInt(3)) { case 0 -> 0x66FF2020; case 1 -> 0x5520E0FF; default -> 0x55FFFFFF; };
            ctx.fill(0, y, w, y + alto, color);
        }
    }

    private static void vineta(DrawContext ctx, int w, int h) {
        for (int i = 0; i < 12; i++) {
            int c = ((12 - i) * 10) << 24;
            int g = i * 3;
            ctx.fill(0, g, w, g + 3, c);
            ctx.fill(0, h - g - 3, w, h - g, c);
            ctx.fill(g, 0, g + 3, h, c);
            ctx.fill(w - g - 3, 0, w - g, h, c);
        }
    }
}

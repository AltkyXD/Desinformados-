package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.ModSounds;
import com.centrodesinformacion.desinformados.network.IntroFinPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.List;
import java.util.Random;

/**
 * Cinemática de bienvenida (sin mods extra):
 * clic en la tele -> estática en toda la pantalla -> la foto de El Gato en medio, con señal débil,
 * avisando que el mundo está en peligro -> la señal se cae, estática total -> apareces en el Centro
 * -> unos 2 segundos después sale el nombre de la serie: DESINFORMADOS.
 * No se puede saltar ni cerrar con ESC.
 */
public class IntroScreen extends Screen {
    private static final Identifier GATO = Desinformados.id("textures/gui/intro_gato.png");
    private static final Random R = new Random();

    /** Lo que dice El Gato. La última línea es cuando la señal se le está cayendo. */
    private static final String[] GUION = {
            "¿Me escuchan? ...Bien. Logré tener señal con ustedes.",
            "Soy El Gato, del Centro de Desinformación. Escuchen: el mundo está en peligro.",
            "El Reactor de la Desinformación ha sido dañado... y una tele apareció.",
            "Está generando desinformaciones que afectan al mundo de formas muy raras.",
            "Estoy tratando de investigarla. Así fue como logré contactarlos.",
            "No puedo mantener la señal mucho tiempo, así que solo les diré esto...",
            "Necesito que me ayuden. Por fav—",
    };

    private static final float LETRAS_POR_TICK = 1.2f;
    private static final int PAUSA = 40;

    private static final int ESTATICA_INICIO = 45;   // estática sola al darle clic
    private static final int APARECE = 70;           // el gato termina de aparecer
    private static final int ESTATICA_FINAL = 55;    // estática total cuando se cae la señal

    private final int[] inicioLinea = new int[GUION.length];
    private final int finDialogo, finTotal;
    private int ticks = 0;
    private boolean avisado = false;

    // ---- Lo que pasa ya en el Centro (se dibuja en el HUD) ----
    private static int salida = -1;
    private static final int SALIDA_ESTATICA = 20;          // la estática se desvanece
    private static final int SALIDA_TITULO = SALIDA_ESTATICA + 40; // ~2 s después sale el título
    private static final int SALIDA_FIN = SALIDA_TITULO + 150;

    public IntroScreen() {
        super(Text.literal("Desinformados"));
        int t = APARECE + 5;
        for (int i = 0; i < GUION.length; i++) {
            inicioLinea[i] = t;
            int escribir = (int) (GUION[i].length() / LETRAS_POR_TICK);
            t += escribir + (i == GUION.length - 1 ? 6 : PAUSA);   // la última se corta de golpe
        }
        finDialogo = t;
        finTotal = finDialogo + ESTATICA_FINAL;
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { }

    private static void sonar(SoundEvent s, float tono, float volumen) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(s, tono, volumen));
    }

    private int lineaActual() {
        for (int i = GUION.length - 1; i >= 0; i--) if (ticks >= inicioLinea[i]) return i;
        return -1;
    }

    @Override
    public void tick() {
        ticks++;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ticks == 1) {
            mc.getMusicTracker().stop();
            sonar(ModSounds.TV_ESTATICA, 1f, 1f);
        }
        if (ticks == ESTATICA_INICIO) sonar(ModSounds.TV_ESTATICA, 0.8f, 0.7f);
        for (int i = 0; i < GUION.length; i++) {
            int dt = ticks - inicioLinea[i];
            if (dt >= 0 && dt % 40 == 0 && dt < GUION[i].length() / LETRAS_POR_TICK) sonar(ModSounds.GATO_VOZ, 1f, 1f);
        }
        if (ticks == finDialogo) {
            sonar(ModSounds.TV_ESTATICA, 0.6f, 1f);
            sonar(SoundEvents.BLOCK_LEVER_CLICK, 0.5f, 1f);
        }
        // A mitad de la estática final el servidor te lleva al Centro (no se ve el viaje)
        if (ticks >= finDialogo + 20 && !avisado) {
            avisado = true;
            if (ClientPlayNetworking.canSend(IntroFinPayload.ID)) ClientPlayNetworking.send(new IntroFinPayload(0));
        }
        if (ticks >= finTotal) {
            salida = 0;
            mc.setScreen(null);
        }
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float t = ticks + delta;
        int w = this.width, h = this.height;
        TextRenderer tr = this.textRenderer;
        ctx.fill(0, 0, w, h, 0xFF000000);

        if (t < ESTATICA_INICIO || t >= finDialogo) {
            estatica(ctx, w, h, 255);
            return;
        }

        int li = lineaActual();
        // Qué tan mala está la señal: al aparecer, un poco durante la charla y mucho en la última línea
        float ruido = 0.18f + 0.06f * MathHelper.sin(t * 0.3f);
        if (t < APARECE) ruido = MathHelper.lerp((t - ESTATICA_INICIO) / (APARECE - ESTATICA_INICIO), 1f, ruido);
        if (li == GUION.length - 1) ruido = MathHelper.lerp(MathHelper.clamp((t - inicioLinea[li]) / (finDialogo - inicioLinea[li]), 0f, 1f), ruido, 0.9f);
        boolean corte = R.nextInt(Math.max(2, (int) (40 * (1f - ruido)))) == 0;   // micro cortes de señal

        // Foto de El Gato en medio
        boolean hablando = li >= 0 && (t - inicioLinea[li]) < GUION[li].length() / LETRAS_POR_TICK;
        float lado = Math.min(w, h) * 0.55f;
        float estirar = hablando ? 0.03f * Math.abs(MathHelper.sin(t * 0.9f)) : 0f;
        float temblor = ruido > 0.3f || corte ? (R.nextFloat() * 2 - 1) * ruido * 10f : 0f;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(w / 2f + temblor, h * 0.42f, 0);
        m.scale(lado / 256f * (1f - estirar * 0.5f), lado / 256f * (1f + estirar), 1f);
        if (!corte) ctx.drawTexture(GATO, -128, -128, 256, 256, 0, 0, 256, 256, 256, 256);
        m.pop();

        // Señal débil encima
        estatica(ctx, w, h, (int) (ruido * 255));
        for (int y = 0; y < h; y += 3) ctx.fill(0, y, w, y + 1, 0x38000000);           // líneas de tele
        for (int i = 0; i < 3; i++) {                                                     // franjas que pasan
            if (R.nextFloat() < ruido) {
                int y = R.nextInt(h);
                ctx.fill(0, y, w, y + 1 + R.nextInt(3), 0x40FFFFFF);
            }
        }
        vineta(ctx, w, h);

        // Indicador de señal
        int barras = ruido > 0.6f ? 1 : ruido > 0.3f ? 2 : 3;
        for (int i = 0; i < 3; i++) {
            int x = 14 + i * 5, alto = 4 + i * 3;
            ctx.fill(x, 26 - alto, x + 3, 26, i < barras ? 0xFF39FF5A : 0x40FFFFFF);
        }
        ctx.drawText(tr, Text.literal("SEÑAL DÉBIL"), 32, 18, ((int) t / 10) % 2 == 0 ? 0xFF39FF5A : 0x8039FF5A, true);

        if (li >= 0) dibujarSubtitulo(ctx, tr, t, li, w, h, ruido);
    }

    private void dibujarSubtitulo(DrawContext ctx, TextRenderer tr, float t, int li, int w, int h, float ruido) {
        float dt = t - inicioLinea[li];
        int n = MathHelper.clamp((int) (dt * LETRAS_POR_TICK), 0, GUION[li].length());
        String texto = GUION[li].substring(0, n);
        if (ruido > 0.45f) {   // la señal se cae: las letras se rompen
            StringBuilder sb = new StringBuilder();
            for (char c : texto.toCharArray()) sb.append(c != ' ' && R.nextFloat() < (ruido - 0.4f) * 0.5f ? "#%&@/?".charAt(R.nextInt(6)) : c);
            texto = sb.toString();
        }
        int ancho = Math.min(w - 40, 340);
        int x = (w - ancho) / 2;
        int y = (int) (h * 0.42f + Math.min(w, h) * 0.275f) + 8;
        y = Math.min(y, h - 52);
        ctx.fill(x - 1, y - 1, x + ancho + 1, y + 45, 0xFF39FF5A);
        ctx.fill(x, y, x + ancho, y + 44, 0xF0101010);
        ctx.drawText(tr, Text.literal("El Gato").formatted(Formatting.BOLD), x + 8, y + 6, 0xFF39FF5A, true);
        List<OrderedText> lineas = tr.wrapLines(Text.literal(texto), ancho - 16);
        for (int i = 0; i < Math.min(2, lineas.size()); i++) {
            ctx.drawText(tr, lineas.get(i), x + 8, y + 19 + i * 11, 0xFFEFEFEF, true);
        }
    }

    // ------------------------------------------------------------------ ya en el Centro

    public static void registrar() {
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (salida < 0) return;
            salida++;
            if (salida == SALIDA_TITULO) sonar(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            if (salida > SALIDA_FIN) salida = -1;
        });
        HudRenderCallback.EVENT.register((ctx, contador) -> {
            if (salida < 0) return;
            float s = salida + contador.getTickDelta(false);
            int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
            if (s < SALIDA_ESTATICA) estatica(ctx, w, h, (int) ((1f - s / SALIDA_ESTATICA) * 255));
            if (s >= SALIDA_TITULO) dibujarTitulo(ctx, MinecraftClient.getInstance().textRenderer, s - SALIDA_TITULO, w, h);
        });
    }

    private static void dibujarTitulo(DrawContext ctx, TextRenderer tr, float dt, int w, int h) {
        float dura = SALIDA_FIN - SALIDA_TITULO;
        float alfa = MathHelper.clamp(Math.min(dt / 10f, (dura - dt) / 25f), 0f, 1f);
        if (alfa <= 0.02f) return;
        String titulo = "DESINFORMADOS";
        int letras = MathHelper.clamp((int) (dt / 2f) + 1, 0, titulo.length());
        String visible = titulo.substring(0, letras);
        float escala = Math.min(w * 0.6f / tr.getWidth(titulo), 6f);
        boolean salto = R.nextInt(10) == 0;
        float jx = salto ? R.nextFloat() * 6 - 3 : 0;
        int a = Math.max(4, (int) (alfa * 255));
        int aColor = Math.max(4, (int) (alfa * 170));

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(w / 2f, h * 0.3f, 0);
        m.scale(escala, escala, 1f);
        int x0 = -tr.getWidth(titulo) / 2;
        float sep = salto ? 1.5f : 0.6f;
        ctx.drawText(tr, visible, (int) (x0 + sep + jx), -4, (aColor << 24) | 0xFF2020, false);
        ctx.drawText(tr, visible, (int) (x0 - sep + jx), -4, (aColor << 24) | 0x20FFFF, false);
        ctx.drawText(tr, visible, x0, -4, (a << 24) | 0xFFFFFF, true);
        m.pop();

        if (dt > 35) {
            int a2 = Math.max(4, (int) (alfa * MathHelper.clamp((dt - 35) / 15f, 0f, 1f) * 255));
            Text sub = Text.literal("Una serie del Centro de Desinformación");
            m.push();
            m.translate(w / 2f, h * 0.3f + 7 * escala, 0);
            m.scale(1.2f, 1.2f, 1f);
            ctx.drawText(tr, sub, -tr.getWidth(sub) / 2, 0, (a2 << 24) | 0xDDDDDD, true);
            m.pop();
        }
    }

    // ------------------------------------------------------------------ utilidades

    /** Estática en toda la pantalla con la opacidad dada (0-255). */
    private static void estatica(DrawContext ctx, int w, int h, int alfa) {
        if (alfa <= 0) return;
        int celda = 4;
        for (int x = 0; x < w; x += celda) {
            for (int y = 0; y < h; y += celda) {
                int g = R.nextInt(256);
                ctx.fill(x, y, x + celda, y + celda, (alfa << 24) | (g << 16) | (g << 8) | g);
            }
        }
    }

    private static void vineta(DrawContext ctx, int w, int h) {
        for (int i = 0; i < 12; i++) {
            int c = ((12 - i) * 10) << 24;
            int g = i * 3;
            ctx.fill(0, g, w, g + 3, c);
            ctx.fill(0, h - g - 3, w, h - g, c);
            ctx.fill(g, 0, g + 3, h, c);
            ctx.fill(w - g - 3, 0, w - g, h, c);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.entidad.agua.PulpoEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** El Pulpo con su modelo propio. Los giros al nadar son los del calamar vanilla (inclinación, balanceo y tentáculos). */
public class PulpoRenderer extends MobEntityRenderer<PulpoEntity, PulpoModel> {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/pulpo.png");

    public PulpoRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PulpoModel(ctx.getPart(PulpoModel.CAPA)), 0.7f);
    }

    @Override
    public Identifier getTexture(PulpoEntity e) {
        return TEXTURA;
    }

    @Override
    protected void setupTransforms(PulpoEntity e, MatrixStack m, float animationProgress, float bodyYaw, float tickDelta, float scale) {
        float inclinacion = MathHelper.lerp(tickDelta, e.prevTiltAngle, e.tiltAngle);
        float giro = MathHelper.lerp(tickDelta, e.prevRollAngle, e.rollAngle);
        m.translate(0f, 0.5f, 0f);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - bodyYaw));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(inclinacion));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(giro));
        m.translate(0f, -1.2f, 0f);
    }

    @Override
    protected float getAnimationProgress(PulpoEntity e, float tickDelta) {
        return MathHelper.lerp(tickDelta, e.prevTentacleAngle, e.tentacleAngle);
    }
}

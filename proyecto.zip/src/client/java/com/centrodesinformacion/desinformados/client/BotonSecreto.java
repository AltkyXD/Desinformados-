package com.centrodesinformacion.desinformados.client;

/**
 * Botón secreto para saltar la intro y el final: 3 clics seguidos (en menos de 2 s) en la esquina
 * de arriba a la derecha de la pantalla (un cuadradito invisible de 16x16). No se dibuja nada.
 */
final class BotonSecreto {
    private static final int LADO = 16;
    private static final int CLICS = 3;
    private static final long VENTANA_MS = 2000;

    private int clics = 0;
    private long primero = 0;

    /** Cuenta un clic; true cuando ya van 3 seguidos en la esquina. */
    boolean clic(double mx, double my, int ancho) {
        if (mx < ancho - LADO || my > LADO) { clics = 0; return false; }
        long ahora = System.currentTimeMillis();
        if (clics == 0 || ahora - primero > VENTANA_MS) { clics = 0; primero = ahora; }
        return ++clics >= CLICS;
    }
}

package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.Random;

/**
 * Eliminación definitiva: una tele cae desde arriba al centro de la pantalla,
 * se parte en dos al impactar (sonido del rayo del warden) y aparece el nombre del eliminado.
 */
public class MuerteOverlay {
    private static final int CAIDA = 18;      // ticks que tarda en caer
    private static final int DURACION = 140;  // 7 segundos
    private static final Random RANDOM = new Random();

    // La tele como lista de rectángulos: x1, y1, x2, y2, color
    private static final int[][] TELE = {
            {-8, -64, 8, -58, 0xFF2B2B2B},
            {-62, 58, -50, 70, 0xFF3E2723}, {50, 58, 62, 70, 0xFF3E2723},
            {-84, -60, 84, 60, 0xFF3E2723}, {-80, -56, 80, 56, 0xFF6D4C41},
            {-72, -48, 48, 48, 0xFF1A1A1A}, {-68, -44, 44, 44, 0xFF0D0D0D},
            {56, -40, 72, -24, 0xFF212121}, {62, -38, 66, -30, 0xFFBDBDBD},
            {56, -16, 72, 0, 0xFF212121}, {62, -14, 66, -6, 0xFFBDBDBD},
    };

    private static String nombre = null;
    private static int ticks = 0;

    public static void iniciar(String quien) {
        nombre = quien;
        ticks = 0;
    }

    public static void tick() {
        if (nombre == null) return;
        ticks++;
        if (ticks == CAIDA) {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f));
        }
        if (ticks >= DURACION) nombre = null;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (nombre == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float salida = MathHelper.clamp((DURACION - t) / 20f, 0f, 1f);

        // Fondo oscuro con destello rojo al impactar
        ctx.fill(0, 0, w, h, ((int) (170 * Math.min(1f, t / 8f) * salida)) << 24);
        if (t >= CAIDA && t < CAIDA + 10) {
            int a = (int) (160 * (1f - (t - CAIDA) / 10f));
            ctx.fill(0, 0, w, h, (a << 24) | 0xB00000);
        }

        int cx = w / 2, cy = h / 2 - 10;
        MatrixStack m = ctx.getMatrices();
        float escala = Math.min(1f, Math.min(w, h) / 260f);

        if (t < CAIDA) {
            // Cayendo con aceleración y girando un poco
            float k = t / CAIDA;
            float y = MathHelper.lerp(k * k, -h / 2f - 90, cy);
            m.push();
            m.translate(cx, y, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((1f - k) * 25f));
            m.scale(escala, escala, 1f);
            dibujarMitad(ctx, 0, t);
            m.pop();
        } else {
            // Partida en dos: cada mitad se separa, gira y cae
            float d = t - CAIDA;
            float temblor = d < 8 ? (8 - d) * 1.2f : 0f;
            for (int lado = -1; lado <= 1; lado += 2) {
                m.push();
                m.translate(cx + lado * d * 2.2f + (RANDOM.nextFloat() - 0.5f) * temblor,
                        cy + 0.12f * d * d + (RANDOM.nextFloat() - 0.5f) * temblor, 0);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(lado * d * 2.5f));
                m.scale(escala, escala, 1f);
                dibujarMitad(ctx, lado, t);
                m.pop();
            }

            // Nombre del eliminado
            if (d > 6) {
                float aparicion = MathHelper.clamp((d - 6) / 8f, 0f, 1f);
                int alfa = Math.max(4, (int) (255 * aparicion * salida));
                float s = 3f * (0.6f + 0.4f * aparicion) * Math.max(0.6f, escala);
                m.push();
                m.translate(cx, cy - 10, 0);
                m.scale(s, s, 1f);
                Text txt = Text.literal(nombre).formatted(Formatting.BOLD);
                ctx.drawText(tr, txt, -tr.getWidth(txt) / 2, -4, (alfa << 24) | 0xFF2A2A, true);
                m.pop();
                Text sub = Text.literal("HA SIDO DESINFORMADO").formatted(Formatting.BOLD);
                m.push();
                m.translate(cx, cy + 22, 0);
                m.scale(1.5f, 1.5f, 1f);
                ctx.drawText(tr, sub, -tr.getWidth(sub) / 2, -4, (alfa << 24) | 0xFFFFFF, true);
                m.pop();
            }
        }
    }

    /** lado: 0 = tele entera, -1 = mitad izquierda, 1 = mitad derecha (corte en zigzag). */
    private static void dibujarMitad(DrawContext ctx, int lado, float t) {
        for (int[] r : TELE) {
            for (int y = r[1]; y < r[3]; y += 4) {
                int y2 = Math.min(y + 4, r[3]);
                int corte = (y / 4) % 2 == 0 ? -3 : 3; // grieta en zigzag
                int x1 = r[0], x2 = r[2];
                if (lado < 0) x2 = Math.min(x2, corte);
                if (lado > 0) x1 = Math.max(x1, corte);
                if (x1 < x2) ctx.fill(x1, y, x2, y2, r[4]);
            }
        }
        // Estática en la pantalla mientras cae
        if (lado == 0) {
            for (int x = -68; x < 44; x += 4) {
                for (int y = -44; y < 44; y += 4) {
                    int g = RANDOM.nextInt(200);
                    ctx.fill(x, y, x + 4, y + 4, 0xFF000000 | (g << 16) | (g << 8) | g);
                }
            }
        }
    }
}

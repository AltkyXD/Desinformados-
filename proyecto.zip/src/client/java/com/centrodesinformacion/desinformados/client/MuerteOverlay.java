package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.Random;

/**
 * Eliminación definitiva: una tele cae desde arriba al centro de la pantalla,
 * se parte en dos al impactar (sonido del rayo del warden) y aparece el nombre del eliminado.
 */
public class MuerteOverlay {
    private static final int CAIDA = 18;      // ticks que tarda en caer
    private static final int DURACION = 140;  // 7 segundos
    private static final Random RANDOM = new Random();

    // La tele como lista de rectángulos: x1, y1, x2, y2, color
    private static final int[][] TELE = {
            {-14, -70, 14, -58, 0xFF2A2A2A},                                  // base de antena
            {-62, 58, -50, 72, 0xFF2E1A0E}, {50, 58, 62, 72, 0xFF2E1A0E},     // patas
            {-66, 72, -54, 75, 0xFFC9A44C}, {54, 72, 66, 75, 0xFFC9A44C},
            {-86, -62, 86, 62, 0xFF1E1008}, {-84, -60, 84, 60, 0xFF3B2213}, {-81, -57, 81, 57, 0xFF7B4A2A},
            {-76, -57, 76, -56, 0x40FFFFFF},
            {-75, -51, 51, 51, 0xFF5A5A5A}, {-74, -50, 50, 50, 0xFF9E9E9E}, {-68, -50, 44, -49, 0xFFE0E0E0},
            {-71, -47, 47, 47, 0xFF141414}, {-68, -44, 44, 44, 0xFF0D0D0D},
            {53, -51, 79, 51, 0xFF2E1A0E}, {54, -50, 78, 50, 0xFF4A2B17},
            {56, -47, 76, -41, 0xFFC9A44C},
            {59, -34, 73, -20, 0xFF1C1C1C}, {60, -33, 72, -21, 0xFF3A3A3A},
            {59, -15, 73, -1, 0xFF1C1C1C}, {60, -14, 72, -2, 0xFF3A3A3A},
            {55, 8, 77, 48, 0xFF1C110A},
            {57, 11, 75, 12, 0xFF6B4527}, {57, 17, 75, 18, 0xFF6B4527}, {57, 23, 75, 24, 0xFF6B4527},
            {57, 29, 75, 30, 0xFF6B4527}, {57, 35, 75, 36, 0xFF6B4527}, {57, 41, 75, 42, 0xFF6B4527},
    };

    private static String nombre = null;
    private static int ticks = 0;

    public static void iniciar(String quien) {
        nombre = quien;
        ticks = 0;
    }

    public static void tick() {
        if (nombre == null) return;
        ticks++;
        if (ticks == CAIDA) {
            MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f));
        }
        if (ticks >= DURACION) nombre = null;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        if (nombre == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        float t = ticks + contador.getTickDelta(false);
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float salida = MathHelper.clamp((DURACION - t) / 20f, 0f, 1f);

        // Fondo oscuro con destello rojo al impactar
        ctx.fill(0, 0, w, h, ((int) (170 * Math.min(1f, t / 8f) * salida)) << 24);
        if (t >= CAIDA && t < CAIDA + 10) {
            int a = (int) (160 * (1f - (t - CAIDA) / 10f));
            ctx.fill(0, 0, w, h, (a << 24) | 0xB00000);
        }

        int cx = w / 2, cy = h / 2 - 10;
        MatrixStack m = ctx.getMatrices();
        float escala = Math.min(1f, Math.min(w, h) / 260f);

        if (t < CAIDA) {
            // Cayendo con aceleración y girando un poco
            float k = t / CAIDA;
            float y = MathHelper.lerp(k * k, -h / 2f - 90, cy);
            m.push();
            m.translate(cx, y, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((1f - k) * 25f));
            m.scale(escala, escala, 1f);
            dibujarMitad(ctx, 0, t);
            m.pop();
        } else {
            // Partida en dos: cada mitad se separa, gira y cae
            float d = t - CAIDA;
            float temblor = d < 8 ? (8 - d) * 1.2f : 0f;
            for (int lado = -1; lado <= 1; lado += 2) {
                m.push();
                m.translate(cx + lado * d * 2.2f + (RANDOM.nextFloat() - 0.5f) * temblor,
                        cy + 0.12f * d * d + (RANDOM.nextFloat() - 0.5f) * temblor, 0);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(lado * d * 2.5f));
                m.scale(escala, escala, 1f);
                dibujarMitad(ctx, lado, t);
                m.pop();
            }

            // Nombre del eliminado
            if (d > 6) {
                float aparicion = MathHelper.clamp((d - 6) / 8f, 0f, 1f);
                int alfa = Math.max(4, (int) (255 * aparicion * salida));
                float s = 3f * (0.6f + 0.4f * aparicion) * Math.max(0.6f, escala);
                m.push();
                m.translate(cx, cy - 10, 0);
                m.scale(s, s, 1f);
                Text txt = Text.literal(nombre).formatted(Formatting.BOLD);
                ctx.drawText(tr, txt, -tr.getWidth(txt) / 2, -4, (alfa << 24) | 0xFF2A2A, true);
                m.pop();
                Text sub = Text.literal("HA SIDO DESINFORMADO").formatted(Formatting.BOLD);
                m.push();
                m.translate(cx, cy + 22, 0);
                m.scale(1.5f, 1.5f, 1f);
                ctx.drawText(tr, sub, -tr.getWidth(sub) / 2, -4, (alfa << 24) | 0xFFFFFF, true);
                m.pop();
            }
        }
    }

    /** lado: 0 = tele entera, -1 = mitad izquierda, 1 = mitad derecha (corte en zigzag). */
    private static void dibujarMitad(DrawContext ctx, int lado, float t) {
        for (int[] r : TELE) {
            for (int y = r[1]; y < r[3]; y += 4) {
                int y2 = Math.min(y + 4, r[3]);
                int corte = (y / 4) % 2 == 0 ? -3 : 3; // grieta en zigzag
                int x1 = r[0], x2 = r[2];
                if (lado < 0) x2 = Math.min(x2, corte);
                if (lado > 0) x1 = Math.max(x1, corte);
                if (x1 < x2) ctx.fill(x1, y, x2, y2, r[4]);
            }
        }
        // Estática en la pantalla mientras cae
        if (lado == 0) {
            Ruido.dibujar(ctx, -68, -44, 44, 44, 0.85f, 4);
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.DobleSaltoPayload;
import com.centrodesinformacion.desinformados.network.PasivasPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/** Lado del cliente de las pasivas: tecla K, doble salto y agarrarse a los bordes con los Guantes de Escala. */
public class PasivasCliente {
    public static final Set<String> COMPRADAS = new HashSet<>();
    public static final Set<String> ACTIVAS = new HashSet<>();

    public static final KeyBinding TECLA = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.desinformados.pasivas", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.desinformados"));

    private static boolean saltoAntes = false;
    private static boolean segundoSaltoListo = false;
    private static boolean saltoUsado = false;

    /** Jugadores (de los demás) que están colgados de un borde, por id de entidad. */
    private static final Set<Integer> COLGADOS = new HashSet<>();
    /** true mientras se dibujan los brazos en primera persona (para que el modelo no les ponga la pose de tercera persona). */
    public static boolean primeraPersona = false;

    /** ¿Este jugador está colgado de un borde? (tú: al instante; los demás: según el servidor) */
    public static boolean estaColgado(net.minecraft.entity.Entity e) {
        if (e == MinecraftClient.getInstance().player) return colgado;
        return COLGADOS.contains(e.getId()) && !e.isOnGround();
    }

    public static boolean yoColgado() { return colgado; }

    /** Deja de estar colgado sin subir (se cayó, abrió un menú...). */
    private static void soltar(ClientPlayerEntity p) {
        if (!colgado) return;
        colgado = false;
        if (p != null && ClientPlayNetworking.canSend(DobleSaltoPayload.ID)) ClientPlayNetworking.send(new DobleSaltoPayload(3));
    }

    public static void registrar() {
        ClientPlayNetworking.registerGlobalReceiver(com.centrodesinformacion.desinformados.network.ColgadoPayload.ID, (p, ctx) -> {
            if (p.colgado()) COLGADOS.add(p.entidad()); else COLGADOS.remove(p.entidad());
        });
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> { COLGADOS.clear(); colgado = false; });
        ClientPlayNetworking.registerGlobalReceiver(PasivasPayload.ID, (p, ctx) -> {
            COMPRADAS.clear();
            ACTIVAS.clear();
            for (String s : p.compradas().split(",")) if (!s.isBlank()) COMPRADAS.add(s);
            for (String s : p.activas().split(",")) if (!s.isBlank()) ACTIVAS.add(s);
        });
        ClientTickEvents.END_CLIENT_TICK.register(PasivasCliente::tick);
    }

    private static void tick(MinecraftClient mc) {
        while (TECLA.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new PasivasScreen());
        }
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) { saltoAntes = false; soltar(p); return; }
        boolean salto = mc.options.jumpKey.isPressed();
        boolean recienPulsado = salto && !saltoAntes;
        saltoAntes = salto;

        // ---- Aletas: nadar un 50% más rápido ----
        if (ACTIVAS.contains("aletas") && p.isTouchingWater() && !p.getAbilities().flying && !p.hasVehicle()) aletas(p);
        if (p.getAbilities().flying || p.isTouchingWater() || p.isInLava() || p.hasVehicle() || p.isClimbing()) { soltar(p); return; }

        // ---- Doble salto: solo en el aire, con una pulsación NUEVA (soltar y volver a pulsar) ----
        if (p.isOnGround()) {
            segundoSaltoListo = false;
            saltoUsado = false;
        } else if (!salto && !saltoUsado) {
            segundoSaltoListo = true;     // ya en el aire y con la tecla suelta: el siguiente salto es el extra
        } else if (ACTIVAS.contains("doble_salto") && recienPulsado && segundoSaltoListo && !p.horizontalCollision) {
            segundoSaltoListo = false;
            saltoUsado = true;
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.5, v.z);
            p.fallDistance = 0;
            for (int i = 0; i < 8; i++) {
                p.getWorld().addParticle(ParticleTypes.CLOUD, p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.6, p.getY(),
                        p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.6, 0, -0.05, 0);
            }
            ClientPlayNetworking.send(new DobleSaltoPayload(0));
        }

        // ---- Guantes de Escala: al caer con ESPACIO pulsado te agarras a la esquina del bloque de delante;
        //      al soltar ESPACIO saltas lo justo para subirte ----
        if (colgado) {
            if (!ACTIVAS.contains("garras") || p.isOnGround() || !sigueElBorde(p)) {
                soltar(p);
            } else if (salto) {
                p.setVelocity(dirBorde.getOffsetX() * 0.02, 0, dirBorde.getOffsetZ() * 0.02);   // pegado a la pared, sin caer
                p.fallDistance = 0;
            } else {
                colgado = false;                                           // soltó ESPACIO: ¡arriba!
                subiendo = 14;
                p.setVelocity(dirBorde.getOffsetX() * 0.1, 0.62, dirBorde.getOffsetZ() * 0.1);
                p.fallDistance = 0;
                for (int i = 0; i < 6; i++)
                    p.getWorld().addParticle(ParticleTypes.CRIT, p.getX() + dirBorde.getOffsetX() * 0.4, bordeY, p.getZ() + dirBorde.getOffsetZ() * 0.4,
                            (p.getRandom().nextDouble() - 0.5) * 0.2, 0.1, (p.getRandom().nextDouble() - 0.5) * 0.2);
                ClientPlayNetworking.send(new DobleSaltoPayload(2));
            }
        } else if (ACTIVAS.contains("garras") && salto && !p.isOnGround() && p.getVelocity().y < 0 && agarrar(p)) {
            colgado = true;
            p.setVelocity(dirBorde.getOffsetX() * 0.02, 0, dirBorde.getOffsetZ() * 0.02);
            p.fallDistance = 0;
            ClientPlayNetworking.send(new DobleSaltoPayload(1));
        }
        if (subiendo > 0) {                                                // empujoncito hacia el borde al subir
            subiendo--;
            if (p.isOnGround()) subiendo = 0;
            else if (p.getY() > bordeY - 0.2) {
                Vec3d v = p.getVelocity();
                p.setVelocity(dirBorde.getOffsetX() * 0.22, v.y, dirBorde.getOffsetZ() * 0.22);
            }
        }
    }

    /**
     * En el agua la velocidad se estabiliza en v = a·d / (1 - d) (a = empuje de nadar 0.02, d = rozamiento 0.8, o 0.9 nadando a crol).
     * Sumando un empujón extra de 0.5·a·d cada tick, esa velocidad sube justo un 50%.
     */
    private static void aletas(ClientPlayerEntity p) {
        float adelante = p.input.movementForward, lado = p.input.movementSideways;
        if (adelante == 0 && lado == 0) return;
        double rad = Math.toRadians(p.getYaw()), sin = Math.sin(rad), cos = Math.cos(rad);
        double x = lado * cos - adelante * sin, z = adelante * cos + lado * sin, y = 0;
        if (p.isSwimming()) {                              // nadando a crol: también hacia donde miras (arriba/abajo)
            Vec3d mira = p.getRotationVector();
            y = mira.y * adelante;
            double h = Math.sqrt(Math.max(0, 1 - mira.y * mira.y));
            x *= h; z *= h;
        }
        double l = Math.sqrt(x * x + y * y + z * z);
        if (l < 1e-4) return;
        double roce = (p.isSwimming() || p.isSprinting()) ? 0.9 : 0.8;
        double extra = 0.5 * 0.02 * roce;
        p.setVelocity(p.getVelocity().add(x / l * extra, y / l * extra, z / l * extra));
    }

    private static boolean colgado = false;
    private static int subiendo = 0;
    private static Direction dirBorde = Direction.NORTH;
    private static double bordeY = 0;

    /** ¿Estás pegado a un bloque con la esquina de arriba a la altura de las manos? Si sí, te engancha a ella. */
    private static boolean agarrar(ClientPlayerEntity p) {
        Direction dir = p.getHorizontalFacing();
        if (!pegado(p, dir)) return false;
        Double borde = buscarBorde(p, dir);
        if (borde == null) return false;
        dirBorde = dir;
        bordeY = borde;
        p.setPosition(p.getX(), borde - 1.75, p.getZ());                   // las manos justo en la esquina
        return true;
    }

    private static boolean sigueElBorde(ClientPlayerEntity p) {
        if (!pegado(p, dirBorde)) return false;
        Double borde = buscarBorde(p, dirBorde);
        if (borde == null) return false;
        bordeY = borde;
        return true;
    }

    /** Tocando la pared de delante (como mucho a 0.05 bloques: si no, el servidor creería que estás volando). */
    private static boolean pegado(ClientPlayerEntity p, Direction dir) {
        return !p.getWorld().isSpaceEmpty(p, p.getBoundingBox().offset(dir.getOffsetX() * 0.05, 0, dir.getOffsetZ() * 0.05));
    }

    /** Altura de la esquina superior del bloque de delante que está al alcance de las manos (con hueco encima para subir). */
    private static Double buscarBorde(ClientPlayerEntity p, Direction dir) {
        BlockPos pies = BlockPos.ofFloored(p.getX(), p.getY(), p.getZ());
        for (int h = 0; h <= 3; h++) {
            BlockPos pared = pies.offset(dir).up(h);
            BlockPos encima = pared.up();
            boolean solido = !p.getWorld().getBlockState(pared).getCollisionShape(p.getWorld(), pared).isEmpty();
            boolean libre = p.getWorld().getBlockState(encima).getCollisionShape(p.getWorld(), encima).isEmpty()
                    && p.getWorld().getBlockState(encima.up()).getCollisionShape(p.getWorld(), encima.up()).isEmpty();
            double alto = pared.getY() + 1 - p.getY();
            if (solido && libre && alto >= 1.2 && alto <= 2.3) return (double) (pared.getY() + 1);
        }
        return null;
    }

}

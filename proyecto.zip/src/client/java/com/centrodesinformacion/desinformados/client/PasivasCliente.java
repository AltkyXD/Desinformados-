package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.network.DobleSaltoPayload;
import com.centrodesinformacion.desinformados.network.PasivasPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/** Lado del cliente de las pasivas: tecla K, doble salto y trepar con las Garras. */
public class PasivasCliente {
    public static final Set<String> COMPRADAS = new HashSet<>();
    public static final Set<String> ACTIVAS = new HashSet<>();

    public static final KeyBinding TECLA = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.desinformados.pasivas", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.desinformados"));

    private static boolean saltoAntes = false;
    private static boolean segundoSaltoListo = false;

    public static void registrar() {
        ClientPlayNetworking.registerGlobalReceiver(PasivasPayload.ID, (p, ctx) -> {
            COMPRADAS.clear();
            ACTIVAS.clear();
            for (String s : p.compradas().split(",")) if (!s.isBlank()) COMPRADAS.add(s);
            for (String s : p.activas().split(",")) if (!s.isBlank()) ACTIVAS.add(s);
        });
        ClientTickEvents.END_CLIENT_TICK.register(PasivasCliente::tick);
    }

    private static void tick(MinecraftClient mc) {
        while (TECLA.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new PasivasScreen());
        }
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) { saltoAntes = false; return; }
        boolean salto = mc.options.jumpKey.isPressed();
        boolean recienPulsado = salto && !saltoAntes;
        saltoAntes = salto;
        if (p.getAbilities().flying || p.isTouchingWater() || p.isInLava() || p.hasVehicle() || p.isClimbing()) return;

        // ---- Doble salto ----
        if (p.isOnGround()) {
            segundoSaltoListo = true;
        } else if (ACTIVAS.contains("doble_salto") && recienPulsado && segundoSaltoListo && !p.horizontalCollision) {
            segundoSaltoListo = false;
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.5, v.z);
            p.fallDistance = 0;
            for (int i = 0; i < 8; i++) {
                p.getWorld().addParticle(ParticleTypes.CLOUD, p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.6, p.getY(),
                        p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.6, 0, -0.05, 0);
            }
            ClientPlayNetworking.send(new DobleSaltoPayload(0));
        }

        // ---- Garras: trepar hasta un borde cercano / quedarse colgado ----
        if (ACTIVAS.contains("garras") && p.horizontalCollision && !p.isOnGround()) {
            if (hayBorde(p)) {
                Vec3d v = p.getVelocity();
                if (p.isSneaking()) {
                    p.setVelocity(v.x * 0.5, 0, v.z * 0.5);                                   // colgado del borde
                } else if (salto) {
                    p.setVelocity(v.x, Math.max(v.y, 0.32), v.z);                             // trepando
                    if (p.age % 4 == 0) p.getWorld().addParticle(ParticleTypes.CRIT, p.getX(), p.getY() + 1, p.getZ(), 0, 0, 0);
                }
                p.fallDistance = 0;
            }
        }
    }

    /** ¿Hay un borde (bloque sólido con aire encima) delante, como mucho 3 bloques por encima de los pies? */
    private static boolean hayBorde(ClientPlayerEntity p) {
        Direction dir = p.getHorizontalFacing();
        BlockPos pies = p.getBlockPos();
        for (int h = 0; h <= 3; h++) {
            BlockPos pared = pies.offset(dir).up(h);
            BlockPos encima = pared.up();
            boolean solido = !p.getWorld().getBlockState(pared).getCollisionShape(p.getWorld(), pared).isEmpty();
            boolean libre = p.getWorld().getBlockState(encima).getCollisionShape(p.getWorld(), encima).isEmpty()
                    && p.getWorld().getBlockState(encima.up()).getCollisionShape(p.getWorld(), encima.up()).isEmpty();
            if (solido && libre) return true;
        }
        return false;
    }
}

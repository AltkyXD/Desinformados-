package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Usa la textura del mob original (zombie o creeper del propio juego) en las variantes, repintada o mezclada con la nuestra.
 * No lleva ninguna textura de Mojang dentro del mod: al usarse por primera vez lee la del juego que tiene instalado
 * el jugador y la pinta en memoria. Si algo falla, se usa la textura del mod tal cual.
 */
public final class CarasOriginales {
    private CarasOriginales() {}

    public static final Identifier ZOMBIE = Identifier.ofVanilla("textures/entity/zombie/zombie.png");
    public static final Identifier CREEPER = Identifier.ofVanilla("textures/entity/creeper/creeper.png");

    private static final Map<Identifier, Identifier> HECHAS = new HashMap<>();

    /** Cómo se mezcla la textura del juego con la nuestra. */
    public enum Modo {
        /** La textura original entera, con la piel (o todo, en el creeper) repintada con la paleta. */
        ENTERA,
        /** La nuestra, pero con la cabeza y la piel de los brazos del original (la ropa y los gorros siguen siendo nuestros). */
        MEZCLA
    }

    /**
     * @param nuestra la textura del mod (también es la de reserva si algo falla)
     * @param original de qué mob se toma (ZOMBIE o CREEPER)
     * @param paleta tonos de oscuro a claro para repintar (null = sin repintar)
     */
    public static Identifier con(Identifier nuestra, Identifier original, Modo modo, int[] paleta) {
        Identifier hecha = HECHAS.get(nuestra);
        if (hecha != null) return hecha;
        Identifier resultado = nuestra;
        try {
            NativeImage img = modo == Modo.ENTERA ? entera(original, paleta) : mezcla(nuestra, original);
            if (img != null) {
                resultado = Desinformados.id("dinamica/" + nuestra.getPath().replace('/', '_'));
                MinecraftClient.getInstance().getTextureManager().registerTexture(resultado, new NativeImageBackedTexture(img));
            }
        } catch (Exception e) {
            Desinformados.LOGGER.warn("No se pudo usar la textura original en {}: {}", nuestra, e.toString());
            resultado = nuestra;
        }
        HECHAS.put(nuestra, resultado);   // aunque falle: no reintentar cada fotograma
        return resultado;
    }

    /** Textura original entera. En el zombie solo se repinta la piel (lo verde); en el creeper, todo. */
    private static NativeImage entera(Identifier original, int[] paleta) throws Exception {
        NativeImage img = leer(MinecraftClient.getInstance(), original);
        if (img == null || paleta == null) return img;
        boolean soloPiel = original.equals(ZOMBIE);
        int lmin = 255, lmax = 0;
        for (int y = 0; y < img.getHeight(); y++)
            for (int x = 0; x < img.getWidth(); x++) {
                int c = img.getColor(x, y);
                if ((c >>> 24) < 128 || (soloPiel && !esPiel(c))) continue;
                int l = luminancia(c);
                lmin = Math.min(lmin, l);
                lmax = Math.max(lmax, l);
            }
        for (int y = 0; y < img.getHeight(); y++)
            for (int x = 0; x < img.getWidth(); x++) {
                int c = img.getColor(x, y);
                if ((c >>> 24) < 128 || (soloPiel && !esPiel(c))) continue;
                float t = lmax > lmin ? (luminancia(c) - lmin) / (float) (lmax - lmin) : 1f;
                img.setColor(x, y, abgr(paleta[Math.round(t * (paleta.length - 1))]));
            }
        return img;
    }

    /** La nuestra + cabeza entera del original (x 0-31, y 0-15) + la piel de los brazos (donde la nuestra es verde de zombie). */
    private static NativeImage mezcla(Identifier nuestra, Identifier original) throws Exception {
        MinecraftClient mc = MinecraftClient.getInstance();
        NativeImage base = leer(mc, nuestra);
        if (base == null) return null;
        NativeImage orig = leer(mc, original);
        if (orig == null) { base.close(); return null; }
        int e = Math.max(1, orig.getWidth() / 64);   // por si un paquete de recursos la trae en HD
        for (int y = 0; y < 16; y++)
            for (int x = 0; x < 32; x++) {
                int c = orig.getColor(x * e, y * e);
                if ((c >>> 24) >= 128) base.setColor(x, y, c | 0xFF000000);
            }
        for (int y = 16; y < 32; y++)
            for (int x = 40; x < 56; x++) {
                if (!esPiel(base.getColor(x, y))) continue;   // la manga se queda
                int c = orig.getColor(x * e, y * e);
                if ((c >>> 24) >= 128) base.setColor(x, y, c | 0xFF000000);
            }
        orig.close();
        return base;
    }

    /** ¿Es piel de zombie? (verde: tono entre 60 y 165 grados y algo de saturación) */
    private static boolean esPiel(int abgr) {
        if ((abgr >>> 24) < 128) return false;
        float r = (abgr & 0xFF) / 255f, g = ((abgr >> 8) & 0xFF) / 255f, b = ((abgr >> 16) & 0xFF) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        if (max <= 0 || (max - min) / max < 0.18f || max != g) return false;
        float tono = 60f * ((b - r) / (max - min)) + 120f;
        return tono >= 60f && tono <= 165f;
    }

    private static NativeImage leer(MinecraftClient mc, Identifier id) throws Exception {
        Optional<Resource> r = mc.getResourceManager().getResource(id);
        if (r.isEmpty()) return null;
        try (InputStream in = r.get().getInputStream()) {
            return NativeImage.read(in);
        }
    }

    /** NativeImage guarda los colores como ABGR. */
    private static int luminancia(int abgr) {
        int r = abgr & 0xFF, g = (abgr >> 8) & 0xFF, b = (abgr >> 16) & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000;
    }

    /** 0xRRGGBB -> ABGR opaco. */
    private static int abgr(int rgb) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return 0xFF000000 | (b << 16) | (g << 8) | r;
    }

    // paletas (de oscuro a claro) para recolorear la cara
    public static final int[] NARANJA = {0x7A3208, 0xA6470C, 0xC95C12, 0xE0781F, 0xEF9638};
    public static final int[] LIMON = {0x8F7A0A, 0xB89D10, 0xD8BB1C, 0xEBD236, 0xF6E468};
    public static final int[] LIMA = {0x0C0C0C, 0x4A6A10, 0x5F8414, 0x78A01C, 0x93BA2A, 0xACD03E, 0xC6E05A};
}

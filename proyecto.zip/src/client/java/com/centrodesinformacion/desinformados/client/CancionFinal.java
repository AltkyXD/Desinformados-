package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/** La canción de los créditos: suena en todo el mundo (no posicional) y al terminar los créditos baja de volumen poco a poco. */
public class CancionFinal extends MovingSoundInstance {
    private static final int TICKS_BAJAR = 120;   // 6 s
    private final float maximo;
    private boolean bajando = false;

    public CancionFinal(SoundEvent sonido, float volumen) {
        super(sonido, SoundCategory.MASTER, SoundInstance.createRandom());
        this.volume = volumen;
        this.maximo = volumen;
        this.pitch = 1f;
        this.repeat = false;
        this.relative = true;
        this.attenuationType = AttenuationType.NONE;
        this.x = 0;
        this.y = 0;
        this.z = 0;
    }

    public void bajar() {
        bajando = true;
    }

    @Override
    public void tick() {
        if (!bajando) return;
        volume -= maximo / TICKS_BAJAR;
        if (volume <= 0.001f) {
            volume = 0f;
            setDone();
        }
    }
}

package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

/** Borde rojo pulsante alrededor de la pantalla mientras tengas un desafío pendiente. */
public class BordeRojo {
    private static boolean activo = false;
    private static float intensidad = 0f;
    private static float anterior = 0f;
    private static int ticks = 0;

    public static void cambiar(boolean nuevo) {
        activo = nuevo;
    }

    public static void tick() {
        anterior = intensidad;
        intensidad = MathHelper.clamp(intensidad + (activo ? 0.05f : -0.05f), 0f, 1f);
        ticks++;
    }

    public static void render(DrawContext ctx, RenderTickCounter contador) {
        float d = contador.getTickDelta(false);
        float i = MathHelper.lerp(d, anterior, intensidad);
        if (i <= 0.001f || MinecraftClient.getInstance().options.hudHidden) return;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float pulso = 0.75f + 0.25f * MathHelper.sin((ticks + d) * 0.15f);
        int pasos = 16;
        int ancho = Math.max(2, Math.min(w, h) / 70);
        for (int k = 0; k < pasos; k++) {
            int a = (int) (170 * i * pulso * (1f - k / (float) pasos));
            if (a <= 0) continue;
            int color = (a << 24) | 0xFF1A1A;
            int o = k * ancho;
            ctx.fill(o, o, w - o, o + ancho, color);                       // arriba
            ctx.fill(o, h - o - ancho, w - o, h - o, color);               // abajo
            ctx.fill(o, o + ancho, o + ancho, h - o - ancho, color);       // izquierda
            ctx.fill(w - o - ancho, o + ancho, w - o, h - o - ancho, color); // derecha
        }
    }
}

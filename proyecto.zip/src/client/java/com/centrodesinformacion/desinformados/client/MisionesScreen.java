package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Random;

/**
 * Misiones (tecla U) en una tele vieja: al abrir sale medio segundo de estática y se enciende la tele
 * con las misiones; al cerrar, otro medio segundo de estática y se apaga.
 */
public class MisionesScreen extends Screen {
    private static final int ESTATICA = 10;           // 0,5 s
    private static final Random R = new Random();
    private static final int MADERA = 0xFF7B4A2A, MADERA_OSC = 0xFF3B2213, CROMO = 0xFF9E9E9E, CROMO_OSC = 0xFF5A5A5A,
            CROMO_CLARO = 0xFFE0E0E0, GOMA = 0xFF141414, LATON = 0xFFC9A44C;
    private static final int TXT = 0xFFE8F2E8, TXT_SUAVE = 0xFF9DB89D, VERDE = 0xFF39FF5A, AMARILLO = 0xFFFFE04A, CIAN = 0xFF5AD8FF;

    private int ticks = 0;
    private int cerrando = -1;
    private double scroll = 0;
    private int altoContenido = 0;
    /** 0 = principales, 1 = secundarias (se recuerda entre aperturas). */
    private static int pestana = 0;
    private int tabX0, tabX1, tabX2, tabY;

    public MisionesScreen() {
        super(Text.literal("Misiones"));
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    @Override
    protected void init() {
        if (ticks == 0) sonar();
    }

    private static void sonar() {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ModSounds.TV_ESTATICA, 1.3f, 0.6f));
    }

    @Override
    public void tick() {
        ticks++;
        if (cerrando >= 0 && ++cerrando >= ESTATICA) super.close();
    }

    @Override
    public void close() {
        if (cerrando < 0) {
            cerrando = 0;
            sonar();
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (DesinformadosClient.TECLA_MISIONES.matchesKey(key, scan) || key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_TAB || key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT) {
            cambiarPestana(1 - pestana);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private void cambiarPestana(int p) {
        if (p == pestana) return;
        pestana = p;
        scroll = 0;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(net.minecraft.sound.SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), 1.6f, 0.4f));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int boton) {
        if (my >= tabY - 2 && my <= tabY + 11) {
            if (mx >= tabX0 && mx < tabX1) { cambiarPestana(0); return true; }
            if (mx >= tabX1 && mx < tabX2) { cambiarPestana(1); return true; }
        }
        return super.mouseClicked(mx, my, boton);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = MathHelper.clamp(scroll - v * 12, 0, Math.max(0, altoContenido - (pantallaAlto() - 52)));
        return true;
    }

    // ------------------------------------------------------------------ medidas de la tele

    private int teleAncho() { return Math.min(width - 16, 420); }
    private int teleAlto() { return height - 30; }
    private int teleX() { return (width - teleAncho()) / 2; }
    private int teleY() { return 22; }
    private int panel() { return 46; }                       // columna de perillas a la derecha
    private int pantallaX() { return teleX() + 14; }
    private int pantallaY() { return teleY() + 14; }
    private int pantallaAncho() { return teleAncho() - panel() - 28; }
    private int pantallaAlto() { return teleAlto() - 36; }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        if (ticks < ESTATICA || cerrando >= 0) {
            ctx.fill(0, 0, width, height, 0xFF000000);
            estatica(ctx, 0, 0, width, height, 255, 4);
            return;
        }
        ctx.fill(0, 0, width, height, 0xAA000000);
        dibujarTele(ctx);
        int sx = pantallaX(), sy = pantallaY(), sw = pantallaAncho(), sh = pantallaAlto();
        if (MisionesCliente.fuera) {
            fueraDeServicio(ctx, sx, sy, sw, sh);
        } else {
            // pantalla encendida: fondo oscuro con un poco de nieve
            ctx.fill(sx, sy, sx + sw, sy + sh, 0xFF0C140F);
            estatica(ctx, sx, sy, sx + sw, sy + sh, 22, 3);
            Text cab = Text.literal("CANAL DE MISIONES").formatted(Formatting.BOLD);
            ctx.drawText(textRenderer, cab, sx + sw / 2 - textRenderer.getWidth(cab) / 2, sy + 8, VERDE, true);
            pestanas(ctx, sx, sy + 24, sw);
            int arriba = sy + 40, abajo = sy + sh - 18;
            ctx.enableScissor(sx, arriba, sx + sw, abajo);
            int y = arriba + 4 - (int) scroll;
            int inicio = y;
            y = pestana == 0 ? principales(ctx, sx, sw, y) : secundarias(ctx, sx, sw, y);
            altoContenido = y - inicio + 10;
            ctx.disableScissor();
        }
        // cristal del tubo: líneas de barrido, bordes oscuros y reflejo
        for (int ly = sy; ly < sy + sh; ly += 2) ctx.fill(sx, ly, sx + sw, ly + 1, 0x26000000);
        for (int i = 0; i < 8; i++) {
            int c = (8 - i) * 12 << 24;
            ctx.fill(sx + i, sy + i, sx + sw - i, sy + i + 1, c);
            ctx.fill(sx + i, sy + sh - i - 1, sx + sw - i, sy + sh - i, c);
            ctx.fill(sx + i, sy + i, sx + i + 1, sy + sh - i, c);
            ctx.fill(sx + sw - i - 1, sy + i, sx + sw - i, sy + sh - i, c);
        }
        ctx.fill(sx + 10, sy + 6, sx + 40, sy + 8, 0x30FFFFFF);
        // banda roja parpadeante "EN VIVO"
        if (!MisionesCliente.fuera) {
            if ((ticks / 15) % 2 == 0) ctx.fill(sx + 8, sy + sh - 14, sx + 13, sy + sh - 9, 0xFFFF3030);
            ctx.drawText(textRenderer, "EN VIVO", sx + 16, sy + sh - 15, 0xFFFF6060, false);
        }
        if (!MisionesCliente.fuera && altoContenido > sh - 52) {
            String t = "rueda del ratón para bajar";
            ctx.drawText(textRenderer, t, sx + sw - 8 - textRenderer.getWidth(t), sy + sh - 15, 0xFF6F8F6F, false);
        }
        Text pie = Text.literal("U o Esc para apagar · Tab para cambiar de sección");
        ctx.drawText(textRenderer, pie, width / 2 - textRenderer.getWidth(pie) / 2, teleY() + teleAlto() + 2, 0xFFAAAAAA, true);
    }

    private void dibujarTele(DrawContext ctx) {
        int x = teleX(), y = teleY(), w = teleAncho(), h = teleAlto();
        // antenas
        int cx = x + (w - panel()) / 2;
        for (int k = 0; k < 18; k++) {
            ctx.fill(cx - 4 - k, y - 2 - k, cx - 1 - k, y + 1 - k, CROMO_OSC);
            ctx.fill(cx + 1 + k, y - 2 - k, cx + 4 + k, y + 1 - k, CROMO_OSC);
        }
        ctx.fill(cx - 8, y - 4, cx + 8, y + 2, 0xFF2A2A2A);
        // mueble de madera con vetas
        ctx.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0xFF1E1008);
        ctx.fill(x, y, x + w, y + h, MADERA_OSC);
        ctx.fill(x + 3, y + 3, x + w - 3, y + h - 3, MADERA);
        for (int vy = y + 5; vy < y + h - 5; vy += 3) {
            int d = (vy * 7) % 23;
            for (int vx = x + 5 + d; vx < x + w - 8; vx += 29) ctx.fill(vx, vy, Math.min(vx + 9 + (vy % 5), x + w - 5), vy + 1, 0x22000000);
        }
        // marco cromado de la pantalla
        int sx = pantallaX(), sy = pantallaY(), sw = pantallaAncho(), sh = pantallaAlto();
        ctx.fill(sx - 6, sy - 6, sx + sw + 6, sy + sh + 6, CROMO_OSC);
        ctx.fill(sx - 5, sy - 5, sx + sw + 5, sy + sh + 5, CROMO);
        ctx.fill(sx - 5, sy - 5, sx + sw + 5, sy - 4, CROMO_CLARO);
        ctx.fill(sx - 2, sy - 2, sx + sw + 2, sy + sh + 2, GOMA);
        // panel de control: placa, perillas, piloto y altavoz
        int px = x + w - panel() - 4, pw = panel() - 4;
        ctx.fill(px, y + 10, px + pw, y + h - 10, 0xFF4A2B17);
        ctx.fill(px + 4, y + 16, px + pw - 4, y + 26, LATON);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(px + pw / 2f, y + 18.5f, 0);
        ctx.getMatrices().scale(0.6f, 0.6f, 1f);
        ctx.drawText(textRenderer, "DESINFO", -textRenderer.getWidth("DESINFO") / 2, 0, 0xFF3B2213, false);
        ctx.getMatrices().pop();
        for (int k = 0; k < 2; k++) {
            int ky = y + 46 + k * 34, kx = px + pw / 2;
            ctx.fill(kx - 10, ky - 10, kx + 10, ky + 10, 0xFF0A0A0A);
            ctx.fill(kx - 9, ky - 9, kx + 9, ky + 9, 0xFF3A3A3A);
            ctx.fill(kx - 6, ky - 6, kx + 2, ky + 2, 0xFF555555);
            float a = (ticks + k * 20) * 0.05f;
            ctx.fill(kx + (int) (Math.cos(a) * 6) - 1, ky + (int) (Math.sin(a) * 6) - 1, kx + (int) (Math.cos(a) * 6) + 1, ky + (int) (Math.sin(a) * 6) + 1, 0xFFE8E8E8);
        }
        ctx.fill(px + 6, y + 108, px + 10, y + 112, (ticks / 10) % 2 == 0 ? 0xFFFF3030 : 0xFF801818);
        for (int ly = y + 120; ly < y + h - 16; ly += 4) ctx.fill(px + 5, ly, px + pw - 5, ly + 2, 0xFF2A1A10);
        // patas
        for (int lado = 0; lado < 2; lado++) {
            int lx = lado == 0 ? x + 16 : x + w - 26;
            ctx.fill(lx, y + h + 3, lx + 10, y + h + 7, 0xFF2E1A0E);
        }
    }

    private void pestanas(DrawContext ctx, int sx, int y, int sw) {
        int hechas = 0;
        for (MisionesCliente.Info m : MisionesCliente.SECUNDARIAS) if (m.hecha()) hechas++;
        String a = "PRINCIPALES", b = "SECUNDARIAS " + hechas + "/" + MisionesCliente.SECUNDARIAS.size();
        int wa = textRenderer.getWidth(a) + 16, wb = textRenderer.getWidth(b) + 16;
        int x0 = sx + sw / 2 - (wa + wb + 6) / 2;
        tabX0 = x0;
        tabX1 = x0 + wa + 6;
        tabX2 = tabX1 + wb;
        tabY = y;
        dibujarPestana(ctx, x0, y, wa, a, pestana == 0, AMARILLO);
        dibujarPestana(ctx, tabX1, y, wb, b, pestana == 1, CIAN);
        ctx.fill(sx + 10, y + 12, sx + sw - 10, y + 13, 0x556F8F6F);
    }

    private void dibujarPestana(DrawContext ctx, int x, int y, int w, String t, boolean activa, int color) {
        if (activa) ctx.fill(x, y - 2, x + w, y + 12, (color & 0x00FFFFFF) | 0x33000000);
        ctx.drawText(textRenderer, Text.literal(t).formatted(activa ? Formatting.BOLD : Formatting.RESET), x + 8, y + 1, activa ? color : TXT_SUAVE, activa);
        if (activa) ctx.fill(x, y + 11, x + w, y + 13, color);
    }

    private int barra(DrawContext ctx, int x, int y, int ancho, int valor, int meta, int color) {
        if (meta <= 0) return y;
        String t = valor + "/" + meta;
        int bw = ancho - textRenderer.getWidth(t) - 6;
        ctx.fill(x, y + 2, x + bw, y + 7, 0xFF1E2A22);
        ctx.fill(x, y + 2, x + (int) (bw * Math.min(1f, valor / (float) meta)), y + 7, color);
        ctx.drawText(textRenderer, t, x + bw + 6, y, TXT_SUAVE, false);
        return y + 11;
    }

    private int principales(DrawContext ctx, int sx, int sw, int y) {
        int x = sx + 12, ancho = sw - 24;
        int n = 0;
        for (MisionesCliente.Info m : MisionesCliente.PRINCIPALES) {
            n++;
            boolean actual = !m.superada();
            ctx.fill(x, y, x + 9, y + 9, actual ? AMARILLO : 0xFF6F8F6F);
            ctx.fill(x + 1, y + 1, x + 8, y + 8, m.hecha() ? 0xFF2E9E44 : 0xFF0C140F);
            if (m.hecha()) ctx.drawText(textRenderer, "✔", x + 1, y, 0xFFFFFFFF, false);
            Text t = Text.literal(n + ". " + m.titulo()).formatted(m.superada() && m.hecha() ? Formatting.STRIKETHROUGH : Formatting.BOLD);
            ctx.drawText(textRenderer, t, x + 14, y + 1, m.superada() && m.hecha() ? 0xFF6F8F6F : (actual ? AMARILLO : TXT), true);
            Text estado;
            int col;
            if (m.superada()) { estado = Text.literal(m.hecha() ? "SUPERADA" : "SUPERADA · te falta a ti"); col = m.hecha() ? VERDE : AMARILLO; }
            else if (m.grupo()) { estado = Text.literal("basta con que la haga uno"); col = CIAN; }
            else { estado = Text.literal("Grupo " + m.hechos() + "/" + MisionesCliente.necesarios + " (de " + MisionesCliente.total + ")"); col = m.hechos() >= MisionesCliente.necesarios ? VERDE : AMARILLO; }
            ctx.drawText(textRenderer, estado, x + ancho - textRenderer.getWidth(estado), y + 1, col, false);
            y += 11;
            for (OrderedText l : textRenderer.wrapLines(Text.literal(m.descripcion()), ancho - 14)) {
                ctx.drawText(textRenderer, l, x + 14, y, TXT_SUAVE, false);
                y += 10;
            }
            if (!m.hecha() && m.meta() > 1) y = barra(ctx, x + 14, y, ancho - 14, m.valor(), m.meta(), AMARILLO);
            if (!m.recompensa().isEmpty()) {
                ctx.drawText(textRenderer, Text.literal((m.grupo() ? "Premio para todos: " : "Recompensa: ") + m.recompensa()).formatted(Formatting.ITALIC),
                        x + 14, y, AMARILLO, false);
                y += 10;
            }
            y += 6;
        }
        if (MisionesCliente.ocultas > 0) {
            ctx.fill(x, y, x + 9, y + 9, 0xFF3A4A3E);
            ctx.drawText(textRenderer, Text.literal("??? ").formatted(Formatting.OBFUSCATED).append(Text.literal(" " + MisionesCliente.ocultas
                    + (MisionesCliente.ocultas == 1 ? " misión más" : " misiones más") + " sin revelar").formatted(Formatting.ITALIC)), x + 14, y + 1, TXT_SUAVE, false);
            y += 12;
            Text ayuda = Text.literal("La siguiente se revela cuando la complete el " + (int) (com.centrodesinformacion.desinformados.Misiones.PORCENTAJE * 100)
                    + " % del grupo (" + MisionesCliente.necesarios + " de " + MisionesCliente.total + ").");
            for (OrderedText l : textRenderer.wrapLines(ayuda, ancho - 14)) {
                ctx.drawText(textRenderer, l, x + 14, y, 0xFF6F8F6F, false);
                y += 10;
            }
        }
        if (MisionesCliente.PRINCIPALES.isEmpty()) {
            ctx.drawText(textRenderer, Text.literal("Sintonizando...").formatted(Formatting.ITALIC), x + 14, y, TXT_SUAVE, false);
            y += 12;
        }
        return y;
    }

    private int secundarias(DrawContext ctx, int sx, int sw, int y) {
        int x = sx + 12, ancho = sw - 24;
        List<MisionesCliente.Info> lista = new java.util.ArrayList<>(MisionesCliente.SECUNDARIAS);
        lista.sort((a, b) -> Boolean.compare(a.hecha(), b.hecha()));          // primero las que faltan
        for (MisionesCliente.Info m : lista) {
            ctx.fill(x, y, x + 9, y + 9, 0xFF6F8F6F);
            ctx.fill(x + 1, y + 1, x + 8, y + 8, m.hecha() ? 0xFF2E9E44 : 0xFF0C140F);
            if (m.hecha()) ctx.drawText(textRenderer, "✔", x + 1, y, 0xFFFFFFFF, false);
            Text t = Text.literal(m.titulo()).formatted(m.hecha() ? Formatting.STRIKETHROUGH : Formatting.BOLD);
            ctx.drawText(textRenderer, t, x + 14, y + 1, m.hecha() ? 0xFF6F8F6F : TXT, true);
            Text r = Text.literal(m.recompensa());
            ctx.drawText(textRenderer, r, x + ancho - textRenderer.getWidth(r), y + 1, m.hecha() ? 0xFF6F8F6F : AMARILLO, false);
            y += 11;
            if (!m.hecha()) {
                for (OrderedText l : textRenderer.wrapLines(Text.literal(m.descripcion()), ancho - 14)) {
                    ctx.drawText(textRenderer, l, x + 14, y, TXT_SUAVE, false);
                    y += 10;
                }
                if (m.meta() > 1) y = barra(ctx, x + 14, y, ancho - 14, m.valor(), m.meta(), CIAN);
            }
            y += 4;
        }
        if (lista.isEmpty()) {
            ctx.drawText(textRenderer, Text.literal("Sintonizando...").formatted(Formatting.ITALIC), x + 14, y, TXT_SUAVE, false);
            y += 12;
        }
        return y;
    }

    /** Se acabaron las misiones y la tele está rota: la pantalla solo da estática. */
    private void fueraDeServicio(DrawContext ctx, int sx, int sy, int sw, int sh) {
        ctx.fill(sx, sy, sx + sw, sy + sh, 0xFF000000);
        estatica(ctx, sx, sy, sx + sw, sy + sh, 255, 3);
        ctx.fill(sx, sy + sh / 2 - 24, sx + sw, sy + sh / 2 + 26, 0xC0000000);
        Text t = Text.literal("FUERA DE SERVICIO").formatted(Formatting.BOLD);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(sx + sw / 2f, sy + sh / 2f - 14, 0);
        ctx.getMatrices().scale(2f, 2f, 1f);
        boolean parpadeo = (ticks / 12) % 4 != 0;
        ctx.drawText(textRenderer, t, -textRenderer.getWidth(t) / 2, 0, parpadeo ? 0xFFFF4040 : 0xFF802020, true);
        ctx.getMatrices().pop();
        Text sub = Text.literal("La tele está rota. Ya no quedan misiones que emitir.");
        ctx.drawText(textRenderer, sub, sx + sw / 2 - textRenderer.getWidth(sub) / 2, sy + sh / 2 + 12, 0xFFBBBBBB, true);
    }

    private static void estatica(DrawContext ctx, int x0, int y0, int x1, int y1, int alfa, int celda) {
        Ruido.dibujar(ctx, x0, y0, x1, y1, alfa >= 255 ? 1f : alfa / 255f * 0.5f, celda);
    }
}

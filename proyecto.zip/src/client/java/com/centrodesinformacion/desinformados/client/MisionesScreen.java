package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.ModSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Random;

/**
 * Misiones (tecla L) en una tele vieja: al abrir sale medio segundo de estática y se enciende la tele
 * con las misiones; al cerrar, otro medio segundo de estática y se apaga.
 */
public class MisionesScreen extends Screen {
    private static final int ESTATICA = 10;           // 0,5 s
    private static final Random R = new Random();
    private static final int MADERA = 0xFF7B4A2A, MADERA_OSC = 0xFF3B2213, CROMO = 0xFF9E9E9E, CROMO_OSC = 0xFF5A5A5A,
            CROMO_CLARO = 0xFFE0E0E0, GOMA = 0xFF141414, LATON = 0xFFC9A44C;
    private static final int TXT = 0xFFE8F2E8, TXT_SUAVE = 0xFF9DB89D, VERDE = 0xFF39FF5A, AMARILLO = 0xFFFFE04A, CIAN = 0xFF5AD8FF;

    private int ticks = 0;
    private int cerrando = -1;
    private double scroll = 0;
    private int altoContenido = 0;

    public MisionesScreen() {
        super(Text.literal("Misiones"));
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    @Override
    protected void init() {
        if (ticks == 0) sonar();
    }

    private static void sonar() {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ModSounds.TV_ESTATICA, 1.3f, 0.6f));
    }

    @Override
    public void tick() {
        ticks++;
        if (cerrando >= 0 && ++cerrando >= ESTATICA) super.close();
    }

    @Override
    public void close() {
        if (cerrando < 0) {
            cerrando = 0;
            sonar();
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (DesinformadosClient.TECLA_MISIONES.matchesKey(key, scan) || key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = MathHelper.clamp(scroll - v * 12, 0, Math.max(0, altoContenido - pantallaAlto()));
        return true;
    }

    // ------------------------------------------------------------------ medidas de la tele

    private int teleAncho() { return Math.min(width - 16, 420); }
    private int teleAlto() { return height - 30; }
    private int teleX() { return (width - teleAncho()) / 2; }
    private int teleY() { return 22; }
    private int panel() { return 46; }                       // columna de perillas a la derecha
    private int pantallaX() { return teleX() + 14; }
    private int pantallaY() { return teleY() + 14; }
    private int pantallaAncho() { return teleAncho() - panel() - 28; }
    private int pantallaAlto() { return teleAlto() - 36; }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        if (ticks < ESTATICA || cerrando >= 0) {
            ctx.fill(0, 0, width, height, 0xFF000000);
            estatica(ctx, 0, 0, width, height, 255, 4);
            return;
        }
        ctx.fill(0, 0, width, height, 0xAA000000);
        dibujarTele(ctx);
        int sx = pantallaX(), sy = pantallaY(), sw = pantallaAncho(), sh = pantallaAlto();
        // pantalla encendida: fondo oscuro con un poco de nieve
        ctx.fill(sx, sy, sx + sw, sy + sh, 0xFF0C140F);
        estatica(ctx, sx, sy, sx + sw, sy + sh, 22, 3);
        ctx.enableScissor(sx, sy, sx + sw, sy + sh);
        int y = sy + 8 - (int) scroll;
        int inicio = y;
        Text cab = Text.literal("CANAL DE MISIONES").formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, cab, sx + sw / 2 - textRenderer.getWidth(cab) / 2, y, VERDE, true);
        y += 11;
        Text sub = Text.literal("Misiones del Reactor · emisión de hoy");
        ctx.drawText(textRenderer, sub, sx + sw / 2 - textRenderer.getWidth(sub) / 2, y, TXT_SUAVE, false);
        y += 14;
        y = seccion(ctx, sx, sw, y, "TAREAS DIARIAS", "diaria", AMARILLO);
        y += 6;
        y = seccion(ctx, sx, sw, y, "MISIONES SECUNDARIAS", "secundaria", CIAN);
        altoContenido = y - inicio + 10;
        ctx.disableScissor();
        // cristal del tubo: líneas de barrido, bordes oscuros y reflejo
        for (int ly = sy; ly < sy + sh; ly += 2) ctx.fill(sx, ly, sx + sw, ly + 1, 0x26000000);
        for (int i = 0; i < 8; i++) {
            int c = (8 - i) * 12 << 24;
            ctx.fill(sx + i, sy + i, sx + sw - i, sy + i + 1, c);
            ctx.fill(sx + i, sy + sh - i - 1, sx + sw - i, sy + sh - i, c);
            ctx.fill(sx + i, sy + i, sx + i + 1, sy + sh - i, c);
            ctx.fill(sx + sw - i - 1, sy + i, sx + sw - i, sy + sh - i, c);
        }
        ctx.fill(sx + 10, sy + 6, sx + 40, sy + 8, 0x30FFFFFF);
        // banda roja parpadeante "EN VIVO"
        if ((ticks / 15) % 2 == 0) ctx.fill(sx + 8, sy + sh - 14, sx + 13, sy + sh - 9, 0xFFFF3030);
        ctx.drawText(textRenderer, "EN VIVO", sx + 16, sy + sh - 15, 0xFFFF6060, false);
        if (altoContenido > sh) {
            String t = "rueda del ratón para bajar";
            ctx.drawText(textRenderer, t, sx + sw - 8 - textRenderer.getWidth(t), sy + sh - 15, 0xFF6F8F6F, false);
        }
        Text pie = Text.literal("L o Esc para apagar");
        ctx.drawText(textRenderer, pie, width / 2 - textRenderer.getWidth(pie) / 2, teleY() + teleAlto() + 2, 0xFFAAAAAA, true);
    }

    private void dibujarTele(DrawContext ctx) {
        int x = teleX(), y = teleY(), w = teleAncho(), h = teleAlto();
        // antenas
        int cx = x + (w - panel()) / 2;
        for (int k = 0; k < 18; k++) {
            ctx.fill(cx - 4 - k, y - 2 - k, cx - 1 - k, y + 1 - k, CROMO_OSC);
            ctx.fill(cx + 1 + k, y - 2 - k, cx + 4 + k, y + 1 - k, CROMO_OSC);
        }
        ctx.fill(cx - 8, y - 4, cx + 8, y + 2, 0xFF2A2A2A);
        // mueble de madera con vetas
        ctx.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0xFF1E1008);
        ctx.fill(x, y, x + w, y + h, MADERA_OSC);
        ctx.fill(x + 3, y + 3, x + w - 3, y + h - 3, MADERA);
        for (int vy = y + 5; vy < y + h - 5; vy += 3) {
            int d = (vy * 7) % 23;
            for (int vx = x + 5 + d; vx < x + w - 8; vx += 29) ctx.fill(vx, vy, Math.min(vx + 9 + (vy % 5), x + w - 5), vy + 1, 0x22000000);
        }
        // marco cromado de la pantalla
        int sx = pantallaX(), sy = pantallaY(), sw = pantallaAncho(), sh = pantallaAlto();
        ctx.fill(sx - 6, sy - 6, sx + sw + 6, sy + sh + 6, CROMO_OSC);
        ctx.fill(sx - 5, sy - 5, sx + sw + 5, sy + sh + 5, CROMO);
        ctx.fill(sx - 5, sy - 5, sx + sw + 5, sy - 4, CROMO_CLARO);
        ctx.fill(sx - 2, sy - 2, sx + sw + 2, sy + sh + 2, GOMA);
        // panel de control: placa, perillas, piloto y altavoz
        int px = x + w - panel() - 4, pw = panel() - 4;
        ctx.fill(px, y + 10, px + pw, y + h - 10, 0xFF4A2B17);
        ctx.fill(px + 4, y + 16, px + pw - 4, y + 26, LATON);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(px + pw / 2f, y + 18.5f, 0);
        ctx.getMatrices().scale(0.6f, 0.6f, 1f);
        ctx.drawText(textRenderer, "DESINFO", -textRenderer.getWidth("DESINFO") / 2, 0, 0xFF3B2213, false);
        ctx.getMatrices().pop();
        for (int k = 0; k < 2; k++) {
            int ky = y + 46 + k * 34, kx = px + pw / 2;
            ctx.fill(kx - 10, ky - 10, kx + 10, ky + 10, 0xFF0A0A0A);
            ctx.fill(kx - 9, ky - 9, kx + 9, ky + 9, 0xFF3A3A3A);
            ctx.fill(kx - 6, ky - 6, kx + 2, ky + 2, 0xFF555555);
            float a = (ticks + k * 20) * 0.05f;
            ctx.fill(kx + (int) (Math.cos(a) * 6) - 1, ky + (int) (Math.sin(a) * 6) - 1, kx + (int) (Math.cos(a) * 6) + 1, ky + (int) (Math.sin(a) * 6) + 1, 0xFFE8E8E8);
        }
        ctx.fill(px + 6, y + 108, px + 10, y + 112, (ticks / 10) % 2 == 0 ? 0xFFFF3030 : 0xFF801818);
        for (int ly = y + 120; ly < y + h - 16; ly += 4) ctx.fill(px + 5, ly, px + pw - 5, ly + 2, 0xFF2A1A10);
        // patas
        for (int lado = 0; lado < 2; lado++) {
            int lx = lado == 0 ? x + 16 : x + w - 26;
            ctx.fill(lx, y + h + 3, lx + 10, y + h + 7, 0xFF2E1A0E);
        }
    }

    private int seccion(DrawContext ctx, int sx, int sw, int y, String titulo, String tipo, int color) {
        int x = sx + 12, ancho = sw - 24;
        ctx.drawText(textRenderer, Text.literal("» " + titulo).formatted(Formatting.BOLD), x, y, color, true);
        ctx.fill(x, y + 10, x + ancho, y + 11, color & 0x99FFFFFF);
        y += 15;
        boolean alguna = false;
        for (MisionesCliente.Info m : MisionesCliente.LISTA) {
            if (!m.tipo().equals(tipo)) continue;
            alguna = true;
            ctx.fill(x, y, x + 9, y + 9, 0xFF6F8F6F);
            ctx.fill(x + 1, y + 1, x + 8, y + 8, m.hecha() ? 0xFF2E9E44 : 0xFF0C140F);
            if (m.hecha()) ctx.drawText(textRenderer, "✔", x + 1, y, 0xFFFFFFFF, false);
            Text t = Text.literal(m.titulo()).formatted(m.hecha() ? Formatting.STRIKETHROUGH : Formatting.BOLD);
            ctx.drawText(textRenderer, t, x + 14, y + 1, m.hecha() ? 0xFF6F8F6F : TXT, true);
            if (tipo.equals("diaria")) {
                int necesarios = (int) Math.ceil(m.total() * 0.75);
                Text g = Text.literal("Grupo " + m.grupo() + "/" + m.total() + " (necesitáis " + necesarios + ")");
                ctx.drawText(textRenderer, g, x + ancho - textRenderer.getWidth(g), y + 1, m.grupo() >= necesarios ? VERDE : AMARILLO, false);
            }
            y += 11;
            List<OrderedText> lineas = textRenderer.wrapLines(Text.literal(m.descripcion()), ancho - 14);
            for (OrderedText l : lineas) {
                ctx.drawText(textRenderer, l, x + 14, y, TXT_SUAVE, false);
                y += 10;
            }
            if (!m.recompensa().isEmpty()) {
                ctx.drawText(textRenderer, Text.literal("Recompensa: " + m.recompensa()).formatted(Formatting.ITALIC), x + 14, y, AMARILLO, false);
                y += 10;
            }
            y += 4;
        }
        if (!alguna) {
            ctx.drawText(textRenderer, Text.literal("Sin señal de misiones por ahora...").formatted(Formatting.ITALIC), x + 14, y, TXT_SUAVE, false);
            y += 12;
        }
        return y;
    }

    private static void estatica(DrawContext ctx, int x0, int y0, int x1, int y1, int alfa, int celda) {
        Ruido.dibujar(ctx, x0, y0, x1, y1, alfa >= 255 ? 1f : alfa / 255f * 0.5f, celda);
    }
}

package com.centrodesinformacion.desinformados.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Pantalla de misiones (tecla L), con estilo de periódico del Centro de Desinformación. */
public class MisionesScreen extends Screen {
    private static final int ANCHO = 260;

    public MisionesScreen() {
        super(Text.literal("Misiones"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (DesinformadosClient.TECLA_MISIONES.matchesKey(key, scan)) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = (width - ANCHO) / 2;
        int y = 20;
        int alto = height - 40;

        // Hoja de periódico
        ctx.fill(x - 2, y - 2, x + ANCHO + 2, y + alto + 2, 0xFF2B2318);
        ctx.fill(x, y, x + ANCHO, y + alto, 0xFFEDE6D3);
        ctx.fill(x + 6, y + 30, x + ANCHO - 6, y + 31, 0xFF2B2318);
        ctx.fill(x + 6, y + 32, x + ANCHO - 6, y + 33, 0xFF2B2318);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + ANCHO / 2f, y + 9, 0);
        ctx.getMatrices().scale(1.6f, 1.6f, 1f);
        Text cabecera = Text.literal("DESINFORMADOS").formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, cabecera, -textRenderer.getWidth(cabecera) / 2, 0, 0xFF1A140C, false);
        ctx.getMatrices().pop();
        Text sub = Text.literal("Misiones del Reactor · edición de hoy");
        ctx.drawText(textRenderer, sub, x + ANCHO / 2 - textRenderer.getWidth(sub) / 2, y + 21, 0xFF5A4C38, false);

        int cy = y + 40;
        cy = seccion(ctx, x, cy, "TAREAS DIARIAS", "diaria", 0xFF8A5A00);
        cy += 6;
        seccion(ctx, x, cy, "MISIONES SECUNDARIAS", "secundaria", 0xFF1F5F7A);

        Text pie = Text.literal("Pulsa L o Esc para cerrar");
        ctx.drawText(textRenderer, pie, x + ANCHO / 2 - textRenderer.getWidth(pie) / 2, y + alto - 12, 0xFF8A7C66, false);
    }

    private int seccion(DrawContext ctx, int x, int y, String titulo, String tipo, int color) {
        ctx.drawText(textRenderer, Text.literal(titulo).formatted(Formatting.BOLD), x + 10, y, color, false);
        ctx.fill(x + 10, y + 10, x + ANCHO - 10, y + 11, color);
        y += 15;
        boolean alguna = false;
        for (MisionesCliente.Info m : MisionesCliente.LISTA) {
            if (!m.tipo().equals(tipo)) continue;
            alguna = true;
            // Casilla
            ctx.fill(x + 10, y, x + 19, y + 9, 0xFF2B2318);
            ctx.fill(x + 11, y + 1, x + 18, y + 8, m.hecha() ? 0xFF3FA34D : 0xFFF7F2E4);
            if (m.hecha()) ctx.drawText(textRenderer, "✔", x + 11, y, 0xFFFFFFFF, false);
            int colorTitulo = m.hecha() ? 0xFF6E8F5A : 0xFF1A140C;
            Text t = Text.literal(m.titulo()).formatted(m.hecha() ? Formatting.STRIKETHROUGH : Formatting.BOLD);
            ctx.drawText(textRenderer, t, x + 24, y + 1, colorTitulo, false);
            if (tipo.equals("diaria")) {
                int necesarios = (int) Math.ceil(m.total() * 0.75);
                Text g = Text.literal("Grupo " + m.grupo() + "/" + m.total() + " (necesitáis " + necesarios + ")");
                ctx.drawText(textRenderer, g, x + ANCHO - 10 - textRenderer.getWidth(g), y + 1,
                        m.grupo() >= necesarios ? 0xFF3FA34D : 0xFF8A5A00, false);
            }
            y += 11;
            List<OrderedText> lineas = textRenderer.wrapLines(Text.literal(m.descripcion()), ANCHO - 34);
            for (OrderedText l : lineas) {
                ctx.drawText(textRenderer, l, x + 24, y, 0xFF4A3F30, false);
                y += 10;
            }
            y += 4;
        }
        if (!alguna) {
            ctx.drawText(textRenderer, Text.literal("Nada por ahora...").formatted(Formatting.ITALIC), x + 24, y, 0xFF8A7C66, false);
            y += 12;
        }
        return y;
    }
}

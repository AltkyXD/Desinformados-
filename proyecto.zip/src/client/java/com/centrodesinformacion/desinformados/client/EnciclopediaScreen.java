package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.CambiosActivos;
import com.centrodesinformacion.desinformados.Eventos;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Enciclopedia de la Desinformación (tecla O): todo lo que ya ha salido en las teles.
 * - Cambios de dificultad (teles amarillas).
 * - Mobs nuevos (teles azules), con sus mutaciones si ya han salido.
 * - Mobs de siempre mutados (teles naranjas sobre mobs normales).
 * - Crafteos especiales: las recetas y conversiones que se van desbloqueando.
 * Lo que aún no ha salido no se enseña (solo cuántos faltan), para no hacer spoilers.
 */
public class EnciclopediaScreen extends Screen {
    private static int pestana = 0;
    private double scroll = 0;
    private int altoContenido = 0;
    private final int[] tabX = new int[5];
    private static final int PESTANAS = 4;
    /** Objeto bajo el ratón en la página de crafteos (para enseñar su nombre). */
    private ItemStack bajoRaton = ItemStack.EMPTY;
    private int ratonX, ratonY, zonaArriba, zonaAbajo;

    /** Un crafteo especial: qué hace falta para verlo y qué se dibuja (una receta, una fila de objetos o una conversión). */
    private record Crafteo(String titulo, String descripcion, String requisito, String receta, List<ItemStack> iconos,
                           List<ItemStack> conversion) {}

    private static List<ItemStack> pilas(Item... items) {
        List<ItemStack> l = new ArrayList<>();
        for (Item i : items) l.add(new ItemStack(i));
        return l;
    }

    private static final List<Crafteo> CRAFTEOS = List.of(
            new Crafteo("Equipo de diamante", "Herramientas, armas y armaduras de diamante, con su receta de siempre.",
                    com.centrodesinformacion.desinformados.Crafteos.CAMBIO_DIAMANTE, null,
                    pilas(Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
                            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS), null),
            new Crafteo("Conversor Difamónico: a netherite", "En el Conversor de la planta baja del Centro: clic derecho con una pieza de diamante "
                    + "en la mano y un lingote de netherite en el inventario. Vale para armadura, armas y herramientas.",
                    "nether_abierto", null, null,
                    List.of(new ItemStack(Items.DIAMOND_CHESTPLATE), new ItemStack(Items.NETHERITE_INGOT), new ItemStack(Items.NETHERITE_CHESTPLATE))),
            new Crafteo("Pastilla anti-Endcer", "20 minutos sin Endcer en el End. Salen 2.", "evento:end_radiactivo",
                    "desinformados:pastilla_anti_endcer", null, null),
            new Crafteo("Libreta del Becario", "La puerta a la Libreta: un mundo entero dibujado a lápiz.", "receta_libreta",
                    "desinformados:libreta_portal", null, null),
            new Crafteo("Bloque de Garatita", "9 Garatitas en un bloque (y se puede volver a deshacer).", "receta_bloque_garatita",
                    "desinformados:bloque_garatita", null, null),
            new Crafteo("Conversor Difamónico: a Garatita", "Clic derecho al Conversor con una pieza de netherite en la mano y "
                    + com.centrodesinformacion.desinformados.ConversorBlock.COSTE_GARATITA + " Garatitas en el inventario.",
                    com.centrodesinformacion.desinformados.dimension.LibretaBlock.MARCA_ABIERTA, null, null,
                    List.of(new ItemStack(Items.NETHERITE_CHESTPLATE),
                            new ItemStack(com.centrodesinformacion.desinformados.ModItems.GARATITA, com.centrodesinformacion.desinformados.ConversorBlock.COSTE_GARATITA),
                            new ItemStack(com.centrodesinformacion.desinformados.ModGaratita.PETO))),
            new Crafteo("Centro de Estática", "9 Fragmentos de Estática bien apretados.", "receta_centro_estatica",
                    "desinformados:centro_estatica", null, null),
            new Crafteo("Desinformación Pura", "Usadla cerca de la Tele Gigante... si os atrevéis.", "receta_desinformacion_pura",
                    "desinformados:cubo_desinformacion", null, null));
    private int tabY;

    private static final int CUERO = 0xFF4A2414, CUERO_OSC = 0xFF2A120A, PAPEL = 0xFFF1E4C4, PAPEL_OSC = 0xFFE2D1A8,
            TINTA = 0xFF3A2410, TINTA_SUAVE = 0xFF5E4A34, TINTA_GRIS = 0xFF8C7656, ROJO = 0xFF9E2A1E, NARANJA = 0xFFB4580A, AZUL = 0xFF2858A8;

    /** Nombre corto de cada mob nuevo (por el id de su tele azul). */
    private static final Map<String, String> NOMBRE_MOB = Map.ofEntries(
            Map.entry("creepers_oscuros", "Creeper Oscuro"), Map.entry("furros", "Furro"), Map.entry("cubo_blanco", "Cubo Blanco"),
            Map.entry("zombie_naranja", "Zombie Naranja"), Map.entry("garabatos", "Garabatos"), Map.entry("interferencia", "Tinky Winky"),
            Map.entry("travensanos", "Travensaños"), Map.entry("ale", "Ale"), Map.entry("ulises", "Ulises"), Map.entry("angel", "Angel Manipulador"),
            Map.entry("brandon_kevin", "Brandon y Kevin"), Map.entry("altky", "Altky"),
            Map.entry("nether_poblado", "Vecinos del Nether (Creeper de Fuego, Cubo Rojo y Esqueleto Ráfaga)"));

    /** A quién afecta cada mutación: "mob:<id de la tele azul>" o el nombre de un mob de siempre. */
    private static final Map<String, List<String>> AFECTA = Map.ofEntries(
            Map.entry("aranas_pequenas", List.of("Arañas")),
            Map.entry("zombies_falsos", List.of("Zombies")),
            Map.entry("bebes_rapidos", List.of("Zombies")),
            Map.entry("esqueletos_doble_arco", List.of("Esqueletos")),
            Map.entry("creepers_electrificados", List.of("Creepers", "mob:creepers_oscuros")),
            Map.entry("creeper_invisible", List.of("mob:creepers_oscuros")),
            Map.entry("ale_poderoso", List.of("mob:ale")),
            Map.entry("travensanos_furiosos", List.of("mob:travensanos")),
            Map.entry("garabatos_altos", List.of("mob:garabatos")),
            Map.entry("furros_manada", List.of("mob:furros")),
            Map.entry("interferencias_clon", List.of("mob:interferencia")),
            Map.entry("cubo_gigante", List.of("mob:cubo_blanco")),
            Map.entry("ulises_rapido", List.of("mob:ulises")),
            Map.entry("brandon_mejorado", List.of("mob:brandon_kevin")),
            Map.entry("altky_tableta", List.of("mob:altky")),
            Map.entry("libreta_mejorada", List.of("Mobs de la Libreta")),
            Map.entry("ghasts_triples", List.of("Ghasts")),
            Map.entry("blazes_dobles", List.of("Blazes")),
            Map.entry("piglins_ladrones", List.of("Piglins")),
            Map.entry("hoglins_gimnasio", List.of("Hoglins")),
            Map.entry("magma_ardiente", List.of("Cubos de magma")),
            Map.entry("wither_veneno", List.of("Esqueletos wither")),
            Map.entry("zombificados_rencorosos", List.of("Piglins zombificados")),
            Map.entry("enderman_teletransporte", List.of("Endermen")));

    public EnciclopediaScreen() {
        super(Text.literal("Enciclopedia de la Desinformación"));
    }

    @Override public boolean shouldPause() { return false; }

    private static boolean visto(String id) {
        return CambiosActivos.CLIENTE.contains("evento:" + id);
    }

    private static List<Eventos.Evento> deColor(String color) {
        List<Eventos.Evento> l = new ArrayList<>();
        for (Eventos.Evento e : Eventos.TODOS.values()) if (e.color().equals(color)) l.add(e);
        return l;
    }

    private int panelAncho() { return Math.min(width - 20, 400); }
    private int panelAlto() { return height - 30; }
    private int panelX() { return (width - panelAncho()) / 2; }
    private int panelY() { return 15; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (DesinformadosClient.TECLA_ENCICLOPEDIA.matchesKey(key, scan) || key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_TAB || key == GLFW.GLFW_KEY_RIGHT) { cambiar((pestana + 1) % PESTANAS); return true; }
        if (key == GLFW.GLFW_KEY_LEFT) { cambiar((pestana + PESTANAS - 1) % PESTANAS); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void cambiar(int p) {
        if (p == pestana) return;
        pestana = p;
        scroll = 0;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ITEM_BOOK_PAGE_TURN, 1f, 0.8f));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int boton) {
        if (my >= tabY - 3 && my <= tabY + 12) {
            for (int i = 0; i < PESTANAS; i++) if (mx >= tabX[i] && mx < tabX[i + 1] - 4) { cambiar(i); return true; }
        }
        return super.mouseClicked(mx, my, boton);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = MathHelper.clamp(scroll - v * 14, 0, Math.max(0, altoContenido - (panelAlto() - 64)));
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = panelX(), y = panelY(), w = panelAncho(), h = panelAlto();
        // tapas de cuero y hojas de papel
        ctx.fill(x - 4, y - 4, x + w + 4, y + h + 4, CUERO_OSC);
        ctx.fill(x - 3, y - 3, x + w + 3, y + h + 3, CUERO);
        ctx.fill(x + 2, y + 2, x + w - 2, y + h - 2, PAPEL_OSC);
        ctx.fill(x + 4, y + 3, x + w - 4, y + h - 3, PAPEL);
        for (int ly = y + 50; ly < y + h - 10; ly += 12) ctx.fill(x + 10, ly, x + w - 10, ly + 1, 0x14000000);   // renglones
        Text titulo = Text.literal("ENCICLOPEDIA DE LA DESINFORMACIÓN").formatted(Formatting.BOLD);
        ctx.drawText(textRenderer, titulo, x + w / 2 - textRenderer.getWidth(titulo) / 2, y + 10, ROJO, false);
        Text sub = Text.literal("Todo lo que el Centro ha emitido hasta hoy");
        ctx.drawText(textRenderer, sub, x + w / 2 - textRenderer.getWidth(sub) / 2, y + 21, TINTA_GRIS, false);

        List<Eventos.Evento> cambios = deColor("amarillo"), mobs = deColor("azul"), mutaciones = deColor("naranja");
        int vc = (int) cambios.stream().filter(e -> visto(e.id())).count();
        int vm = (int) mobs.stream().filter(e -> visto(e.id())).count();
        List<Eventos.Evento> normales = new ArrayList<>();
        for (Eventos.Evento e : mutaciones) {
            List<String> a = AFECTA.getOrDefault(e.id(), List.of());
            if (a.stream().anyMatch(t -> !t.startsWith("mob:"))) normales.add(e);
        }
        int vn = (int) normales.stream().filter(e -> visto(e.id())).count();
        int vr = (int) CRAFTEOS.stream().filter(c -> CambiosActivos.CLIENTE.contains(c.requisito())).count();
        pestanas(ctx, x, y + 34, w, new String[]{"Cambios " + vc + "/" + cambios.size(), "Mobs " + vm + "/" + mobs.size(),
                "Mutados " + vn + "/" + normales.size(), "Crafteos " + vr + "/" + CRAFTEOS.size()});

        int arriba = y + 50, abajo = y + h - 14;
        bajoRaton = ItemStack.EMPTY;
        ratonX = mx;
        ratonY = my;
        zonaArriba = arriba;
        zonaAbajo = abajo;
        ctx.enableScissor(x + 4, arriba, x + w - 4, abajo);
        int cy = arriba + 4 - (int) scroll, inicio = cy;
        int cx = x + 14, ancho = w - 28;
        if (pestana == 0) cy = listaCambios(ctx, cx, cy, ancho, cambios);
        else if (pestana == 1) cy = listaMobs(ctx, cx, cy, ancho, mobs, mutaciones);
        else if (pestana == 2) cy = listaNormales(ctx, cx, cy, ancho, normales);
        else cy = listaCrafteos(ctx, cx, cy, ancho);
        altoContenido = cy - inicio + 8;
        ctx.disableScissor();
        if (!bajoRaton.isEmpty()) ctx.drawItemTooltip(textRenderer, bajoRaton, mx, my);
        Text pie = Text.literal("O o Esc para cerrar · Tab para pasar de página" + (altoContenido > h - 64 ? " · rueda para bajar" : ""));
        ctx.drawText(textRenderer, pie, width / 2 - textRenderer.getWidth(pie) / 2, y + h + 6, 0xFFAAAAAA, true);
    }

    private void pestanas(DrawContext ctx, int x, int y, int w, String[] nombres) {
        int total = 0;
        for (String n : nombres) total += textRenderer.getWidth(n) + 14;
        int px = x + w / 2 - (total + 8) / 2;
        tabY = y;
        for (int i = 0; i < PESTANAS; i++) {
            tabX[i] = px;
            int tw = textRenderer.getWidth(nombres[i]) + 10;
            boolean activa = i == pestana;
            if (activa) ctx.fill(px, y - 3, px + tw, y + 11, 0x22000000);
            ctx.drawText(textRenderer, Text.literal(nombres[i]).formatted(activa ? Formatting.BOLD : Formatting.RESET), px + 5, y, activa ? TINTA : TINTA_GRIS, false);
            if (activa) ctx.fill(px, y + 10, px + tw, y + 12, ROJO);
            px += tw + 4;
        }
        tabX[PESTANAS] = px;
        ctx.fill(x + 10, y + 13, x + w - 10, y + 14, 0x44000000);
    }

    private int parrafo(DrawContext ctx, String texto, int x, int y, int ancho, int color, boolean cursiva) {
        Text t = cursiva ? Text.literal(texto).formatted(Formatting.ITALIC) : Text.literal(texto);
        for (OrderedText l : textRenderer.wrapLines(t, ancho)) {
            ctx.drawText(textRenderer, l, x, y, color, false);
            y += 10;
        }
        return y;
    }

    private int titulo(DrawContext ctx, String texto, int x, int y, int color) {
        ctx.drawText(textRenderer, Text.literal(texto).formatted(Formatting.BOLD), x, y, color, false);
        return y + 11;
    }

    private int faltan(DrawContext ctx, int x, int y, int ancho, int n, String que) {
        if (n <= 0) return y;
        y += 2;
        ctx.drawText(textRenderer, Text.literal("??????").formatted(Formatting.OBFUSCATED), x, y, TINTA_GRIS, false);
        return parrafo(ctx, "Faltan " + n + " " + que + " por descubrir. Seguid mirando la tele.", x + 46, y, ancho - 46, TINTA_GRIS, true);
    }

    private int listaCambios(DrawContext ctx, int x, int y, int ancho, List<Eventos.Evento> cambios) {
        int faltan = 0;
        boolean alguno = false;
        for (Eventos.Evento e : cambios) {
            if (!visto(e.id())) { faltan++; continue; }
            alguno = true;
            y = titulo(ctx, "◆ " + e.titulo(), x, y, TINTA);
            y = parrafo(ctx, e.descripcion(), x + 8, y, ancho - 8, TINTA_SUAVE, false);
            if (!e.excusa().isEmpty()) y = parrafo(ctx, "«" + e.excusa() + "»", x + 8, y + 1, ancho - 8, TINTA_GRIS, true);
            y += 7;
        }
        if (!alguno) y = parrafo(ctx, "Todavía no ha salido ningún cambio de dificultad. Disfrutad mientras dure.", x, y, ancho, TINTA_SUAVE, true) + 4;
        return faltan(ctx, x, y, ancho, faltan, faltan == 1 ? "cambio" : "cambios");
    }

    private int listaMobs(DrawContext ctx, int x, int y, int ancho, List<Eventos.Evento> mobs, List<Eventos.Evento> mutaciones) {
        int faltan = 0;
        boolean alguno = false;
        for (Eventos.Evento e : mobs) {
            if (!visto(e.id())) { faltan++; continue; }
            alguno = true;
            y = titulo(ctx, "☠ " + NOMBRE_MOB.getOrDefault(e.id(), e.titulo()), x, y, AZUL);
            y = parrafo(ctx, e.descripcion(), x + 8, y, ancho - 8, TINTA_SUAVE, false);
            for (Eventos.Evento m : mutaciones) {
                if (!visto(m.id()) || !AFECTA.getOrDefault(m.id(), List.of()).contains("mob:" + e.id())) continue;
                y += 2;
                ctx.drawText(textRenderer, Text.literal("⚡ MUTACIÓN: ").formatted(Formatting.BOLD).append(Text.literal(m.titulo())), x + 8, y, NARANJA, false);
                y += 10;
                y = parrafo(ctx, m.descripcion(), x + 16, y, ancho - 16, TINTA_SUAVE, false);
            }
            y += 7;
        }
        if (!alguno) y = parrafo(ctx, "Todavía no ha llegado ningún mob nuevo. Sospechosamente tranquilo todo.", x, y, ancho, TINTA_SUAVE, true) + 4;
        return faltan(ctx, x, y, ancho, faltan, faltan == 1 ? "mob" : "mobs");
    }

    private int listaNormales(DrawContext ctx, int x, int y, int ancho, List<Eventos.Evento> normales) {
        // agrupadas por mob (Zombies, Esqueletos...), en el orden en que aparecen
        Map<String, List<Eventos.Evento>> grupos = new LinkedHashMap<>();
        int faltan = 0;
        for (Eventos.Evento e : normales) {
            if (!visto(e.id())) { faltan++; continue; }
            for (String t : AFECTA.getOrDefault(e.id(), List.of())) {
                if (!t.startsWith("mob:")) grupos.computeIfAbsent(t, k -> new ArrayList<>()).add(e);
            }
        }
        for (var g : grupos.entrySet()) {
            y = titulo(ctx, "☠ " + g.getKey(), x, y, NARANJA);
            for (Eventos.Evento m : g.getValue()) {
                ctx.drawText(textRenderer, Text.literal("⚡ " + m.titulo()).formatted(Formatting.BOLD), x + 8, y, TINTA, false);
                y += 10;
                y = parrafo(ctx, m.descripcion(), x + 16, y, ancho - 16, TINTA_SUAVE, false);
                y += 3;
            }
            y += 5;
        }
        if (grupos.isEmpty()) y = parrafo(ctx, "Los mobs de siempre siguen siendo los de siempre. De momento.", x, y, ancho, TINTA_SUAVE, true) + 4;
        return faltan(ctx, x, y, ancho, faltan, faltan == 1 ? "mutación" : "mutaciones");
    }

    // ------------------------------------------------------------------ crafteos especiales

    private int listaCrafteos(DrawContext ctx, int x, int y, int ancho) {
        int faltan = 0;
        boolean alguno = false;
        for (Crafteo c : CRAFTEOS) {
            if (!CambiosActivos.CLIENTE.contains(c.requisito())) { faltan++; continue; }
            alguno = true;
            y = titulo(ctx, "⚒ " + c.titulo(), x, y, TINTA);
            y = parrafo(ctx, c.descripcion(), x + 8, y, ancho - 8, TINTA_SUAVE, false);
            y += 3;
            if (c.receta() != null) y = receta(ctx, x + 8, y, c.receta());
            else if (c.iconos() != null) {
                for (int i = 0; i < c.iconos().size(); i++) hueco(ctx, x + 8 + i * 19, y, c.iconos().get(i));
                y += 20;
            } else if (c.conversion() != null) {
                hueco(ctx, x + 8, y, c.conversion().get(0));
                ctx.drawText(textRenderer, "+", x + 8 + 22, y + 5, TINTA, false);
                hueco(ctx, x + 8 + 30, y, c.conversion().get(1));
                ctx.drawText(textRenderer, "→", x + 8 + 54, y + 5, TINTA, false);
                hueco(ctx, x + 8 + 66, y, c.conversion().get(2));
                y += 20;
            }
            y += 8;
        }
        if (!alguno) y = parrafo(ctx, "Todavía no se ha desbloqueado ningún crafteo especial. Las misiones (tecla U) os irán dando recetas.",
                x, y, ancho, TINTA_SUAVE, true) + 4;
        return faltan(ctx, x, y, ancho, faltan, faltan == 1 ? "crafteo" : "crafteos");
    }

    /** Una casilla de inventario con su objeto (y su nombre si pasas el ratón por encima). */
    private void hueco(DrawContext ctx, int x, int y, ItemStack stack) {
        ctx.fill(x, y, x + 18, y + 18, 0xFF8B7355);
        ctx.fill(x + 1, y + 1, x + 17, y + 17, 0xFFD8C79E);
        if (stack.isEmpty()) return;
        ctx.drawItem(stack, x + 1, y + 1);
        ctx.drawItemInSlot(textRenderer, stack, x + 1, y + 1);
        if (ratonX >= x && ratonX < x + 18 && ratonY >= y && ratonY < y + 18 && ratonY >= zonaArriba && ratonY < zonaAbajo) bajoRaton = stack;
    }

    /** Si un ingrediente vale varios objetos, se van turnando cada segundo. */
    private static ItemStack deIngrediente(Ingredient ing) {
        ItemStack[] opciones = ing.getMatchingStacks();
        if (opciones.length == 0) return ItemStack.EMPTY;
        return opciones[(int) ((System.currentTimeMillis() / 1000) % opciones.length)];
    }

    /** Dibuja la receta tal cual la tiene el juego: la cuadrícula, la flecha y el resultado. */
    private int receta(DrawContext ctx, int x, int y, String id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return y;
        var entrada = mc.world.getRecipeManager().get(Identifier.of(id));
        if (entrada.isEmpty()) return y;
        Recipe<?> r = entrada.get().value();
        List<Ingredient> ings = r.getIngredients();
        int ancho = 3, alto;
        if (r instanceof ShapedRecipe forma) {
            ancho = forma.getWidth();
            alto = forma.getHeight();
        } else {
            ancho = Math.min(3, Math.max(1, ings.size()));
            alto = (ings.size() + 2) / 3;
        }
        for (int fila = 0; fila < alto; fila++) {
            for (int col = 0; col < ancho; col++) {
                int i = fila * ancho + col;
                hueco(ctx, x + col * 18, y + fila * 18, i < ings.size() ? deIngrediente(ings.get(i)) : ItemStack.EMPTY);
            }
        }
        int medio = y + alto * 18 / 2 - 9;
        ctx.drawText(textRenderer, "→", x + ancho * 18 + 6, medio + 5, TINTA, false);
        hueco(ctx, x + ancho * 18 + 18, medio, r.getResult(mc.world.getRegistryManager()));
        return y + Math.max(alto * 18, 18) + 2;
    }
}

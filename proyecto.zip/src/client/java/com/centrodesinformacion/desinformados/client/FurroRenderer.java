package com.centrodesinformacion.desinformados.client;

import com.centrodesinformacion.desinformados.Desinformados;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Usa el modelo de zombi (brazos estirados = abrazo) con skin de perro. Formato de skin de jugador 64x64. */
public class FurroRenderer extends ZombieEntityRenderer {
    private static final Identifier TEXTURA = Desinformados.id("textures/entity/furro.png");

    public FurroRenderer(EntityRendererFactory.Context contexto) {
        super(contexto);
    }

    @Override
    public Identifier getTexture(ZombieEntity entidad) {
        return TEXTURA;
    }
}

package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.client.PasivasCliente;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Garras en primera persona: mientras estás colgado ves tus dos brazos subiendo hasta la esquina del bloque. */
@Mixin(HeldItemRenderer.class)
public abstract class ManosColgadoMixin {
    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At("HEAD"), cancellable = true)
    private void desinformados$manosAlBorde(float tickDelta, MatrixStack matrices, VertexConsumerProvider.Immediate consumidores,
                                            ClientPlayerEntity jugador, int luz, CallbackInfo ci) {
        if (!PasivasCliente.yoColgado() || jugador.isInvisible()) return;
        if (!(MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(jugador) instanceof PlayerEntityRenderer r)) return;
        PasivasCliente.primeraPersona = true;
        try {
            for (int lado = -1; lado <= 1; lado += 2) {          // +1 = brazo derecho (a la derecha de la pantalla)
                matrices.push();
                matrices.translate(lado * 0.6f, -0.42f, -0.32f);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(lado * -5f));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-28f));
                if (lado > 0) r.renderRightArm(matrices, consumidores, luz, jugador);
                else r.renderLeftArm(matrices, consumidores, luz, jugador);
                matrices.pop();
            }
        } finally {
            PasivasCliente.primeraPersona = false;
        }
        consumidores.draw();
        ci.cancel();
    }
}

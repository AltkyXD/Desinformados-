package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.client.ControlesInvertidos;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Invierte el movimiento cuando un Travensaño está en tu cabeza. */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void desinformados$invertir(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        if (!ControlesInvertidos.activos()) return;
        movementForward = -movementForward;
        movementSideways = -movementSideways;
        boolean adelante = pressingForward;
        pressingForward = pressingBack;
        pressingBack = adelante;
        boolean izquierda = pressingLeft;
        pressingLeft = pressingRight;
        pressingRight = izquierda;
    }
}

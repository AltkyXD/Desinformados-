package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.client.ControlesInvertidos;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Invierte el ratón (izquierda/derecha y arriba/abajo) mientras tengas un Travensaño encima. */
@Mixin(Entity.class)
public abstract class EntityLookMixin {
    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private double desinformados$invertirX(double dx) {
        return esYoInvertido() ? -dx : dx;
    }

    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private double desinformados$invertirY(double dy) {
        return esYoInvertido() ? -dy : dy;
    }

    private boolean esYoInvertido() {
        return ControlesInvertidos.activos() && (Object) this == MinecraftClient.getInstance().player;
    }
}

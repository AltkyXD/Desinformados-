package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.client.PasivasCliente;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Garras: si el jugador está colgado de un borde, levanta los dos brazos hacia la esquina (lo ven todos y tú en F5). */
@Mixin(PlayerEntityModel.class)
public abstract class BrazosColgadoMixin<T extends LivingEntity> extends BipedEntityModel<T> {
    @Shadow @Final public ModelPart leftSleeve;
    @Shadow @Final public ModelPart rightSleeve;

    protected BrazosColgadoMixin(ModelPart root) {
        super(root);
    }

    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void desinformados$brazosArriba(T entidad, float f, float g, float h, float i, float j, CallbackInfo ci) {
        if (PasivasCliente.primeraPersona || !PasivasCliente.estaColgado(entidad)) return;
        // brazos hacia arriba y un poco hacia delante (la pared), con las manos juntas en la esquina
        float arriba = (float) -Math.PI + 0.3f;
        rightArm.pitch = arriba;
        leftArm.pitch = arriba;
        rightArm.yaw = 0.12f;
        leftArm.yaw = -0.12f;
        rightArm.roll = 0.08f;
        leftArm.roll = -0.08f;
        rightSleeve.copyTransform(rightArm);
        leftSleeve.copyTransform(leftArm);
    }
}

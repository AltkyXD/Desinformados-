package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.Desinformados;
import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** En la Libreta el sol es un garabato sonriente. */
@Mixin(WorldRenderer.class)
public class SolLibretaMixin {
    private static final Identifier SOL_GARABATO = Desinformados.id("textures/environment/sol_garabato.png");

    @ModifyArg(method = "renderSky", require = 0,
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderTexture(ILnet/minecraft/util/Identifier;)V"),
            index = 1)
    private Identifier desinformados$solGarabato(Identifier textura) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null && mc.world.getRegistryKey() == Dimensiones.LIBRETA
                && textura.getPath().equals("textures/environment/sun.png")) {
            return SOL_GARABATO;
        }
        return textura;
    }
}

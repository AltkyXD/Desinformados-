package com.centrodesinformacion.desinformados.mixin;

import com.centrodesinformacion.desinformados.dimension.Dimensiones;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Sin niebla en el Interior de la Tele ni en la Libreta (dentro de la tinta sí se ve oscuro). */
@Mixin(BackgroundRenderer.class)
public class SinNieblaMixin {
    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void desinformados$sinNiebla(Camera camera, BackgroundRenderer.FogType fogType, float viewDistance,
                                                boolean thickFog, float tickDelta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        var mundo = mc.world.getRegistryKey();
        if (mundo != Dimensiones.TELE && mundo != Dimensiones.LIBRETA) return;
        if (camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        if (mc.player.hasStatusEffect(StatusEffects.BLINDNESS) || mc.player.hasStatusEffect(StatusEffects.DARKNESS)) return;
        RenderSystem.setShaderFogStart(viewDistance * 4f);
        RenderSystem.setShaderFogEnd(viewDistance * 5f);
    }
}

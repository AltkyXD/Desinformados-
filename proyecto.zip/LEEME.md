# Desinformados – Mod para Minecraft 1.21.1 (Fabric)

## 1. Preparar el proyecto (solo la primera vez)
1. Instala **Java 21 (JDK)** e **IntelliJ IDEA Community**.
2. Entra en https://fabricmc.net/develop/template y rellena:
   - Mod Name: `Desinformados` · Mod ID: `desinformados`
   - Package: `com.centrodesinformacion.desinformados`
   - Minecraft: `1.21.1` · marca **Split client and common sources**
3. Descarga y descomprime el proyecto.
4. **Borra su carpeta `src`** y pon en su lugar la carpeta `src` de este zip.
5. Ábrelo con IntelliJ y espera a que Gradle termine de cargar.

## 2. Probar y compilar
- Probar en el juego: `./gradlew runClient` (en Windows: `gradlew.bat runClient`)
- Generar el .jar: `./gradlew build` → `build/libs/desinformados-1.0.0.jar`

## 3. Instalar
- **Servidor:** Fabric server 1.21.1 + Fabric API + el .jar en `mods/`.
- **Los 5 jugadores:** Fabric 1.21.1 + Fabric API + el mismo .jar.

## 4. Comandos (solo operadores)
| Comando | Qué hace |
|---|---|
| `/desinfo evento <verde\|rojo\|amarillo> "Título" descripción...` | Lanza la tele a todos |
| `/desinfo fase <1-4>` | Desbloquea minerales (1 hierro, 2 oro/redstone/lapis, 3 diamante, 4 netherite) |
| `/desinfo spawn radio <bloques>` | Tamaño de la zona protegida del spawn (32 por defecto) |
| `/desinfo muertos` | Lista de jugadores fuera |
| `/desinfo revivir <jugador>` | Revivir gratis (para emergencias) |

Ejemplo: `/desinfo evento rojo "Momento Desinformado" Los creepers ahora explotan el doble`

## 5. Para los jugadores
- Click derecho con un **Periódico Desinformado** → lista de muertos, clic en el nombre para revivirlo.
- O escribe `/revivir <jugador>` (gasta 1 periódico).
- Si mueres quedas fuera del server hasta que alguien te reviva.
- En **creativo** sí se puede construir en el spawn (para montarlo).

## 6. Dónde poner tus archivos
- Textura del periódico: `assets/desinformados/textures/item/periodico.png` (16x16)
- Gato (tótem): `assets/minecraft/textures/item/totem_of_undying.png`
- Sonidos: pon tus `.ogg` en `assets/desinformados/sounds/` y en `sounds.json`
  cambia cada `{ "name": "minecraft:...", "type": "event" }` por `"desinformados:nombre_del_archivo"`.

## 7. Sistema de vida
- **Corazón Rojo:** click derecho = +1 corazón (máximo 30). Los extra **se pierden al morir**.
- **Corazón de Alma:** click derecho = +1 corazón azul (máximo 10), en su propia fila encima de la armadura.
  Es un escudo aparte de los corazones dorados: el daño va a dorados -> azules -> rojos. No se regenera y se pierde al morir.
- Solo enemigos concretos quitarán contenedores rojos (se programan con `Vida.cambiarRojos(jugador, -1)`).
- Comandos (operadores):
  - `/desinfo vida <jugador> ver`
  - `/desinfo vida <jugador> rojos <cantidad>` (negativo para quitar)
  - `/desinfo vida <jugador> almas <cantidad>`

## 8. Eventos de la tele
- `/desinfo lanzar <id>` lanza la tele y su efecto. Sale una barra arriba con la cuenta atrás y el tiempo restante.
- `/desinfo detener` para todos los desafíos rojos en curso (sin castigos).
- Anuncios verdes libres: `/desinfo evento verde "Título" texto`

**Rojos (aviso → duración):**
creeper_sorpresa · lluvia_creepers · suelo_lava · gravedad_loca · noche_infernal · hambre_extrema ·
mobs_potenciados · prohibido_saltar · inventario_maldito · tormenta_rayos · apagon · todo_explota ·
todo_explota_suerte (1 de cada 3) · agua_toxica · mareo_total · mineria_explosiva · un_corazon ·
asedio · agachate · bloque_prohibido · no_te_muevas

**Rojos con objetivo (quien falle recibe el castigo):**
escalada · fondo_mundo · toca_madera · come_algo · a_la_cama · ponte_casco · cazarrecompensas ·
mojate · mira_cielo · mata_mob · sube_bloque

**Amarillos (permanentes):** arboles · creepers_oscuros
- `/desinfo cambios` lista los cambios activos · `/desinfo cambios quitar <id>` deshace uno.
- Los desafíos se programan en `desafio/Desafios.java` y los amarillos en `Eventos.java`.

## 9. Mobs bloqueados
Un mob bloqueado no puede existir en el mundo hasta que un evento lo desbloquee.
- `/desinfo mobs` · `/desinfo mobs bloquear <mod:mob>` · `/desinfo mobs desbloquear <mod:mob>`
- Para bloquear un mod entero: `/desinfo mobs bloquear nombredelmod:*`
- El **Creeper Oscuro** viene bloqueado. Si su explosión te alcanza pierdes un contenedor de corazón.
  Para probarlo: desbloquéalo y usa el Huevo de Creeper Oscuro.

## 10. Texturas incluidas
- Tótem → Gato de la Desinformación (la textura que mandaste).
- Icono del mod: la cara del gato.
- Creeper Oscuro: textura provisional en `textures/entity/creeper_oscuro.png` (formato 64x32 del creeper).

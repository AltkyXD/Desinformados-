# Desinformados – Mod para Minecraft 1.21.1 (Fabric)

## 1. Preparar el proyecto (solo la primera vez)
1. Instala **Java 21 (JDK)** e **IntelliJ IDEA Community**.
2. Entra en https://fabricmc.net/develop/template y rellena:
   - Mod Name: `Desinformados` · Mod ID: `desinformados`
   - Package: `com.centrodesinformacion.desinformados`
   - Minecraft: `1.21.1` · marca **Split client and common sources**
3. Descarga y descomprime el proyecto.
4. **Borra su carpeta `src`** y pon en su lugar la carpeta `src` de este zip.
5. Ábrelo con IntelliJ y espera a que Gradle termine de cargar.

## 2. Probar y compilar
- Probar en el juego: `./gradlew runClient` (en Windows: `gradlew.bat runClient`)
- Generar el .jar: `./gradlew build` → `build/libs/desinformados-1.0.0.jar`

## 3. Instalar
- **Servidor:** Fabric server 1.21.1 + Fabric API + el .jar en `mods/`.
- **Los 5 jugadores:** Fabric 1.21.1 + Fabric API + el mismo .jar.

## 4. Comandos (solo operadores)
| Comando | Qué hace |
|---|---|
| `/desinfo evento <verde\|rojo\|amarillo> "Título" descripción...` | Lanza la tele a todos |
| `/desinfo spawn radio <bloques>` | Tamaño de la zona protegida del spawn (32 por defecto) |
| `/desinfo muertos` | Lista de jugadores fuera |
| `/desinfo revivir <jugador>` | Revivir gratis (para emergencias) |

Ejemplo: `/desinfo evento rojo "Momento Desinformado" Los creepers ahora explotan el doble`

## 5. Para los jugadores
- Click derecho con un **Periódico Desinformado** → lista de muertos, clic en el nombre para revivirlo.
- O escribe `/revivir <jugador>` (gasta 1 periódico).
- Si mueres quedas fuera del server hasta que alguien te reviva.
- En **creativo** sí se puede construir en el spawn (para montarlo).

## 6. Dónde poner tus archivos
- Textura del periódico: `assets/desinformados/textures/item/periodico.png` (16x16)
- Gato (tótem): `assets/minecraft/textures/item/totem_of_undying.png`
- Sonidos: pon tus `.ogg` en `assets/desinformados/sounds/` y en `sounds.json`
  cambia cada `{ "name": "minecraft:...", "type": "event" }` por `"desinformados:nombre_del_archivo"`.

## 7. Sistema de vida
- **Corazón Rojo:** click derecho = +1 corazón (máximo 30). Los extra **se pierden al morir**.
- **Corazón de Alma:** click derecho = +1 corazón azul (máximo 3), en su propia fila encima de la armadura.
  Cada uno **bloquea un golpe entero**: ni daño ni pérdida de contenedor (Creeper Oscuro incluido). No se regenera y se pierde al morir.
- Solo enemigos concretos quitarán contenedores rojos (se programan con `Vida.cambiarRojos(jugador, -1)`).
- Comandos (operadores):
  - `/desinfo vida <jugador> ver`
  - `/desinfo vida <jugador> rojos <cantidad>` (negativo para quitar)
  - `/desinfo vida <jugador> almas <cantidad>`

## 8. Eventos de la tele
- `/desinfo lanzar <id>` lanza la tele y su efecto. Sale una barra arriba con la cuenta atrás y el tiempo restante.
- `/desinfo detener` para todos los desafíos rojos en curso (sin castigos).
- Anuncios verdes libres: `/desinfo evento verde "Título" texto`

**Rojos (aviso → duración):**
creeper_sorpresa · lluvia_creepers · suelo_lava · gravedad_loca · noche_infernal · hambre_extrema ·
mobs_potenciados · prohibido_saltar · inventario_maldito · tormenta_rayos · apagon · todo_explota ·
todo_explota_suerte (1 de cada 3) · agua_toxica · mareo_total · mineria_explosiva · un_corazon ·
asedio · agachate · bloque_prohibido · no_te_muevas

**Rojos con objetivo (quien falle recibe el castigo):**
escalada · fondo_mundo · toca_madera · come_algo · a_la_cama · ponte_casco · cazarrecompensas ·
mojate · mira_cielo · mata_mob · sube_bloque

**Amarillos (permanentes):** arboles · creepers_oscuros

**Colores de las teles:**
- 🟢 **Verde:** buenas noticias (recetas, desbloqueos, anuncios).
- 🔴 **Roja:** desafío.
- 🟡 **Amarilla:** cambio de dificultad del mundo (permanente).
- 🔵 **Azul:** llegan **nuevos mobs** (permanente). Son: creepers_oscuros · furros · cubo_blanco · zombie_naranja · garabatos · interferencia · travensanos · ale · ulises · angel · brandon_kevin · altky · nether_poblado. En el chat salen como **[NUEVO MOB]**.
- 🟠 **Naranja:** **mutaciones** de mobs (permanente). Son: aranas_pequenas · zombies_falsos · esqueletos_doble_arco · creepers_electrificados · bebes_rapidos · ale_poderoso · travensanos_furiosos · garabatos_altos · furros_manada · interferencias_clon · cubo_gigante · ulises_rapido · creeper_invisible · libreta_mejorada · brandon_mejorado · altky_tableta · ghasts_triples · blazes_dobles · piglins_ladrones · hoglins_gimnasio · magma_ardiente · wither_veneno · zombificados_rencorosos · enderman_teletransporte. En el chat salen como **[MUTACIÓN]**.
- 🟣 **Morada:** cosas importantes (Nether, End, la Libreta, la tele rota).
- `/desinfo evento <color> "Título" texto` acepta también **azul** y **naranja**.
- **Tele amarilla `mobs_cruzados`** ("¡Los mobs se han cambiado de dimensión!"):
  - **En el Overworld**, de noche y en sitios oscuros, aparecen también mobs del Nether: blazes, piglins, piglins brutos, hoglins, esqueletos wither, cubos de magma, piglins zombificados y, rara vez y solo al aire libre, algún ghast.
  - **En el Nether** aparecen zombies, esqueletos, creepers, arañas, brujas, aldeanos zombie y slimes.
  - Funciona aparte del spawn normal: cada 5 s, con un 60 % de probabilidad, sale uno a 18-40 bloques de cada jugador, con un máximo de 6 cerca de cada uno.
  - Los piglins y hoglins no se zombifican fuera del Nether.
- (Para el agua infinita ya existe la tele amarilla `agua_escasa`.)
- `/desinfo cambios` lista los cambios activos · `/desinfo cambios quitar <id>` deshace uno.
- Los desafíos se programan en `desafio/Desafios.java` y los amarillos en `Eventos.java`.

## 9. Mobs bloqueados
Un mob bloqueado no puede existir en el mundo hasta que un evento lo desbloquee.
- `/desinfo mobs` · `/desinfo mobs bloquear <mod:mob>` · `/desinfo mobs desbloquear <mod:mob>`
- Para bloquear un mod entero: `/desinfo mobs bloquear nombredelmod:*`
- El **Creeper Oscuro** viene bloqueado. Si su explosión te alcanza pierdes un contenedor de corazón.
  Para probarlo: desbloquéalo y usa el Huevo de Creeper Oscuro.

## 10. Texturas incluidas
- Tótem → Gato de la Desinformación (la textura que mandaste).
- Icono del mod: la cara del gato.
- Creeper Oscuro: textura provisional en `textures/entity/creeper_oscuro.png` (formato 64x32 del creeper).

## 11. Vidas
- Cada jugador tiene **2 vidas**. Al perder la primera sale la tele de la calavera: "¡Estás a punto de ser Desinformado!".
- Al perder la última: todos ven la tele cayendo y partiéndose con su nombre. El eliminado queda 8 s en espectador
  donde murió (suelta sus cosas) y luego sale del server.
- Al revivirlo con un periódico vuelve en supervivencia al spawn con **1 vida**.
- `/desinfo vidas <jugador> <n>` cambia las vidas · `/desinfo vida <jugador> ver` muestra vidas y corazones.

## 12. Furros
- `/desinfo lanzar furros` los desbloquea. Si te ven te persiguen y te abrazan (máx. 10 s): Lentitud IV y medio corazón cada 2 s.
- Textura: `textures/entity/furro.png`, **formato de skin de jugador 64x64** (podéis usar cualquier skin de Minecraft).
- Todos los mobs del mod empiezan bloqueados hasta que su tele amarilla los desbloquea.

## 13. Cubo Blanco
- `/desinfo lanzar cubo_blanco`. Cubo lento que salta hacia ti. Si te toca: 3 s aturdido y 4 s de pantalla en blanco. No hace daño ni se divide.
- Textura: `textures/entity/cubo_blanco.png` (formato de slime 64x32).

## 14. Ale y Travensaño
- No aparecen solos: huevo en creativo o `/summon desinformados:ale`.
- Ale: 10 corazones, te persigue y pega (1,5 corazones). Al morir suelta 2 Travensaños: te persiguen, se te sientan en el cuello (medio corazón cada 3 s, controles y cámara invertidos) hasta que los matas o pasan 15 s.
- Skins en formato de jugador 64x64: `textures/entity/ale.png` y `textures/entity/travensano.png`.

## 15. Ulises
- Solo con huevo o `/summon desinformados:ulises`. 7 corazones.
- Si te ve, se queda mirándote 8 s y lanza un rayo rojo que te quita la mitad de tu vida actual. Si lo pierdes de vista, se reinicia; si le pegas, le cuesta más concentrarse.

## 16. Tinky Winky (antes "Interferencia")
- Skin y screamer de Slendytubbies (con permiso). El id interno sigue siendo `interferencia`.
- `/desinfo lanzar interferencia`. Solo en cuevas y oscuridad total. 4 corazones, rápida.
- Si te toca: screamer de 2 s (siempre; un corazón de alma solo evita perder los corazones) (imagen `textures/gui/susto.png`, sonido `sounds/susto.ogg`), pierdes 5 contenedores de corazón durante 60 s y desaparece.

## 17. Misiones (tecla U)
Ya no hay misiones diarias ni fases de minerales. Ahora la progresión la marcan las **misiones**. Todo se explica en la sección 52.

## 18. Tótems
- Los evocadores ya no sueltan tótems (solo esmeraldas). Los Gatos de la Desinformación solo salen de misiones o cofres que preparéis.

## 19. Días de la serie
Ya no hace falta nada a mano: las misiones principales (sección 52) desbloquean el diamante, el Nether, el End, la Libreta y las recetas.

## 20. Rumores y Banco de Rumores
- Monedas: Amarillo (1), Azul (5), Verde (10), Rojo (20), Gris (50).
- **Banco de Rumores** (bloque, en creativo): clic derecho → pantalla con tu saldo. "Depositar" mete todos tus Rumores como número; "Sacar" te da la moneda que elijas (Shift = 10). Así se cambian monedas.
- No se puede romper en supervivencia. El saldo se guarda en el mundo.

## 21. Tragamonedas
- Bloques (en creativo): Tragamonedas Azul (10), Morada (20) y Gris (50). Miden 2 de ancho x 3 de alto; necesitan 2 bloques libres encima.
- Clic derecho: cobra con los Rumores del inventario (devuelve el cambio), los rodillos giran 3 s en la barra de acción y sale el premio.
- Tablas de premios en `Tragamonedas.java` (peso = probabilidad). Incluyen premios malos (mobs, desafío sorpresa).

## 22. Angel Manipulador
- `/desinfo lanzar angel` (aparece en lugares oscuros) o huevo / `/summon desinformados:angel`. 10 corazones.
- Si te ve: cámara fija en él, sin poder moverte, pantalla azul y te arrastra hacia él. Ya cerca, 2 s para matarlo antes de que explote.

## 23. Activar en bloque (pruebas)
- `/desinfo activar mobs` · `/desinfo activar mutaciones` · `/desinfo activar mundo` (sin teles).
- `/desinfo desactivar todo`: quita todos los cambios y vuelve a bloquear los mobs del mod.


## 24. Dimensiones
### Interior de la Tele (jefe final)
- **Tele Gigante (portal)** 5x5 en creativo, en el spawn (pantalla de 4x4, panel con perillas a la derecha y base con patas abajo). `/desinfo portal tele romper` → vórtice; entrar en la pantalla te lleva dentro. `reparar` la arregla.
- Siempre se llega a un **cuartito** → **túnel largo** (a oscuras: mobs de estática, Interferencias, Cubos Blancos) → **arena circular** iluminada para el jefe final (aún sin jefe).
- Paredes irrompibles. Salir: Salida de la Tele en el cuartito. `/desinfo arena reconstruir` rehace la estructura.
### Libreta del Becario
- Bloque **Libreta del Becario**: una libreta plana sobre el escritorio. Receta: 3 papel arriba, diamante-libro-diamante en medio y saco de tinta abajo. Se puede romper (con la mano basta) y la recuperas, así podéis poner entradas/salidas donde queráis. La Tele Gigante NO tiene receta: solo la colocan los admins en creativo.
  - Empieza **cerrada**: no deja entrar. `/desinfo portal libreta abrir` abre todas las libretas (se ven abiertas, con sus hojas) y entonces clic → Libreta. `/desinfo portal libreta cerrar` las vuelve a cerrar.
  - Dentro, la libreta de al lado (siempre abierta) te devuelve. Siempre llegáis a tierra firme, no al mar.
- Sin niebla ni en la Libreta ni en el Interior de la Tele.
- Mundo normal de altura 0-256 (como 1.16.5), casi todo tierra (nivel del mar bajado a 48, sin océanos grandes) con pocitos de tinta repartidos, cuevas clásicas y algún cañón (las de abajo están secas, con algún charco de tinta). **Todo es papel de cuaderno a lápiz**: piedra, tierra, césped, arena, troncos, tablas, hojas y un fondo irrompible abajo. Los troncos de papel sirven como madera normal (tablas, mesa, palos) y la piedra de papel como piedra (herramientas y horno).
- **Solo hay 2 minerales**: **Garatita** (muy común: 16 vetas grandes por chunk, y 0-80; cada mena da 1; pico de hierro, ¡tráiganse uno!) y **Mineral de Estática** (rara, vetas pequeñas, sobre todo abajo; pico de piedra; cada mena da 1 fragmento). La Estática se ve como una mena de Garatita con glitch animado.
- El agua es **Tinta**: se nada igual, pero al tocarla los bordes de la pantalla se manchan de negro y tardan ~8 s en secarse. Se puede recoger con cubo.
- Cielo **gris** con un **sol garabateado sonriente**.
- Solo aparecen **mobs hostiles dibujados** (zombie, esqueleto, creeper, araña): más rápidos pero con menos vida. **No se queman de día y aparecen también de día** (las antorchas siguen evitando que aparezcan cerca); las arañas atacan siempre. No hay animales, así que no hay comida: lleven la suya.
- Pruebas: `/desinfo ir tele`, `/desinfo ir libreta`, `/desinfo ir volver`.

## 25. Reglas del mundo
- **Sin placa de mejora de netherite**: las mejoras se hacen en el **Conversor Difamónico**. Si alguien encuentra una placa de mejora en un bastión, desaparece del inventario (excepto en creativo).
- **Conversor Difamónico** (2x1, con dos ojos enormes; se coloca en creativo y es irrompible en supervivencia). Clic derecho con la pieza en la mano:
  - Pieza de **diamante** + 1 **lingote de netherite** (del inventario) → pieza de netherite.
  - Pieza de **netherite** + 4 **Garatitas** (del inventario) → pieza de **Garatita**.
  - Se conservan encantamientos, nombre y durabilidad. Con la mano vacía te dice qué necesita.
- **Equipo de Garatita** (moldes del diamante con textura de hoja de libreta; **el doble de durabilidad que el netherite**; no se quema en lava; se repara con Garatita). Base = netherite:
  - **Armadura**: +2 de armadura por pieza (5/10/8/5), dureza 3, empuje 10 %, y **+10 % de velocidad por pieza** (+40 % con el set completo).
    Puesta tiene **la misma forma que la armadura de netherite** (casco abierto, relieves, sombras) pero pintada con el papel de libreta. La textura la genera el juego al cargar los recursos a partir de la netherite de tu propio Minecraft (si usas un paquete de texturas que cambia la netherite, la de Garatita sigue esa forma).
  - **Espada**: 11 de daño (+3) y ataca más rápido (2.0 por segundo en vez de 1.6).
  - **Hacha**: 12 de daño (+2) y ataca más rápido (1.4 en vez de 1.0).
  - **Pico**: mina mucho más rápido (velocidad 14 en vez de 9).
  - **Pala** y **azada**: igual que las de netherite. Al mejorar la azada, el Conversor solo dice: *"¿En serio?"*
- **Estructuras eliminadas** (no se generan en mundos/chunks nuevos): cámaras de desafío (trial chambers), mansiones del bosque, monumentos oceánicos, templos del desierto y templos de la jungla.

## 26. Orden de la tele
1. La tele aparece y muestra **estática** (~4 s).
2. Flash y la pantalla se pone del **color** del evento (~3 s).
3. **Verde/amarillo**: la tele se encoge y desaparece → llega el **mensaje al chat** y se aplica el evento.
   **Rojo**: la pantalla se agrieta y la tele **estalla en pedazos** → entonces llega el **mensaje** y **empieza el desafío** (con su aviso de 10 s).
Todo dura ~8,6 s. `/desinfo detener` también cancela un desafío anunciado cuya tele aún no se rompió.

## 27. Libreta: mobs y cambios de dificultad
- Aparecen en **grupos**: zombies (4-8), esqueletos (3-6), arañas (2-5), creepers (2-4) y **Garabatos** (3-6, libres en la Libreta sin desbloquearlos).
- Cambio de dificultad propio: `/desinfo lanzar libreta_mejorada` (amarillo). **Solo se puede lanzar con la libreta abierta** (`/desinfo portal libreta abrir`); si está cerrada da error y `/desinfo activar` se lo salta.
  Comunicado: *"Los garabatos se sintieron celosos de que solo hayamos mejorado a los de la superficie, así que les hemos agregado cosas."*
  - Zombies dibujados: Debilidad 4 s al golpearte.
  - Esqueletos dibujados: sus flechas dan Lentitud II 3 s.
  - Creepers dibujados: su explosión ciega 3 s y mancha la pantalla de tinta.
  - Arañas dibujadas: te dejan 4 s en una telaraña.
  - Garabatos: al matarlos en la Libreta, 50 % de que reaparezcan (una vez).

## 28. Centro de Estática y Desinformación Pura
- **Bloque de Garatita**: 9 Garatitas (y se puede volver a deshacer en 9). Pico de hierro.
- **Centro de Estática**: 9 Fragmentos de Estática (3x3). Textura animada: círculo que se deforma en cubo y pentágono, glitcheando.
- **Desinformación Pura** (orbe con un cristal de estática arriba y líneas blancas girando):
  ```
  N F N      N = lingote de netherite   F = Fragmento de Estática
  D C D      D = bloque de diamante     C = Centro de Estática
  N G N      G = Bloque de Garatita
  ```
  Al usarlo (clic derecho al aire o sobre un bloque) sale flotando donde lo usaste, gira cargándose de estática 5 s y **estalla**, rompiendo la Tele Gigante (como `/desinfo portal tele romper`, con su tele roja). Si no hay ninguna Tele Gigante colocada, no se gasta.

## 29. Tele morada (cosas importantes)
- Nuevo color **morado** = anuncio importante (chat en morado claro con la etiqueta [IMPORTANTE]). También vale para `/desinfo evento morado "Título" descripción`.
- Usan la tele morada:
  - **La tele se ha roto** (`/desinfo portal tele romper` o al usar la Desinformación Pura).
  - **La Libreta abierta** (`/desinfo portal libreta abrir`): las libretas se abren cuando termina la tele.
  - **`/desinfo lanzar nether`** y **`/desinfo lanzar end`**.
- **El Nether y el End empiezan cerrados**: los portales no funcionan ("todavía no ha sido autorizado por el Centro de Desinformación") hasta lanzar su evento morado.

## 30. Recetas bloqueadas (teles verdes)
Bloqueadas hasta su desbloqueo (la mesa de crafteo no da el resultado y **no salen en el librito de recetas**):
| Receta | Se desbloquea con |
|---|---|
| Equipo de diamante (herramientas, armas, armadura) | `/desinfo lanzar diamante` (el mineral de diamante se puede picar siempre) |
| Libreta del Becario | al abrir la dimensión: `/desinfo portal libreta abrir` |
| Bloque de Garatita | `/desinfo lanzar receta_bloque_garatita` |
| Centro de Estática | `/desinfo lanzar receta_centro_estatica` |
| Desinformación Pura | `/desinfo lanzar receta_desinformacion_pura` |

**Herramientas necesarias:** Mena de Garatita → pico de diamante o mejor. Mineral de Estática → pico de netherite o mejor (o de Garatita). Bloque de Garatita → pico de hierro o mejor.

## 31. Gatos Cubo (NPC) y tiendas
Cubos estilo "Floppa": la cara del gato del canal delante (lo negro del fondo se convierte en pelaje), pelo por todos lados y dos orejas altas arriba. Inmortales (un admin en creativo los quita de un golpe) y maúllan al hablar.
**El becario es anónimo: nunca aparece** (los demás hablan de él como si lo vieran todos los días).
**Hablar con ellos**: los que no venden tienen una conversación de **3 frases seguidas** (cada clic, la siguiente). Después te sueltan cosas como *"¿No tienes algo mejor que hacer?"* (más una frase propia de cada uno). Lo que dicen sale en un **cuadro encima de la barra de objetos** (se va escribiendo letra a letra) mientras suena su voz. Solo hablan cuando les das clic derecho, con **7 segundos de espera** entre frase y frase. Cuando te acercas (5 bloques) les sale una **burbuja con "..."** sobre la cabeza; desaparece mientras están en espera.
**Solo caminan sobre madera** (tablones, troncos, losas y escaleras de madera), **lana/alfombras** de cualquier color, la **Pista de Baile** y las luces del suelo: así controláis por dónde andan.
**Pasean libremente por todo su piso** (eligen sitios al azar y solo aceptan caminos que vayan enteros por suelo permitido) y cada 1-3 minutos cambian entre el piso 1 y el 2 por las escaleras. Si acaban encima de algo que no pueden pisar, buscan el suelo bueno más cercano y van hacia él (si andando no pueden, dan saltitos hacia él). Si se quedan atascados andando, cambian de destino. *(La columna "Se mueve" de la tabla es de versiones antiguas: ahora todos pasean libres.)*
Cada uno tiene su **huevo** (pestaña de Herramientas) o `/desinfo npc <tipo>` (vendedores: `/desinfo vendedor <tipo>`). **17 Gatos Cubo:**
| Gato Cubo | tipo | Aspecto | Se mueve |
|---|---|---|---|
| **El Gato** (el principal: dirige el Centro; la tele es la que causa las desinformaciones, él solo puede mandar señales verdes) | `principal` | sin nada, tal cual | paseo corto |
| Recepcionista Cubo | `recepcionista` | diadema con micrófono, camisa, lazo rojo, credencial | línea recta |
| Periodista Cubo | `periodista` | sombrero con PRENSA, lápiz, corbata floja, libreta | círculo |
| Conserje Cubo | `conserje` | gorra con logo, peto vaquero, escoba | zigzag |
| Gata Kawaii | `anime` | lazo rosa gigante, coloretes, brillitos en los ojos, cuello de marinera | círculo |
| Gato Nerd | `nerd` | gafas gordas con celo, pajarita, protector de bolsillo con bolis | va y viene corto |
| GATO-BOT 3000 | `robot` | chapa con remaches, antena con luz, tornillos, panel con lucecitas | cuadrado perfecto |
| Gato Granjero | `granjero` | sombrero de paja, espiga en la boca, pañuelo de lunares | zigzag grande ("arando") |
| Gato Gato | `gato` | collar con cascabel (solo dice "miau") | paseo libre |
| Gato Romántico | `romantico` | boina, rosa en la boca, corazón flotando | círculo pequeño |
| Gato Millonario | `millonario` | monóculo, collar de oro con "$", fajos de billetes falsos | cuadrado pequeño |
| Gato Elegante | `elegante` | sombrero de copa, pajarita, pañuelo, bastón | línea |
| Chef Michelin | `chef` | gorro de chef, bigote rizado, pañuelo, cucharón | va y viene corto |
| Detective Bigotes | `detective` | gorro de cazador a cuadros, pipa, lupa | paseo "investigando" |
| Mago de las Pasivas | vendedor `pasivas` | sombrero de mago, barba, capa | quieto |
| Enfermero de Corazones | vendedor `corazones` | cofia, bata, estetoscopio | quieto (cura) |
| Minero Cubo | vendedor `minerales` | casco con linterna, peto reflectante, pico | quieto |
- `/desinfo tienda <pasivas|corazones|minerales>` además construye el puesto con toldo. Los huevos de vendedor lo dejan mirando hacia ti.
- **Tiendas**: pasivas *próximamente* · corazones: Manzana de oro 70 · Corazón rojo 180 · Corazón azul 300 · Tótem 450 · minerales: 32 redstone 40 · 32 lapislázuli 45 · 16 hierro 60 · 16 oro 90 · 4 esmeraldas 80 · 1 diamante 120 · 1 lingote de netherite 900.
- Se paga en **Rumores**: primero del saldo del Banco y, si no llega, con las monedas del inventario (el cambio vuelve al Banco).

## 32. Mutaciones del Nether y del enderman (amarillos)
| Comando | Efecto |
|---|---|
| `/desinfo lanzar ghasts_triples` | Los ghasts disparan 3 bolas de fuego en abanico. |
| `/desinfo lanzar blazes_dobles` | Cada bola de fuego de blaze sale con una gemela. |
| `/desinfo lanzar piglins_ladrones` | Si un piglin te golpea, te roba hasta 3 objetos de oro. |
| `/desinfo lanzar hoglins_gimnasio` | Hoglins con +50 % de vida y embestidas mucho más fuertes. |
| `/desinfo lanzar magma_ardiente` | El golpe de un cubo de magma te prende fuego 5 s. |
| `/desinfo lanzar wither_veneno` | Esqueletos wither +25 % rápidos y su golpe da Wither II 8 s. |
| `/desinfo lanzar zombificados_rencorosos` | Los piglins zombificados te atacan si estás a menos de 10 bloques. |
| `/desinfo lanzar enderman_teletransporte` | Si un enderman te golpea, te teletransporta a un sitio cercano al azar. |
Todos están en `/desinfo activar mutaciones`.

## 33. Mobs del Nether
**30 minutos de juego después de que alguien pise el Nether por primera vez** sale la tele *"¡El Nether tiene nuevos vecinos!"*. Antes salía nada más entrar. Ver la sección 52. (*"...el Nether se veía muy sin vida. Hemos enviado a unos cuantos voluntarios. No eran voluntarios."*).
En el Nether aparecen sin necesidad de desbloquearlos:
- **Zombie Naranja**, **Furros** y **Travensaños** (los de siempre).
- **Creeper de Fuego** (nuevo): naranja con brasas y ojos de lava; al explotar te prende fuego 8 s y deja llamas alrededor. Le afecta "creepers electrificados" (más radio de fuego).
- **Cubo Rojo** (nuevo): cubo sólido que se desliza (no rebota), como el Cubo Blanco (pantalla blanca + Lentitud) y además te quema 5 s.
- **Esqueleto Ráfaga** (nuevo, verde): dispara 5 flechas seguidas y recarga 5 s.
Los tres nuevos son inmunes al fuego y solo aparecen en el Nether (tienen huevo en la pestaña de Herramientas).

## 34. Bienvenida: el cuarto de la tele y la cinemática

- La primera vez que un jugador entra al server aparece en un cuartito oscuro (dimensión `desinformados:cuarto_intro`, uno por jugador) en modo aventura: no puede romper ni poner nada y no recibe daño.
- Solo puede darle clic derecho a la tele vieja. Eso lanza la cinemática (hecha dentro del mod, no hacen falta mods extra): estática en toda la pantalla; la foto de El Gato en medio con señal débil (el mundo está en peligro, el Reactor dañado, apareció una tele que genera desinformaciones, la está investigando, no puede mantener la señal); al final dice "Vale, no tenemos mucho tiempo. Te transportaré al Centro de Desinformación en 5... 4... 3..." mientras la señal se rompe; 5 s de estática con glitches; pantalla en blanco con la canción (`sounds/intro_cancion.ogg`, 24 s, baja de volumen desde los 17 s); a los 3 s cae el título DESINFORMADOS letra por letra con la fuente de Minecraft; a los 24 s se esfuma el título; con la pantalla aún en blanco te lleva al Centro, el blanco se desvanece y sale en el chat "✦ Jugador ha ingresado al mundo desinformado."
- No se puede saltar ni cerrar con ESC. Al terminar, el jugador aparece en el Centro de Desinformación (y su punto de reaparición queda ahí).
- Comandos:
  - `/desinfo intro centro`: dónde aparecen al terminar (tu posición y hacia dónde miras). Si no lo pones, aparecen en el spawn del mundo.
  - `/primeravez [jugador]`: te regresa (o a ese jugador) al cuarto de la tele como si fuera la primera vez, para probar la tele y la cinemática.
  - `/desinfo intro ver`: lo mismo que `/primeravez`.
  - `/desinfo intro reiniciar <jugador>`: manda a ese jugador de vuelta al cuarto.
  - `/desinfo intro activar | desactivar`.
- El guion está en `IntroScreen.java` (arreglo `GUION`).

## 35. Brandon y Kevin

- **Brandon** (8 corazones, muy rápido): aparece solo de noche/en la oscuridad en el Overworld después de su tele amarilla (`brandon_kevin`). Te ataca primero desde lejos: mantiene la distancia (entre 7 y 15 bloques), carga un rayo azul con los brazos hacia delante (~0,7 s) y dispara a donde estabas al empezar a cargar, así que se puede esquivar moviéndose. El rayo hace 2 corazones y te paraliza medio segundo.
- **Kevin** (20 corazones, pega como un zombie normal): llega la primera vez que alguien le pega a Brandon (solo una vez). Siempre se pone delante de Brandon, entre él y el jugador, y te pega si te acercas. Mientras esté a menos de 4 bloques de Brandon, los golpes que le des a Brandon se los come Kevin. Los rayos no le hacen nada. Si Brandon muere, Kevin sigue peleando como un zombie.
- Huevos: Huevo de Brandon y Huevo de Kevin. Como todos los mobs del mod, Brandon está bloqueado hasta que salga su tele (`/desinfo lanzar brandon_kevin`).
- **Mejora `brandon_mejorado`** (tele amarilla, grupo de mutaciones): Brandon cura a Kevin con un rayo (2 corazones cada 3 s si está a menos de 12 bloques y herido), dispara el doble de rápido (y carga el rayo un poco más rápido) y Kevin tiene el doble de vida (40 corazones). Excusa: "Brandon vio un tutorial de 'cómo ser el support de tu equipo'..."

## 36. Altky

- Skin propia. Aparece solo en la oscuridad del Overworld después de su tele amarilla (`/desinfo lanzar altky`).
- Cuando te ve, se queda a distancia (6-14 bloques), saca su pluma y se pone a dibujar (2 s, con partículas de tinta; es bastante rápido corriendo). Al terminar, de su hoja sale un mob dibujado mal hecho que va a por ti:
  - 50 %: **Furro Dibujado** (abraza como un Furro; 5 corazones, más rápido, no se quema).
  - 50 %: un mob de la Libreta al azar (zombie, esqueleto, creeper o araña dibujados, o un Garabato).
- 5 segundos de espera entre dibujo y dibujo, y como mucho 6 dibujos vivos a la vez.
- **Mutación `altky_tableta`**: se compra una tableta de dibujo (la lleva en la mano) y en vez de mobs de papel saca mobs normales: zombie, esqueleto, creeper, araña, Zombie Naranja, Cubo Blanco, Creeper Oscuro, Travensaño, Creeper de Fuego, Cubo Rojo, Esqueleto Ráfaga o Garabato. Los Furros (normales) siguen siendo el 50 %.

## 37. Spawn: zona protegida y dónde aparecen

- `/desinfo spawn radio <bloques>`: tamaño de la zona protegida (cuadrado de ese radio).
- `/desinfo spawn centro`: la zona protegida se centra donde estás parado. `/desinfo spawn centro mundo` la vuelve a centrar en el spawn del mundo.
- `/desinfo spawn aparecer`: los jugadores aparecen donde estás (mirando hacia donde miras): al terminar la cinemática, al morir sin cama y al ser revividos. Pone el spawn del mundo ahí, sin dispersión aleatoria.
- `/desinfo spawn info`: muestra dónde aparecen y dónde está la zona protegida.

## 38. Construir el Centro de Desinformación

- `/desinfo construir centro`: construye el esqueleto del Centro delante de ti (la entrada queda mirando hacia ti). Despeja el terreno y pone cimientos de ladrillo de piedra donde haga falta.
  - Torre circular de 41 bloques de diámetro, tres pisos de 6 de alto y techo plano accesible con pretil.
  - Suelo de tablones de abeto; pared de Panel Metálico; 16 Vigas de Acero alrededor; franja verde entre pisos y en el pretil.
  - Un ventanal en cada tramo entre vigas (en los tres pisos), entrada de 5 x 4 con marquesina de Rejilla Metálica.
  - Atrio circular en el centro que atraviesa el 2º y el 3º piso (hueco de 11 de diámetro con barandal).
  - Escaleras de madera de 2 de ancho: planta baja → 2º piso (al fondo), 2º → 3º (delante, junto a la fachada) y 3º → techo (al fondo, sale a una caseta de metal con puerta).
  - Luces Industriales empotradas en los techos (no aparecen mobs dentro).
  - Al terminar: la zona protegida se centra en el edificio (radio mínimo 30) y los jugadores aparecen en el vestíbulo.
- Bloques nuevos (pestaña del mod): Panel Metálico, Panel Metálico con Franja, Viga de Acero, Rejilla Metálica, Luz Industrial.

## 39. Muebles y decoración del Centro

- **Recepción**: mostrador en L (3 bloques de frente + 1 hacia atrás en el extremo derecho). Se coloca de una vez con el frente hacia ti; el bloque del medio lleva el logo del Centro. Si rompes una parte se quita entero y te devuelve el objeto.
- **Mesa de DJ** (2 x 1): tocadiscos con vinilo girando a la izquierda; mezclador y portátil a la derecha; ecualizador animado en el frente.
- **Pista de Baile**: cada medio segundo cada baldosa cambia a un color al azar (todas a la vez). Da luz.
- **Decoración** (con gatos): Cuadro de El Gato, Pantalla de Noticias (animada, con titulares), Letrero del Centro, Peluche de Gato Cubo, Lámpara de Gato (da luz), Rascador para Gatos, Cama de Gato, Taza de El Gato, Maceta de Hierba Gatera y Estatua del Gato Dorado. El cuadro, la pantalla y el letrero se pegan a la pared en la que haces clic.
- **DJ Miaumix** (Gato Cubo nuevo, `/desinfo npc dj` o su huevo): gorra al revés, auriculares con luces, gafas de sol y cadena con vinilo. Se queda quieto donde lo pongas. Su función está por definir.

## 40. Bloques de obra

- **Valla de Obra** (rayas amarillas y negras) y **Andamio de Obra** (estructura naranja, se ve a través): para cerrar zonas mientras construyes. No se pueden romper en supervivencia (en creativo sí).
- `/desinfo obra quitar` quita **todos** los bloques de obra del mundo (en cualquier dimensión, aunque estén lejos). También `/desinfo obra quitar valla` o `/desinfo obra quitar andamio` para quitar solo un tipo.

## 41. DJ Miaumix: música y pista de baile

- Cuando no hace nada (y hay alguien a menos de 16 bloques) pone en bucle **Dj espontaneo**, bajito.
- Clic derecho: te dice una frase y abre su menú con 3 canciones, **20 Rumores** cada una (se cobra del Banco y luego de los Rumores que lleves): *Hombre denigrante ante un genero*, *Me porto bonito Remix* y *Chichabeba*. Mientras suena una, no se puede pedir otra.
- La música sale del DJ y se oye hasta unos 16 bloques (categoría "Discos" del volumen). Al pedir una canción se corta el bucle, suena el disco moviéndose (scratch) y luego empieza la canción.
- Mientras suena una canción: el DJ salta despacio para animar y suelta notas; y más o menos el 60 % de los Gatos Cubo que haya a menos de 24 bloques (no vendedores) se van a una **Pista de Baile** que esté a menos de 16 bloques del DJ y bailan (giran, saltan y sueltan notas). Al terminar la canción vuelven a lo suyo.

## 42. Más gatos del Centro

| Gato | `/desinfo npc` | Aspecto | Comportamiento |
|---|---|---|---|
| Gata Científica | `cientifica` | bata blanca, gafas de laboratorio en la frente, tubo de ensayo brillante | camina en línea |
| Gata Fujoshi | `fujoshi` | gafas opacas que le tapan los ojos, coletas con lazos rosas, libreta y lápiz | da vueltas |
| Gata Mamá | `madre` | delantal con corazón, collar de perlas, pañuelo | pasea |
| Gatito | `gatito` | pequeñito, babero y chupete | sigue a la Gata Mamá más cercana a todas partes |
| Gata Fiestera | `fiestera` | gorrito de fiesta, gafas de corazón, pulseras de neón | se va a la Pista de Baile más cercana y baila siempre, haya música o no |
| Gato Perro | `perro` | orejas caídas, lengua fuera, collar con placa, hueso | solo dice "guau" y ladra |
| Gato 2D | `plano` | es plano (de lado casi ni se ve) | zigzag |

- Unos hablan de otros (la Científica y el Nerd discuten quién es ayudante de quién, a la Fujoshi le encanta el BL y tiene sus ships del Centro (el Romántico con el Elegante, el DJ con el Conserje, el Nerd con el GATO-BOT), la Mamá habla de su hijo y de la Fiestera...).
- El Gato Gato y el Gato Perro, aunque ya les hayas sacado toda la conversación, siguen diciendo solo "miau" / "guau".
- Ningún gato se describe ya como "cubo"; Recepcionista, Periodista, Conserje y Minero ya no llevan "Cubo" en el nombre.

## 43. Muñeco de Prueba

- Huevo de **Muñeco de Prueba** (pestaña del mod): un "jugador" falso (skin de Steve) que se queda quieto y que **todos los mobs hostiles y los del mod atacan** como si fuera un jugador, para ver cómo se comportan sin arriesgarte.
- 100 de vida, se cura 1 corazón cada 2 s y muestra su vida en el nombre. Cada golpe sale en la barra de acción con el daño y quién se lo hizo.
- Los ataques especiales que solo funcionan con jugadores (abrazo del Furro, Travensaño en el cuello, desafíos...) no le hacen efecto; los rayos de Brandon sí le dan.
- Para quitarlo: golpéalo en creativo o `/kill @e[type=desinformados:muneco]`.

## 44. Pasivas (tecla I)

- Se compran al **Mago de las Pasivas** como libros; clic derecho con el libro = la aprendes para siempre (se gasta).
- **Tecla I**: menú de pasivas con icono, nombre y descripción de cada una. Las que tienes se pueden **activar/desactivar** con su botón; las que no, salen en gris con su precio.

| Pasiva | Precio | Qué hace |
|---|---|---|
| Sistema Inmunológico | 1100 | Inmune al veneno (icono: la imagen del esqueleto azul con virus, en alta resolución, sin pixelar) |
| Aletas | 1200 | Nadas un 50% más rápido (en la superficie y buceando a crol) |
| Patas de Gato | 1250 | Sin daño de caída |
| Guantes de Escala | 1500 | Si caes pegado a un bloque manteniendo ESPACIO, te quedas colgado de su esquina (a la altura de las manos). Al soltar ESPACIO saltas lo justo para subirte encima. Mientras cuelgas se te ven los dos brazos agarrados a la esquina (en primera persona, en F5 y para los demás) |
| Tendones Reforzados | 1800 | Doble salto: suelta y vuelve a pulsar saltar en el aire para un segundo salto (reinicia la caída) |
| Fondo de Roca | 5000 | Tus contenedores de corazón nunca bajan: ni al morir, ni por el Creeper Oscuro, ni por los sustos, ni por el desafío "Un solo corazón". Rota a propósito |

## 45. Gata Katemcita (la artista)
- La que decoró todo el Centro y hace las miniaturas del canal. Pelo negro largo con flequillo, gafas blancas rectangulares, camisa blanca y un lápiz detrás de la oreja.
- Colocarla: `/desinfo npc katem` o el **Huevo de Gata Katemcita**.
- Es un NPC más: te cuenta quién es y te ofrece (en broma) una comisión de 67 dólares.

## 46. Los gatos cambian de piso
- Cada 1-3 minutos, los gatos que pasean eligen un sitio del otro piso y van por las escaleras: del 1º suben al 2º y del 2º bajan al 1º.
- Nunca suben al 3º (el casino) ni al techo (donde está la tele).
- No cambian de piso: los vendedores, DJ Miaumix, la Gata Fiestera (vive en la pista) y el Gatito (sigue a su mamá, así que cambia de piso con ella).
- Para cambiar de piso SIEMPRE usan las escaleras: buscan el tramo de escaleras de madera que une los dos pisos, van a la entrada, suben/bajan y luego van a su sitio. Si no hay escaleras cerca, no cambian de piso.
- Lo mismo al ir a bailar, al volver de bailar y el Gatito cuando sigue a su mamá a otro piso (ya no se teletransportan).
- Las luces del suelo de los pisos de arriba y la Pista de Baile cuentan como suelo por el que pueden caminar (ya no se quedan atascados en la pista).
- Cuando el DJ pone una canción, se apunta a bailar el 90% de los gatos cercanos (antes el 60%).
- Al acabar la canción, los gatos que bajaron a bailar vuelven caminando justo al sitio donde estaban y miran hacia donde miraban (la Gata Fiestera se queda en la pista). Si no pueden volver, se quedan en el piso donde estén.

## 47. Jefe final: La Desinformación (la tele)
- Es una tele de 5x5 y su barra de vida se llama **LA DESINFORMACIÓN**.
- **Cómo sacarla:** con el **Huevo de La Desinformación (jefe final)** (pestaña de Herramientas) o `/desinfo jefe invocar` (aparece 8 bloques delante de ti). `/desinfo jefe quitar` la quita junto con todos sus mobs.
- **Fase 0 (dormida):** es un **televisor antiguo de 5x5x5 con relieve**: mueble de madera, tubo por detrás con rejillas, marco plateado, perillas, altavoz, placa de latón, patas y antena de orejas de conejo. La pantalla tiene estática de verdad. Da saltitos sin rumbo cerca de donde la pusieron y se apaga y enciende sin parar. No le baja la vida: **a los 3 golpes despierta**.
- **Transformación a la fase 1 (5 s):** le salen 4 **tentáculos de estática** que la levantan 2 bloques, se le abren **ojos realistas** en la pantalla (parpadean) y aparece su **barra de vida de estática** arriba en la pantalla. Es invulnerable mientras se transforma.
- **Fase 1 (400 de vida):**
  - No se mueve de su sitio.
  - Gira para **mirar al jugador más cercano**.
  - Cada 4 s **lanza 4-6 mobs de estática** desde la pantalla hacia todas las direcciones (máximo 26 a la vez).
  - Cada 2 s dispara un **rayo de estática** al jugador que mira. El rayo va en línea recta y no persigue, así que si corres hacia un lado lo esquivas. Hace 3 corazones de daño y frena un momento.
- **Transformación a la fase 2 (6 s):** los tentáculos se glitchean (tirones, colores rojo/cian), salen 4 más (8 en total) y la tele se despega del todo del suelo (4 bloques). La barra se vuelve a llenar.
- **Fase 2 (400 de vida):**
  - Salta por la arena, hacia el jugador o a un punto al azar. Al caer hace una onda de choque: 3 corazones y empuje a los que estén a menos de 6 bloques.
  - Sigue disparando (cada 1.5 s, rayos más rápidos).
  - Cada 6 s lanza 3-5 mobs de **todo lo que habéis visto en el desafío, menos los clones** (Ale, Ulises y el Angel). Máximo 30 a la vez.
  - **Cada 30 s lanza una tele roja** solo a los que están en la pelea. Al terminar de salir la tele, pasa una de estas:
    - **Lluvia de Creepers Oscuros:** 6 tandas, una cada 2 s, caen encima de cada jugador.
    - **Lentitud II:** 15 s.
    - **Pasivas apagadas:** 20 s; vuelven solas.
    - **Stun:** 3 s sin moverse y con la cámara fija en la tele.
    - **Quemadura:** os prende fuego una sola vez.
- **Solo le hacen daño los jugadores:** sus propios mobs, las explosiones, el fuego y las caídas no le afectan.
- **Al morir:** se encoge glitcheando, desaparecen todos sus mobs y sale en el chat "📺 ¡LA DESINFORMACIÓN HA SIDO APAGADA!".
- Se guarda la fase al cerrar el mundo.
- **Orbe de Estática:** al morir, La Desinformación suelta un **Orbe de Estática** brillante. No desaparece y no se quema. **Clic derecho** y TODOS los conectados ven la **cinemática final**:
  1. Estática y El Gato con buena señal: os da las gracias. Gracias a vosotros el mundo volvió a desinformarse de forma correcta, supisteis arreglároslas a pesar de los peligros y gracias por divertiros. Os va a mandar a vuestro hogar.
  2. "Adiós... y sigan desinformando de buena forma." La señal se rompe como en la intro: 5 s de estática.
  3. **Pantalla negra**: cae el título DESINFORMADOS (blanco), empieza la **canción de los créditos (Ripple)** y todo empieza a bajar con los **créditos**: los protagonistas (los nombres de los jugadores conectados), los créditos reales (Altky y Angel) y muchos créditos de broma del personal del Centro y los mobs.
  4. Cuando se acaban los créditos, la canción baja de volumen poco a poco hasta apagarse.
  5. Cada jugador vuelve a **su hogar** (su cama o, si no tiene, el spawn del mundo), el negro se desvanece y sale una última **tele verde**: *"La serie acabó. Ya pueden morir sin miedo. El casino y las dificultades siguen igual, así que tomen esto como un mundo diferente. Espero que les haya gustado."* (luego queda escrito en el chat como los demás anuncios).
  - **Después del final:** morir ya no quita vidas ni contenedores de corazón y nadie es expulsado; los que estaban eliminados pueden volver a entrar. El casino, las teles y los cambios de dificultad siguen igual.
  - Mientras ven el final, nadie recibe daño. No se puede saltar ni cerrar con ESC.

## 48. Teles automáticas (`/desinfo auto`)
Lanzan solas, una a una y en orden, las **49 teles amarillas, azules y naranjas** de la lista progresiva (actos 1A → 5). Los mobs del Nether y sus 8 mejoras van aparte (sección 52).
- **Se activan solas**: cuando el **primer jugador llega al Centro** (al terminar la intro), la **primera tele sale a los 30 minutos** de juego.
- Después, **cada una sale al azar entre 20 y 40 minutos** de juego tras la anterior.
- `/desinfo auto pausar` las para cuando queráis y `/desinfo auto iniciar` las reanuda. El reloj se guarda, así que sigue donde iba. Si pausáis antes de que llegue nadie, ya no arrancan solas.
- `/desinfo auto` muestra el estado: activas o en pausa, cada cuánto salen, cuántas van, cuál es la próxima y cuánto falta.
- `/desinfo auto intervalo <mín> <máx>` cambia el rango al azar. Por defecto, **20 y 40** minutos.
- `/desinfo auto ahora` lanza ya la próxima y reinicia el reloj.
- `/desinfo auto saltar` se salta la próxima; `/desinfo auto recuperar <id>` la devuelve a la lista.
- `/desinfo auto lista` enseña la lista entera: ✔ salida · ▶ próxima · ✘ saltada.
- **El reloj solo corre si hay alguien jugando** (no cuenta con el server vacío ni con solo espectadores).
- **Si una tele ya salió** (por ejemplo, porque la lanzasteis a mano con `/desinfo lanzar`), se la salta sola.
- **Espera sola, sin perder la tele**, mientras:
  - haya un desafío rojo en marcha;
  - esté el jefe final;
  - esté la cinemática final.
- **Respeta las puertas de la historia:**
  - Las del **Acto 4** esperan a que abráis el **Nether** (`/desinfo lanzar nether`).
  - "Libreta mejorada" espera a que se abra la **Libreta**.
  - Las 3 últimas esperan al **End** (`/desinfo lanzar end`).
  - Las teles moradas y la tele rota del jefe **no** son automáticas: esas las decidís vosotros.
- **Los avisos solo los ven los admins** (`[Auto]` en el chat): un minuto antes de cada tele, qué tele ha salido y por qué está esperando.
- Al terminar la serie (cinemática final) se apagan solas.
- **Desafíos rojos automáticos (reloj aparte):**
  - Durante la **primera 1 h 20 min** de juego no sale ninguno.
  - Después sale **uno al azar cada 30-60 minutos** de entre los 33 desafíos rojos. No se repite ninguno hasta que hayan salido todos.
  - Esperan si ya hay un rojo en marcha, si está el jefe o la cinemática final.
  - Entre una tele y otra (de cualquier tipo) siempre pasan al menos 3 minutos, para que no se pisen.
  - `/desinfo auto pausar` pausa también los rojos.
  - **Al romperse la tele** (la tele morada "¡La tele se ha roto!") los desafíos rojos automáticos **se apagan para siempre**: desde ahí las teles rojas las lanza el jefe. Si se repara la tele con `/desinfo portal tele reparar`, vuelven.
  - `/desinfo auto rojo` lanza uno al azar ya.
  - `/desinfo auto intervalo_rojos <mín> <máx>` cambia su rango.
  - `/desinfo auto` muestra cuánto falta para el próximo rojo.

## 49. La Tele Gigante ahora es de 5x5x5
- **Frente** (5x5, el de siempre, con su estática animada o el vórtice cuando está rota), ahora **con relieve**: el marco plateado de la pantalla, las dos perillas, la placa de latón del panel y la de abajo sobresalen, y tiene un reborde de madera arriba.
- **Cuerpo detrás** (4 bloques de fondo):
  - 2 capas de mueble de madera.
  - El tubo de la tele, que se va estrechando hacia atrás, con **rejillas de ventilación** al fondo.
  - Una **antena de orejas de conejo** encima.
- **Ocupa 5 de ancho, 5 de alto y 5 de fondo.** Al ponerla necesita ese hueco libre detrás de la pantalla.
- **El cuerpo se pone y se quita solo** con la tele (es irrompible, como el frente).
- **Las teles que ya estaban puestas** reciben su cuerpo automáticamente al arrancar el servidor, solo donde haya aire.
- **Romperla y repararla** (`/desinfo portal tele romper|reparar`) funciona igual: solo cambia la pantalla.

## 50. El Centro aparece solo al crear el mundo
- **Mundo nuevo = Centro listo:** la primera vez que arranca un mundo nuevo, el mod lo hace todo solo (tarda unos segundos):
  - **Busca la montaña más alta cerca del spawn** (hasta unos 380 bloques; cuanto más lejos, menos le gusta), en tierra firme.
  - **Aplana la cima** en una explanada redonda. Si no hay montaña de verdad (o es muy baja), **levanta una** con laderas de roca y del mismo terreno de la zona (césped, nieve, arena...), hasta al menos 45 bloques sobre el mar.
  - **Construye el Centro** con la entrada mirando hacia el spawn original.
  - **Talla una escalera en espiral** desde la entrada hasta el pie de la montaña: 3 de ancho, losas para que se baje andando, barandal donde hay caída, faroles cada 10 bloques y un cartel abajo.
  - En la cima: camino de la entrada a la escalera, muro bajo con faroles alrededor y flores.
  - **Pone a todos los gatos** en su sitio.
  - El spawn del mundo pasa al vestíbulo y, al acabar la cinemática de bienvenida, aparecéis ahí.
- **Zona protegida: el Centro + 20 bloques** (cuadrado de 81 x 81 alrededor del Centro, toda la altura). Dentro:
  - Nadie rompe ni pone bloques (en creativo sí).
  - **Las explosiones no rompen nada** (creepers, TNT, la lluvia de creepers del jefe...).
  - **No aparecen mobs hostiles** por sí solos (tampoco los de "mobs cruzados").
  - **El fuego se apaga solo** y no quema nada.
  - **Los endermen no se llevan ni dejan bloques.**
- **Por dentro:**
  - **Planta baja:**
    - Recepción en L con la Recepcionista (ahora se queda en su mostrador).
    - Sala de espera con sillas, mesitas, tazas, lámparas, rincón del café y cuadros.
    - Las **3 tiendas** con toldo de colores (Mago de las Pasivas, Enfermero y Minero).
    - Estatua del gato en el centro, rincón del Conserje y rincón de siesta.
  - **Piso 2 (el centro va tapado):**
    - Pista de baile de 9 x 9 con el **DJ Miaumix** en su cabina y sofás alrededor.
    - Estudio de Katemcita (caballetes, cuadros y pintura por el suelo).
    - Cocina del Chef con mesa.
    - Guardería de la Gata Mamá y el Gatito.
    - Laboratorio de la Gata Científica y GATO-BOT.
  - **Piso 3, casino:**
    - 12 tragamonedas (4 azules, 4 moradas y 4 grises).
    - 2 **ruletas** y el **Banco**.
    - Alfombra roja con anillo dorado, columnas de oro y cuarzo con luz.
  - **Techo:**
    - La **Tele Gigante** (5x5x5) mirando a la caseta de la escalera.
    - Una tarima con bancos para verla.
    - **El Gato**, quieto a su lado.
- **Los gatos** empiezan repartidos entre la planta baja y el piso 2 y se mueven como siempre (cambian de piso por las escaleras). Los que se quedan quietos en su sitio son estos:
  - los vendedores;
  - el DJ;
  - la Recepcionista;
  - El Gato.
- **Mundos ya empezados:** no se toca nada. Para generarlo igual a mano: `/desinfo generar centro` (una vez; con `forzar` se puede repetir y quita los gatos del Centro anterior). `/desinfo construir centro` sigue construyendo el esqueleto vacío delante de ti, como antes (y ahora también protege radio 40).

## 51. Ruleta (casino)
- Bloque **Ruleta** (pestaña de herramientas). Clic derecho para abrirla. Se juega con los **Rumores del inventario**.
- **Apuesta:** de 10 a 1000, de 10 en 10.
  - **Rojo o negro:** si aciertas, cobras lo apostado **+30 %**. Por ejemplo, apuestas 100 y cobras 130.
  - **Verde (el 0):** si aciertas, cobras el **doble**. Por ejemplo, apuestas 100 y cobras 200. Solo gana el que apostó al verde; si sale verde y apostaste a rojo o negro, pierdes.
  - Si no aciertas, pierdes lo apostado.
- **La rueda es una ruleta europea de 37 casillas:** 18 rojas, 18 negras y el 0 verde.
- **Al girar:** la rueda y la bola dan vueltas en sentidos contrarios unos 5 segundos y la bola cae en su número. Entonces se paga y sale en el chat. Si alguien acierta el verde, se anuncia a todos.
- **Si te desconectas a mitad de tirada:** lo que ganes va a tu cuenta del Banco.
- **Ojo con el verde:** solo sale 1 de cada 37 veces.

## 52. Nueva progresión: misiones principales y secundarias
- **Teclas:**
  - **U:** misiones. Tiene dos pestañas, Principales y Secundarias; se cambia con Tab o con clic.
  - **I:** pasivas.
  - **O:** enciclopedia.
  - Si en el menú de controles seguían L y K, ahora salen como U e I.
- **Se quitaron:**
  - las misiones diarias;
  - las fases de minerales: todo se puede picar desde el principio (`/desinfo fase` ya no existe).

### Misiones principales (una cadena)
- **Cuándo se revela la siguiente:**
  - Solo se ve la misión actual y las ya superadas. Las demás salen como "???".
  - La siguiente se revela cuando la completa el **75 % de los jugadores de la serie**, redondeando hacia arriba: con 5 jugadores, 4; con 4, 3.
  - Cuentan todos los que han jugado en supervivencia alguna vez. Los eliminados no cuentan.
- **Premios:** cada uno cobra su premio al completarla.
- **Desbloqueos:** lo que desbloquea pasa cuando la supera el grupo.
- **Misiones de grupo:** el dragón, el Centro de Estática y la Desinformación Pura. Basta con que lo haga uno y **el premio es para todos**. Los que no estén conectados lo reciben al entrar.

| # | Misión | Premio | Al superarla el grupo |
|---|---|---|---|
| 1 | Una pieza de hierro (puesta) | 10 Rumores | — |
| 2 | Full hierro | 30 Rumores | Tele morada: el diamante ya se puede usar en crafteos |
| 3 | Una pieza de diamante | 20 Rumores | — |
| 4 | Full diamante | 30 Rumores + 1 tótem | Tele morada: se abre el Nether (ver abajo) |
| 5 | Una pieza de netherite | 30 Rumores + 5 corazones rojos | — |
| 6 | Full netherite | 150 Rumores + 1 tótem | Tele morada: se abre el End |
| 7 | Matar al dragón (de grupo) | 120 Rumores + 1 tótem + 3 Pastillas anti-Endcer | Tele amarilla: el End se vuelve radiactivo. 5 min después, tele morada: se abre la Libreta |
| 8 | Craftear una pieza de Garatita | 200 Rumores + 3 tótems | — |
| 9 | Full Garatita | 240 Rumores + 10 corazones rojos | Tele morada: receta del Centro de Estática |
| 10 | Centro de Estática (de grupo) | 250 Rumores + 5 corazones rojos + 3 azules | Tele morada: canalizad su energía. Recetas de la Desinformación Pura y del Bloque de Garatita |
| 11 | Desinformación Pura (de grupo) | 400 Rumores + 3 tótems | Tele morada: "¿y si la usáis cerca de la tele?" |

- **El final de la cadena:**
  - Usar la Desinformación Pura cerca de la Tele Gigante **rompe la tele**.
  - **La Desinformación (el jefe) aparece dormida en medio de la arena** de la dimensión de la tele.
  - Solo pasa una vez y no vuelve a salir si ya la habéis vencido.
- **Fuera de servicio:** cuando se acaban las principales y la tele está rota, el menú de misiones sale **"FUERA DE SERVICIO"**.

### El Nether, aparte
- **Cuenta atrás:** cuando alguien pisa el Nether por primera vez empieza una cuenta de **30 minutos de juego**.
- **Primero llegan los mobs:** al acabar la cuenta sale la tele azul de los nuevos vecinos (Creeper de Fuego, Cubo Rojo y Esqueleto Ráfaga).
- **Después, las mejoras:** cada **20-40 minutos** sale una de las **8 mejoras** al azar (ghasts, blazes, piglins, hoglins, magma, wither, zombificados, enderman), sin repetir.
- **Ya no están en la lista de `/desinfo auto`.** Esperan igual si hay un desafío, el jefe o la cinemática.
- **Comandos:**
  - `/desinfo auto nether`: cuánto falta.
  - `/desinfo auto nether ahora`: lanza la siguiente ya.

### Endcer (el End radiactivo)
- **Daño:** tras morir el dragón, quien esté en el End sin protección pierde **1 corazón cada 3 segundos**, y la armadura no le protege. Hay unos segundos de margen después de la tele.
- **Pastilla anti-Endcer:**
  - Receta sin forma: melón brillante + azúcar + perla de ender, y salen 2.
  - Al tomarla da el efecto **Anti-Endcer** durante **20 minutos**.
  - Avisa cuando le quedan 30 segundos.

### Misiones secundarias (28, cada uno a su ritmo)
| Misión | Qué hay que hacer | Premio |
|---|---|---|
| Conoce al personal | Hablar con los 26 gatos del Centro al menos una vez | 10 |
| Mano verde | Cosechar 10 cultivos maduros | 10 |
| Picapedrero | Minar 100 bloques de pico | 10 |
| Buen provecho | Comer 20 veces | 10 |
| Paciencia de pescador | Pescar 5 peces | 15 |
| Dulces sueños | Dormir 3 veces | 10 |
| Cazazombis | Matar 15 zombis | 15 |
| Rompehuesos | Matar 10 esqueletos | 15 |
| Artificiero | Matar 5 creepers | 15 |
| Fumigador | Matar 8 arañas | 10 |
| No le mires a los ojos | Matar 3 endermen | 20 |
| Experto en desinformación | Matar 10 mobs del mod | 20 |
| Turista | Andar 5 km | 10 |
| Sirena | Nadar 300 bloques | 10 |
| Regateo | Comerciar 5 veces con aldeanos | 15 |
| Cupido de granja | Criar 5 animales | 10 |
| Abracadabra | Encantar un objeto | 15 |
| Leñador | Cortar 64 troncos | 10 |
| Fiebre del hierro | Minar 20 menas de hierro | 15 |
| ¡Diamantes! | Minar una mena de diamante | 15 |
| Probando suerte | Jugar 10 veces a las tragamonedas | 10 |
| Rojo o negro | Jugar 5 veces a la ruleta | 10 |
| Pon la música | Pedirle una canción a DJ Miaumix | 10 |
| Rey de la pista | Pasar 60 s en la pista de baile | 10 |
| Ahorrador | Depositar 100 Rumores en el Banco | 10 |
| Melómano | Poner un disco en un tocadiscos | 10 |
| Que se haga la luz | Fabricar 64 antorchas | 10 |
| Alquimista | Beberse 3 pociones | 15 |

Los premios son en Rumores.

### Enciclopedia (tecla O)
- **Cuatro páginas:**
  - **Cambios de dificultad** (teles amarillas).
  - **Mobs nuevos** (teles azules), con sus **mutaciones** debajo si ya han salido.
  - **Mobs de siempre mutados**: zombies, esqueletos, ghasts...
  - **Crafteos especiales:** cada receta con su cuadrícula tal cual está en el juego. Si pasas el ratón por encima de un objeto, sale su nombre.
    - Equipo de diamante.
    - Conversor a netherite: sale al abrirse el Nether.
    - Pastilla anti-Endcer: sale al volverse radiactivo el End.
    - Libreta.
    - Bloque de Garatita.
    - Conversor a Garatita: sale al abrirse la Libreta.
    - Centro de Estática.
    - Desinformación Pura.
- **Sin spoilers:** solo sale lo que ya ha aparecido en la tele. De lo demás solo dice cuántos faltan.

### Comandos de misiones
- `/desinfo mision`: misión actual y cuántos la llevan.
- `/desinfo mision superar`: da por superada la actual, para probar o si alguien se queda atrás.
- `/desinfo mision completar <jugador> <id>`: se la completa a un jugador.
- `/desinfo mision reiniciar`: vuelve a empezar la cadena. Lo ya desbloqueado se queda.
- `/desinfo mision jugadores`: quién cuenta para el 75 %.
- `/desinfo mision jugadores quitar <nombre>`: lo saca de la cuenta, por si entró alguien que no juega la serie.

## 53. Ajustes del jefe y del final
- **La Desinformación aguanta el doble:**
  - Recibe la mitad de daño. La barra sigue igual, pero cuesta el doble bajarla. La vida máxima de Minecraft no pasa de 1024, por eso se hace así.
  - **Lanza un 20 % menos de mobs:** en la fase 1, cada 5 s (antes cada 4); en la fase 2, cada 7,5 s (antes cada 6).
- **Morir sin miedo empieza solo cuando muere el jefe final** de verdad. Antes empezaba al usar el Orbe de Estática.
  - Si en un mundo de prueba ya habíais visto el final, `/desinfo final estado` dice cómo está.
  - `/desinfo final reiniciar` lo deja como si el final no hubiera pasado.
- **El Conversor Difamónico** ahora también aparece en el Centro generado, delante a la derecha de la planta baja. Hace falta para la armadura de Garatita.
- **El Conversor no dice nada de la Garatita hasta que se abre la Libreta.** Antes solo habla del netherite, y con una pieza de netherite en la mano no hace nada.

## 54. Sin puestos de saqueadores ni bastiones, y prismarina irrompible en la tele
- **Ya no se generan los puestos de saqueadores ni los bastiones del Nether** (sin la placa no tenían sentido). Las mansiones del bosque, los templos del desierto y de la jungla, los monumentos oceánicos y las cámaras de desafío ya estaban quitados de antes. Solo afecta a los chunks nuevos: lo ya generado se queda como está.
- **En la dimensión de la tele la prismarina no se rompe.** Incluye todos sus bloques (normal, ladrillos, oscura, losas, escaleras y muro) y las **linternas de mar**, que son las luces de la arena y del túnel.
  - No se rompen a mano ni con explosiones. En creativo sí se pueden quitar.

## 55. Botín en When Dungeons Arise
- **Si instaláis When Dungeons Arise (Fabric)**, o su expansión Seven Seas, sus cofres y barriles llevan botín extra. Son los 141 de la versión 2.1.68. Las vasijas, la arqueología y los spawners de desafío no cambian.
  - **Rumores** en 3 de cada 4 cofres, salen 1 o 2 tandas:

    | Rumor | Probabilidad | Cantidad |
    |---|---|---|
    | Amarillo | 40 % | 3-10 |
    | Azul | 30 % | 1-4 |
    | Verde | 18 % | 1-3 |
    | Rojo | 9 % | 1-2 |
    | Gris | 3 % | 1 |

    Unos 15-20 Rumores de media por cofre.
  - **Tótem:** solo un 2 % de los cofres.
  - **El mod ya trae tótems por su cuenta** en los barcos voladores (Heavenly Conqueror, Rider y Challenger) y en el Aviary: casi siempre un 1 % por cofre; en los cofres del tesoro de los dos barcos grandes, un 9 %. Esos no se han tocado.
- **Sin el mod no hace nada.** Para cambiar las probabilidades: `BotinMazmorras.java`.

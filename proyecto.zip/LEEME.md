# Desinformados – Mod para Minecraft 1.21.1 (Fabric)

## 1. Preparar el proyecto (solo la primera vez)
1. Instala **Java 21 (JDK)** e **IntelliJ IDEA Community**.
2. Entra en https://fabricmc.net/develop/template y rellena:
   - Mod Name: `Desinformados` · Mod ID: `desinformados`
   - Package: `com.centrodesinformacion.desinformados`
   - Minecraft: `1.21.1` · marca **Split client and common sources**
3. Descarga y descomprime el proyecto.
4. **Borra su carpeta `src`** y pon en su lugar la carpeta `src` de este zip.
5. Ábrelo con IntelliJ y espera a que Gradle termine de cargar.

## 2. Probar y compilar
- Probar en el juego: `./gradlew runClient` (en Windows: `gradlew.bat runClient`)
- Generar el .jar: `./gradlew build` → `build/libs/desinformados-1.0.0.jar`

## 3. Instalar
- **Servidor:** Fabric server 1.21.1 + Fabric API + el .jar en `mods/`.
- **Los 5 jugadores:** Fabric 1.21.1 + Fabric API + el mismo .jar.

## 4. Comandos (solo operadores)
| Comando | Qué hace |
|---|---|
| `/desinfo evento <verde\|rojo\|amarillo> "Título" descripción...` | Lanza la tele a todos |
| `/desinfo fase <1-4>` | Desbloquea minerales (1 hierro, 2 oro/redstone/lapis, 3 diamante, 4 netherite) |
| `/desinfo spawn radio <bloques>` | Tamaño de la zona protegida del spawn (32 por defecto) |
| `/desinfo muertos` | Lista de jugadores fuera |
| `/desinfo revivir <jugador>` | Revivir gratis (para emergencias) |

Ejemplo: `/desinfo evento rojo "Momento Desinformado" Los creepers ahora explotan el doble`

## 5. Para los jugadores
- Click derecho con un **Periódico Desinformado** → lista de muertos, clic en el nombre para revivirlo.
- O escribe `/revivir <jugador>` (gasta 1 periódico).
- Si mueres quedas fuera del server hasta que alguien te reviva.
- En **creativo** sí se puede construir en el spawn (para montarlo).

## 6. Dónde poner tus archivos
- Textura del periódico: `assets/desinformados/textures/item/periodico.png` (16x16)
- Gato (tótem): `assets/minecraft/textures/item/totem_of_undying.png`
- Sonidos: pon tus `.ogg` en `assets/desinformados/sounds/` y en `sounds.json`
  cambia cada `{ "name": "minecraft:...", "type": "event" }` por `"desinformados:nombre_del_archivo"`.

## 7. Sistema de vida
- **Corazón Rojo:** click derecho = +1 corazón (máximo 30). Los extra **se pierden al morir**.
- **Corazón de Alma:** click derecho = +1 corazón azul (máximo 3), en su propia fila encima de la armadura.
  Cada uno **bloquea un golpe entero**: ni daño ni pérdida de contenedor (Creeper Oscuro incluido). No se regenera y se pierde al morir.
- Solo enemigos concretos quitarán contenedores rojos (se programan con `Vida.cambiarRojos(jugador, -1)`).
- Comandos (operadores):
  - `/desinfo vida <jugador> ver`
  - `/desinfo vida <jugador> rojos <cantidad>` (negativo para quitar)
  - `/desinfo vida <jugador> almas <cantidad>`

## 8. Eventos de la tele
- `/desinfo lanzar <id>` lanza la tele y su efecto. Sale una barra arriba con la cuenta atrás y el tiempo restante.
- `/desinfo detener` para todos los desafíos rojos en curso (sin castigos).
- Anuncios verdes libres: `/desinfo evento verde "Título" texto`

**Rojos (aviso → duración):**
creeper_sorpresa · lluvia_creepers · suelo_lava · gravedad_loca · noche_infernal · hambre_extrema ·
mobs_potenciados · prohibido_saltar · inventario_maldito · tormenta_rayos · apagon · todo_explota ·
todo_explota_suerte (1 de cada 3) · agua_toxica · mareo_total · mineria_explosiva · un_corazon ·
asedio · agachate · bloque_prohibido · no_te_muevas

**Rojos con objetivo (quien falle recibe el castigo):**
escalada · fondo_mundo · toca_madera · come_algo · a_la_cama · ponte_casco · cazarrecompensas ·
mojate · mira_cielo · mata_mob · sube_bloque

**Amarillos (permanentes):** arboles · creepers_oscuros
- `/desinfo cambios` lista los cambios activos · `/desinfo cambios quitar <id>` deshace uno.
- Los desafíos se programan en `desafio/Desafios.java` y los amarillos en `Eventos.java`.

## 9. Mobs bloqueados
Un mob bloqueado no puede existir en el mundo hasta que un evento lo desbloquee.
- `/desinfo mobs` · `/desinfo mobs bloquear <mod:mob>` · `/desinfo mobs desbloquear <mod:mob>`
- Para bloquear un mod entero: `/desinfo mobs bloquear nombredelmod:*`
- El **Creeper Oscuro** viene bloqueado. Si su explosión te alcanza pierdes un contenedor de corazón.
  Para probarlo: desbloquéalo y usa el Huevo de Creeper Oscuro.

## 10. Texturas incluidas
- Tótem → Gato de la Desinformación (la textura que mandaste).
- Icono del mod: la cara del gato.
- Creeper Oscuro: textura provisional en `textures/entity/creeper_oscuro.png` (formato 64x32 del creeper).

## 11. Vidas
- Cada jugador tiene **2 vidas**. Al perder la primera sale la tele de la calavera: "¡Estás a punto de ser Desinformado!".
- Al perder la última: todos ven la tele cayendo y partiéndose con su nombre. El eliminado queda 8 s en espectador
  donde murió (suelta sus cosas) y luego sale del server.
- Al revivirlo con un periódico vuelve en supervivencia al spawn con **1 vida**.
- `/desinfo vidas <jugador> <n>` cambia las vidas · `/desinfo vida <jugador> ver` muestra vidas y corazones.

## 12. Furros
- `/desinfo lanzar furros` los desbloquea. Si te ven te persiguen y te abrazan (máx. 10 s): Lentitud IV y medio corazón cada 2 s.
- Textura: `textures/entity/furro.png`, **formato de skin de jugador 64x64** (podéis usar cualquier skin de Minecraft).
- Todos los mobs del mod empiezan bloqueados hasta que su tele amarilla los desbloquea.

## 13. Cubo Blanco
- `/desinfo lanzar cubo_blanco`. Cubo lento que salta hacia ti. Si te toca: 3 s aturdido y 4 s de pantalla en blanco. No hace daño ni se divide.
- Textura: `textures/entity/cubo_blanco.png` (formato de slime 64x32).

## 14. Ale y Travensaño
- No aparecen solos: huevo en creativo o `/summon desinformados:ale`.
- Ale: 10 corazones, te persigue y pega (1,5 corazones). Al morir suelta 2 Travensaños: te persiguen, se te sientan en el cuello (medio corazón cada 3 s, controles y cámara invertidos) hasta que los matas o pasan 15 s.
- Skins en formato de jugador 64x64: `textures/entity/ale.png` y `textures/entity/travensano.png`.

## 15. Ulises
- Solo con huevo o `/summon desinformados:ulises`. 7 corazones.
- Si te ve, se queda mirándote 8 s y lanza un rayo rojo que te quita la mitad de tu vida actual. Si lo pierdes de vista, se reinicia; si le pegas, le cuesta más concentrarse.

## 16. Interferencia
- `/desinfo lanzar interferencia`. Solo en cuevas y oscuridad total. 4 corazones, rápida.
- Si te toca: screamer de 2 s (siempre; un corazón de alma solo evita perder los corazones) (imagen `textures/gui/susto.png`, sonido `sounds/susto.ogg`), pierdes 5 contenedores de corazón durante 60 s y desaparece.

## 17. Misiones (tecla L)
- Los jugadores pulsan **L** para ver sus tareas diarias y misiones secundarias.
- `/desinfo mision diaria <id>` · `/desinfo mision secundaria <id>` · `/desinfo mision quitar <id>` · `/desinfo mision limpiar` (nuevo día).
- Diarias: el grupo la supera cuando el 75% de los jugadores la completa.
- Misión de prueba: `full_hierro` (armadura de hierro completa). Las misiones se añaden en `Misiones.java`.

## 18. Tótems
- Los evocadores ya no sueltan tótems (solo esmeraldas). Los Gatos de la Desinformación solo salen de misiones o cofres que preparéis.

## 19. Días de la serie (todo manual)
- Día 1: `/desinfo mision limpiar` + `/desinfo mision diaria full_hierro` (recompensa: 1 tótem).
- Día 2: `/desinfo lanzar diamante` (tele verde: desbloquea picar diamante y sus crafteos) + `/desinfo mision limpiar` + `/desinfo mision diaria algo_diamante` (recompensa: 3 Corazones de Alma).
- Día 3: `/desinfo mision limpiar` + `/desinfo mision diaria full_diamante` (recompensa: 3 Corazones Rojos).
- Hasta `/desinfo lanzar diamante`, las herramientas/armas/armaduras de diamante no se pueden craftear.

## 20. Rumores y Banco de Rumores
- Monedas: Amarillo (1), Azul (5), Verde (10), Rojo (20), Gris (50).
- **Banco de Rumores** (bloque, en creativo): clic derecho → pantalla con tu saldo. "Depositar" mete todos tus Rumores como número; "Sacar" te da la moneda que elijas (Shift = 10). Así se cambian monedas.
- No se puede romper en supervivencia. El saldo se guarda en el mundo.

## 21. Tragamonedas
- Bloques (en creativo): Tragamonedas Azul (10), Morada (20) y Gris (50). Miden 2 de ancho x 3 de alto; necesitan 2 bloques libres encima.
- Clic derecho: cobra con los Rumores del inventario (devuelve el cambio), los rodillos giran 3 s en la barra de acción y sale el premio.
- Tablas de premios en `Tragamonedas.java` (peso = probabilidad). Incluyen premios malos (mobs, desafío sorpresa).

## 22. Angel Manipulador
- `/desinfo lanzar angel` (aparece en lugares oscuros) o huevo / `/summon desinformados:angel`. 10 corazones.
- Si te ve: cámara fija en él, sin poder moverte, pantalla azul y te arrastra hacia él. Ya cerca, 2 s para matarlo antes de que explote.

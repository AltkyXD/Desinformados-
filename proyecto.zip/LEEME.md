# Desinformados – Mod para Minecraft 1.21.1 (Fabric)

## 1. Preparar el proyecto (solo la primera vez)
1. Instala **Java 21 (JDK)** e **IntelliJ IDEA Community**.
2. Entra en https://fabricmc.net/develop/template y rellena:
   - Mod Name: `Desinformados` · Mod ID: `desinformados`
   - Package: `com.centrodesinformacion.desinformados`
   - Minecraft: `1.21.1` · marca **Split client and common sources**
3. Descarga y descomprime el proyecto.
4. **Borra su carpeta `src`** y pon en su lugar la carpeta `src` de este zip.
5. Ábrelo con IntelliJ y espera a que Gradle termine de cargar.

## 2. Probar y compilar
- Probar en el juego: `./gradlew runClient` (en Windows: `gradlew.bat runClient`)
- Generar el .jar: `./gradlew build` → `build/libs/desinformados-1.0.0.jar`

## 3. Instalar
- **Servidor:** Fabric server 1.21.1 + Fabric API + el .jar en `mods/`.
- **Los 5 jugadores:** Fabric 1.21.1 + Fabric API + el mismo .jar.

## 4. Comandos (solo operadores)
| Comando | Qué hace |
|---|---|
| `/desinfo evento <verde\|rojo\|amarillo> "Título" descripción...` | Lanza la tele a todos |
| `/desinfo fase <1-4>` | Desbloquea minerales (1 hierro, 2 oro/redstone/lapis, 3 diamante, 4 netherite) |
| `/desinfo spawn radio <bloques>` | Tamaño de la zona protegida del spawn (32 por defecto) |
| `/desinfo muertos` | Lista de jugadores fuera |
| `/desinfo revivir <jugador>` | Revivir gratis (para emergencias) |

Ejemplo: `/desinfo evento rojo "Momento Desinformado" Los creepers ahora explotan el doble`

## 5. Para los jugadores
- Click derecho con un **Periódico Desinformado** → lista de muertos, clic en el nombre para revivirlo.
- O escribe `/revivir <jugador>` (gasta 1 periódico).
- Si mueres quedas fuera del server hasta que alguien te reviva.
- En **creativo** sí se puede construir en el spawn (para montarlo).

## 6. Dónde poner tus archivos
- Textura del periódico: `assets/desinformados/textures/item/periodico.png` (16x16)
- Gato (tótem): `assets/minecraft/textures/item/totem_of_undying.png`
- Sonidos: pon tus `.ogg` en `assets/desinformados/sounds/` y en `sounds.json`
  cambia cada `{ "name": "minecraft:...", "type": "event" }` por `"desinformados:nombre_del_archivo"`.

## 7. Sistema de vida
- **Corazón Rojo:** click derecho = +1 corazón (máximo 30). Los extra **se pierden al morir**.
- **Corazón de Alma:** click derecho = +1 corazón azul (máximo 3), en su propia fila encima de la armadura.
  Cada uno **bloquea un golpe entero**: ni daño ni pérdida de contenedor (Creeper Oscuro incluido). No se regenera y se pierde al morir.
- Solo enemigos concretos quitarán contenedores rojos (se programan con `Vida.cambiarRojos(jugador, -1)`).
- Comandos (operadores):
  - `/desinfo vida <jugador> ver`
  - `/desinfo vida <jugador> rojos <cantidad>` (negativo para quitar)
  - `/desinfo vida <jugador> almas <cantidad>`

## 8. Eventos de la tele
- `/desinfo lanzar <id>` lanza la tele y su efecto. Sale una barra arriba con la cuenta atrás y el tiempo restante.
- `/desinfo detener` para todos los desafíos rojos en curso (sin castigos).
- Anuncios verdes libres: `/desinfo evento verde "Título" texto`

**Rojos (aviso → duración):**
creeper_sorpresa · lluvia_creepers · suelo_lava · gravedad_loca · noche_infernal · hambre_extrema ·
mobs_potenciados · prohibido_saltar · inventario_maldito · tormenta_rayos · apagon · todo_explota ·
todo_explota_suerte (1 de cada 3) · agua_toxica · mareo_total · mineria_explosiva · un_corazon ·
asedio · agachate · bloque_prohibido · no_te_muevas

**Rojos con objetivo (quien falle recibe el castigo):**
escalada · fondo_mundo · toca_madera · come_algo · a_la_cama · ponte_casco · cazarrecompensas ·
mojate · mira_cielo · mata_mob · sube_bloque

**Amarillos (permanentes):** arboles · creepers_oscuros
- `/desinfo cambios` lista los cambios activos · `/desinfo cambios quitar <id>` deshace uno.
- Los desafíos se programan en `desafio/Desafios.java` y los amarillos en `Eventos.java`.

## 9. Mobs bloqueados
Un mob bloqueado no puede existir en el mundo hasta que un evento lo desbloquee.
- `/desinfo mobs` · `/desinfo mobs bloquear <mod:mob>` · `/desinfo mobs desbloquear <mod:mob>`
- Para bloquear un mod entero: `/desinfo mobs bloquear nombredelmod:*`
- El **Creeper Oscuro** viene bloqueado. Si su explosión te alcanza pierdes un contenedor de corazón.
  Para probarlo: desbloquéalo y usa el Huevo de Creeper Oscuro.

## 10. Texturas incluidas
- Tótem → Gato de la Desinformación (la textura que mandaste).
- Icono del mod: la cara del gato.
- Creeper Oscuro: textura provisional en `textures/entity/creeper_oscuro.png` (formato 64x32 del creeper).

## 11. Vidas
- Cada jugador tiene **2 vidas**. Al perder la primera sale la tele de la calavera: "¡Estás a punto de ser Desinformado!".
- Al perder la última: todos ven la tele cayendo y partiéndose con su nombre. El eliminado queda 8 s en espectador
  donde murió (suelta sus cosas) y luego sale del server.
- Al revivirlo con un periódico vuelve en supervivencia al spawn con **1 vida**.
- `/desinfo vidas <jugador> <n>` cambia las vidas · `/desinfo vida <jugador> ver` muestra vidas y corazones.

## 12. Furros
- `/desinfo lanzar furros` los desbloquea. Si te ven te persiguen y te abrazan (máx. 10 s): Lentitud IV y medio corazón cada 2 s.
- Textura: `textures/entity/furro.png`, **formato de skin de jugador 64x64** (podéis usar cualquier skin de Minecraft).
- Todos los mobs del mod empiezan bloqueados hasta que su tele amarilla los desbloquea.

## 13. Cubo Blanco
- `/desinfo lanzar cubo_blanco`. Cubo lento que salta hacia ti. Si te toca: 3 s aturdido y 4 s de pantalla en blanco. No hace daño ni se divide.
- Textura: `textures/entity/cubo_blanco.png` (formato de slime 64x32).

## 14. Ale y Travensaño
- No aparecen solos: huevo en creativo o `/summon desinformados:ale`.
- Ale: 10 corazones, te persigue y pega (1,5 corazones). Al morir suelta 2 Travensaños: te persiguen, se te sientan en el cuello (medio corazón cada 3 s, controles y cámara invertidos) hasta que los matas o pasan 15 s.
- Skins en formato de jugador 64x64: `textures/entity/ale.png` y `textures/entity/travensano.png`.

## 15. Ulises
- Solo con huevo o `/summon desinformados:ulises`. 7 corazones.
- Si te ve, se queda mirándote 8 s y lanza un rayo rojo que te quita la mitad de tu vida actual. Si lo pierdes de vista, se reinicia; si le pegas, le cuesta más concentrarse.

## 16. Interferencia
- `/desinfo lanzar interferencia`. Solo en cuevas y oscuridad total. 4 corazones, rápida.
- Si te toca: screamer de 2 s (siempre; un corazón de alma solo evita perder los corazones) (imagen `textures/gui/susto.png`, sonido `sounds/susto.ogg`), pierdes 5 contenedores de corazón durante 60 s y desaparece.

## 17. Misiones (tecla L)
- Los jugadores pulsan **L** para ver sus tareas diarias y misiones secundarias.
- `/desinfo mision diaria <id>` · `/desinfo mision secundaria <id>` · `/desinfo mision quitar <id>` · `/desinfo mision limpiar` (nuevo día).
- Diarias: el grupo la supera cuando el 75% de los jugadores la completa.
- Misión de prueba: `full_hierro` (armadura de hierro completa). Las misiones se añaden en `Misiones.java`.

## 18. Tótems
- Los evocadores ya no sueltan tótems (solo esmeraldas). Los Gatos de la Desinformación solo salen de misiones o cofres que preparéis.

## 19. Días de la serie (todo manual)
- Día 1: `/desinfo mision limpiar` + `/desinfo mision diaria full_hierro` (recompensa: 1 tótem).
- Día 2: `/desinfo lanzar diamante` (tele verde: desbloquea picar diamante y sus crafteos) + `/desinfo mision limpiar` + `/desinfo mision diaria algo_diamante` (recompensa: 3 Corazones de Alma).
- Día 3: `/desinfo mision limpiar` + `/desinfo mision diaria full_diamante` (recompensa: 3 Corazones Rojos).
- Hasta `/desinfo lanzar diamante`, las herramientas/armas/armaduras de diamante no se pueden craftear.

## 20. Rumores y Banco de Rumores
- Monedas: Amarillo (1), Azul (5), Verde (10), Rojo (20), Gris (50).
- **Banco de Rumores** (bloque, en creativo): clic derecho → pantalla con tu saldo. "Depositar" mete todos tus Rumores como número; "Sacar" te da la moneda que elijas (Shift = 10). Así se cambian monedas.
- No se puede romper en supervivencia. El saldo se guarda en el mundo.

## 21. Tragamonedas
- Bloques (en creativo): Tragamonedas Azul (10), Morada (20) y Gris (50). Miden 2 de ancho x 3 de alto; necesitan 2 bloques libres encima.
- Clic derecho: cobra con los Rumores del inventario (devuelve el cambio), los rodillos giran 3 s en la barra de acción y sale el premio.
- Tablas de premios en `Tragamonedas.java` (peso = probabilidad). Incluyen premios malos (mobs, desafío sorpresa).

## 22. Angel Manipulador
- `/desinfo lanzar angel` (aparece en lugares oscuros) o huevo / `/summon desinformados:angel`. 10 corazones.
- Si te ve: cámara fija en él, sin poder moverte, pantalla azul y te arrastra hacia él. Ya cerca, 2 s para matarlo antes de que explote.

## 23. Activar en bloque (pruebas)
- `/desinfo activar mobs` · `/desinfo activar mutaciones` · `/desinfo activar mundo` (sin teles).
- `/desinfo desactivar todo`: quita todos los cambios y vuelve a bloquear los mobs del mod.


## 24. Dimensiones
### Interior de la Tele (jefe final)
- **Tele Gigante (portal)** 4x4 en creativo, en el spawn. `/desinfo portal tele romper` → vórtice; entrar en la pantalla te lleva dentro. `reparar` la arregla.
- Siempre se llega a un **cuartito** → **túnel largo** (a oscuras: mobs de estática, Interferencias, Cubos Blancos) → **arena circular** iluminada para el jefe final (aún sin jefe).
- Paredes irrompibles. Salir: Salida de la Tele en el cuartito. `/desinfo arena reconstruir` rehace la estructura.
### Libreta del Becario
- Bloque **Libreta del Becario**: una libreta plana sobre el escritorio. Receta: 3 papel arriba, diamante-libro-diamante en medio y saco de tinta abajo. Se puede romper (con la mano basta) y la recuperas, así podéis poner entradas/salidas donde queráis. La Tele Gigante NO tiene receta: solo la colocan los admins en creativo.
  - Empieza **cerrada**: no deja entrar. `/desinfo portal libreta abrir` abre todas las libretas (se ven abiertas, con sus hojas) y entonces clic → Libreta. `/desinfo portal libreta cerrar` las vuelve a cerrar.
  - Dentro, la libreta de al lado (siempre abierta) te devuelve. Siempre llegáis a tierra firme, no al mar.
- Sin niebla ni en la Libreta ni en el Interior de la Tele.
- Mundo normal de altura 0-256 (como 1.16.5), casi todo tierra (nivel del mar bajado a 48, sin océanos grandes) con pocitos de tinta repartidos, cuevas clásicas y algún cañón (las de abajo están secas, con algún charco de tinta). **Todo es papel de cuaderno a lápiz**: piedra, tierra, césped, arena, troncos, tablas, hojas y un fondo irrompible abajo. Los troncos de papel sirven como madera normal (tablas, mesa, palos) y la piedra de papel como piedra (herramientas y horno).
- **Solo hay 2 minerales**: **Garatita** (muy común: 16 vetas grandes por chunk, y 0-80; cada mena da 1; pico de hierro, ¡tráiganse uno!) y **Mineral de Estática** (rara, vetas pequeñas, sobre todo abajo; pico de piedra; cada mena da 1 fragmento). La Estática se ve como una mena de Garatita con glitch animado.
- El agua es **Tinta**: se nada igual, pero al tocarla los bordes de la pantalla se manchan de negro y tardan ~8 s en secarse. Se puede recoger con cubo.
- Cielo **gris** con un **sol garabateado sonriente**.
- Solo aparecen **mobs hostiles dibujados** (zombie, esqueleto, creeper, araña): más rápidos pero con menos vida. **No se queman de día y aparecen también de día** (las antorchas siguen evitando que aparezcan cerca); las arañas atacan siempre. No hay animales, así que no hay comida: lleven la suya.
- Pruebas: `/desinfo ir tele`, `/desinfo ir libreta`, `/desinfo ir volver`.

## 25. Reglas del mundo
- **Sin placa de mejora de netherite**: las mejoras se hacen en el **Conversor Difamónico**. Si alguien encuentra una placa de mejora en un bastión, desaparece del inventario (excepto en creativo).
- **Conversor Difamónico** (2x1, con dos ojos enormes; se coloca en creativo y es irrompible en supervivencia). Clic derecho con la pieza en la mano:
  - Pieza de **diamante** + 1 **lingote de netherite** (del inventario) → pieza de netherite.
  - Pieza de **netherite** + 4 **Garatitas** (del inventario) → pieza de **Garatita**.
  - Se conservan encantamientos, nombre y durabilidad. Con la mano vacía te dice qué necesita.
- **Equipo de Garatita** (moldes del diamante con textura de hoja de libreta; **el doble de durabilidad que el netherite**; no se quema en lava; se repara con Garatita). Base = netherite:
  - **Armadura**: +2 de armadura por pieza (5/10/8/5), dureza 3, empuje 10 %, y **+10 % de velocidad por pieza** (+40 % con el set completo).
  - **Espada**: 11 de daño (+3) y ataca más rápido (2.0 por segundo en vez de 1.6).
  - **Hacha**: 12 de daño (+2) y ataca más rápido (1.4 en vez de 1.0).
  - **Pico**: mina mucho más rápido (velocidad 14 en vez de 9).
  - **Pala** y **azada**: igual que las de netherite. Al mejorar la azada, el Conversor solo dice: *"¿En serio?"*
- **Estructuras eliminadas** (no se generan en mundos/chunks nuevos): cámaras de desafío (trial chambers), mansiones del bosque, monumentos oceánicos, templos del desierto y templos de la jungla.

## 26. Orden de la tele
1. La tele aparece y muestra **estática** (~4 s).
2. Flash y la pantalla se pone del **color** del evento (~3 s).
3. **Verde/amarillo**: la tele se encoge y desaparece → llega el **mensaje al chat** y se aplica el evento.
   **Rojo**: la pantalla se agrieta y la tele **estalla en pedazos** → entonces llega el **mensaje** y **empieza el desafío** (con su aviso de 10 s).
Todo dura ~8,6 s. `/desinfo detener` también cancela un desafío anunciado cuya tele aún no se rompió.

## 27. Libreta: mobs y cambios de dificultad
- Aparecen en **grupos**: zombies (4-8), esqueletos (3-6), arañas (2-5), creepers (2-4) y **Garabatos** (3-6, libres en la Libreta sin desbloquearlos).
- Cambio de dificultad propio: `/desinfo lanzar libreta_mejorada` (amarillo). **Solo se puede lanzar con la libreta abierta** (`/desinfo portal libreta abrir`); si está cerrada da error y `/desinfo activar` se lo salta.
  Comunicado: *"Los garabatos se sintieron celosos de que solo hayamos mejorado a los de la superficie, así que les hemos agregado cosas."*
  - Zombies dibujados: Debilidad 4 s al golpearte.
  - Esqueletos dibujados: sus flechas dan Lentitud II 3 s.
  - Creepers dibujados: su explosión ciega 3 s y mancha la pantalla de tinta.
  - Arañas dibujadas: te dejan 4 s en una telaraña.
  - Garabatos: al matarlos en la Libreta, 50 % de que reaparezcan (una vez).

## 28. Centro de Estática y Desinformación Pura
- **Bloque de Garatita**: 9 Garatitas (y se puede volver a deshacer en 9). Pico de hierro.
- **Centro de Estática**: 9 Fragmentos de Estática (3x3). Textura animada: círculo que se deforma en cubo y pentágono, glitcheando.
- **Desinformación Pura** (orbe con un cristal de estática arriba y líneas blancas girando):
  ```
  N F N      N = lingote de netherite   F = Fragmento de Estática
  D C D      D = bloque de diamante     C = Centro de Estática
  N G N      G = Bloque de Garatita
  ```
  Al usarlo (clic derecho al aire o sobre un bloque) sale flotando donde lo usaste, gira cargándose de estática 5 s y **estalla**, rompiendo la Tele Gigante (como `/desinfo portal tele romper`, con su tele roja). Si no hay ninguna Tele Gigante colocada, no se gasta.

## 29. Tele morada (cosas importantes)
- Nuevo color **morado** = anuncio importante (chat en morado claro con la etiqueta [IMPORTANTE]). También vale para `/desinfo evento morado "Título" descripción`.
- Usan la tele morada:
  - **La tele se ha roto** (`/desinfo portal tele romper` o al usar la Desinformación Pura).
  - **La Libreta abierta** (`/desinfo portal libreta abrir`): las libretas se abren cuando termina la tele.
  - **`/desinfo lanzar nether`** y **`/desinfo lanzar end`**.
- **El Nether y el End empiezan cerrados**: los portales no funcionan ("todavía no ha sido autorizado por el Centro de Desinformación") hasta lanzar su evento morado.

## 30. Recetas bloqueadas (teles verdes)
Bloqueadas hasta su desbloqueo (la mesa de crafteo no da el resultado y **no salen en el librito de recetas**):
| Receta | Se desbloquea con |
|---|---|
| Equipo de diamante (herramientas, armas, armadura) | `/desinfo lanzar diamante` (el mineral de diamante se puede picar siempre) |
| Libreta del Becario | al abrir la dimensión: `/desinfo portal libreta abrir` |
| Bloque de Garatita | `/desinfo lanzar receta_bloque_garatita` |
| Centro de Estática | `/desinfo lanzar receta_centro_estatica` |
| Desinformación Pura | `/desinfo lanzar receta_desinformacion_pura` |

**Herramientas necesarias:** Mena de Garatita → pico de diamante o mejor. Mineral de Estática → pico de netherite o mejor (o de Garatita). Bloque de Garatita → pico de hierro o mejor.

## 31. Gatos Cubo (NPC) y tiendas
Cubos estilo "Floppa": la cara del gato del canal delante (lo negro del fondo se convierte en pelaje), pelo por todos lados y dos orejas altas arriba. Inmortales (un admin en creativo los quita de un golpe) y maúllan al hablar.
**El becario es anónimo: nunca aparece** (los demás hablan de él como si lo vieran todos los días).
**Hablar con ellos**: los que no venden tienen una conversación de **3 frases seguidas** (cada clic, la siguiente). Después te sueltan cosas como *"¿No tienes algo mejor que hacer?"* (más una frase propia de cada uno). Lo que dicen sale en un **cuadro encima de la barra de objetos** (se va escribiendo letra a letra) mientras suena su voz. Solo hablan cuando les das clic derecho, con **7 segundos de espera** entre frase y frase. Cuando te acercas (5 bloques) les sale una **burbuja con "..."** sobre la cabeza; desaparece mientras están en espera.
**Solo caminan sobre madera** (tablones, troncos, losas y escaleras de madera) **o lana/alfombras** de cualquier color: así controláis por dónde andan. Si acaban fuera, vuelven al bloque de madera/lana más cercano.
Cada uno tiene su **huevo** (pestaña de Herramientas) o `/desinfo npc <tipo>` (vendedores: `/desinfo vendedor <tipo>`). **17 Gatos Cubo:**
| Gato Cubo | tipo | Aspecto | Se mueve |
|---|---|---|---|
| **El Gato** (el principal: dirige el Centro; la tele es la que causa las desinformaciones, él solo puede mandar señales verdes) | `principal` | sin nada, tal cual | paseo corto |
| Recepcionista Cubo | `recepcionista` | diadema con micrófono, camisa, lazo rojo, credencial | línea recta |
| Periodista Cubo | `periodista` | sombrero con PRENSA, lápiz, corbata floja, libreta | círculo |
| Conserje Cubo | `conserje` | gorra con logo, peto vaquero, escoba | zigzag |
| Gata Kawaii | `anime` | lazo rosa gigante, coloretes, brillitos en los ojos, cuello de marinera | círculo |
| Gato Nerd | `nerd` | gafas gordas con celo, pajarita, protector de bolsillo con bolis | va y viene corto |
| GATO-BOT 3000 | `robot` | chapa con remaches, antena con luz, tornillos, panel con lucecitas | cuadrado perfecto |
| Gato Granjero | `granjero` | sombrero de paja, espiga en la boca, pañuelo de lunares | zigzag grande ("arando") |
| Gato Gato | `gato` | collar con cascabel (solo dice "miau") | paseo libre |
| Gato Romántico | `romantico` | boina, rosa en la boca, corazón flotando | círculo pequeño |
| Gato Millonario | `millonario` | monóculo, collar de oro con "$", fajos de billetes falsos | cuadrado pequeño |
| Gato Elegante | `elegante` | sombrero de copa, pajarita, pañuelo, bastón | línea |
| Chef Michelin | `chef` | gorro de chef, bigote rizado, pañuelo, cucharón | va y viene corto |
| Detective Bigotes | `detective` | gorro de cazador a cuadros, pipa, lupa | paseo "investigando" |
| Mago de las Pasivas | vendedor `pasivas` | sombrero de mago, barba, capa | quieto |
| Enfermero de Corazones | vendedor `corazones` | cofia, bata, estetoscopio | quieto (cura) |
| Minero Cubo | vendedor `minerales` | casco con linterna, peto reflectante, pico | quieto |
- `/desinfo tienda <pasivas|corazones|minerales>` además construye el puesto con toldo. Los huevos de vendedor lo dejan mirando hacia ti.
- **Tiendas**: pasivas *próximamente* · corazones: Manzana de oro 70 · Corazón rojo 180 · Corazón azul 300 · Tótem 450 · minerales: 32 redstone 40 · 32 lapislázuli 45 · 16 hierro 60 · 16 oro 90 · 4 esmeraldas 80 · 1 diamante 120 · 4 Garatitas 200 · 1 Fragmento de Estática 500 · 1 lingote de netherite 900.
- Se paga en **Rumores**: primero del saldo del Banco y, si no llega, con las monedas del inventario (el cambio vuelve al Banco).

## 32. Mutaciones del Nether y del enderman (amarillos)
| Comando | Efecto |
|---|---|
| `/desinfo lanzar ghasts_triples` | Los ghasts disparan 3 bolas de fuego en abanico. |
| `/desinfo lanzar blazes_dobles` | Cada bola de fuego de blaze sale con una gemela. |
| `/desinfo lanzar piglins_ladrones` | Si un piglin te golpea, te roba hasta 3 objetos de oro. |
| `/desinfo lanzar hoglins_gimnasio` | Hoglins con +50 % de vida y embestidas mucho más fuertes. |
| `/desinfo lanzar magma_ardiente` | El golpe de un cubo de magma te prende fuego 5 s. |
| `/desinfo lanzar wither_veneno` | Esqueletos wither +25 % rápidos y su golpe da Wither II 8 s. |
| `/desinfo lanzar zombificados_rencorosos` | Los piglins zombificados te atacan si estás a menos de 10 bloques. |
| `/desinfo lanzar enderman_teletransporte` | Si un enderman te golpea, te teletransporta a un sitio cercano al azar. |
Todos están en `/desinfo activar mutaciones`.

## 33. Mobs del Nether
La **primera vez que alguien entra al Nether** sale la tele amarilla *"¡El Nether tiene nuevos vecinos!"* (*"...el Nether se veía muy sin vida. Hemos enviado a unos cuantos voluntarios. No eran voluntarios."*).
En el Nether aparecen sin necesidad de desbloquearlos:
- **Zombie Naranja**, **Furros** y **Travensaños** (los de siempre).
- **Creeper de Fuego** (nuevo): naranja con brasas y ojos de lava; al explotar te prende fuego 8 s y deja llamas alrededor. Le afecta "creepers electrificados" (más radio de fuego).
- **Cubo Rojo** (nuevo): cubo sólido que se desliza (no rebota), como el Cubo Blanco (pantalla blanca + Lentitud) y además te quema 5 s.
- **Esqueleto Ráfaga** (nuevo, verde): dispara 5 flechas seguidas y recarga 5 s.
Los tres nuevos son inmunes al fuego y solo aparecen en el Nether (tienen huevo en la pestaña de Herramientas).

## 34. Bienvenida: el cuarto de la tele y la cinemática

- La primera vez que un jugador entra al server aparece en un cuartito oscuro (dimensión `desinformados:cuarto_intro`, uno por jugador) en modo aventura: no puede romper ni poner nada y no recibe daño.
- Solo puede darle clic derecho a la tele vieja. Eso lanza la cinemática (hecha dentro del mod, no hacen falta mods extra): estática en toda la pantalla, la foto de El Gato en medio con señal débil avisando que el mundo está en peligro (Reactor dañado, apareció una tele que genera desinformaciones, la está investigando, no puede mantener la señal, necesita ayuda), la señal se cae en estática total, apareces en el Centro y ~2 s después sale el título DESINFORMADOS.
- No se puede saltar ni cerrar con ESC. Al terminar, el jugador aparece en el Centro de Desinformación (y su punto de reaparición queda ahí).
- Comandos:
  - `/desinfo intro centro`: dónde aparecen al terminar (tu posición y hacia dónde miras). Si no lo pones, aparecen en el spawn del mundo.
  - `/primeravez [jugador]`: te regresa (o a ese jugador) al cuarto de la tele como si fuera la primera vez, para probar la tele y la cinemática.
  - `/desinfo intro ver`: lo mismo que `/primeravez`.
  - `/desinfo intro reiniciar <jugador>`: manda a ese jugador de vuelta al cuarto.
  - `/desinfo intro activar | desactivar`.
- El guion está en `IntroScreen.java` (arreglo `GUION`).

## 35. Brandon y Kevin

- **Brandon** (8 corazones, muy rápido): aparece solo de noche/en la oscuridad en el Overworld después de su tele amarilla (`brandon_kevin`). Te ataca primero desde lejos: mantiene la distancia (entre 7 y 15 bloques), carga un rayo azul con los brazos hacia delante (~0,7 s) y dispara a donde estabas al empezar a cargar, así que se puede esquivar moviéndose. El rayo hace 2 corazones y te paraliza medio segundo.
- **Kevin** (20 corazones, pega como un zombie normal): llega la primera vez que alguien le pega a Brandon (solo una vez). Siempre se pone delante de Brandon, entre él y el jugador, y te pega si te acercas. Mientras esté a menos de 4 bloques de Brandon, los golpes que le des a Brandon se los come Kevin. Los rayos no le hacen nada. Si Brandon muere, Kevin sigue peleando como un zombie.
- Huevos: Huevo de Brandon y Huevo de Kevin. Como todos los mobs del mod, Brandon está bloqueado hasta que salga su tele (`/desinfo lanzar brandon_kevin`).
- **Mejora `brandon_mejorado`** (tele amarilla, grupo de mutaciones): Brandon cura a Kevin con un rayo (2 corazones cada 3 s si está a menos de 12 bloques y herido), dispara el doble de rápido (y carga el rayo un poco más rápido) y Kevin tiene el doble de vida (40 corazones). Excusa: "Brandon vio un tutorial de 'cómo ser el support de tu equipo'..."

## 36. Altky

- Skin propia. Aparece solo en la oscuridad del Overworld después de su tele amarilla (`/desinfo lanzar altky`).
- Cuando te ve, se queda a distancia (6-14 bloques), saca su pluma y se pone a dibujar (2,5 s, con partículas de tinta). Al terminar, de su hoja sale un mob dibujado mal hecho que va a por ti:
  - 50 %: **Furro Dibujado** (abraza como un Furro; 5 corazones, más rápido, no se quema).
  - 50 %: un mob de la Libreta al azar (zombie, esqueleto, creeper o araña dibujados, o un Garabato).
- 10 segundos de espera entre dibujo y dibujo, y como mucho 6 dibujos vivos a la vez.
- **Mutación `altky_tableta`**: se compra una tableta de dibujo (la lleva en la mano) y en vez de mobs de papel saca mobs normales: zombie, esqueleto, creeper, araña, Zombie Naranja, Cubo Blanco, Creeper Oscuro, Travensaño, Creeper de Fuego, Cubo Rojo, Esqueleto Ráfaga o Garabato. Los Furros (normales) siguen siendo el 50 %.

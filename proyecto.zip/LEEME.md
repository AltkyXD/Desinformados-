# Desinformados – Mod para Minecraft 1.21.1 (Fabric)

## 1. Preparar el proyecto (solo la primera vez)
1. Instala **Java 21 (JDK)** e **IntelliJ IDEA Community**.
2. Entra en https://fabricmc.net/develop/template y rellena:
   - Mod Name: `Desinformados` · Mod ID: `desinformados`
   - Package: `com.centrodesinformacion.desinformados`
   - Minecraft: `1.21.1` · marca **Split client and common sources**
3. Descarga y descomprime el proyecto.
4. **Borra su carpeta `src`** y pon en su lugar la carpeta `src` de este zip.
5. Ábrelo con IntelliJ y espera a que Gradle termine de cargar.

## 2. Probar y compilar
- Probar en el juego: `./gradlew runClient` (en Windows: `gradlew.bat runClient`)
- Generar el .jar: `./gradlew build` → `build/libs/desinformados-1.0.0.jar`

## 3. Instalar
- **Servidor:** Fabric server 1.21.1 + Fabric API + el .jar en `mods/`.
- **Los 5 jugadores:** Fabric 1.21.1 + Fabric API + el mismo .jar.

## 4. Comandos (solo operadores)
| Comando | Qué hace |
|---|---|
| `/desinfo evento <verde\|rojo\|amarillo> "Título" descripción...` | Lanza la tele a todos |
| `/desinfo fase <1-4>` | Desbloquea minerales (1 hierro, 2 oro/redstone/lapis, 3 diamante, 4 netherite) |
| `/desinfo spawn radio <bloques>` | Tamaño de la zona protegida del spawn (32 por defecto) |
| `/desinfo muertos` | Lista de jugadores fuera |
| `/desinfo revivir <jugador>` | Revivir gratis (para emergencias) |

Ejemplo: `/desinfo evento rojo "Momento Desinformado" Los creepers ahora explotan el doble`

## 5. Para los jugadores
- Click derecho con un **Periódico Desinformado** → lista de muertos, clic en el nombre para revivirlo.
- O escribe `/revivir <jugador>` (gasta 1 periódico).
- Si mueres quedas fuera del server hasta que alguien te reviva.
- En **creativo** sí se puede construir en el spawn (para montarlo).

## 6. Dónde poner tus archivos
- Textura del periódico: `assets/desinformados/textures/item/periodico.png` (16x16)
- Gato (tótem): `assets/minecraft/textures/item/totem_of_undying.png`
- Sonidos: pon tus `.ogg` en `assets/desinformados/sounds/` y en `sounds.json`
  cambia cada `{ "name": "minecraft:...", "type": "event" }` por `"desinformados:nombre_del_archivo"`.
